#!/usr/bin/env python3
"""src/ parçalarını tek dosyalık dist/index.html içinde birleştirir.
Kullanım:  python3 build.py
Sıra: 00_head.html + style.css + 01_body.html + <script> + js/*.js (ada göre sıralı) + </script></body></html>
Not: js/ içindeki dosyalar TEK bir IIFE'nin parçalarıdır (başı 00_*.js, sonu zz_footer.js).
Bu yüzden dosyalar tek başına çalışmaz; yalnızca sırayla birleşince geçerlidir."""
import glob, os, subprocess, sys
R = os.path.dirname(os.path.abspath(__file__))
def rd(p): return open(os.path.join(R, p), encoding='utf-8').read()
js = ''.join(rd(os.path.relpath(p, R)) for p in sorted(glob.glob(os.path.join(R, 'src/js/*.js'))))
out = rd('src/00_head.html') + rd('src/style.css') + rd('src/01_body.html') + js + '</script>\n</body>\n</html>\n'
os.makedirs(os.path.join(R, 'dist'), exist_ok=True)
open(os.path.join(R, 'dist/index.html'), 'w', encoding='utf-8').write(out)
print('dist/index.html yazıldı: %.0f KB' % (len(out.encode('utf-8')) / 1024))
open('/tmp/_chk.js', 'w', encoding='utf-8').write(js)
try:
    r = subprocess.run(['node', '--check', '/tmp/_chk.js'], capture_output=True, text=True)
    print('JS sözdizimi: OK' if r.returncode == 0 else 'JS HATASI:\n' + r.stderr[:800])
    sys.exit(r.returncode)
except FileNotFoundError:
    print('(node yok, sözdizimi kontrolü atlandı)')
