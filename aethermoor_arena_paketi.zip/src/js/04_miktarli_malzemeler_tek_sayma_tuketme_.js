/* ===== MİKTARLI MALZEMELER · TEK SAYMA / TÜKETME / TAŞIMA KURALI ===== */
const BAG_CAPACITY=20;
const MATERIALS={
  wood:{n:'Odun',icon:'🪵',val:8,desc:'İnşaat ve tamirde kullanılır.'},
  stone:{n:'Taş',icon:'🪨',val:6,desc:'İnşaat ve zanaatta kullanılır.'},
  copper_ore:{n:'Bakır Cevheri',icon:'🥉',val:15},
  iron_ore:{n:'Demir Cevheri',icon:'⛓️',val:18},
  gold_ore:{n:'Altın Cevheri',icon:'🪙',val:35},
  coal:{n:'Maden Kömürü',icon:'⚫',val:10},
  ruby:{n:'Kırmızı Yakut',icon:'🔴',val:65},
  diamond:{n:'Saf Elmas',icon:'💎',val:100},
  iridium_ore:{n:'İridyum Cevheri',icon:'🔮',val:120}
};
const ITEMS=window.ITEMS=(()=>{
  const MAX_STACK=99;
  const aliases={ore_copper:'copper_ore',ore_iron:'iron_ore',ore_gold:'gold_ore',ore_coal:'coal',ore_ruby:'ruby',ore_diamond:'diamond',ore_iridium:'iridium_ore'};
  const key=k=>Object.prototype.hasOwnProperty.call(aliases,k)?aliases[k]:k;
  // Ekipman, yemek, kalite yıldızlı hasat, yün ve tekil anahtarlar bu turda yığınlanmaz.
  const stackable=it=>!!it&&['mat','material','ore',undefined].includes(it.s)&&Object.prototype.hasOwnProperty.call(MATERIALS,key(it.k));
  const qty=it=>{
    if(!it)return 0;
    if(!stackable(it)||it.qty===undefined)return 1;
    const n=Number(it.qty);
    return Number.isSafeInteger(n)&&n>=0?n:1;
  };
  const prepare=it=>stackable(it)?{...MATERIALS[key(it.k)],...it,s:'mat',k:key(it.k),qty:qty(it)}:it;
  const clone=list=>list.map(it=>stackable(it)?prepare(it):it);
  const replace=(list,next)=>{list.length=0;for(const it of next)list.push(it)};
  const signature=it=>{
    if(!stackable(it))return null;
    const data={...prepare(it),r:it.r||0,star:it.star||0,up:it.up||0};
    for(const k of ['qty','n','icon','desc','locked'])delete data[k];
    // Değer, kalite, köken ve diğer özellikleri farklı iki malzemeyi birleştirme.
    return JSON.stringify(Object.keys(data).sort().map(k=>[k,data[k]]));
  };
  const matches=(it,k)=>typeof k==='function'?k(it):k==='fish'?it.s==='fish':key(it.k)===key(k);
  const count=(list,k)=>list.reduce((n,it)=>n+(k===undefined||matches(it,k)?qty(it):0),0);
  const room=(list,it,capacity)=>{
    if(!it)return 0;
    let n=Math.max(0,capacity-list.length)*(stackable(it)?MAX_STACK:1);
    if(stackable(it)){
      const sig=signature(it);
      for(const other of list)if(signature(other)===sig)n+=Math.max(0,MAX_STACK-qty(other));
    }
    return n;
  };
  function addRaw(list,item,capacity){
    if(!item||typeof item!=='object'||Array.isArray(item))return false;
    const it=prepare(item);let remaining=qty(it);
    if(remaining<=0)return true;
    if(room(list,it,capacity)<remaining)return false;
    if(!stackable(it)){list.push(it);return true}
    const sig=signature(it);
    for(let i=0;i<list.length&&remaining>0;i++){
      if(signature(list[i])!==sig)continue;
      const n=Math.min(remaining,Math.max(0,MAX_STACK-qty(list[i])));
      if(n){list[i]={...prepare(list[i]),qty:qty(list[i])+n};remaining-=n}
    }
    while(remaining>0){const n=Math.min(MAX_STACK,remaining);list.push({...it,qty:n});remaining-=n}
    return true;
  }
  function normalize(list){
    const result=[],open=new Map();if(!Array.isArray(list))return result;
    for(const raw of list){
      if(!raw||typeof raw!=='object'||Array.isArray(raw))continue;
      const it=prepare(raw);if(!stackable(it)){result.push(it);continue}
      let left=qty(it);if(left<=0)continue;const sig=signature(it),index=open.get(sig);
      if(index!==undefined){const n=Math.min(left,MAX_STACK-result[index].qty);result[index].qty+=n;left-=n;if(result[index].qty===MAX_STACK)open.delete(sig)}
      while(left>0){const n=Math.min(MAX_STACK,left);result.push({...it,qty:n});if(n<MAX_STACK)open.set(sig,result.length-1);left-=n}
    }
    // Eski kayıt kesilmez; birleştirme doğrusal çalışır, dolu yığınlar tekrar tekrar taranmaz.
    return result;
  }
  function addMany(list,items,capacity=BAG_CAPACITY){
    const next=clone(list);
    for(const it of items)if(!it||!addRaw(next,it,capacity))return false;
    replace(list,next);return true;
  }
  const add=(list,it,capacity=BAG_CAPACITY)=>addMany(list,[it],capacity);
  const canAdd=(list,items,capacity=BAG_CAPACITY)=>addMany(clone(list),items,capacity);
  function removeAt(list,index,n=1){
    const it=list[index];
    if(!it||!Number.isSafeInteger(n)||n<=0||n>qty(it))return false;
    if(n===qty(it))list.splice(index,1);
    else list[index]={...prepare(it),qty:qty(it)-n};
    return true;
  }
  function take(list,k,n){
    if(!Number.isSafeInteger(n)||n<0||count(list,k)<n)return false;
    let remaining=n;
    for(let i=0;i<list.length&&remaining>0;){
      if(!matches(list[i],k)){i++;continue}
      const used=Math.min(remaining,qty(list[i]));
      if(!used){i++;continue}
      const all=used===qty(list[i]);removeAt(list,i,used);remaining-=used;
      if(!all)i++;
    }
    return true;
  }
  function transfer(from,to,index,n,capacity){
    if(from===to||!Number.isSafeInteger(index)||index<0)return false;
    const it=from[index];
    if(!it||!Number.isSafeInteger(n)||n<=0||n>qty(it))return false;
    const source=clone(from),target=clone(to),part=stackable(it)?{...prepare(it),qty:n}:it;
    if(!add(target,part,capacity)||!removeAt(source,index,n))return false;
    replace(from,source);replace(to,target);return true;
  }
  function exchange(containers,needs,outputs=[],capacity=BAG_CAPACITY){
    const drafts=containers.map(clone);
    for(const [k,n]of Object.entries(needs)){
      if(!Number.isSafeInteger(n)||n<0)return {ok:false,reason:'amount'};
      if(drafts.reduce((sum,list)=>sum+count(list,k),0)<n)return {ok:false,reason:'materials',key:k};
      let remaining=n;
      for(const list of drafts){const used=Math.min(remaining,count(list,k));take(list,k,used);remaining-=used}
    }
    // Önce bütün girdiler ve çıktı kapasitesi denenir; ancak tamamı uygunsa değişiklik yapılır.
    if(!addMany(drafts[0],outputs,capacity))return {ok:false,reason:'space'};
    containers.forEach((list,i)=>replace(list,drafts[i]));
    return {ok:true};
  }
  const make=(k,n=1)=>{k=key(k);return Object.prototype.hasOwnProperty.call(MATERIALS,k)?{...MATERIALS[k],s:'mat',k,qty:n}:null};
  return {MAX_STACK,key,stackable,qty,count,room,normalize,add,addMany,canAdd,removeAt,take,transfer,exchange,make};
})();
function countInv(k){return ITEMS.count(P.inv,k)}
function inventoryRecipe(needs={},outputs=[],options={}){
  const {gold=0,gems=0,camp=false}=options;
  if(!Number.isSafeInteger(gold)||gold<0||!Number.isSafeInteger(gems)||gems<0)return {ok:false,reason:'amount'};
  if(P.gold<gold||P.gems<gems)return {ok:false,reason:'currency'};
  const boxes=[P.inv];
  if(camp&&P.fieldCampLevel>=2)boxes.push(P.fieldCampStorage);
  const result=ITEMS.exchange(boxes,needs,outputs);
  if(result.ok){P.gold-=gold;P.gems-=gems}
  return result;
}
function inventoryWarning(text){
  fl(P.x,P.y-26,text,'#fca5a5',true);
  const cards=[...document.querySelectorAll('.ov:not(.h) .card')],card=cards[cards.length-1];
  if(!card)return;
  let status=card.querySelector('[data-inventory-feedback]');
  if(!status){status=document.createElement('p');status.className='inventory-status';status.dataset.inventoryFeedback='1';status.setAttribute('role','status');card.querySelector('.top')?.after(status)}
  status.textContent=text;
}
function tryInventoryRecipe(needs={},outputs=[],options={}){
  const result=inventoryRecipe(needs,outputs,options);
  if(!result.ok)inventoryWarning(result.reason==='space'?'Çantada ürünün tamamına yer yok; malzemelerin korundu.':result.reason==='currency'?'Altın veya elmas yetersiz.':'Gerekli malzeme eksik.');
  else document.querySelectorAll('[data-inventory-feedback]').forEach(el=>el.textContent='');
  return result.ok;
}
function normalizeInventories(){
  for(const field of ['inv','storage','fieldCampStorage','shippingBin','pendingRewards'])P[field]=ITEMS.normalize(P[field]);
  if(Array.isArray(P.orders))for(const order of P.orders)order.reqK=ITEMS.key(order.reqK);
  P.inventoryVersion=1;
}
function awardInventoryItem(item){
  if(!ITEMS.add(P.inv,item)){
    // Tekrar alınamayan görev/boss ödülü ne silinir ne de 20 göz sınırını deler.
    if(!Array.isArray(P.pendingRewards))P.pendingRewards=[];
    P.pendingRewards.push(item);
    fl(P.x,P.y-42,'🎒 Ödül bekliyor · çantada yer açıp Teslim Al.','#a5f3fc',true);
  }
}
function oreMaterial(res){
  return res.k==='ore_crystal'?null:ITEMS.make(ITEMS.key(res.k))||ITEMS.make('stone');
}
// Kazma, yakın dövüş ve mermi aynı teslim kuralını kullanır: yer yoksa kaynak kalır.
function strikeOre(res,damage,charged=false){
  if(res.mined)return false;
  const material=oreMaterial(res);
  if(material&&!ITEMS.canAdd(P.inv,[material])){fl(P.x,P.y-23,'Çanta dolu; bu malzeme için yığında veya yeni bir gözde yer aç.','#facc15');return false}
  if(res.hp<=damage&&material&&!ITEMS.add(P.inv,material))return false;
  res.hp-=damage;
  spark(res.x,res.y-6,charged?20:10,res.col,charged?60:40);
  sfx(540+(res.maxHp-res.hp)*50,.08,'triangle',.05);
  fl(res.x,res.y-16,charged?'⛏️ AĞIR DARBE!':'⛏️ -'+damage+' Darbe',charged?'#ffd23f':'#cbd5e1',charged);
  if(charged)shk=Math.max(shk,4.5);
  if(res.hp<=0){
    markResourceMined(res,90);
    const baseGold=Array.isArray(res.gold)?ri(res.gold[0],res.gold[1]):(res.gold||0);
    const gold=Math.round(baseGold*(charged?1.5:1)),gems=res.gems||(res.k==='ore_crystal'?2:0);
    P.gold+=gold;P.gems+=gems;
    spark(res.x,res.y-6,22,res.col,80);
    fl(res.x,res.y-28,`${material?'+1 '+material.icon+' '+material.n+' · ':''}+${gold}🪙${gems?' +'+gems+'💎':''}`,'#ffd23f',true);
    playChord([523,659,784],.25,'triangle',.05);
    addMasteryXp('mine',18);DAILY_FOCUS.event('explore',1);WORLD_EVENTS.progress('mine',1);EXPEDITIONS.event('mine',res.k,1);revealMineLadder(res);
    if(res.isSecret)CAVE.reveal(WORLD_DATA.mine);
  }
  if(curMap==='world'||curMap==='frontier'||res.hp<=0)sv();
  return true;
}
function strikeFarmDebris(o){
  const wood=o.k==='stump',item=ITEMS.make(wood?'wood':'stone',2);
  if(!ITEMS.canAdd(P.inv,[item])){fl(P.x,P.y-23,'Çanta dolu; 2 malzeme için yer aç.','#facc15');return false}
  if(o.hp<=1&&!ITEMS.add(P.inv,item))return false;
  o.hp--;
  spark(o.x,o.y-4,8,wood?'#a16207':'#94a3b8',40);
  sfx(wood?480:600,.08,wood?'sawtooth':'triangle',.05);
  fl(o.x,o.y-12,wood?'🪓 Tak!':'⛏️ Tak!',wood?'#d97706':'#cbd5e1');
  if(o.hp<=0){
    if(o.homeId&&P.adventure&&!P.adventure.home.cleared.includes(o.homeId))P.adventure.home.cleared.push(o.homeId);
    const index=objs.indexOf(o);if(index>=0)objs.splice(index,1);
    spark(o.x,o.y-4,18,wood?'#ca8a04':'#94a3b8',60);
    playChord([523,659,784],.2,'triangle',.04);
    fl(o.x,o.y-24,`+2 ${item.icon} ${item.n} Toplandı!`,wood?'#ffd23f':'#cbd5e1',true);
    addMasteryXp(wood?'farm':'mine',12);sv();
  }
  return true;
}
function unitSaleValue(it,fallback=10){if(SL[it.s])fallback=Math.round(8*(RAR[it.r]||RAR[0])[2]*(P.lvl+1));return ECONOMY.quote(it,fallback)}
function isFarmSaleItem(it){return ['crop','food_ing','fish'].includes(it.s)||['wool','honey','royal_honey','flour','apple','peach','cherry','lemon','pomegranate','golden_apple','jam','pickles','malt','wine','nectar'].includes(it.k)}
// Depo ekranında onlarca boş kutuyu kaydırma; dolu gözler + bir boş sıra yeterli.
function containerSlots(items,capacity){
  return Math.max(items.length,Math.min(capacity,Math.max(5,Math.ceil((items.length+1)/5)*5)));
}
function transferAmount(it,selectId){
  const value=$(selectId)?.value||'all';
  return value==='all'?ITEMS.qty(it):Math.min(ITEMS.qty(it),Number(value)||1);
}
function inventoryNotice(owner,text,dt=0){
  owner.fullNotice=(owner.fullNotice||0)-dt;
  if(owner.fullNotice<=0){fl(P.x,P.y-23,text,'#facc15');owner.fullNotice=2}
}
