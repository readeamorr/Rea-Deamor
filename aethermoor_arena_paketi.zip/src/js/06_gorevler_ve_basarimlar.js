/* ===== GÖREVLER VE BAŞARIMLAR ===== */
const QS=[
  {icon:'🟢',ch:'YUVADAN İLK ADIM',t:'6 Slime avla',k:'slime',n:6,xp:70,g:35,m:5,z:1,story:'Güneyden inen kül, orman yolundaki slime’ları çoğaltmış. Gölgeköy’ün nefesi bu yoldan geçiyor.',why:'Yolu açmadan kasaba ne pazara ne ormana güvenle çıkabiliyor. Bu ilk av hem seni hem kasabayı sınar.',tip:'Orman girişinde kal. Turuncu alan dolmadan sıyrıl; düşman açık verince karşılık ver. Kuru dallardan odun, taşlardan taş topla — dönüşte sandık için lazım.'},
  {icon:'🎣',ch:'YUVADAN İLK ADIM',t:'3 balık tut',k:'fish',n:3,xp:100,g:60,m:6,z:2,story:'Pazar korkudan seyrelince Melis’in ocağı aç kaldı. Sığ Göl hâlâ taze balık veriyor.',why:'Balık; yemek, satış ve Melis’in sofrası için güvenli bir kaynak. Ormandan sonra kasaba göle ihtiyaç duyuyor.',tip:'Balıkçı İskelesi’ne git, oltayı seç ve su kenarında Balık Tut düğmesini kullan.'},
  {icon:'🌳',ch:'YUVADAN İLK ADIM',t:'Orman Muhafızını devir',k:'treant',n:1,xp:350,g:150,m:10,z:1,story:'Slime açıklığının kuzeydoğusunda, yoldan ayrı bir koru var. Köklerine kül işlemiş muhafız dostu düşmandan ayıramıyor.',why:'İlk büyük sınav tek başına yapılır. Yolun üstündeki avla karıştırma.',tip:'Koruya yalnız gir. Ekmeğini ye, işaretli alandan çık, sersemleyince yeteneğini kullan.'},
  {icon:'🦎',ch:'KIYILARIN ÇAĞRISI',t:'4 Murloc avla',k:'lizard',n:4,xp:240,g:100,m:8,z:2,story:'Güneydeki huzursuzluk göl halkını kıyıya sürmüş. Balıkçıların iskelesi artık bir sınır.',why:'Hareketli düşmanlara karşı hedef seçmeyi ve kıyıyı tutmayı öğrenirsin.',tip:'İskele koyundaki dört Murloc. Suya sıkışma, tek tek çek.'},
  {icon:'🦀',ch:'KIYILARIN ÇAĞRISI',t:'Kral Yengeci mağlup et',k:'crab',n:1,xp:500,g:220,m:12,z:2,story:'Kral Yengeç kuzey kıyıyı bir kapı gibi tutuyor. Geçmeden göl yeniden kasabanın kileri olamaz.',why:'Menzilli saldırılardan kaçmayı ve vuruş aralığını yakalamayı öğretir.',tip:'Yengeç Kayalığı iskelenin kuzeyinde. Baloncukların boşluğunu kullan; açık verince yaklaş.'},
  {icon:'🦂',ch:'KIZIL ÇÖL',t:'4 Akrep avla',k:'scorpion',n:4,xp:450,g:180,m:10,z:3,story:'Çöl bir anda bitmez. Kervan yolunun ağzından gir; dört akrep yolun kuzey kenarında, vaha daha ileride.',why:'Mesafe de sınavın parçası. Yemek ve iksir olmadan taşın karşısına çıkma.',tip:'Çöl ağzından gir. Atılma çizgisinden yana sıyrıl. Bitince vahada dur.'},
  {icon:'🗿',ch:'KIZIL ÇÖL',t:'Kum Golemini yen',k:'golem',n:1,xp:700,g:300,m:15,z:3,story:'Taş dev yolun üstünde değil. Vahada nefes al, sonra kervan yolunun güneyindeki çukura in.',why:'Alan saldırısıyla kaya atışını aynı anda okumayı sınar. Nefessiz girilmez.',tip:'Çukur yolun güneyinde. Şok dalgasından uzaklaş, kaya atışını sıyrılmayla geç.'},
  {icon:'🔨',ch:'EJDER YOLU',t:'Demircide bir eşyayı +1 geliştir',k:'forge',n:1,xp:400,g:120,m:10,z:0,story:'Ejder yoluna kör çelikle çıkılmaz. Boran, üzerindeki kılıcı bir kez +1 yapar. 40 altın, kesin.',why:'Tek bir net güçlenme. Fıskiye ve kovan bu adımın parçası değil.',tip:'Sarı hedef Demirci Boran’ı gösterir. Kılıca dokun, Kılıcı +1 Yap’a bas.'},
  {icon:'💀',ch:'EJDER YOLU',t:'5 İskelet temizle',k:'skeleton',n:5,xp:800,g:280,m:15,z:4,story:'Kül Geçidi yolu tutuyor. Beş iskelet yolun kenarında. Ejder daha güneydeki arenada; onu buraya çekme.',why:'Geçit bir yer, arama değil. Ejderle aynı anda dövüşülmez.',tip:'Geçitte dur. Birini çek, bitir, sonra diğerine geç. Arenaya inmeden işi kapat.'},
  {icon:'🐉',ch:'EJDER YOLU',t:"Kızıl Ejder'i yen",k:'dragon',n:1,xp:3500,g:1000,m:60,z:4,story:'Arena geçidin güneyinde, yalnız. İskeletleri oraya sürme. İşaretli alandan çık, ikinci fazda hareketi bırakma.',why:'Tek bir arena. Yol boyunca kurduğun çelik ve nefes burada işe yarar.',tip:'Geçidi geç, arenaya yalnız gir. İşaretli alandan çık, sersemleyince tüm gücünü kullan.'},
  {icon:'★',ch:'USTALIK HEDEFLERİ',t:'3 Elit canavar yen',k:'elite',n:3,xp:2500,g:600,m:30,z:0,story:'Seçkinler kül sırtının batısında, üçü. Yoldan çekilmezler. Birine yanaş, bitir, sonra diğerine geç.',why:'Bir ustalık. Kasabanın her işi değil.',tip:'Sarı hedef seçkin sırtı gösterir. Üçünü birden çekme.'},
  {icon:'⚔️',ch:'GÜNLÜK SERBEST HEDEF',t:'10 Canavar temizle',k:'any',n:10,xp:1800,g:400,m:20,z:0,story:'Bugün seçtiğin bölgede güvenliği artır.',why:'Ana hikâye sonrasında isteğe bağlı tekrar ödülüdür; her gün yapmak zorunda değilsin.',tip:'Günlük odağınla birleştir veya yalnızca keşif yapmak istiyorsan bu hedefi görmezden gel.'}
]
// ==== BÖLÜM MODELİ (tek kaynak: QS.ch) ====
const CHAPTERS=window.CHAPTERS=(()=>{
  const out=[],FIN=QS.findIndex(q=>q.k==='dragon');
  QS.slice(0,FIN<0?QS.length:FIN+1).forEach((q,i)=>{const last=out[out.length-1];
    if(last&&last.name===q.ch){last.end=i;last.quests.push(i)}
    else out.push({name:q.ch,start:i,end:i,quests:[i],icon:['🌱','🌊','🏜️','🔥','👑'][out.length]||'📖'});});
  out.forEach((c,k)=>{c.no=k+1;c.total=out.length});
  return out;
})();
function chapterAt(index){
  if(!Number.isInteger(index)||index<0||index>=QS.length)return null;
  const ci=CHAPTERS.findIndex(c=>index>=c.start&&index<=c.end);if(ci<0)return null;
  const c=CHAPTERS[ci],q=QS[index];
  const done=c.quests.filter(k=>k<index).length;
  return {...c,index:ci,no:ci+1,total:CHAPTERS.length,label:`BÖLÜM ${ci+1}/${CHAPTERS.length}`,
    short:`📖 B${ci+1}/${c.total||CHAPTERS.length}`,done,size:c.quests.length,quest:q};
}
window.chapterAt=chapterAt;

// ==== BÖLÜM AÇILIŞ SAHNELERİ ====
const CHAPSCENES=window.CHAPSCENES={
  scenes:{
    2:[
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'BÖLÜM 1 KAPANDI',line:'Orman yolu açıldı, muhafız düştü. Gölgeköy ilk kez rahat bir nefes aldı. Ama kıyıdan gelen haber iyi değil.'},
      {who:'Fırıncı Melis',icon:'🥖',kicker:'BÖLÜM 2 · KIYILARIN ÇAĞRISI',line:'Orman sustu… ama göl sustu mu? Bu sabah fırına iki kişi geldi, ikisi de kıyıdan kaçmış.'},
      {who:'Balıkçı Rıza',icon:'🎣',kicker:'KIYI',line:'İskele murloc doldu. Ağ atıyorum, boş çekiyorum. Kasabanın kileri iki hafta dayanır; fazlası değil.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'GÖREV',line:'Kıyıyı geri al. Ama unutma: sen artık misafir değilsin. Bu kasabanın sesi sensin.'}
    ],
    3:[
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'BÖLÜM 2 KAPANDI',line:'Kıyı geri alındı, balık tezgâhı yeniden kuruldu. Şimdi güneyden, kervan yolundan hiç ses gelmiyor.'},
      {who:'Kervancı Leyla',icon:'🐪',kicker:'BÖLÜM 3 · KIZIL ÇÖL',line:'Kervan yolu kapandı. Akrepler geçidi tuttu, kum golemi vahayı kuruttu. Un gelmiyor, kahve gelmiyor.'},
      {who:'Çiftçi Dede',icon:'🌾',kicker:'ÇÖL',line:'Çöl bir anda bitmez. Nefesini say, suyunu say, sonra taşın karşısına çık.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'GÖREV',line:'Kiler boş kalırsa kış bizi yer. Yolu aç; ne olursa olsun geri dön.'}
    ],
    4:[
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'BÖLÜM 3 KAPANDI',line:'Çöl yolu açıldı, kervan döndü, kiler doldu. Geriye tek şey kaldı: kuzeydeki kül.'},
      {who:'Demirci Boran',icon:'⚔️',kicker:'BÖLÜM 4 · EJDER YOLU',line:'Kılıcını al. Geçit açık — ama geçit, giren herkesi geri bırakmıyor.'},
      {who:'Fırıncı Melis',icon:'🥖',kicker:'YOLA ÇIKIŞ',line:'Sıcak bir somun al. Kül, aç karna daha ağırdır.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'SON SÖZ',line:'Kızıl Ejder seni bekliyor. Gölgeköy seninle gelmiyor; sen Gölgeköy için gidiyorsun.'}
    ]
  },
  key(){const c=window.chapterAt?chapterAt(P.q):null;return c?c.no:0},
  seen(k){const st=STORY.state();return st.beats['ch'+k]===true},
  maybe(force){
    if(!P.adventure||typeof gameStarted==='undefined'||!gameStarted)return false;
    if(window.ONBOARD&&ONBOARD.active&&ONBOARD.active())return false;
    const k=this.key();if(!k||k<2||!this.scenes[k]||this.seen(k))return false;
    if(!force){
      if(P.dead||P.combatTimer>0||STORY.scene)return false;
      if(document.querySelector('.ov:not(.h)'))return false;
    }
    STORY.state().beats['ch'+k]=true;sv();
    STORY.play(this.scenes[k],null,{skipDone:false});
    return true;
  },
  tick(){if(this._t&&Date.now()-this._t<2500)return;this._t=Date.now();this.maybe(false)}
};
window.CHAPSCENES=CHAPSCENES;
;
const QUEST_META={
  slime:{giver:'Muhtar Hamdi',rec:1,done:'Yolun ilk nefesi açıldı. Gölgeköy adını fısıldamaya başladı. Dönüşte odun ve taşı sandığa çevir.'},
  fish:{giver:'Fırıncı Melis',rec:1,done:'Bu balıklar akşam sofrasına yetişir. Artanını pişir ya da sat; kasaba aç kalmasın.'},
  treant:{giver:'Çiftçi Dede',rec:3,done:'Muhafızın öfkesi dindi. Kökler seni düşman saymıyor artık. Sırada göl var.'},
  lizard:{giver:'Balıkçı Rıza',rec:3,done:'Kıyı yolu yeniden insan ayağı taşıyabilir. Balıkçılar göle dönecek.'},
  crab:{giver:'Balıkçı Rıza',rec:5,done:'Kral geri çekildi. Sığ Göl yine kasabanın kileri. Çöl yolu ise hâlâ suskun.'},
  scorpion:{giver:'Kervancı Leyla',rec:6,done:'Kervan izi temiz. Leyla’nın yükleri yeniden kasabaya varacak.'},
  golem:{giver:'Kervancı Leyla',rec:8,done:'Taş dev durdu. Geçit, dostu düşmandan ayırmayı yeniden öğrenecek.'},
  forge:{giver:'Demirci Boran',rec:6,done:'Çelik artık niyetini biliyor. Ejder yolunda farkı bu yaratır.'},
  skeleton:{giver:'Rahibe Elara',rec:9,done:'Geçit sustu. İn’in ağzı önünde. Acele etme; hazır olduğunda gir.'},
  dragon:{giver:'Muhtar Hamdi',rec:12,done:'Duman kesildi. Hamdi kapıda. Rapor yok.'},
  elite:{giver:'Arena Ustası',rec:12,done:'Seçkin av tamamlandı. Gücün artık sıradan düşmanlarla ölçülmüyor.'},
  any:{giver:'Kasaba Panosu',rec:8,done:'Bugünün güvenlik işi tamamlandı. Yarın yeni bir hedef seçebilirsin.'}
};
for(const q of QS)Object.assign(q,QUEST_META[q.k]||{});

// Mevcut görev kimlikleri/sırası korunur. Final kanıtı genel 'boss' sınıfından türetilmez.
const QUEST_FLOW=window.QUEST_FLOW={
  finale:QS.findIndex(q=>q.k==='dragon'),
  verifiedDragon(){return P.adventure?.dragonVictory?.v===1&&P.adventure.dragonVictory.verified===true&&['dragon','quest-history'].includes(P.adventure.dragonVictory.source)},
  optional(){return Number.isInteger(P.q)&&P.q>this.finale&&P.q<=QS.length},
  migrate(a){
    const previous=a.dragonVictory;
    if(previous?.v===1&&previous.verified===true&&['dragon','quest-history'].includes(previous.source)){
      a.dragonVictory={v:1,verified:true,source:previous.source,day:Number.isInteger(previous.day)&&previous.day>0?previous.day:null};
    }else if(this.optional())a.dragonVictory={v:1,verified:true,source:'quest-history',day:null};
    else a.dragonVictory={v:1,verified:false,source:P.ach.dragon_killed||P.ach.dragon>0||a.bestiary.dragon?.kills>0?'legacy-credit':'none',day:null};
    // Eski ödüller ve mevcut kart sayıları silinmez. Belirsiz bir bayraktan yeni öldürme üretilmez.
    if(!a.bestiary.dragon&&this.verifiedDragon())a.bestiary.dragon={seen:true,kills:1,source:'quest-history'};
    else if(!a.bestiary.dragon&&a.dragonVictory.source==='legacy-credit')a.bestiary.dragon={seen:true,kills:0,legacyCredit:true};
  },
  recordDragon(e){
    if(e.k!=='dragon'||e.trial)return false;
    const first=!this.verifiedDragon();P.ach.dragon_killed=1;
    P.adventure.dragonVictory={v:1,verified:true,source:'dragon',day:first?P.day:(P.adventure.dragonVictory.day||P.day)};
    return first;
  },
  resolveRecorded(){
    if(P.q!==this.finale||!this.verifiedDragon())return false;
    // Önceden doğrulanmış bir ejderi sırf görev sırası için yeniden öldürmek gerekmez.
    qp('dragon');return true;
  },
  status(){
    if(this.optional())return STORY.closed()?'Ana hikâyeyi Muhtar Hamdi ile tamamladın. Çiftlik, dostluklar ve ustalık hedefleri serbestçe devam eder.':'Ejder görev rotan tamamlandı. Gölgeköy’de Muhtar Hamdi’ye dönerek hikâyeni kapatabilirsin; elit avları, arena ve derin maden isteğe bağlıdır.';
    if(this.verifiedDragon())return 'Gerçek ejder zaferin kayıtlı. Görev rotası finale ulaştığında bu zafer bir kez hesaba katılır.';
    if(P.adventure?.dragonVictory?.source==='legacy-credit')return 'Önceki sürümdeki ejder kazanımların korundu. Eski boss işareti tek başına olayın türünü doğrulamıyor; mevcut görev ilerlemen değiştirilmedi.';
    return 'Uzun vadeli hedefin: Gölgeköy’de kurduğun hayatı korumak ve Kızıl Ejder tehdidiyle yüzleşmek.';
  },
  preparation(q){
    if(!q)return {checks:[],ready:0,total:0};
    const healing=P.pots>0||P.inv.some(i=>i.s==='food'&&ITEMS.qty(i)>0),gear=q.k==='fish'?FEATURES.is('fishing'):q.k==='forge'?Object.values(P.eq).some(Boolean):q.rec<=2||!!(P.eq.weapon||P.eq.armor),level=P.lvl>=(q.rec||1);
    const checks=[{id:'level',ok:level,label:`Seviye ${P.lvl}/${q.rec||1}`},{id:'healing',ok:healing,label:healing?'Şifa hazır':'Yemek/iksir al'},{id:'gear',ok:gear,label:q.k==='fish'?(gear?'Olta açık':'Oltayı aç'):q.k==='forge'?(gear?'Eşya hazır':'Eşya kuşan'):(gear?'Ekipman hazır':'Ekipman kuşan')}];
    return {checks,ready:checks.filter(c=>c.ok).length,total:checks.length};
  },
  openPreparation(){
    const q=QS[P.q];if(!q)return;const prep=this.preparation(q),advice={level:`Önerilen seviye ${q.rec}. Eksik seviyeleri daha kolay bölgelerde savaşarak, görev ödülleri ve ekipmanla tamamla.`,healing:'Ev ocağında yemek hazırla, çantandaki yiyecekleri kontrol et veya tüccardan can iksiri al.',gear:q.k==='fish'?'Balıkçılık açıldığında sağ menüdeki Araçlar bölümünden oltayı seç.':q.k==='forge'?'Çantandaki veya üzerinde takılı bir eşyayı Demirci Boran’a götür.':'Çantadan silah veya zırh kuşan; mümkünse demircide +1 geliştir.'};
    $('quest-prep-content').innerHTML=`<span class="guide-kicker">${q.ch}</span><h2 class="guide-title">${q.icon} ${q.t}</h2><p class="guide-copy">Hazırlık ${prep.ready}/${prep.total}. Eksikler görevi engellemez; yalnızca daha zor hâle getirir.</p><div class="quest-prep-list">${prep.checks.map(c=>`<div class="quest-prep-row ${c.ok?'ok':''}"><span>${c.ok?'✓':'!'}</span><div><b>${c.label}</b><small>${c.ok?'Bu hazırlık tamam.':advice[c.id]}</small></div></div>`).join('')}</div><div class="quest-tip">💡 Göreve özel taktik: ${q.tip}</div>`;
    $('quest-prep-modal').classList.remove('h');
  },
  chapterOptions(index){const data={2:{wealth:{icon:'🪙',name:'Servet Sandığı',text:'+100 altın · +2 elmas',gold:100,gems:2},supplies:{icon:'📦',name:'Hazırlık Sandığı',text:'+3 iksir · +8 tohum · +2 gübre',pots:3,seeds:{wheat:8},fert:2},gear:{icon:'⚔️',name:'Ekipman Sandığı',text:'Seviye 3 nadir ekipman',level:3,rarity:1}},6:{wealth:{icon:'🪙',name:'Servet Sandığı',text:'+220 altın · +5 elmas',gold:220,gems:5},supplies:{icon:'📦',name:'Hazırlık Sandığı',text:'+4 iksir · +4 gübre · nadir tohum',pots:4,fert:4,seeds:{star_berry:2}},gear:{icon:'⚔️',name:'Ekipman Sandığı',text:'Seviye 8 epik ekipman',level:8,rarity:2}},9:{wealth:{icon:'🪙',name:'Kraliyet Hazinesi',text:'+500 altın · +10 elmas',gold:500,gems:10},supplies:{icon:'📦',name:'Usta Hazırlığı',text:'+6 iksir · +8 gübre · kadim tohum',pots:6,fert:8,seeds:{ancient_fruit:1}},gear:{icon:'👑',name:'Efsanevi Sandık',text:'Seviye 15 efsanevi ekipman',level:15,rarity:3}}};return data[index]||null},
  chapterChoiceHTML(index){const options=this.chapterOptions(index);if(!options)return'';return `<div class="reward-pending"><h3>Bir Bölüm Ödülü Seç</h3><p>Seçim kalıcıdır. Oyun tarzına en uygun sandığı al.</p><div class="reward-choice-grid">${Object.entries(options).map(([id,o])=>`<button type="button" class="reward-choice" data-chapter-choice="${id}" data-chapter-index="${index}"><strong>${o.icon}</strong><b>${o.name}</b><span>${o.text}</span></button>`).join('')}</div></div>`},
  claimChapterReward(index,choice){const pending=P.adventure.chapterRewardPending,claimed=P.adventure.questChapters||(P.adventure.questChapters={}),options=this.chapterOptions(index),o=options?.[choice];if(!pending||pending.index!==index||claimed[index]||!o)return false;if(o.gold)P.gold+=o.gold;if(o.gems)P.gems+=o.gems;if(o.pots)P.pots+=o.pots;if(o.fert)P.fert=(P.fert||0)+o.fert;if(o.seeds)for(const[k,n]of Object.entries(o.seeds))P.seeds[k]=(P.seeds[k]||0)+n;if(o.level)awardInventoryItem(gen(Math.max(P.lvl,o.level),o.rarity));claimed[index]=true;P.adventure.chapterRewardPending=null;P.adventure.chapterNotice=null;NOTIFICATIONS.push('reward',o.icon,`${pending.name}: ${o.name}`,o.text);ban(`🎁 ${o.name} ALINDI`,'#fde68a');playChord([523,659,784,1046],.35,'triangle',.055);updHotbarUI();sv();if(!$('chapter-complete-modal').classList.contains('h'))closeChapterComplete();if(!$('rewards-modal').classList.contains('h'))rewardsUI();return true},
  maybeShowChapter(){
    const notice=P.adventure?.chapterNotice;if(!notice)return;P.adventure.chapterNotice=null;NOTIFICATIONS.push('chapter','🎁',`${notice.name} tamamlandı`,'Ödül Merkezi’nde üç farklı bölüm sandığından birini seçebilirsin.');sv();
    MODAL_QUEUE.enqueue(`chapter:${notice.index}:${P.day}`,3,'chapter-complete-modal',()=>{const next=QS[P.q],stories={2:'İlk bölüm kapandı. Evi tanıdın, sofrayı kurdun, orman yolunu açtın ve gölün kadim öfkesini dindirdin. Gölgeköy artık seni yolcu değil, komşu sayıyor. Kıyı ve çöl seni bekliyor; acele etme, hazırlan.',6:'Kıyıyı ve kervan yolunu geri aldın. Kasabanın ekmeği, balığı ve ticareti yeniden nefes alıyor. Ama güney sırtındaki kül dinmedi. Ejder yoluna çıkmadan önce çeliğini, azığını ve cesaretini aynı masaya koy.',9:'Kızıl Ejder düştü. Güney sırtı sustu. Hamdi rapor istemiyor; belediye kapısında bir nefes istiyor. Elit av bu gecenin işi değil.'};const after=notice.index===9?'<p><b>Şimdi:</b> Belediye önüne dön. Hikâye orada kapanır. Sabah olunca tarla, dostlar ve seçtiğin bir ustalık durur.</p>':next?`<p><b>Sıradaki:</b> ${next.icon} ${next.t}<br>${next.story}</p>`:'<p>Artık kendi hedeflerini seçebilirsin.</p>';$('chapter-complete-content').innerHTML=`<div class="chapter-recap"><span class="guide-kicker">${notice.name}</span><h3>${notice.name}</h3><p>${stories[notice.index]||'Yeni bir hikâye bölümü tamamlandı.'}</p>${after}</div>`;$('chapter-reward-choices').innerHTML=this.chapterChoiceHTML(notice.index);$('chapter-complete-modal').classList.remove('h');GAME_CORE.resetInput()});
  },
  chapterReward(index){
    const names={2:'Yuvadan İlk Adım',6:'Kızıl Çöl Yolu',9:'Ejder Yolu'},name=names[index];if(!name)return;const claimed=P.adventure.questChapters||(P.adventure.questChapters={});if(claimed[index]||P.adventure.chapterRewardPending?.index===index)return;P.adventure.chapterRewardPending={index,name};P.adventure.chapterNotice={index,name};setTimeout(()=>{ban(`🎁 BÖLÜM TAMAMLANDI: ${name}`,'#fde68a');playChord([523,659,784,1046],.35,'triangle',.055)},650);
  },
  timelineHTML(q){
    if(!q)return '';
    const chapter=QS.map((v,i)=>({q:v,i})).filter(x=>x.q.ch===q.ch);
    return `<details class="farm-details"><summary><span>📖 Bu Bölümün Adımları</span><small style="color:#9fb6c0">${q.ch}</small></summary><div class="farm-details-body quest-timeline">${chapter.map(({q:item,i})=>{const state=i<P.q?'done':i===P.q?'current':'locked';return `<div class="quest-step ${state}"><span>${i<P.q?'✓':i===P.q?'➜':'🔒'}</span><strong>${item.icon} ${item.t}</strong><span>${i<P.q?'Tamam':i===P.q?`${Math.min(P.qn,item.n)}/${item.n}`:'Sırada'}</span></div>`}).join('')}</div></details>`;
  },
  html(){
    const q=QS[P.q];if(!q)return `<div id="story-direction" class="journey-box"><b>🧭 Bir hayat kur, kurduğun hayatı koru.</b><p>${this.status()}</p><p class="inventory-help">Çiftlik, keşif veya ustalık hedefini kendi hızında seç.</p></div>`;
    const progress=cl(Math.floor(Number(P.qn)||0),0,q.n),pct=Math.round(progress/q.n*100),label=this.optional()?'İSTEĞE BAĞLI HEDEF':'ANA GÖREV ROTASI',repeat=q.k==='any'&&P.bounties>0,rewardG=repeat?80:q.g,rewardM=repeat?2:q.m,rewardXp=repeat?150:q.xp,prep=this.preparation(q),ready=prep.ready===prep.total;
    return `<div id="story-direction" class="quest-card"><div class="quest-card-head"><div><span class="quest-chapter">${label} · ${q.ch}</span><h3>${q.icon} ${q.t}</h3><span class="quest-giver">📜 Görevi veren: ${q.giver}</span></div><span class="quest-ready ${ready?'ok':''}">${ready?'HAZIR':`HAZIRLIK ${prep.ready}/${prep.total}`}</span></div><p style="color:#d7c7a2;font-size:9.5px">${window.STORY?STORY.soFar():''}</p><p>${q.story}</p><div class="quest-progress"><i style="width:${pct}%"></i></div><p style="text-align:right;font-size:8.5px">İlerleme ${progress}/${q.n}</p><p><b>Neden?</b> ${q.why}</p><div class="quest-prep">${prep.checks.map(c=>`<span class="${c.ok?'ok':''}">${c.ok?'✓':'○'} ${c.label}</span>`).join('')}</div><div class="quest-rewards"><span>+${rewardG}🪙</span><span>+${rewardM}💎</span><span>+${rewardXp} XP</span></div><div class="quest-tip">💡 ${q.tip}</div><div class="quest-actions"><button type="button" class="primary" data-quest-map="1">🗺️ Hedefi Haritada Göster</button><button type="button" data-quest-bag="1">🧰 Hazırlık Planını Aç</button></div></div>${this.timelineHTML(q)}<p class="inventory-help">Hepsini aynı gün yapmak zorunda değilsin. Hazırlan → hedefi tamamla → ödülle dön → sonraki bölüme geç.</p>`;
  }
};
function closeQuestPrep(){$('quest-prep-modal').classList.add('h');GAME_CORE.resetInput()}
$('quest-prep-close').onclick=closeQuestPrep;
$('quest-prep-bag').onclick=()=>{closeQuestPrep();$('journey-modal').classList.add('h');openInv()};
$('quest-prep-map').onclick=()=>{closeQuestPrep();$('journey-modal').classList.add('h');const nav=navigationTarget();openMap(nav?.map)};
function closeChapterComplete(){$('chapter-complete-modal').classList.add('h');GAME_CORE.resetInput();MODAL_QUEUE.done();setTimeout(()=>window.CHAPSCENES&&CHAPSCENES.maybe(false),700)}
function closeChapterBrief(){
  $('chapter-brief-modal').classList.add('h');GAME_CORE.resetInput();
  chat('MUHTAR HAMDİ','','İlk iş: kapıyı aç. İçeride ocağı ve yatağı gör; sonra konuşuruz.',1);
  MODAL_QUEUE.done();
}
$('chapter-brief-close').onclick=closeChapterBrief;
$('chapter-brief-start').onclick=closeChapterBrief;
$('chapter-complete-close').onclick=closeChapterComplete;$('chapter-complete-ok').onclick=closeChapterComplete;
function qp(k){
  const q=QS[P.q];if(!q)return;
  const daily=q.k==='any';
  // HitMob zaten qp(canavar) ve qp(any) çağırır: günlük av sadece 'any' olayında bir kez sayılır.
  if(daily?k!=='any':q.k!==k)return;
  if(daily&&P.bounties>0&&P.lastBountyDay===P.day)return;
  P.qn++;
  if(P.qn<q.n){
    const left=q.n-P.qn;if(q.k==='slime'&&q.n===6)fl(P.x,P.y-34,`${P.qn}/6 slime`,'#fde68a',true);if(P.qn===Math.ceil(q.n/2)&&q.n>3)ban(`📜 GÖREV YARILANDI · ${P.qn}/${q.n}`,'#a7f3d0');else if(left===1&&q.k!=='slime')fl(P.x,P.y-34,`📜 Son 1 hedef kaldı!`,'#fde68a',true);
    sv();return;
  }
  const completedIndex=P.q,first=daily&&P.bounties===0;
  const gold=daily&&!first?80:q.g,gems=daily&&!first?2:q.m,xp=daily&&!first?150:q.xp;
  P.gold+=gold;P.gems+=gems;P.townWorkDay=P.day;
  if(daily){P.bounties++;P.lastBountyDay=P.day}else P.q++;
  P.qn=0;if(q.k==='slime'&&q.n===6)ONBOARD.event('forest');
  if(!daily)QUEST_FLOW.chapterReward(completedIndex);
  // Seviye atlamak sv() çağırabilir: o kayıtta görev ödülü zaten işlenmiş görünmeli.
  addXp(xp);
  NOTIFICATIONS.push('quest',q.icon||'📜',`${q.t} tamamlandı`,`Ödül: +${gold} altın · +${gems} elmas · +${xp} XP.`);ban('GÖREV TAMAM! +'+gold+'🪙 +'+gems+'💎','#7dff9c');
  playChord([523,659,784,1046],.25,'triangle',.04);chat(q.giver||'REHBER','',q.done||'Görev tamamlandı.',1);
  const next=QS[P.q];
  if(!daily&&completedIndex===1&&window.STORY){STORY.state().beats.rest=true;setTimeout(()=>chat('FIRINCI MELİS','','Balıklar akşam sofrasına yetişir. Eve dön, yatakta sabahı aç. Orman Muhafızı sabah korusunda bekler.',1),900)}
  else if(!daily&&completedIndex===5&&window.STORY){STORY.state().beats.oasis=true;setTimeout(()=>chat('KERVANCI LEYLA','','Yol temiz. Hemen çukura inme. Vahada bir nefes al, kovayı doldur. Taş dev güneyde bekler.',1),900)}
  else if(!daily&&completedIndex===9&&window.STORY)setTimeout(()=>chat('MUHTAR HAMDİ','','Duman kesildi. Bunu sormayacağım. Belediye önündeyim. Dön, bu gece burada kal.',1),1600);
  else if(next&&!daily&&completedIndex!==9&&!(window.ONBOARD&&ONBOARD.active()))setTimeout(()=>chat(next.giver||'REHBER','',`${next.t}. ${next.story}`,1),[2,6].includes(completedIndex)?1600:1000);
  QUEST_FLOW.resolveRecorded();sv();
  if(!daily&&window.DECISIONS)setTimeout(()=>DECISIONS.check(),700);
}

const ACH_LIST=[
  {id:'first_kill',t:'İlk Kan',d:'İlk canavarı mağlup et',g:20,m:3,check:()=>P.kills>=1},
  {id:'slimer',t:'Slime Avcısı',d:'15 Slime temizle',g:50,m:5,check:()=>(P.adventure?.bestiary.slime?.kills||0)>=15},
  {id:'treant',t:'Orman Fatihi',d:'Orman Muhafızı mini-bossunu devir',g:150,m:10,check:()=>P.ach.treant_killed},
  {id:'crab',t:'Dalga Efendisi',d:'Kral Yengeç mini-bossunu alt et',g:200,m:12,check:()=>P.ach.crab_killed},
  {id:'golem',t:'Çöl Muhafızı',d:'Kum Golemi mini-bossunu yen',g:250,m:15,check:()=>P.ach.golem_killed},
  {id:'dragon',t:'Kızıl Ejder Katili',d:'Kızıl Ejder bossunu devir!',g:1000,m:50,check:()=>P.ach.dragon_killed},
  {id:'forge3',t:'Usta Kuyumcu',d:'Bir eşyayı [+3] seviyeye yükselt',g:150,m:10,check:()=>P.ach.forge_3},
  {id:'chests',t:'Hazine Avcısı',d:'3 Gizli hazine sandığı aç',g:120,m:8,check:()=>(P.ach.chests_opened||0)>=3},
  {id:'fisher',t:'Usta Balıkçı',d:'5 balık yakala',g:80,m:6,check:()=>(P.ach.fish_caught||0)>=5},
  {id:'lvl10',t:'Deneyimli Kahraman',d:'Seviye 10 veya üstüne ulaş',g:300,m:15,check:()=>P.lvl>=10}
];

function checkAch(id){
  if(P.ach[id]===2)return;
  const a=ACH_LIST.find(x=>x.id===id);
  if(a&&a.check()&&P.ach[id]!==1){
    P.ach[id]=1;
    NOTIFICATIONS.push('achievement','🏆',`Başarım: ${a.t}`,`Ödül hazır: +${a.g} altın · +${a.m} elmas.`);ban('🏆 BAŞARIM: '+a.t,'#ffd23f');
    playChord([440,554,659,880],.25,'sine',.04);
    sv();
  }
}

