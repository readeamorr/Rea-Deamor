/* ===== EVİN SICAK İÇ MEKANI VE RETRO EĞLENCE SİSTEMİ ===== */
let musicTrack = 0;
const MUSIC_TRACKS = [
  { id: 0, name: 'Huzurlu Çiftlik Valsi', icon: '🎵', base: 196, desc: 'Sıcak majör çiftlik melodisi' },
  { id: 1, name: 'Yağmurlu Kahve Molası', icon: '☕', base: 164, desc: 'Sakin akustik lo-fi akorları' },
  { id: 2, name: 'Aethermoor Efsanesi', icon: '⚔️', base: 185, desc: 'Epik retro fantastik ezgiler' },
  { id: 3, name: 'Yıldızlı Gece Ninnisi', icon: '✨', base: 130, desc: 'Yumuşak dinlendirici ninni' }
];

function initInsideMap(){
  const inN = 30, inTS = 16, inC = 15;
  const inTl = new Uint8Array(inN * inN), inObjs = [];
  // 4: duvarlar, 3: parke ahşap zemin
  for(let i=0; i<inTl.length; i++) inTl[i] = 4;
  for(let y=6; y<25; y++) for(let x=6; x<25; x++) inTl[y*inN + x] = 3;
  // Çıkış kapısı
  inTl[25*inN + 15] = 3;

  // İç Mekan Nesneleri:
  // Şömine (Kuzey duvarı)
  inObjs.push({ k: 'in_fireplace', x: 15*inTS, y: 7*inTS, r: 6 });
  // Çift Kişilik Yatak (Kuzeydoğu)
  inObjs.push({ k: 'in_bed', x: 22*inTS, y: 8*inTS, r: 6 });
  // Retro TV (Kuzeybatı)
  inObjs.push({ k: 'in_tv', x: 8*inTS, y: 8*inTS, r: 5 });
  // Gramofon (Doğu masası)
  inObjs.push({ k: 'in_gramophone', x: 23*inTS, y: 14*inTS, r: 5 });
  // Mutfak Ocağı (Batı tezgahı)
  inObjs.push({ k: 'in_stove', x: 7*inTS, y: 14*inTS, r: 5 });
  // Kiler Depolama Sandığı (Güneybatı)
  inObjs.push({ k: 'in_storage', x: 7*inTS, y: 20*inTS, r: 5 });
  // Büyük Kırmızı Yün Halı (Merkez)
  inObjs.push({ k: 'in_rug', x: 15*inTS, y: 15*inTS, r: 8 });
  // Çıkış Paspası (Güney)
  inObjs.push({ k: 'in_doormat', x: 15*inTS, y: 24*inTS, r: 4 });
  // Tadilat & Ev Geliştirme Masası
  inObjs.push({ k: 'in_workbench', x: 18*inTS, y: 22*inTS, r: 6 });

  const inMmc = document.createElement('canvas'); inMmc.width = inMmc.height = inN;
  const m = inMmc.getContext('2d');
  for(let y=0; y<inN; y++) for(let x=0; x<inN; x++){
    m.fillStyle = inTl[y*inN+x]===3?'#78350f':'#1e293b';
    m.fillRect(x,y,1,1);
  }

  return { N: inN, TS: inTS, C: inC, tl: inTl, objs: inObjs, hs: [], chests: [], critters: [], resources: [], mobs: [], npcs: [], mmc: inMmc, farmPlots: [] };
}

function insideObjD(o){
  const x = Math.round(o.x), y = Math.round(o.y);
  if(o.k === 'in_rug'){
    R(x-24, y-16, 48, 32, '#991b1b');
    R(x-22, y-14, 44, 28, '#b91c1c');
    R(x-20, y-12, 40, 24, '#facc15');
    R(x-18, y-10, 36, 20, '#b91c1c');
  }else if(o.k === 'in_fireplace'){
    R(x-10, y-16, 20, 16, '#475569');
    R(x-8, y-14, 16, 12, '#334155');
    R(x-6, y-8, 12, 8, '#0f172a');
    // Çıtırdayan alev
    const fl = Math.sin(P.t*18)*2;
    R(x-4, y-6+fl, 8, 6, '#ea580c');
    R(x-2, y-4+fl, 4, 4, '#fde047');
    // Şömine kıvılcımları FX.emitters tarafından üretilir.
    if(labelNear(x,y,70))T('Somine',x,y-22,'#f97316');
  }else if(o.k === 'in_bed'){
    R(x-12, y-16, 24, 5, '#78350f');
    R(x-11, y-12, 22, 20, '#1e3a8a');
    R(x-9, y-11, 16, 5, '#f8fafc');
    R(x-10, y-5, 20, 10, '#2563eb');
    R(x-12, y-2, 3, 8, '#78350f');
    R(x+9, y-2, 3, 8, '#78350f');
    if(labelNear(x,y,80))T('Yatak',x,y-20,'#93c5fd');
  }else if(o.k === 'in_tv'){
    R(x-8, y-10, 16, 10, '#64748b');
    R(x-6, y-8, 12, 7, '#020617');
    R(x-5, y-7, 10, 5, '#1e293b'); // ekran
    R(x-1, y-13, 1, 4, '#94a3b8'); // anten
    R(x+1, y-13, 1, 4, '#94a3b8');
    if(labelNear(x,y,46))T('Retro TV 📺',x,y-16,'#38bdf8');
  }else if(o.k === 'in_gramophone'){
    R(x-6, y-8, 12, 8, '#78350f');
    R(x-4, y-6, 8, 4, '#ca8a04');
    R(x+1, y-14, 6, 8, '#facc15'); // boru
    R(x+4, y-16, 4, 4, '#fde047');
    if(labelNear(x,y,46))T('Gramofon 📻',x,y-18,'#facc15');
  }else if(o.k === 'in_stove'){
    R(x-7, y-10, 14, 10, '#334155');
    R(x-5, y-8, 10, 3, '#0f172a');
    R(x-3, y-6, 6, 4, '#ea580c');
    if(labelNear(x,y,70))T('Ocak',x,y-16,'#fbbf24');
  }else if(o.k === 'in_storage'){
    R(x-7, y-8, 14, 8, '#854d0e');
    R(x-8, y-10, 16, 2, '#ca8a04');
    R(x-2, y-6, 4, 3, '#facc15');
    if(labelNear(x,y,46))T('Kiler 📦',x,y-14,'#fde047');
  }else if(o.k === 'in_rug'){
    // Kupa Duvarı Süsleri (Kuzey Duvarı)
    const trophies = [];
    if(P.ach?.treant_killed) trophies.push({ icon:'🌲', name:'Orman Dalı', x:x-20 });
    if(P.ach?.crab_killed) trophies.push({ icon:'🌊', name:'Kral Kıskacı', x:x-8 });
    if(P.ach?.golem_killed) trophies.push({ icon:'🏜️', name:'Golem Çekirdeği', x:x+8 });
    if(P.ach?.dragon_killed) trophies.push({ icon:'🐉', name:'Ejder Boynuzu', x:x+20 });
    trophies.forEach(tr => {
      R(tr.x-4, y-26, 8, 8, '#78350f');
      R(tr.x-3, y-25, 6, 6, '#ffd23f');
      T(tr.icon, tr.x, y-22, '#ffd23f');
    });
    if(trophies.length&&labelNear(x,y,50))T('Kupa Duvarı 🏆',x,y-32,'#ffd23f');

  }else if(o.k === 'in_workbench'){
    // Çiftlik Evi Tadilat Masası
    R(x-8, y-10, 16, 10, '#78350f');
    R(x-7, y-11, 14, 2, '#92400e');
    R(x-6, y-13, 7, 3, '#38bdf8'); // mavi mimari plan
    R(x+2, y-13, 3, 3, '#facc15'); // gönye
    R(x+3, y-9, 2, 4, '#64748b'); // çekiç
    if(labelNear(x,y,46))T('Tadilat Masası 🔨',x,y-18,'#ffd23f');
  }else if(o.k === 'in_doormat'){
    R(x-8, y-4, 16, 8, '#92400e');
    R(x-7, y-3, 14, 6, '#b45309');
    if(labelNear(x,y,70))T('Kapi',x,y-12,'#f8fafc');
  }
}

/* TV Ekranı ve Kanallar */
function tvUI(channel){
  channel = channel || 'weather';
  $('tab-weather').classList.toggle('act', channel==='weather');
  $('tab-fortune').classList.toggle('act', channel==='fortune');
  $('tab-cooking').classList.toggle('act', channel==='cooking');
  const scr = $('tv-screen');

  if(channel==='weather'){
    const names={clear:DAY_CLOCK.night()?'🌙 Açık Gece':'☀️ Açık',rain:'🌧️ Yağmurlu',storm:'⛈️ Fırtınalı',fog:'🌫️ Sisli',blood_moon:'🌑 Kanlı Ay'};
    scr.innerHTML=`
      <b style="color:#38bdf8;font-size:12px">🌦️ Güncel Hava Bülteni (Bay Pırasa)</b><br>
      ${WORLD_EVENTS.html(true)}
      <span style="color:#e2e8f0">${SEASONS[FARM.seasonIdx()].n}, ${FARM.dayOf()}. gün · <b>${names[weather.type]||names.clear}</b>.<br>${isWetWeather()?'Yağış şu anda ekinlerini suluyor; yağışlı havada Şimşek Balığına rastlayabilirsin.':'Şu anda yağış yok. Ekinlerinin su durumunu kontrol et; fıskıyen yoksa sulamayı unutma.'}</span><br><br>
      <small style="color:#a7f3d0">Yarın için kesin bir tahmin verilmiyor. Hava oyun sırasında değişebilir. ${DAY_CLOCK.detail()}</small>
    `;
  }else if(channel==='fortune'){
    const fortList=[
      'Yolun uzak olabilir; sağlam bir hazırlık cesaretine güç katar.',
      'Kurduğun yuvayı hatırla. Her keşif seni oraya geri götürecek bir hikâye olsun.',
      'Bugün hangi işi seçeceğine sen karar ver. Küçük bir adım da ilerlemedir.'
    ];
    P.buffs.atk=180;S=st(); // Mevcut etki korunur: saldırı desteği, rastlantı/ganimet çarpanı değil.
    scr.innerHTML=`
      <b style="color:#c084fc;font-size:12px">🔮 Günün Şans Falı (Kadim Aetheria):</b><br><br>
      <span style="color:#fde047">"${fortList[Math.floor(P.t*3)%fortList.length]}"</span><br><br>
      <small style="color:#6ee7b7">✨ 3 dakika aktif oyun süresince +%22 Saldırı. Yeniden izlemek süreyi yeniler; oranı artırmaz. Elmas, ekin kalitesi veya kritik şansı değişmez.</small>
    `;
    fl(P.x, P.y-26, '🔮 ŞANS KUTSAMASI KAZANILDI!', '#c084fc', true);
    playChord([523,659,784], .25, 'sine', .05);
  }else{
    scr.innerHTML=`
      <b style="color:#fbbf24;font-size:12px">🍳 Kraliyet Aşçısının Sırları (Şef Gurme):</b><br><br>
      <span style="color:#fed7aa">"Taze inek sütü ve yumurtayı buğdayla harmanlarsanız ortaya çıkan <b>Ballı Sütlü Pankek</b>, savaşta hem canınızı doldurur hem de bacaklarınıza rüzgar hızı kazandırır!"</span><br><br>
      <small style="color:#cbd5e1">Tarif: 1 Süt + 1 Yumurta + 1 Buğday (Mutfak Ocağında)</small>
    `;
  }
}

$('tab-weather').onclick=()=>tvUI('weather');
$('tab-fortune').onclick=()=>tvUI('fortune');
$('tab-cooking').onclick=()=>tvUI('cooking');

/* Gramofon Müzik Kutusu UI */
function gramophoneUI(){
  let h='';
  MUSIC_TRACKS.forEach(tr=>{
    const isCur = musicTrack === tr.id;
    h+=`<div class="ach-item" style="cursor:pointer" data-track="${tr.id}">
      <div class="ach-info">
        <div class="ach-title">${tr.icon} ${tr.name} ${isCur?'<span style="color:#4ade80">(Çalıyor 🎶)</span>':''}</div>
        <div class="ach-desc">${tr.desc}</div>
      </div>
      <div>
        <button class="m" data-track="${tr.id}" style="padding:5px 12px;font-size:11px;margin:0;background:${isCur?'#16a34a':'#243258'}">${isCur?'Aktif':'Çal (▶)'}</button>
      </div>
    </div>`;
  });
  $('gramophone-list').innerHTML=h;
}

$('gramophone-list').onclick=e=>{
  const s=e.target.closest('[data-track]');
  if(!s)return;
  const tid = +s.dataset.track;
  musicTrack = tid;
  P.musicTrack = tid;
  fl(P.x, P.y-26, `🎶 ${MUSIC_TRACKS[tid].name} Çalıyor!`, '#fde047', true);
  playChord([523, 659, 784], .3, 'triangle', .06);
  sv();
  gramophoneUI();
};


