/* ===== ADIM 4: ÇİFTLİK OTOMASYONU (Golem, Akıllı Sevkiyat, Tedarik, Posta Güvercini) ===== */
const AUTO=window.AUTO={
  RX:20*16+8,RY:22*16+8,g:null,report:'',errorAt:0,
  COST:{golem:[600,1500,3500],sorter:700,supply:500,post:900},
  CAP:[0,12,24,40],SPD:[0,34,48,66],ACT:[0,1.4,1,.7],
  A(){
    const a=P.auto=P.auto&&typeof P.auto==='object'&&!Array.isArray(P.auto)?P.auto:{};
    for(const [k,v] of Object.entries({golem:0,sorter:false,supply:false,post:false,energy:0,day:0,h:0,p:0,w:0,gold:0,orders:0}))if(!Number.isFinite(a[k])&&typeof a[k]!=='boolean')a[k]=v;
    a.golem=cl(Math.floor(Number(a.golem)||0),0,this.CAP.length-1);
    for(const k of ['sorter','supply','post'])a[k]=a[k]===true||a[k]===1;
    a.energy=cl(Math.floor(Number(a.energy)||0),0,this.CAP[a.golem]||0);
    a.day=cl(Math.floor(Number(a.day)||0),0,1e9);
    for(const k of ['h','p','w','gold','orders'])a[k]=cl(Math.floor(Number(a[k])||0),0,1e12);
    if(a.day!==P.day){a.day=P.day;a.h=a.p=a.w=a.gold=0}
    return a;
  },
  reportError(error){
    const now=Date.now();if(now-this.errorAt<30000)return;this.errorAt=now;
    console.error('Otomasyon güncellemesi başarısız; bu kare atlandı:',error);
    this.report='⚠ Otomasyon güncellemesi durdu; ayrıntı konsola yazıldı.';
    chat('OTOMASYON','⚠️','Otomasyon güncellemesi durdu; hata ayrıntısı konsolda.',1);
  },
  cap(){return this.CAP[this.A().golem]||0},
  plots(){return WORLD_DATA.home?.farmPlots||[]},
  /* En kârlı ve mevsime sığan tohumu seç (tedarik açıksa gerekirse satın alır) */
  bestSeed(){
    const a=this.A(),season=FARM.seasonIdx(),left=28-FARM.dayOf();
    const fit=k=>{const c=CROPS[k];return c&&c.se.includes(season)&&(c.rg>0||c.d<=left)};
    const score=k=>{const c=CROPS[k];return c.val*(c.rg?1.4:1)/c.d};
    let best=null;
    for(const k in P.seeds)if((P.seeds[k]||0)>0&&fit(k)&&(!best||score(k)>score(best.k)))best={k,buy:false};
    if(!best&&a.supply){
      for(const k in CROPS)if(fit(k)&&P.gold>=Math.round(CROPS[k].cost*1.3)+30&&(!best||score(k)>score(best.k)))best={k,buy:true};
    }
    return best;
  },
  /* Öncelik: hasat > sulama (kuruyanlar önce) > temizlik > ekim; yakın olan tercih edilir */
  pick(fromX,fromY,skipDist){
    const wet=isWetWeather()||P.hasSprinkler,seed=this.bestSeed();let best=null;
    for(const p of this.plots()){
      if((p.autoBlock||0)>P.t)continue;
      let sc=-1,type='';
      if(p.dead){sc=60;type='clear'}
      else if(p.crop&&FARM.ripe(p)){sc=100+CROPS[p.crop].val/10;type='harvest'}
      else if(p.crop&&!wet&&!p.watered&&!(p.moisture>0)){sc=80+(p.dry||0)*8;type='water'}
      else if(!p.crop&&seed){sc=50;type='plant'}
      if(sc<0)continue;
      if(!skipDist)sc-=Math.hypot(fromX-p.x,fromY-p.y)/40;
      if(!best||sc>best.sc)best={p,type,sc,seed};
    }
    return best;
  },
  act(job){
    const a=this.A(),p=job.p;
    if(job.type==='harvest'){
      const had=ITEMS.count(P.inv);
      const cm=curMap;curMap='home';let ok=false;try{ok=FARM.harvest(p)}finally{curMap=cm}
      if(!ok){p.autoBlock=P.t+25;return false}
      a.h++;if(a.sorter)this.sort(true);
    }else if(job.type==='water'){
      p.watered=true;p.moisture=Math.max(p.moisture||0,1);spark(p.x,p.y-4,6,'#7dd3fc',26);a.w++;
    }else if(job.type==='clear'){
      FARM.clearPlot(p);spark(p.x,p.y,6,'#78350f',26);
    }else if(job.type==='plant'){
      const sd=this.bestSeed();if(!sd)return false;
      const c=CROPS[sd.k];
      if(sd.buy){P.gold-=Math.round(c.cost*1.3)}
      else{P.seeds[sd.k]--;if(P.seeds[sd.k]<=0)delete P.seeds[sd.k]}
      p.crop=sd.k;p.age=0;p.stage=0;p.dry=0;p.dead=false;p.watered=false;p.moisture=0;p.fert=0;
      if((P.fert||0)>0){P.fert--;p.fert=1}
      spark(p.x,p.y,6,'#a3e635',26);a.p++;
    }
    a.energy--;return true;
  },
  /* Akıllı sevkiyat: her üründen en iyi 4'ü çantada kalır, fazlası piyasa uygunsa sandığa gider */
  sort(quiet){
    const a=this.A();if(!a.sorter)return 0;
    P.shippingBin=P.shippingBin||[];
    const by={};for(const it of P.inv)if(it.s==='crop')(by[it.k]=by[it.k]||[]).push(it);
    const moved=[];let held=0;
    for(const k in by){
      const arr=by[k].sort((x,y)=>(y.star||1)-(x.star||1));let kept=0;
      for(const it of arr){
        if(kept<4){kept+=ITEMS.qty(it);continue}
        if(ECONOMY.factor(it)<.85){held++;continue}
        moved.push(it);
      }
    }
    if(!moved.length)return 0;
    P.inv=P.inv.filter(it=>!moved.includes(it));
    if(!ITEMS.addMany(P.shippingBin,moved,30)){P.inv=P.inv.concat(moved);return 0}
    if(!quiet)fl(P.x,P.y-30,`📦 ${moved.length} ürün sevkiyata gitti`,'#fde68a');
    return moved.length;
  },
  /* Gece vardiyası: artan güçle sula, hasat et, ek, siparişleri teslim et, fazlayı sevk et */
  nightShift(){
    const a=this.A(),home=this.plots();let w=0,h=0,pl=0,cl=0;
    if(a.golem&&a.energy>0&&home.length){
      for(let i=0;i<90&&a.energy>0;i++){
        const job=this.pick(0,0,true);if(!job)break;
        const t=job.type;if(!this.act(job))continue;
        if(t==='water')w++;else if(t==='harvest')h++;else if(t==='plant')pl++;else cl++;
      }
    }
    let od=0;
    if(a.post&&Array.isArray(P.orders)){
      for(const ord of P.orders){
        if(ord.done)continue;
        if(inventoryRecipe({[ord.reqK]:ord.reqN}).ok){
          ord.done=true;P.gold+=ord.g;P.gems+=ord.m;P.rep=(P.rep||0)+ord.rep;P.townWorkDay=P.day;a.gold+=ord.g;od++;
        }
      }
      a.orders+=od;
    }
    const shipped=this.sort(true);
    a.energy=this.cap();
    const parts=[];
    if(w)parts.push(`${w} sulama`);if(h)parts.push(`${h} hasat`);if(pl)parts.push(`${pl} ekim`);if(cl)parts.push(`${cl} temizlik`);
    if(od)parts.push(`${od} sipariş teslim`);if(shipped)parts.push(`${shipped} ürün sevk`);
    this.report=parts.length?'Gece vardiyası: '+parts.join(' · '):'';
    if(this.report)setTimeout(()=>chat('OTOMASYON','⚙️',this.report,1),1200);
  },
  /* Gün içi: golem sahada çalışır (yalnız çiftlik haritasında) */
  update(dt){
    const a=this.A();
    if(!a.golem||curMap!=='home'||P.dead)return;
    const gm=this.g||(this.g={x:this.RX,y:this.RY+14,job:null,cool:0,t:0,busy:false});
    gm.t+=dt;
    const spd=this.SPD[a.golem];
    const goto=(x,y)=>{const dx=x-gm.x,dy=y-gm.y,d=Math.hypot(dx,dy);if(d>2){gm.x+=dx/d*Math.min(spd*dt,d);gm.y+=dy/d*Math.min(spd*dt,d)}return d};
    if(gm.cool>0){gm.cool-=dt;return}
    if(a.energy<=0){gm.busy=false;goto(this.RX+12,this.RY+14);return}
    if(!gm.job||!this.plots().includes(gm.job.p)){gm.job=this.pick(gm.x,gm.y)}
    if(!gm.job){gm.busy=false;goto(this.RX+12,this.RY+14);return}
    gm.busy=true;
    const d=goto(gm.job.p.x,gm.job.p.y+8);
    if(d<=3){
      const j=gm.job,st=this.act(j);gm.job=null;gm.cool=this.ACT[a.golem];
      if(st)fl(j.p.x,j.p.y-24,{harvest:'🧺',water:'💧',clear:'🧹',plant:'🌱'}[j.type],'#fff');
    }
  },
  drawGolem(x,y){
    const a=this.A(),gm=this.g;if(!gm)return;
    x=Math.round(gm.x);y=Math.round(gm.y);
    const b=Math.round(Math.sin(P.t*3)*1.5)-3,lv=a.golem,low=a.energy<=0;
    const eye=low?'#f87171':gm.busy?'#fbbf24':'#86efac';
    R(x-6,y-1,12,2,'#0003');
    R(x-5,y-11+b,10,8,'#b9893f');R(x-5,y-11+b,10,2,'#e2b866');R(x-5,y-4+b,10,1,'#8a6a2d');
    R(x-4,y-17+b,8,6,'#cfa04d');R(x-4,y-17+b,8,1,'#f0cd80');
    R(x-3,y-15+b,2,2,eye);R(x+1,y-15+b,2,2,eye);
    R(x-8,y-10+b,3,5,'#8a6a2d');R(x+5,y-10+b,3,5,'#8a6a2d');
    R(x,y-20+b,1,3,'#64748b');R(x-1,y-21+b,3,2,low?'#f87171':'#fbbf24');
    if(lv>=2){R(x-6,y-8+b,1,5,'#7c5a22');R(x+5,y-8+b,1,5,'#7c5a22')}
    if(lv>=3){R(x-2,y-9+b,4,3,'#7dd3fc');if(Math.sin(P.t*6)>0)R(x-1,y-8+b,2,1,'#fff')}
    if(Math.hypot(P.x-x,P.y-y)<90){
      const cp=this.cap()||1,f=Math.max(0,Math.min(1,a.energy/cp));
      R(x-7,y-24+b,14,3,'#111827');R(x-6,y-23+b,Math.round(12*f),1,f>.4?'#4ade80':f>0?'#fbbf24':'#ef4444');
    }
  },
  drawStation(x,y){
    x=Math.round(x);y=Math.round(y);const a=this.A();
    R(x-9,y-1,18,3,'#0003');
    R(x-8,y-15,16,15,'#475569');R(x-8,y-15,16,2,'#7b8aa0');R(x-6,y-11,12,8,'#0f172a');
    const f=this.cap()?Math.max(0,Math.min(1,a.energy/this.cap())):0;
    R(x-5,y-8,10,2,'#1e293b');R(x-5,y-8,Math.round(10*f),2,f>.4?'#4ade80':'#fbbf24');
    R(x-4,y-5,2,2,a.golem?'#4ade80':'#64748b');R(x,y-5,2,2,a.sorter?'#fbbf24':'#64748b');R(x+4,y-5,2,2,a.post?'#7dd3fc':'#64748b');
    R(x+5,y-20,1,6,'#94a3b8');R(x+4,y-21,3,2,Math.sin(P.t*4)>0?'#fbbf24':'#78350f');
    if(Math.hypot(P.x-x,P.y-y)<70)T('Otomasyon Merkezi [U]',x,y-26,'#ffd23f');
  },
  near(){return curMap==='home'&&Math.hypot(P.x-this.RX,P.y-this.RY)<30},
  buy(what){
    if(!['golem','sorter','supply','post'].includes(what)){console.warn('Bilinmeyen otomasyon seçeneği:',what);return false}
    const a=this.A();let cost=0;
    if(what==='golem'){if(a.golem>=3)return;cost=this.COST.golem[a.golem]}
    else{if(a[what])return;cost=this.COST[what]}
    if(P.gold<cost){fl(P.x,P.y-26,'Altın yetersiz','#fca5a5',true);return}
    P.gold-=cost;
    if(what==='golem'){a.golem++;a.energy=this.cap();this.g=null}else a[what]=1;
    const W=TOWN_LIFE.wallets;
    if(W['Amca Osman']!=null)W['Amca Osman']+=Math.round(cost*.3);
    if(W['Muhtar Hamdi']!=null)W['Muhtar Hamdi']+=Math.round(cost*.1);
    TOWN_LIFE.log.unshift(`Gün ${P.day}: Osman otomasyon parçası sattı (+${Math.round(cost*.3)}g)`);TOWN_LIFE.log=TOWN_LIFE.log.slice(0,6);
    fl(P.x,P.y-30,'⚙️ Kuruldu!','#6ee7b7',true);playChord([523,659,784,1046],.3,'triangle',.06);sv();this.ui();
  },
  ui(){
    const a=this.A();let m=document.getElementById('auto-panel');
    if(!m){
      m=document.createElement('div');m.id='auto-panel';
      m.style.cssText='position:fixed;inset:0;z-index:9000;display:flex;align-items:center;justify-content:center;background:rgba(5,10,20,.62)';
      m.onclick=e=>{
        if(e.target===m||e.target.id==='ap-x'){m.style.display='none';return}
        const b=e.target.closest('[data-ab]');if(b)AUTO.buy(b.dataset.ab);
      };
      document.body.appendChild(m);
    }
    const row=(icon,name,desc,state,btn)=>`<div style="display:flex;gap:8px;align-items:center;padding:8px 0;border-bottom:1px solid #2a3a5a">
      <div style="font-size:22px;width:30px;text-align:center">${icon}</div>
      <div style="flex:1;min-width:0"><b>${name}</b> <small style="color:#86efac">${state}</small><br><small style="color:#9fb3d9">${desc}</small></div>${btn}</div>`;
    const B=(k,cost,label)=>`<button data-ab="${k}" style="background:${P.gold>=cost?'#16a34a':'#475569'};color:#fff;border:0;border-radius:6px;padding:6px 9px;cursor:pointer;font-size:12px;white-space:nowrap">${label} ${cost}🪙</button>`;
    const gl=a.golem;
    m.innerHTML=`<div style="background:#0f1a2e;color:#e5edff;border:2px solid #4a5d94;border-radius:10px;padding:14px 16px;width:min(94vw,450px);max-height:88vh;overflow:auto;font-family:sans-serif">
      <div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:16px">⚙️ Otomasyon Merkezi</b><button id="ap-x" style="background:#243455;color:#fff;border:0;border-radius:6px;padding:4px 10px;cursor:pointer">✖</button></div>
      <small style="color:#9fb3d9">Altın: <b style="color:#ffd23f">${P.gold}</b> · Her iş 1 güç harcar. Güç yeni günde dolar; kullanılmayan güç gece vardiyasında çalışır.</small>
      ${row('🤖','Çiftlik Golemi',gl?`Sv.${gl}: hasat, sulama, temizlik, ekim. Güç ${a.energy}/${this.cap()}`:'Tarlayı kendi başına işler. Kuraklığa karşı kuruyanlara öncelik verir.',gl?`Sv.${gl}/3`:'',gl>=3?'':B('golem',this.COST.golem[gl],gl?'Yükselt':'Satın al'))}
      ${row('📦','Akıllı Sevkiyat','Her ekin türünden en iyi 4 ürün çantada kalır; fazlası, piyasa fiyatı düşük değilse sandığa gider.',a.sorter?'✔ Açık':'',a.sorter?'':B('sorter',this.COST.sorter,'Kur'))}
      ${row('🌱','Otomatik Tedarik','Tohum bitince mevsime ve kalan güne sığan en kârlı tohumu alır; en az 30🪙 yedek bırakır.',a.supply?'✔ Açık':'',a.supply?'':B('supply',this.COST.supply,'Kur'))}
      ${row('🕊️','Posta Güvercini','Çantandaki malzemeyle kasaba siparişlerini gece kendisi teslim eder.',a.post?'✔ Açık':'',a.post?'':B('post',this.COST.post,'Kur'))}
      <div style="margin-top:10px;font-size:12px;color:#cbd5e1">Bugün: 🧺 ${a.h} hasat · 🌱 ${a.p} ekim · 💧 ${a.w} sulama${a.post?` · 📜 toplam ${a.orders} sipariş`:''}</div>
      ${this.report?`<div style="margin-top:6px;font-size:12px;color:#fde68a">🌙 ${this.report}</div>`:''}
    </div>`;
    m.style.display='flex';
  }
};
window.addEventListener('keydown',e=>{
  if((e.key==='u'||e.key==='U')&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&curMap==='home'&&!/INPUT|TEXTAREA/.test((e.target||{}).tagName||'')){
    const m=document.getElementById('auto-panel');
    if(m&&m.style.display==='flex')m.style.display='none';else AUTO.ui();
  }
});

