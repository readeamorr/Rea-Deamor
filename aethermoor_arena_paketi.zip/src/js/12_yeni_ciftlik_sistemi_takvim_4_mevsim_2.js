/* ===== YENİ ÇİFTLİK SİSTEMİ: Takvim, 4 Mevsim, 22 Ekin, Kalite, Gübre, Tohum Kesesi ===== */
const SEASONS=[
  {n:'İlkbahar',icon:'🌸',col:'#86efac'},
  {n:'Yaz',icon:'☀️',col:'#fde047'},
  {n:'Sonbahar',icon:'🍂',col:'#fb923c'},
  {n:'Kış',icon:'❄️',col:'#bae6fd'}
];
// se: yetiştiği mevsimler (0 İlkbahar,1 Yaz,2 Sonbahar,3 Kış) · d: olgunlaşma günü · rg: tekrar ürün verme süresi (gün)
const CROPS={
  wheat:{n:'Buğday',icon:'🌾',se:[0,1,2],d:4,rg:0,cost:5,val:22,shape:'grain',leaf:'#a3e635',fruit:'#facc15'},
  carrot:{n:'Havuç',icon:'🥕',se:[0,2],d:3,rg:0,cost:8,val:32,shape:'root',leaf:'#22c55e',fruit:'#ea580c'},
  potato:{n:'Patates',icon:'🥔',se:[0,2],d:5,rg:0,cost:10,val:42,shape:'root',leaf:'#16a34a',fruit:'#a16207'},
  onion:{n:'Soğan',icon:'🧅',se:[0,2],d:4,rg:0,cost:9,val:36,shape:'root',leaf:'#4ade80',fruit:'#e9d5ff'},
  cabbage:{n:'Lahana',icon:'🥬',se:[0,2],d:6,rg:0,cost:14,val:52,shape:'leaf',leaf:'#22c55e',fruit:'#86efac'},
  pea:{n:'Bezelye',icon:'🫛',se:[0],d:5,rg:2,cost:12,val:18,shape:'vine',leaf:'#4ade80',fruit:'#22c55e'},
  berry:{n:'Çilek',icon:'🍓',se:[0],d:6,rg:2,cost:15,val:34,shape:'bush',leaf:'#15803d',fruit:'#e11d48'},
  tulip:{n:'Lale',icon:'🌷',se:[0],d:4,rg:0,cost:10,val:38,shape:'flower',leaf:'#4ade80',fruit:'#f472b6'},
  corn:{n:'Mısır',icon:'🌽',se:[1,2],d:6,rg:3,cost:10,val:27,shape:'tall',leaf:'#16a34a',fruit:'#fde047'},
  tomato:{n:'Domates',icon:'🍅',se:[1],d:5,rg:2,cost:12,val:29,shape:'bush',leaf:'#15803d',fruit:'#ef4444'},
  melon:{n:'Kavun',icon:'🍈',se:[1],d:8,rg:0,cost:25,val:110,shape:'vine',leaf:'#16a34a',fruit:'#bef264'},
  pepper:{n:'Biber',icon:'🌶️',se:[1],d:5,rg:2,cost:14,val:30,shape:'bush',leaf:'#15803d',fruit:'#dc2626'},
  blueberry:{n:'Yaban Mersini',icon:'🫐',se:[1],d:7,rg:3,cost:20,val:40,shape:'bush',leaf:'#166534',fruit:'#3b82f6'},
  sunflower:{n:'Ayçiçeği',icon:'🌻',se:[1,2],d:6,rg:0,cost:15,val:66,shape:'tall',flower:true,leaf:'#16a34a',fruit:'#facc15'},
  eggplant:{n:'Patlıcan',icon:'🍆',se:[1],d:6,rg:2,cost:16,val:35,shape:'bush',leaf:'#15803d',fruit:'#7c3aed'},
  pumpkin:{n:'Balkabağı',icon:'🎃',se:[2],d:8,rg:0,cost:20,val:92,shape:'vine',leaf:'#15803d',fruit:'#ea580c'},
  grape:{n:'Üzüm',icon:'🍇',se:[2],d:8,rg:3,cost:28,val:52,shape:'vine',leaf:'#166534',fruit:'#7e22ce'},
  yam:{n:'Tatlı Patates',icon:'🍠',se:[2],d:6,rg:0,cost:15,val:62,shape:'root',leaf:'#a855f7',fruit:'#b45309'},
  cranberry:{n:'Kızılcık',icon:'🍒',se:[2],d:7,rg:3,cost:22,val:44,shape:'bush',leaf:'#14532d',fruit:'#be123c'},
  turnip:{n:'Kış Şalgamı',icon:'🫚',se:[3],d:5,rg:0,cost:8,val:36,shape:'root',leaf:'#4ade80',fruit:'#e9d5ff'},
  snowdrop:{n:'Kardelen',icon:'❄️',se:[3],d:4,rg:0,cost:14,val:60,shape:'flower',flower:true,leaf:'#4ade80',fruit:'#e0f2fe'},
  kale:{n:'Kara Lahana',icon:'🥦',se:[3],d:6,rg:0,cost:12,val:52,shape:'leaf',leaf:'#166534',fruit:'#22c55e'},
  star_berry:{n:'Yıldız Çileği',icon:'⭐',se:[0,1,2],d:7,rg:3,cost:35,val:88,shape:'bush',leaf:'#15803d',fruit:'#facc15',rare:true},
  mana_rose:{n:'Aether Gülü',icon:'🔮',se:[0,1,2,3],d:6,rg:3,cost:45,val:115,shape:'flower',flower:true,leaf:'#3b82f6',fruit:'#c084fc',rare:true},
  sun_melon:{n:'Altın Kavun',icon:'☀️',se:[1,2],d:8,rg:0,cost:55,val:175,shape:'vine',leaf:'#22c55e',fruit:'#fde047',rare:true},
  ancient_fruit:{n:'Kadim Aether Meyvesi',icon:'👑',se:[0,1,2,3],d:9,rg:4,cost:120,val:240,shape:'tall',leaf:'#0ea5e9',fruit:'#f43f5e',rare:true}
};
const FARM_BOUNDS={x0:15,x1:22,y0:25,y1:33,max:72};

const GARDEN_BEDS={
  1:{id:1,name:'1. Bahçe Yatağı (Başlangıç Sebze Yatağı)',sub:'4×3 · 12 Simetrik Parsel',x0:15,x1:18,y0:26,y1:28,cost:null,
     coords:[[15,26],[16,26],[17,26],[18,26],[15,27],[16,27],[17,27],[18,27],[15,28],[16,28],[17,28],[18,28]]},
  2:{id:2,name:'2. Bahçe Yatağı (Güney Bereket Yatağı)',sub:'4×3 · +12 Parsel (Toplam 24)',x0:15,x1:18,y0:30,y1:32,cost:{gold:150,wood:6,stone:4},
     coords:[[15,30],[16,30],[17,30],[18,30],[15,31],[16,31],[17,31],[18,31],[15,32],[16,32],[17,32],[18,32]]},
  3:{id:3,name:'3. Bahçe Yatağı (Doğu Kraliyet Yatağı)',sub:'3×6 · +18 Parsel (Toplam 42)',x0:20,x1:22,y0:26,y1:32,cost:{gold:400,wood:12,stone:8},
     coords:[[20,26],[21,26],[22,26],[20,27],[21,27],[22,27],[20,28],[21,28],[22,28],[20,30],[21,30],[22,30],[20,31],[21,31],[22,31],[20,32],[21,32],[22,32]]}
};

const ORCHARD_TREES={
  apple:{k:'apple',n:'Elma Ağacı',fruitName:'Taze Elma',icon:'🍎',hp:25,mp:0,val:15,desc:'+25 Can taze çiftlik elması',foliage:['#2a6428','#3a8133','#4fa044'],fruitCol:'#ef4444'},
  peach:{k:'peach',n:'Şeftali Ağacı',fruitName:'Taze Şeftali',icon:'🍑',hp:25,mp:10,val:20,desc:'+25 Can · +10 Mana sulu şeftali',foliage:['#3d7a33','#44853a','#65a34e'],fruitCol:'#fb7185'},
  cherry:{k:'cherry',n:'Kiraz Ağacı',fruitName:'Kızıl Kiraz',icon:'🍒',hp:35,mp:15,buff:'spd',dur:180,val:32,cost:{gold:180,wood:4},desc:'+35 Can · +15 Mana · 3dk Hız',foliage:['#2d6a4f','#40916c','#74c69d'],fruitCol:'#e11d48'},
  lemon:{k:'lemon',n:'Altın Limon Ağacı',fruitName:'Altın Limon',icon:'🍋',hp:30,mp:40,buff:'crit',dur:180,val:40,cost:{gold:240,wood:4},desc:'+30 Can · +40 Mana · 3dk Kritik',foliage:['#365314','#4d7c0f','#84cc16'],fruitCol:'#facc15'},
  pomegranate:{k:'pomegranate',n:'Kızıl Nar Ağacı',fruitName:'Bereket Narı',icon:'🌺',hp:55,mp:30,buff:'atk',dur:240,val:52,cost:{gold:320,wood:6},desc:'+55 Can · +30 Mana · 4dk Saldırı',foliage:['#1e4620','#2e6f40','#52b788'],fruitCol:'#be123c'},
  golden_apple:{k:'golden_apple',n:'Kraliyet Altın Elması',fruitName:'Altın Elma',icon:'🌟',hp:100,mp:60,buff:'atk',dur:360,val:95,cost:{gold:600,gems:5,wood:8},desc:'+100 Can · +60 Mana · 6dk Saldırı',foliage:['#713f12','#a16207','#eab308'],fruitCol:'#fde047'}
};

const ORCHARD_SLOTS=[
  {slot:0,type:'apple',gx:15,gy:16,defaultOpen:true},
  {slot:1,type:'apple',gx:17,gy:16,defaultOpen:true},
  {slot:2,type:'peach',gx:19,gy:16,defaultOpen:true},
  {slot:3,type:'peach',gx:21,gy:16,defaultOpen:true},
  {slot:4,type:'cherry',gx:15,gy:18.5,defaultOpen:false},
  {slot:5,type:'lemon',gx:17,gy:18.5,defaultOpen:false},
  {slot:6,type:'pomegranate',gx:19,gy:18.5,defaultOpen:false},
  {slot:7,type:'golden_apple',gx:21,gy:18.5,defaultOpen:false}
];

const SOIL_UPGRADES={
  1:{lv:1,name:'Humuslu Organik Toprak',cost:{gold:120,fert:2},desc:'Tüm hasatlarda +%15 ekstra mahsul ve +%10 Gümüş/Altın kalite şansı sağlar.'},
  2:{lv:2,name:'Solucan Gübreli Bereket Toprağı',cost:{gold:280,fert:4},desc:'Ekinler her gece %35 şansla +1 gün hızlı büyür; ekstra mahsul şansı +%25 olur.'},
  3:{lv:3,name:'Aethermoor Kristal Toprağı',cost:{gold:650,gems:4,fert:6},desc:'Tüm ekinler her gece garantili hızlı büyür ve ★★★ Altın Yıldız şansı 2 katına çıkar!'}
};

const SPRINKLER_UPGRADES={
  1:{lv:1,name:'Bakır Fıskiye Sistemi',cost:{gold:150,wood:0},desc:'Her sabah tüm açık bahçe yataklarını otomatik olarak sular.'},
  2:{lv:2,name:'Basınçlı Gümüş Fıskiye',cost:{gold:350,iron_ore:3},desc:'Toprak nemini 2 kat korur (2 gün nem) ve büyüme verimini artırır.'},
  3:{lv:3,name:'Kristal Bereket Fıskiyesi',cost:{gold:700,gems:5},desc:'Her sabah sulanan ekinlere %30 şansla ücretsiz sıvı gübre bereketi kazandırır!'}
};

const FARM={
  uiTab:'beds',
  selectedPlotId:null,
  cfg(){
    if(!P.adventure)P.adventure={};
    if(!P.adventure.home||typeof P.adventure.home!=='object')P.adventure.home={cleared:[],fruitDays:{},ores:{}};
    const h=P.adventure.home;
    h.beds=cl(Math.floor(Number(h.beds)||1),1,3);
    h.soilLv=cl(Math.floor(Number(h.soilLv)||0),0,3);
    h.sprinklerLv=cl(Math.floor(Number(h.sprinklerLv)||(P.hasSprinkler?1:0)),0,3);
    if(h.sprinklerLv>=1)P.hasSprinkler=true;
    h.greenhouse=h.greenhouse===true;
    if(!Array.isArray(h.orchard)||!h.orchard.length)h.orchard=[0,1,2,3];
    else h.orchard=[...new Set([0,1,2,3,...h.orchard.filter(n=>Number.isInteger(n)&&n>=0&&n<ORCHARD_SLOTS.length)])];
    h.fruitDays=h.fruitDays&&typeof h.fruitDays==='object'?h.fruitDays:{};
    h.totalHarvests=Math.max(0,Math.floor(Number(h.totalHarvests)||0));
    h.milestoneClaimed=Math.max(0,Math.floor(Number(h.milestoneClaimed)||0));
    h.contractsDay=Math.max(0,Math.floor(Number(h.contractsDay)||0));
    h.contractsDone=Array.isArray(h.contractsDone)?h.contractsDone.filter(n=>Number.isInteger(n)&&n>=0&&n<3):[];
    if(h.contractsDay!==P.day){h.contractsDay=P.day||1;h.contractsDone=[]}
    return h;
  },
  combatPerks(){
    const h=P.adventure?.home||{},plots=WORLD_DATA?.home?.farmPlots||[];
    const wetLive=plots.filter(p=>p.crop&&!p.dead&&p.watered).length;
    const trees=(h.orchard||[0,1,2,3]).length;
    return {
      vitality:wetLive>=6,
      wetLive,
      orchard:trees>=6,
      trees,
      master:!!(h.greenhouse&&(h.beds||1)>=3)
    };
  },
  bedOf(gx,gy){
    for(const b of [1,2,3]){
      if(GARDEN_BEDS[b].coords.some(([x,y])=>x===gx&&y===gy))return b;
    }
    return 1;
  },
  syncBeds(){
    const md=WORLD_DATA.home;if(!md)return;
    const h=this.cfg(),fp=md.farmPlots||(md.farmPlots=[]);
    const byCoord=new Map();
    for(const p of fp){
      const gx=Math.floor(p.x/TS),gy=Math.floor(p.y/TS);
      byCoord.set(gx+':'+gy,p);
    }
    // Eğer kayıtta eski koordinatlarda (örn. 19,26) ekili ürün varsa ve yeni yatakta boş yer varsa koru
    const orphanCrops=fp.filter(p=>{
      const gx=Math.floor(p.x/TS),gy=Math.floor(p.y/TS);
      return p.crop&&![1,2,3].some(b=>b<=h.beds&&GARDEN_BEDS[b].coords.some(([x,y])=>x===gx&&y===gy));
    });
    const nextPlots=[];
    let id=0;
    for(let b=1;b<=h.beds;b++){
      for(const [gx,gy] of GARDEN_BEDS[b].coords){
        const px=gx*TS+8,py=gy*TS+8,key=gx+':'+gy;
        let existing=byCoord.get(key);
        if(!existing&&orphanCrops.length){
          const donor=orphanCrops.shift();
          existing={...donor,x:px,y:py};
        }
        if(existing){
          existing.id=id++;existing.bed=b;existing.x=px;existing.y=py;
          nextPlots.push(existing);
        }else{
          nextPlots.push({
            id:id++,bed:b,x:px,y:py,crop:null,stage:0,age:0,t:0,
            watered:P.hasSprinkler||h.sprinklerLv>=1,moisture:(P.hasSprinkler||h.sprinklerLv>=1)?1:0,fert:0,dry:0
          });
        }
      }
    }
    fp.length=0;fp.push(...nextPlots);
    if(curMap==='home')farmPlots=fp;

    // Meyve bahçesi ağaçlarını senkronize et
    md.fruitTrees=md.fruitTrees||[];
    for(let i=md.objs.length-1;i>=0;i--){
      if(md.objs[i].k==='apple_tree'||md.objs[i].k==='peach_tree')md.objs.splice(i,1);
    }
    md.fruitTrees.length=0;
    for(const slot of ORCHARD_SLOTS){
      if(!h.orchard.includes(slot.slot))continue;
      const tDef=ORCHARD_TREES[slot.type]||ORCHARD_TREES.apple;
      const x=slot.gx*TS,y=slot.gy*TS;
      const k=slot.type==='peach'?'peach_tree':'apple_tree';
      const dayKey=slot.type+':'+x+':'+y,legacyKey=k+':'+x+':'+y;
      const harvestedToday=h.fruitDays[dayKey]===P.day||h.fruitDays[legacyKey]===P.day;
      const treeObj={slot:slot.slot,k,treeType:slot.type,x,y,r:5,isPeach:slot.type==='peach',fruitReady:!harvestedToday};
      md.fruitTrees.push(treeObj);
      md.objs.push(treeObj);
    }
  },
  seasonIdx(){return Math.floor(((P.day||1)-1)/28)%4},
  dayOf(){return ((P.day||1)-1)%28+1},
  year(){return Math.floor(((P.day||1)-1)/112)+1},
  canGrowInSeason(cropKey,season=this.seasonIdx()){
    const c=CROPS[cropKey];if(!c)return false;
    return this.cfg().greenhouse||c.se.includes(season);
  },
  stageOf(p){
    const c=CROPS[p.crop]; if(!c)return 0;
    const r=(p.age||0)/c.d;
    return r>=1?3:r>=.6?2:r>=.25?1:0;
  },
  ripe(p){return !!(p&&p.crop&&!p.dead&&CROPS[p.crop]&&(p.age||0)>=CROPS[p.crop].d)},
  plotAt(px,py){return farmPlots&&farmPlots.find(p=>Math.abs(p.x-px)<8&&Math.abs(p.y-py)<8)},
  inFarm(gx,gy){return curMap==='home'&&gx>=FARM_BOUNDS.x0&&gx<=FARM_BOUNDS.x1&&gy>=FARM_BOUNDS.y0&&gy<=FARM_BOUNDS.y1},
  nearCampus(){return curMap==='home'&&P.x>=13*TS&&P.x<=24*TS&&P.y>=23*TS&&P.y<=34.5*TS},
  nearOrchard(){return curMap==='home'&&P.x>=13.5*TS&&P.x<=22.5*TS&&P.y>=14.5*TS&&P.y<=20.5*TS},
  seedCount(){let n=0;for(const k in P.seeds)n+=P.seeds[k]||0;return n},
  clearPlot(p){p.crop=null;p.dead=false;p.age=0;p.stage=0;p.fert=0;p.dry=0;p.t=0},

  /* --- Yeni gün (uyuyunca) --- */
  newDay(){
    if(curMap!=='inside'||Math.hypot(P.x-22*TS,P.y-8*TS)>=24||!DAY_CLOCK.late())return false;
    this.syncBeds();
    const h=this.cfg();DAY_RECAP.closeDay();
    P.day=(P.day||1)+1;DAY_CLOCK.reset();try{AUTO.nightShift()}catch(e){console.error(e)}try{TOWN_LIFE.settleDay()}catch(e){console.error('Kasaba günlük yerleşimi tamamlanamadı:',e)}
    if(P.q===QS.length-1&&P.bounties>0)P.qn=0;
    refreshWildResources(WORLD_DATA.world);refreshWildResources(WORLD_DATA.frontier);
    const s=this.seasonIdx(), first=((P.day-1)%28===0);
    let died=0,grew=0,ripeN=0;
    const homePlots=WORLD_DATA.home?.farmPlots||[];
    const hasAutoWater=P.hasSprinkler||h.sprinklerLv>=1||isWetWeather();
    for(const p of homePlots){
      if(!p.crop||p.dead)continue;
      const c=CROPS[p.crop];
      if(!c){this.clearPlot(p);continue}
      if(!h.greenhouse&&!c.se.includes(s)){p.dead=true;died++;continue}
      const moisture=Number.isFinite(p.moisture)?p.moisture:(p.watered?1:0);
      if(p.watered||moisture>0||hasAutoWater){
        const soilBonus=h.soilLv>=3?1:(h.soilLv===2&&Math.random()<.35)?1:0;
        const fertBonus=(p.fert&&Math.random()<.3)?1:0,beforeAge=p.age||0;
        if(beforeAge<c.d)p.age=Math.min(c.d,beforeAge+1+soilBonus+fertBonus);
        if((p.age||0)>beforeAge)grew++;
        p.dry=0;
      }else{
        p.dry=(p.dry||0)+1;
        if(p.dry>=4){p.dead=true;died++}
      }
      if(h.sprinklerLv>=3&&!p.fert&&Math.random()<.3)p.fert=1;
      p.stage=this.stageOf(p);
      if(this.ripe(p))ripeN++;
      p.moisture=hasAutoWater?(h.sprinklerLv>=2||friendHearts('dede')>=5?2:1):Math.max(0,moisture-1);
      p.watered=p.moisture>0;
    }
    h.lastFarmReport={day:P.day,grew,ripe:ripeN,died,autoWater:hasAutoWater,weather:String(weather.type||'clear')};
    const S0=SEASONS[s];
    setTimeout(()=>{
      if(first)fl(P.x,P.y-34,`${S0.icon} ${S0.n} Başladı!`,S0.col,true);
      else fl(P.x,P.y-34,`${S0.icon} ${S0.n} · ${this.dayOf()}. Gün`,S0.col,true);
      if(ripeN)fl(P.x,P.y-46,`🌾 ${ripeN} ekin hasada hazır!`,'#6ee7b7',true);
      if(died)fl(P.x,P.y-58,`🥀 ${died} ekin soldu (kuraklık/mevsim)`,'#fca5a5',true);
    },600);
    ADVENTURE.newDay();this.updCal();sv();return true;
  },

  /* --- Takvim HUD --- */
  updCal(){
    const el=$('cal'); if(!el)return;
    const S0=SEASONS[this.seasonIdx()];
    const clock=DAY_CLOCK.label();
    el.innerHTML=`${S0.icon} <b style="color:${S0.col}">${S0.n}</b> ${this.dayOf()}/28 · <b class="cal-time">${clock}</b> <span class="cal-year">· Yıl ${this.year()}</span>`;
    el.title=`${S0.n} ${this.dayOf()}/28 · Yıl ${this.year()} · ${DAY_CLOCK.detail()}`;
    this._ld=P.day;this._clock=clock;
  },
  tick(dt){if(this._ld!==P.day||this._clock!==DAY_CLOCK.label())this.updCal()},

  /* --- Tohum kesesi --- */
  curSeed(){
    const s=this.seasonIdx();
    if(P.seedSel&&(P.seeds[P.seedSel]||0)>0&&CROPS[P.seedSel]&&this.canGrowInSeason(P.seedSel,s))return P.seedSel;
    if(P.seedSel)P.seedSel=null;
    return null;
  },
  cycleSeed(){
    const keys=Object.keys(P.seeds).filter(k=>(P.seeds[k]||0)>0&&CROPS[k]&&this.canGrowInSeason(k));
    if(!keys.length){fl(P.x,P.y-26,'Tohum kesen boş! Bahçe panelinden tohum al.','#ff5d5d');return}
    let i=keys.indexOf(P.seedSel); i=(i+1)%keys.length; P.seedSel=keys[i];
    this.announceSeed(); updHotbarUI(); sv();
  },
  announceSeed(){
    const k=this.curSeed();
    if(!k){fl(P.x,P.y-26,'🌱 Tohum yok · Bahçe panelinden al','#ff5d5d');return}
    const c=CROPS[k], ok=this.canGrowInSeason(k);
    fl(P.x,P.y-36,`${c.icon} ${c.n} Tohumu ×${P.seeds[k]}${ok?'':' (bu mevsim değil!)'}`,ok?'#a7f3d0':'#fca5a5',true);
  },

  /* --- Ekim / Hasat / Sulama / Toplu İşlemler --- */
  fertilizeFront(){
    if(curMap!=='home')return 'Gübrelemek için çiftliğe dön.';
    const target=tileAhead(),x=target.gx*TS+8,y=target.gy*TS+8;
    const p=this.plotAt(x,y)||(WORLD_DATA.home?.farmPlots||[]).find(pl=>pl.crop&&!pl.dead&&!pl.fert);
    if(!p||!p.crop||p.dead)return 'Gübrelenecek yaşayan bir ekin bulunamadı.';
    if(p.fert)return 'Bu ekin zaten gübreli.';if(!(P.fert>0))return 'Pazardan gübre al veya atölyede üret.';
    P.fert--;p.fert=1;spark(p.x,p.y-6,10,'#b4ef98',30);sv();return '✓ Ekin gübrelendi · kalite ve büyüme şansı arttı.';
  },
  plant(p,seedKey=null,quiet=false){
    const homePlots=WORLD_DATA.home?.farmPlots||[];
    if(curMap!=='home'||!homePlots.includes(p)||p.crop||p.dead)return false;
    const k=seedKey||this.curSeed();
    if(!k||!(P.seeds[k]>0)){if(!quiet)fl(p.x,p.y-16,'Tohum kesen boş!','#ff5d5d');return false}
    const c=CROPS[k], s=this.seasonIdx(), h=this.cfg();
    if(!this.canGrowInSeason(k,s)){if(!quiet){fl(p.x,p.y-16,`${c.n} bu mevsimde yetişmez!`,'#fca5a5');sfx(220,.1,'square',.04)}return false}
    if(!(friendHearts('osman')>=5&&Math.random()<.15)){P.seeds[k]--;if(P.seeds[k]<=0)delete P.seeds[k]}
    const autoWet=P.hasSprinkler||h.sprinklerLv>=1||isWetWeather();
    p.crop=k;p.age=0;p.stage=0;p.dry=0;p.dead=false;
    p.moisture=autoWet?(h.sprinklerLv>=2||friendHearts('dede')>=5?2:1):0;
    p.watered=p.moisture>0;
    p.fert=0;p.introPlant=ONBOARD.active();
    ONBOARD.event('plant');
    if(p.watered)ONBOARD.event('water');
    const left=28-this.dayOf();
    spark(p.x,p.y,8,'#a3e635',30);
    if(!quiet){
      fl(p.x,p.y-14,`🌱 ${c.n} ekildi${p.fert?' (gübreli)':''}${!h.greenhouse&&left<c.d&&!c.rg&&!c.se.includes((s+1)%4)?' ⚠ mevsim yetmeyebilir':''}`,'#a7f3d0');
      sfx(650,.1,'sine',.04);
    }
    updHotbarUI(); sv(); return true;
  },
  waterPlot(p,quiet=false){
    if(!p||p.dead)return false;
    const h=this.cfg(),maxM=(h.sprinklerLv>=2||friendHearts('dede')>=5)?2:1;
    if(p.watered&&(p.moisture||1)>=maxM)return false;
    // Çiftlik kuyusu hemen bahçenin yanında olduğu için bahçe içinde kova otomatik tazelenir
    if((P.waterCan||0)<=0)P.waterCan=20;
    P.waterCan=Math.max(0,(P.waterCan||20)-1);
    if(P.waterCan===0)P.waterCan=20;
    p.moisture=maxM;p.watered=true;
    if(p.introPlant||ONBOARD.active())ONBOARD.event('water');
    spark(p.x,p.y-6,10,'#38bdf8',35);
    if(!quiet){fl(p.x,p.y-14,'💧 Sulandı!','#38bdf8');sfx(800,.09,'sine',.04)}
    addMasteryXp('farm',4);updHotbarUI();sv();return true;
  },
  harvest(p,quiet=false){
    const c=CROPS[p.crop];if(curMap!=='home'||!WORLD_DATA.home.farmPlots.includes(p)||!c||!this.ripe(p))return false;
    const fLvl=P.skills?.farm?.lvl||1,h=this.cfg();
    const extraChance=.12+fLvl*.03+(p.fert?.18:0)+(h.soilLv===1?.15:h.soilLv>=2?.25:0);
    let cnt=1; if(Math.random()<extraChance)cnt++;
    const goldBase=.04+fLvl*.025+(p.fert?.12:0)+(h.soilLv>=1?.08:0);
    const gold=h.soilLv>=3?goldBase*2:goldBase;
    const silver=.2+fLvl*.03+(p.fert?.15:0)+(h.soilLv>=1?.1:0);
    let best=1;const harvest=[];
    for(let i=0;i<cnt;i++){
      const r=Math.random(), star=r<gold?3:r<gold+silver?2:1; best=Math.max(best,star);
      const tag=star===3?'★★★ Altın ':star===2?'★ Gümüş ':'', mult=star===3?3:star===2?1.7:1;
      harvest.push({s:'crop',k:p.crop,star,n:tag+c.n,icon:c.icon,val:Math.round(c.val*mult),
        desc:star===3?'(Altın Kalite - 3 Kat Değer)':star===2?'(Gümüş Kalite - 1.7 Kat Değer)':'Yemekte veya satışta kullanılır'});
    }
    if(!ITEMS.addMany(P.inv,harvest)){if(!quiet)fl(p.x,p.y-22,`Hasadın ${cnt} ürününe yer aç; ekin korunuyor.`,'#facc15');return false}
    h.totalHarvests=(h.totalHarvests||0)+cnt;WORLD_EVENTS.progress('harvest',cnt);
    if(p.crop==='wheat')ONBOARD.event('harvest',cnt);
    spark(p.x,p.y-6,14,c.fruit,45);
    if(!quiet){
      fl(p.x,p.y-18,best===3?`★★★ ${c.n} ×${cnt}`:best===2?`★ ${c.n} ×${cnt}`:`+${cnt} ${c.icon} ${c.n}`,best===3?'#ffd23f':best===2?'#c084fc':'#6ee7b7',true);
      playChord(best===3?[523,659,784,1046]:[523,659,784],.2,'triangle',.05);
    }
    addMasteryXp('farm',10+c.d);
    if(c.rg){p.age=c.d-c.rg;p.stage=this.stageOf(p);p.watered=false;p.moisture=0;if(!quiet)fl(p.x,p.y-30,`🔁 ${c.rg} gün sonra yeniden`,'#facc15')}
    else this.clearPlot(p);
    sv();return cnt;
  },
  harvestAll(){
    if(curMap!=='home')return 'Hasat için çiftliğe dön.';
    this.syncBeds();
    let totalPlots=0,totalItems=0;
    for(const p of WORLD_DATA.home.farmPlots){
      if(this.ripe(p)){
        const got=this.harvest(p,true);
        if(got){totalPlots++;totalItems+=got}else break;
      }
    }
    if(totalPlots>0){
      fl(P.x,P.y-26,`🧺 ${totalPlots} Parselden ${totalItems} Mahsul Hasat Edildi!`,'#ffd23f',true);
      playChord([523,659,784,1046],.28,'triangle',.06);
      return `✓ ${totalPlots} parsel hasat edildi (+${totalItems} ürün çantaya eklendi).`;
    }
    return 'Şu an hasada hazır olgun mahsul yok.';
  },
  waterAll(){
    if(curMap!=='home')return 'Sulama için çiftliğe dön.';
    this.syncBeds();
    let cnt=0;
    for(const p of WORLD_DATA.home.farmPlots){
      if(!p.dead&&(!p.watered||!(p.moisture>0))){
        if(this.waterPlot(p,true))cnt++;
      }
    }
    P.waterCan=20;updHotbarUI();
    if(cnt>0){
      fl(P.x,P.y-26,`💧 ${cnt} Bahçe Parseli Sulandı!`,'#38bdf8',true);
      playChord([440,554,659],.22,'sine',.05);
      return `✓ ${cnt} parsel sulandı ve kova kuyudan dolduruldu (20/20).`;
    }
    return 'Tüm parseller zaten sulu ve nemli!';
  },
  plantAll(seedKey=null){
    if(curMap!=='home')return 'Ekim için çiftliğe dön.';
    this.syncBeds();
    const k=seedKey||this.curSeed();
    if(!k||!(P.seeds[k]>0))return 'Seçili tohumdan kalmadı. Tohum sekmesinden yeni tohum al veya seç.';
    if(!this.canGrowInSeason(k))return `${CROPS[k].n} bu mevsimde yetişmez (Cam Sera ile 4 mevsim ekilebilir).`;
    let planted=0,watered=0;
    for(const p of WORLD_DATA.home.farmPlots){
      if(p.dead)this.clearPlot(p);
      if(!p.crop&&(P.seeds[k]||0)>0){
        if(this.plant(p,k,true)){
          planted++;
          if(!p.watered&&this.waterPlot(p,true))watered++;
        }
      }
    }
    if(planted>0){
      const c=CROPS[k];
      fl(P.x,P.y-26,`🌱 ${planted} Parsele ${c.icon} ${c.n} Ekildi & Sulandı!`,'#a7f3d0',true);
      playChord([440,554,659,880],.25,'triangle',.05);
      return `✓ ${planted} parsele ${c.n} ekildi ve otomatik sulandı!`;
    }
    return 'Boş bahçe parseli yok veya tohum yetersiz.';
  },
  fertilizeAll(){
    if(curMap!=='home')return 'Gübrelemek için çiftliğe dön.';
    if(!(P.fert>0))return 'Gübre stoğun boş! Tohum & Pazar sekmesinden gübre al.';
    let cnt=0;
    for(const p of WORLD_DATA.home.farmPlots){
      if(p.crop&&!p.dead&&!p.fert&&P.fert>0){
        P.fert--;p.fert=1;spark(p.x,p.y-6,8,'#b4ef98',28);cnt++;
      }
    }
    if(cnt>0){
      fl(P.x,P.y-26,`✨ ${cnt} Ekin Gübrelendi!`,'#86efac',true);
      sfx(740,.12,'sine',.05);sv();
      return `✓ ${cnt} ekin gübrelendi (Kalite ve hızlı büyüme şansı arttı).`;
    }
    return 'Gübrelenecek gübresiz ekin bulunamadı.';
  },
  clearDeadAll(){
    let cnt=0;
    for(const p of WORLD_DATA.home.farmPlots||[]){
      if(p.dead){this.clearPlot(p);spark(p.x,p.y,8,'#78350f',30);cnt++}
    }
    if(cnt>0){sv();return `✓ ${cnt} solmuş ekin temizlendi.`}
    return 'Temizlenecek solmuş ekin yok.';
  },
  harvestTree(treeObj,quiet=false){
    if(!treeObj||!treeObj.fruitReady)return false;
    const tDef=ORCHARD_TREES[treeObj.treeType||(treeObj.isPeach?'peach':'apple')]||ORCHARD_TREES.apple;
    const item={
      s:'food',k:tDef.k,n:tDef.fruitName,icon:tDef.icon,hp:tDef.hp,mp:tDef.mp||0,
      buff:tDef.buff,duration:tDef.dur||180,val:tDef.val,desc:tDef.desc
    };
    if(!ITEMS.add(P.inv,item)){if(!quiet)fl(P.x,P.y-24,'Çanta dolu; meyveler ağaçta korunuyor.','#facc15');return false}
    treeObj.fruitReady=false;
    const h=this.cfg();
    h.fruitDays[tDef.k+':'+treeObj.x+':'+treeObj.y]=P.day;
    h.fruitDays[treeObj.k+':'+treeObj.x+':'+treeObj.y]=P.day;
    spark(treeObj.x,treeObj.y-14,12,tDef.fruitCol,40);
    if(!quiet){
      fl(treeObj.x,treeObj.y-26,`+1 ${tDef.icon} ${tDef.fruitName}`,'#ffd23f',true);
      sfx(680,.1,'sine',.04);
    }
    addMasteryXp('farm',8);sv();return true;
  },
  harvestOrchardAll(){
    if(curMap!=='home')return 'Meyve toplamak için çiftliğe dön.';
    this.syncBeds();
    let cnt=0;
    for(const t of WORLD_DATA.home.fruitTrees||[]){
      if(t.fruitReady){if(this.harvestTree(t,true))cnt++;else break}
    }
    if(cnt>0){
      fl(P.x,P.y-26,`🍎 Meyve Bahçesinden ${cnt} Taze Meyve Toplandı!`,'#ffd23f',true);
      playChord([523,659,784],.24,'triangle',.05);
      return `✓ ${cnt} ağaçtan taze meyveler toplandı!`;
    }
    return 'Tüm ağaçların bugünkü meyveleri toplandı; yarın sabah yenilenir.';
  },
  unlockBed(bedId){
    const h=this.cfg(),bed=GARDEN_BEDS[bedId];
    if(!bed||h.beds>=bedId)return 'Bu bahçe yatağı zaten açık.';
    if(bedId!==h.beds+1)return 'Önce bir önceki bahçe yatağını açmalısın.';
    const c=bed.cost;
    if(!tryInventoryRecipe({wood:c.wood||0,stone:c.stone||0},[],{gold:c.gold||0}))return `Eksik malzeme veya altın! Gereken: ${c.gold}🪙, ${c.wood} Odun, ${c.stone} Taş.`;
    h.beds=bedId;this.syncBeds();
    fl(P.x,P.y-28,`🌱 ${bed.name} Hizmete Açıldı!`,'#4ade80',true);
    playChord([523,659,784,1046],.35,'triangle',.07);sv();
    return `✓ ${bed.name} açıldı! Yeni parseller ekime hazır.`;
  },
  upgradeSoil(){
    const h=this.cfg(),next=SOIL_UPGRADES[h.soilLv+1];
    if(!next)return 'Toprak kalitesi maksimum seviyede!';
    const c=next.cost;
    if(P.gold<(c.gold||0)||P.gems<(c.gems||0)||(P.fert||0)<(c.fert||0)){
      return `Eksik! Gereken: ${c.gold}🪙${c.gems?` · ${c.gems}💎`:''}${c.fert?` · ${c.fert}🧪 Gübre`:''}`;
    }
    P.gold-=c.gold||0;P.gems-=c.gems||0;P.fert=(P.fert||0)-(c.fert||0);
    h.soilLv=next.lv;
    fl(P.x,P.y-28,`✨ Toprak Islahı Sv.${next.lv}: ${next.name}!`,'#fde047',true);
    playChord([523,659,784,1046],.32,'triangle',.06);sv();
    return `✓ ${next.name} tamamlandı!`;
  },
  upgradeSprinkler(){
    const h=this.cfg(),next=SPRINKLER_UPGRADES[h.sprinklerLv+1];
    if(!next)return 'Fıskiye sistemi maksimum seviyede!';
    const c=next.cost;
    if(!tryInventoryRecipe({wood:c.wood||0,iron_ore:c.iron_ore||0},[],{gold:c.gold||0,gems:c.gems||0})){
      return `Eksik! Gereken: ${c.gold}🪙${c.gems?` · ${c.gems}💎`:''}${c.iron_ore?` · ${c.iron_ore} Demir Cevheri`:''}`;
    }
    h.sprinklerLv=next.lv;P.hasSprinkler=true;
    this.waterAll();
    fl(P.x,P.y-28,`🚰 ${next.name} Kuruldu!`,'#38bdf8',true);
    playChord([523,659,784,1046],.32,'triangle',.06);sv();
    return `✓ ${next.name} kuruldu ve tüm yataklar sulandı!`;
  },
  unlockGreenhouse(){
    const h=this.cfg();
    if(h.greenhouse)return 'Cam Sera zaten kurulu!';
    if(!tryInventoryRecipe({wood:12,stone:8},[],{gold:850,gems:6})){
      return 'Eksik! Gereken: 850🪙 · 6💎 · 12 Odun · 8 Taş.';
    }
    h.greenhouse=true;
    fl(P.x,P.y-28,'🏛️ KRALİYET CAM SERASI KURULDU! (4 Mevsim Tarım)','#a7f3d0',true);
    playChord([523,659,784,1046],.4,'triangle',.08);sv();
    return '✓ Cam Sera kuruldu! Artık 4 mevsim tüm tohumları ekebilirsin, ekinler solmaz!';
  },
  plantOrchardTree(slotIdx){
    const h=this.cfg(),slot=ORCHARD_SLOTS[slotIdx];
    if(!slot||h.orchard.includes(slotIdx))return 'Bu fidan zaten dikili.';
    const tDef=ORCHARD_TREES[slot.type],c=tDef.cost||{gold:200,wood:4};
    if(!tryInventoryRecipe({wood:c.wood||0},[],{gold:c.gold||0,gems:c.gems||0})){
      return `Eksik! Gereken: ${c.gold}🪙${c.gems?` · ${c.gems}💎`:''} · ${c.wood||0} Odun.`;
    }
    h.orchard.push(slotIdx);this.syncBeds();
    fl(P.x,P.y-28,`${tDef.icon} ${tDef.n} Meyve Bahçesine Dikildi!`,'#4ade80',true);
    playChord([523,659,784,1046],.32,'triangle',.06);sv();
    return `✓ ${tDef.n} dikildi ve ilk meyvesini verdi!`;
  },

  /* --- Kolay Bahçe: oyuncuya tek bir günlük bakım işi gösterilir. --- */
  carePlan(){
    const plots=WORLD_DATA.home?.farmPlots||[],sk=this.curSeed();
    const ripe=plots.filter(p=>this.ripe(p)).length;
    const dry=plots.filter(p=>p.crop&&!p.dead&&!this.ripe(p)&&!p.watered).length;
    const dead=plots.filter(p=>p.dead).length;
    const empty=plots.filter(p=>!p.crop&&!p.dead).length;
    const plant=sk?Math.min(empty,P.seeds[sk]||0):0;
    const fruit=(WORLD_DATA.home?.fruitTrees||[]).filter(t=>t.fruitReady).length;
    return {ripe,dry,dead,empty,plant,fruit,sk,tasks:ripe+dry+dead+plant+fruit};
  },
  dailyCare(){
    if(curMap!=='home')return 'Bahçe bakımı için çiftliğe dön.';
    this.syncBeds();
    const done=[];
    let before=this.carePlan();
    if(before.ripe){
      this.harvestAll();
      const left=this.carePlan().ripe,got=before.ripe-left;
      if(got>0)done.push(`${got} parsel hasat`);
    }
    const dead=(WORLD_DATA.home?.farmPlots||[]).filter(p=>p.dead).length;
    if(dead){this.clearDeadAll();done.push(`${dead} solmuş ekin temizlendi`)}
    const dry=(WORLD_DATA.home?.farmPlots||[]).filter(p=>p.crop&&!p.dead&&!this.ripe(p)&&!p.watered).length;
    if(dry){this.waterAll();done.push(`${dry} ekin sulandı`)}
    const sk=this.curSeed();
    if(sk){
      const empty=(WORLD_DATA.home?.farmPlots||[]).filter(p=>!p.crop&&!p.dead).length;
      const canPlant=Math.min(empty,P.seeds[sk]||0);
      if(canPlant){this.plantAll(sk);done.push(`${canPlant} ${CROPS[sk].n} ekildi`)}
    }
    const readyFruit=(WORLD_DATA.home?.fruitTrees||[]).filter(t=>t.fruitReady).length;
    if(readyFruit){
      this.harvestOrchardAll();
      const left=(WORLD_DATA.home?.fruitTrees||[]).filter(t=>t.fruitReady).length;
      if(readyFruit-left>0)done.push(`${readyFruit-left} meyve toplandı`);
    }
    if($('farm-hud'))$('farm-hud').dataset.hudKey='';
    if(done.length){ONBOARD.event('farm');DAILY_FOCUS.event('farm',1)}
    const after=this.carePlan();
    if(!done.length){
      if(after.empty&&!after.sk)return 'Ekime devam etmek için aşağıdan bir tohum seç veya satın al.';
      return '✓ Bugünün bahçe işi tamam. Ürünlerin büyümesi için evde uyu.';
    }
    const next=after.empty&&!after.sk?'Tohumun bitti; kalan boş alanlar için başka bir tohum seçebilirsin.':after.tasks?'Bir iş daha var; günlük bakıma tekrar basabilirsin.':'Bugünün işi bitti. Şimdi eve dönüp yatağında uyu.';
    sv();return `✓ ${done.join(' · ')}. ${next}`;
  },
  smartPrompt(){
    if(curMap!=='home')return null;
    this.syncBeds();
    if(!this.nearCampus()&&!this.nearOrchard()&&Math.hypot(P.x-18*TS,P.y-24*TS)>=34)return null;
    const plan=this.carePlan();
    if(plan.tasks)return {text:`🌿 Günlük Bahçe Bakımını Yap (${plan.tasks})`,fn:()=>{const msg=this.dailyCare();fl(P.x,P.y-30,msg,'#86efac',true)}};
    const growing=(WORLD_DATA.home?.farmPlots||[]).some(p=>p.crop&&!p.dead&&!this.ripe(p));
    if(plan.empty&&!plan.sk)return {text:'🌱 Sıradaki adım: Tohum seç',fn:()=>this.openUI('simple')};
    if(growing)return {text:'🌙 Bahçe bakımlı · Gece evde uyu',fn:()=>this.openUI('simple')};
    return {text:'🌱 Kolay Bahçeyi Aç',fn:()=>this.openUI('simple')};
  },
  smartTileAction(plot){
    if(!plot)return false;
    if(plot.dead){this.clearPlot(plot);spark(plot.x,plot.y,8,'#78350f',30);fl(plot.x,plot.y-12,'🥀 Temizlendi','#fca5a5');sv();return true}
    if(this.ripe(plot))return !!this.harvest(plot);
    if(!plot.crop){
      const ok=this.plant(plot);
      if(ok&&!plot.watered)this.waterPlot(plot,true);
      return ok;
    }
    if(!plot.watered)return this.waterPlot(plot);
    const c=CROPS[plot.crop];
    fl(plot.x,plot.y-14,`${c.icon} ${c.n}: ${Math.max(0,c.d-(plot.age||0))} gün kaldı · Sulu 💧`,'#fde68a');
    return true;
  },
  useHoe(off,sweep,charged){
    this.syncBeds();
    let acted=0;
    for(const so of sweep){
      const gx=Math.floor(P.x/TS)+off[0]+so[0],gy=Math.floor(P.y/TS)+off[1]+so[1];
      const px=gx*TS+8, py=gy*TS+8, plot=this.plotAt(px,py);
      if(plot&&this.smartTileAction(plot))acted++;
    }
    if(!acted&&this.nearCampus()){
      const sp=this.smartPrompt();if(sp){sp.fn();return}
    }
  },
  useSeed(off,sweep,charged){
    this.syncBeds();
    let acted=0;
    for(const so of sweep){
      const gx=Math.floor(P.x/TS)+off[0]+so[0],gy=Math.floor(P.y/TS)+off[1]+so[1];
      const px=gx*TS+8, py=gy*TS+8, plot=this.plotAt(px,py);
      if(plot&&this.smartTileAction(plot))acted++;
    }
    if(!acted&&this.nearCampus()){
      const sk=this.curSeed();
      if(sk)this.plantAll(sk);else this.openUI('seeds');
    }
  },

  /* --- Pazar & Bahçe Mağazası --- */
  buy(sd,qty){
    if(!Number.isInteger(qty)||qty<1||qty>99)return;
    if(sd==='fert'){
      const cost=18*qty;
      if(P.gold<cost){inventoryWarning('Yetersiz altın; hiçbir şey harcanmadı.');return}
      P.gold-=cost;P.fert=(P.fert||0)+qty;
      fl(P.x,P.y-26,`+${qty} 🧪 Gübre`,'#6ee7b7',true);sfx(700,.1,'sine',.05);sv();
      if(!$('market-modal').classList.contains('h'))marketUI();
      if(!$('garden-modal').classList.contains('h'))this.renderUI();
      return;
    }
    const c=CROPS[sd]; if(!c)return;
    if(!this.canGrowInSeason(sd)){fl(P.x,P.y-22,'Bu mevsim yetişmez (Cam Sera gerekir)!','#fca5a5');return}
    const cost=friendPrice('osman',c.cost)*qty;
    if(P.gold<cost){inventoryWarning('Yetersiz altın; hiçbir şey harcanmadı.');return}
    P.gold-=cost;P.seeds[sd]=(P.seeds[sd]||0)+qty;
    P.seedSel=sd;
    fl(P.x,P.y-26,`+${qty} ${c.icon} ${c.n} Tohumu`,'#6ee7b7',true);
    sfx(700,.1,'sine',.05);updHotbarUI();sv();
    if(!$('market-modal').classList.contains('h'))marketUI();
    if(!$('garden-modal').classList.contains('h')){this.status(`✓ ${qty} ${c.n} tohumu alındı ve ekim için seçildi.`);this.renderUI()}
  },
  shopHTML(){
    const s=this.seasonIdx(), S0=SEASONS[s], gh=this.cfg().greenhouse;
    const row=(label,sub,key)=>`
      <div style="display:flex;justify-content:space-between;align-items:center;background:#1e293b;padding:4px 8px;border-radius:6px;gap:6px">
        <span>${label}<br><small style="color:#94a3b8">${sub}</small></span>
        <div style="display:flex;gap:4px;flex-shrink:0">
          <button data-sd="${key}" data-qty="1" style="padding:2px 7px;font-size:10px">+1</button>
          <button data-sd="${key}" data-qty="5" style="padding:2px 7px;font-size:10px;background:#2563eb">+5</button>
          <button data-sd="${key}" data-qty="12" style="padding:2px 7px;font-size:10px;background:#16a34a">+12</button>
        </div>
      </div>`;
    let h=`<b style="color:var(--gd)">🌱 Tohum Dükkânı · ${S0.icon} ${S0.n}${gh?' · 🏛️ Sera':''}</b>
      <div style="font-size:9.5px;color:#94a3b8;margin:2px 0">Çantanda ${this.seedCount()} tohum · 🧪 ${P.fert||0} gübre</div>
      <div style="display:flex;flex-direction:column;gap:4px;margin:6px 0">`;
    for(const k in CROPS){
      const c=CROPS[k]; if(!gh&&!c.se.includes(s))continue;
      h+=row(`${c.icon} ${c.n} · ${friendPrice('osman',c.cost)}🪙 · çantanda: ${P.seeds[k]||0}`,
        `${c.d} gün${c.rg?` · her ${c.rg} günde yeniden`:''} · satış ${c.val}🪙`,k);
    }
    h+=row('🧪 Organik Gübre (18🪙)','Büyümeyi ve kaliteyi artırır','fert');
    return h+'</div>';
  },

  /* --- ADIM 3: Tohum Islah Tezgâhı, Kompost & Çiçek-Arı Sinerjisi --- */
  extractSeeds(cropKey){
    if(!CROPS[cropKey]||countInv(cropKey)<1)return 'Islah için çantanda bu mahsulden en az 1 adet olmalı.';
    if(!consumeInv(cropKey,1))return 'Mahsul tüketilemedi.';
    const c=CROPS[cropKey],fLvl=P.skills?.farm?.lvl||1;
    const count=2+(Math.random()<.35+fLvl*.04?1:0);
    P.seeds[cropKey]=(P.seeds[cropKey]||0)+count;
    if(!P.seedSel)P.seedSel=cropKey;
    let bonusMsg='';
    const rarePool=['star_berry','mana_rose','sun_melon','ancient_fruit'];
    if(Math.random()<.22+fLvl*.02){
      const rk=pick(rarePool),rc=CROPS[rk];
      P.seeds[rk]=(P.seeds[rk]||0)+1;
      bonusMsg=` + 🌟 Nadir Keşif: 1 ${rc.icon} ${rc.n} Tohumu!`;
    }
    addMasteryXp('farm',12);updHotbarUI();sv();
    fl(P.x,P.y-28,`🧬 +${count} ${c.icon} ${c.n} Tohumu${bonusMsg?' + Nadir Tohum!':''}`,'#a7f3d0',true);
    playChord([523,659,784],.24,'triangle',.05);
    return `✓ 1 ${c.n} işlendi → +${count} ${c.n} Tohumu üretildi!${bonusMsg}`;
  },
  makeCompost(){
    const candidates=['wheat','carrot','potato','onion','berry','corn','turnip','wood'];
    const found=candidates.find(k=>countInv(k)>=2);
    if(!found)return 'Kompost için çantanda en az 2 adet mahsul (veya 2 odun) olmalı.';
    if(!consumeInv(found,2))return 'Malzeme kullanılamadı.';
    P.fert=(P.fert||0)+2;
    addMasteryXp('farm',8);sv();
    fl(P.x,P.y-26,'♻️ +2 🧪 Organik Gübre Üretildi!','#86efac',true);
    sfx(680,.12,'sine',.05);
    return '✓ Kompost Varili: +2 🧪 Organik Gübre üretildi!';
  },
  hasFlowerInGarden(){
    return (WORLD_DATA.home?.farmPlots||[]).some(p=>p.crop&&!p.dead&&(CROPS[p.crop]?.flower||CROPS[p.crop]?.shape==='flower'));
  },
  collectBeehive(){
    if(!P.hasBeehive)return 'Önce Arı Kovanını kurmalısın.';
    if(!P.honeyReady)return 'Arılar şu an nektar topluyor; yarın sabah yeni bal hazır olur.';
    const floral=this.hasFlowerInGarden();
    const honey=floral
      ? {s:'food',k:'royal_honey',n:'Kraliyet Çiçek Balı',icon:'🌺',hp:100,mp:50,buff:'atk',duration:360,desc:'Bahçedeki çiçeklerden üretilmiş özel nektar · +100 Can, +50 Mana & Saldırı (6dk)',val:120}
      : {s:'food',k:'honey',n:'Doğal Çiçek Balı',icon:'🍯',hp:60,mp:30,buff:'spd',duration:360,desc:'+60 Can, +30 Mana & Hız (6dk) · Değer: 60🪙',val:60};
    if(!ITEMS.add(P.inv,honey))return 'Çantan dolu! Bal kovanda güvende bekliyor.';
    P.honeyReady=false;addMasteryXp('farm',18);sv();
    fl(P.x,P.y-28,`+${honey.icon} ${honey.n} (${honey.val}🪙)!`,'#ffd23f',true);
    playChord([523,659,784,1046],.25,'triangle',.06);
    return `✓ ${honey.n} toplandı!${floral?' (🌸 Çiçek Sinerjisi ile 2× Değer!)':''}`;
  },
  buildArtisan(kind){
    if(kind==='beehive'){
      if(P.hasBeehive)return 'Arı Kovanı zaten kurulu!';
      if(!tryInventoryRecipe({wood:8},[],{gold:80}))return 'Eksik! Gereken: 80🪙 · 8 Odun.';
      P.hasBeehive=true;P.honeyReady=true;sv();
      fl(P.x,P.y-28,'🐝 Arı Kovanı Zanaat Terasına Kuruldu!','#ffd23f',true);
      return '✓ Arı Kovanı kuruldu ve ilk balı hazır!';
    }
    if(kind==='cask'){
      if(P.hasCask)return 'Mayalama Fıçısı zaten kurulu!';
      if(!tryInventoryRecipe({wood:10},[],{gold:100}))return 'Eksik! Gereken: 100🪙 · 10 Odun.';
      P.hasCask=true;sv();
      fl(P.x,P.y-28,'🛢️ Mayalama Fıçısı Zanaat Terasına Kuruldu!','#ffd23f',true);
      return '✓ Mayalama Fıçısı kuruldu!';
    }
    return '';
  },

  /* --- ADIM 4: Günlük Çiftlik Kontratları & Hasat Bereketi --- */
  dailyContracts(){
    const s=this.seasonIdx(),d=P.day||1;
    const seasonalPools=[
      ['wheat','carrot','potato','berry','tulip'],
      ['corn','tomato','pepper','sunflower','melon'],
      ['pumpkin','grape','yam','cranberry','wheat'],
      ['turnip','snowdrop','kale','wheat','carrot']
    ][s];
    const c0=seasonalPools[d%seasonalPools.length];
    const c1=seasonalPools[(d+2)%seasonalPools.length];
    const fKey=d%2===0?'apple':'peach';
    return [
      {idx:0,giver:'🥐 Fırıncı Melis',title:`Taze ${CROPS[c0].n} Tedariki`,reqK:c0,reqName:CROPS[c0].n,reqIcon:CROPS[c0].icon,qty:2,gold:CROPS[c0].val*3,gems:2,fert:2,seedReward:'star_berry'},
      {idx:1,giver:'🛒 Manav Osman',title:`Seçkin ${CROPS[c1].n} Kasası`,reqK:c1,reqName:CROPS[c1].n,reqIcon:CROPS[c1].icon,qty:3,gold:CROPS[c1].val*4,gems:3,fert:3,seedReward:'mana_rose'},
      {idx:2,giver:'🕊️ Şifacı Elara',title:`Meyve Bahçesi Sepeti (${fKey==='apple'?'Elma':'Şeftali'})`,reqK:fKey,reqName:fKey==='apple'?'Taze Elma':'Taze Şeftali',reqIcon:fKey==='apple'?'🍎':'🍑',qty:2,gold:110,gems:3,fert:2,seedReward:'ancient_fruit'}
    ];
  },
  deliverContract(idx){
    const h=this.cfg(),list=this.dailyContracts(),ord=list[idx];
    if(!ord)return 'Geçersiz kontrat.';
    if(h.contractsDone.includes(idx))return 'Bu kontrat bugün zaten teslim edildi.';
    if(countInv(ord.reqK)<ord.qty)return `Eksik! Çantanda ${ord.qty} adet ${ord.reqName} olmalı (Şu an: ${countInv(ord.reqK)}).`;
    if(!consumeInv(ord.reqK,ord.qty))return 'Ürün teslim edilemedi.';
    h.contractsDone.push(idx);
    P.gold+=ord.gold;P.gems+=ord.gems;P.fert=(P.fert||0)+ord.fert;
    P.rep=(P.rep||0)+8;P.townWorkDay=P.day;
    const sr=ord.seedReward,sc=CROPS[sr];
    if(sc){P.seeds[sr]=(P.seeds[sr]||0)+1}
    addMasteryXp('farm',25);S=st();sv();
    fl(P.x,P.y-28,`📜 Kontrat Tamam! +${ord.gold}🪙 +${ord.gems}💎 +1 ${sc.icon} ${sc.n} Tohumu!`,'#ffd23f',true);
    playChord([523,659,784,1046],.35,'triangle',.07);
    return `✓ ${ord.title} teslim edildi! +${ord.gold}🪙, +${ord.gems}💎, +${ord.fert}🧪 Gübre ve +1 ${sc.icon} ${sc.n} Tohumu kazandın!`;
  },
  claimMilestone(){
    const h=this.cfg(),nextTarget=((h.milestoneClaimed||0)+1)*15;
    if((h.totalHarvests||0)<nextTarget)return `Bereket Sandığı için ${nextTarget-(h.totalHarvests||0)} mahsul daha hasat etmelisin.`;
    h.milestoneClaimed=(h.milestoneClaimed||0)+1;
    const gold=180+h.milestoneClaimed*40,gems=4;
    P.gold+=gold;P.gems+=gems;P.fert=(P.fert||0)+4;
    P.seeds.ancient_fruit=(P.seeds.ancient_fruit||0)+1;
    P.seeds.star_berry=(P.seeds.star_berry||0)+2;
    updHotbarUI();sv();
    fl(P.x,P.y-28,`🎁 BEREKET SANDIĞI AÇILDI! +${gold}🪙 +${gems}💎 +👑 Kadim Meyve Tohumu!`,'#ffd23f',true);
    playChord([523,659,784,1046],.4,'triangle',.08);
    return `✓ Bereket Sandığı #${h.milestoneClaimed} alındı: +${gold}🪙, +${gems}💎, +4🧪 Gübre, +1 👑 Kadim Meyve ve +2 ⭐ Yıldız Çileği Tohumu!`;
  },

  /* --- Görsel Bahçe & Kampüs Yönetim Paneli --- */
  openUI(tab){
    this.syncBeds();
    if(tab)this.uiTab=tab;
    $('garden-modal').classList.remove('h');
    this.status('');this.renderUI();
  },
  status(msg){
    const el=$('garden-status');if(!el)return;
    el.textContent=msg||'';
  },
  renderSimpleUI(){
    this.syncBeds();
    const box=$('garden-content');if(!box)return;
    const plots=WORLD_DATA.home?.farmPlots||[],plan=this.carePlan(),h=this.cfg();
    const s=this.seasonIdx(),S0=SEASONS[s],sk=plan.sk,sc=sk?CROPS[sk]:null;
    const weatherInfo={clear:['☀️','Güneşli'],rain:['🌧️','Yağmurlu'],storm:['⛈️','Fırtınalı'],fog:['🌫️','Sisli'],blood_moon:['🌕','Kanlı Ay']}[weather.type]||['☀️','Açık'];
    const report=h.lastFarmReport?.day===P.day?h.lastFarmReport:null;
    const growing=plots.filter(p=>p.crop&&!p.dead&&!this.ripe(p)).length;
    const owned=Object.keys(P.seeds||{}).filter(k=>(P.seeds[k]||0)>0&&CROPS[k]&&this.canGrowInSeason(k,s));
    const shop=Object.keys(CROPS).filter(k=>!CROPS[k].rare&&this.canGrowInSeason(k,s)).sort((a,b)=>CROPS[a].d-CROPS[b].d||CROPS[b].val-CROPS[a].val).slice(0,4);
    const groups={};
    for(const p of plots){
      if(!p.crop||p.dead||!CROPS[p.crop])continue;
      const c=CROPS[p.crop],g=groups[p.crop]||(groups[p.crop]={count:0,ready:0,progress:0,days:99});
      g.count++;g.ready+=this.ripe(p)?1:0;g.progress+=Math.min(1,(p.age||0)/c.d);g.days=Math.min(g.days,Math.max(0,c.d-(p.age||0)));
    }
    const work=[];
    if(plan.ripe)work.push(`${plan.ripe} olgun ürün toplanacak`);
    if(plan.dry)work.push(`${plan.dry} ekin sulanacak`);
    if(plan.dead)work.push(`${plan.dead} solmuş ekin temizlenecek`);
    if(plan.plant&&sc)work.push(`${plan.plant} ${sc.n} ekilecek`);
    if(plan.fruit)work.push(`${plan.fruit} ağaçtan meyve toplanacak`);
    const atHome=curMap==='home';
    let stage,title,desc;
    if(!atHome){stage='away';title='Önce çiftliğe dön';desc='Bahçe durumunu buradan görebilirsin. Ekim ve bakım yapmak için Çiftlik Evi haritasında olmalısın.'}
    else if(plan.tasks){stage='care';title='Şimdi günlük bakımı yap';desc=work.join(' · ')+'. Tek düğme bütün bu işleri sırayla tamamlar.'}
    else if(plan.empty&&!sk){stage='seed';title='Şimdi bir tohum seç';desc=owned.length?'Aşağıdaki tohumlardan birine dokun. Seçtiğin ürün boş alanlara ekilecek.':'Bu mevsime uygun tohumun kalmamış. Aşağıdaki dükkândan bir paket al.'}
    else if(growing){stage='sleep';title='Bugünün işi tamam';desc='Ekinler bakımlı. Gece olunca evin içine gir, yatağa dokun ve yeni güne geç.'}
    else{stage='seed';title='Yeni ekime başla';desc='Bir tohum seç. Ardından Günlük Bakım düğmesi boş alanlara ekim yapacak.'}
    const plantable=sc?Math.min(plan.empty,P.seeds[sk]||0):0;
    const estimate=sc&&plantable?plantable*sc.val:0;
    const cropRows=Object.entries(groups).map(([k,g])=>{const c=CROPS[k],pct=Math.round(g.progress/g.count*100);return `<div class="farm-crop-row"><span><b>${c.icon} ${c.n}</b> ×${g.count}</span><span class="farm-progress"><i style="width:${pct}%"></i></span><span>${g.ready?`${g.ready} hazır`:g.days?`en erken ${g.days} gün`:'hazır'}</span></div>`}).join('');
    const selectedPlot=plots.find(p=>p.id===this.selectedPlotId)||null;
    const layoutCells=plots.map(p=>{const c=p.crop?CROPS[p.crop]:null,ripe=this.ripe(p),left=c?Math.max(0,c.d-(p.age||0)):0,cls=`farm-layout-cell${p.watered?' wet':''}${ripe?' ripe':''}${p.dead?' dead':''}${selectedPlot===p?' selected':''}`,label=p.dead?`${c?.n||'Ekin'} solmuş`:c?`${c.n} · ${ripe?'Hasada hazır':left+' gün kaldı'} · ${p.watered?'Sulu':'Kuru'}`:'Boş ekim alanı';return `<button type="button" class="${cls}" data-g-plot="${p.id}" title="${label}" aria-label="${label}"><span>${p.dead?'🥀':c?c.icon:'·'}</span>${p.watered&&c?'<span class="plot-water">💧</span>':''}<span class="plot-days">${ripe?'HAZIR':c?left+'g':'BOŞ'}</span></button>`}).join('');
    let inspector='';
    if(selectedPlot){
      const c=selectedPlot.crop?CROPS[selectedPlot.crop]:null,ripe=this.ripe(selectedPlot),left=c?Math.max(0,c.d-(selectedPlot.age||0)):0,stageName=selectedPlot.dead?'Solmuş':!c?'Boş':ripe?'Hasada hazır':this.stageOf(selectedPlot)===0?'Yeni ekildi':this.stageOf(selectedPlot)===1?'Filizlendi':'Büyüyor';
      let action='';
      if(selectedPlot.dead)action=`<button type="button" data-g-plot-act="clear" data-pid="${selectedPlot.id}" style="background:#7f1d1d">🧹 Solmuş Ekini Temizle</button>`;
      else if(ripe)action=`<button type="button" data-g-plot-act="harvest" data-pid="${selectedPlot.id}" style="background:#166534">🧺 ${c.n} Hasat Et</button>`;
      else if(!c&&sc)action=`<button type="button" data-g-plot-act="plant" data-pid="${selectedPlot.id}" style="background:#0f766e">${sc.icon} ${sc.n} Ek ve Sula</button>`;
      else if(c&&!selectedPlot.watered)action=`<button type="button" data-g-plot-act="water" data-pid="${selectedPlot.id}" style="background:#0369a1">💧 Bu Alanı Sula</button>`;
      inspector=`<div class="farm-plot-inspector"><h4>${selectedPlot.dead?'🥀':c?c.icon:'🟫'} ${c?c.n:'Boş Tarla Alanı'} · Yatak ${selectedPlot.bed||1}</h4><p><b>Durum:</b> ${stageName}${c&&!ripe&&!selectedPlot.dead?` · ${left} gün kaldı`:''}<br><b>Toprak:</b> ${selectedPlot.watered?'Nemli ve sulu 💧':'Kuru'}${selectedPlot.fert?' · Gübreli ✨':''}${c?`<br><b>Taban ürün değeri:</b> ${c.val}🪙`:''}</p><div class="farm-plot-actions">${action||(!c?'<span style="color:#fca5a5">Ekim yapmak için önce bir tohum seç.</span>':'<span style="color:#86efac">Bu alan bakımlı; yeni günü bekliyor.</span>')}</div></div>`;
    }
    box.innerHTML=`
      <div class="farm-simple-hero">
        <h2>${S0.icon} ${S0.n} · ${this.dayOf()}. Gün</h2>
        <span>🪙 ${P.gold} · ${plots.length} alan<br><span class="farm-weather">${weatherInfo[0]} ${weatherInfo[1]}${isWetWeather()?' · Tarlayı sular':''}</span></span>
      </div>
      ${report?`<div class="farm-report"><span><b>🌅 Sabah Tarla Raporu</b>${report.grew} ekin büyüdü · ${report.ripe} ürün hasada hazır</span><span>${report.died?`🥀 ${report.died} ekin soldu`:'✓ Kayıp yok'}${report.autoWater?'<br>💧 Doğal/otomatik sulama aktif':''}</span></div>`:''}
      <div class="farm-flow">
        <div class="${stage==='seed'?'active':''}"><b>1 · Tohum</b>Ürünü seç</div>
        <div class="${stage==='care'?'active':''}"><b>2 · Bakım</b>Tek düğmeye bas</div>
        <div class="${stage==='sleep'?'active':''}"><b>3 · Yeni Gün</b>Evde uyu</div>
      </div>
      <div class="farm-next ${stage}">
        <span class="farm-next-label">SIRADAKİ ADIM</span>
        <h3>${title}</h3>
        <p>${desc}</p>
        ${stage==='care'?`<button type="button" class="farm-primary" data-g-act="daily-care">🌿 Günlük Bakımı Başlat · ${plan.tasks} iş</button>`:''}
      </div>
      <div class="farm-simple-stats">
        <div><b style="color:#86efac">${plan.ripe+plan.fruit}</b><span>Toplanacak</span></div>
        <div><b style="color:#7dd3fc">${growing}</b><span>Büyüyen</span></div>
        <div><b style="color:#e5c07b">${plan.empty+plan.dead}</b><span>Boş alan</span></div>
      </div>

      <div class="farm-simple-section">
        <div class="farm-simple-head"><b>🌱 Ekim Seçimi</b><small>Bir tohuma dokunarak seç</small></div>
        ${sc?`<div class="farm-seed-current"><span class="crop">${sc.icon}</span><span style="flex:1"><b>${sc.n} seçili</b><small>${P.seeds[sk]||0} tohumun var · ${sc.d} günde yetişir</small></span><span class="forecast">${plantable?`${plantable} alan ekilir<br>taban değer ≈ ${estimate}🪙`:'Boş alan açılınca ekilir'}</span></div>`:`<div class="farm-seed-current" style="background:#332719;border-color:#a98554"><span class="crop">❔</span><span style="flex:1"><b>Henüz tohum seçilmedi</b><small>Önce sahip olduğun bir tohumu seç veya yenisini al.</small></span></div>`}
        <div class="farm-seed-grid">
          ${owned.length?owned.map(k=>{const c=CROPS[k];return `<button type="button" class="farm-seed ${k===sk?'active':''}" data-g-seed="${k}"><strong>${c.icon} ${c.n}</strong><span>${P.seeds[k]} adet · ${c.d} gün</span></button>`}).join(''):'<p style="grid-column:1/-1;color:#fca5a5;text-align:center">Bu mevsime uygun tohumun yok.</p>'}
        </div>
      </div>

      <details class="farm-details" ${plots.length<=12||selectedPlot?'open':''}>
        <summary><span>🟫 Tarlanın Canlı Görünümü</span><small style="color:#9fb6c0">Her kare gerçek ekili ürünü gösterir</small></summary>
        <div class="farm-details-body"><div class="farm-layout">${layoutCells}</div><div class="farm-layout-legend"><span>💧 Sulu</span><span style="color:#86efac">Yeşil çerçeve: Hasat hazır</span><span>BOŞ: Ekilebilir</span><span>Bir kareye dokun: ayrıntıyı gör</span></div>${inspector}</div>
      </details>

      <details class="farm-details" ${stage==='seed'&&!owned.length?'open':''}>
        <summary><span>🛒 Tohum Satın Al</span><small style="color:#9fb6c0">Bakiyen ${P.gold}🪙</small></summary>
        <div class="farm-details-body farm-shop-grid">
          ${shop.map((k,i)=>{const c=CROPS[k],price=friendPrice('osman',c.cost)*6,ok=P.gold>=price;return `<div class="farm-shop-item"><span>${i===0?'<em>BAŞLANGIÇ İÇİN KOLAY</em>':''}<b>${c.icon} ${c.n}</b><br>${c.d} gün · ürün ${c.val}🪙</span><button type="button" data-sd="${k}" data-qty="6" ${ok?'':'disabled'}>${ok?`6’lı Al · ${price}🪙`:'Altın Yetmiyor'}</button></div>`}).join('')}
        </div>
      </details>

      <details class="farm-details">
        <summary><span>🌾 Tarladaki Ürünler</span><small style="color:#9fb6c0">${Object.keys(groups).length} ürün türü</small></summary>
        <div class="farm-details-body farm-crop-list">${cropRows||'<span style="color:#94a3b8;font-size:10px">Tarlada henüz ekili ürün yok.</span>'}</div>
      </details>

      <details class="farm-details">
        <summary><span>❓ Günlük Bakım Ne Yapar?</span><small style="color:#9fb6c0">Kısa açıklama</small></summary>
        <div class="farm-details-body"><ol class="farm-help-list"><li><b>Hazır ürünleri ve meyveleri toplar.</b></li><li><b>Büyüyen kuru ekinleri sular.</b></li><li><b>Seçili tohumu boş alanlara eker ve hemen sular.</b></li><li>İş bitince gece evde uyursun; ürünler bir gün büyür.</li></ol></div>
      </details>`;
  },
  renderUI(){
    return this.renderSimpleUI();
    this.syncBeds();
    const h=this.cfg(),s=this.seasonIdx(),S0=SEASONS[s],plots=WORLD_DATA.home?.farmPlots||[];
    const ripeN=plots.filter(p=>this.ripe(p)).length;
    const dryN=plots.filter(p=>p.crop&&!p.dead&&!p.watered).length;
    const emptyN=plots.filter(p=>!p.crop||p.dead).length;
    const sk=this.curSeed(),sc=sk?CROPS[sk]:null;
    document.querySelectorAll('#garden-tabs button').forEach(b=>b.classList.toggle('act',b.dataset.gtab===this.uiTab));
    const box=$('garden-content');if(!box)return;

    let html=`<div style="display:flex;flex-wrap:wrap;gap:4px 12px;align-items:center;justify-content:center;font-size:11px;color:#cbd5e1;padding:2px 2px 8px">
      <b style="color:#f0d7a3">${S0.icon} ${S0.n} · Gün ${this.dayOf()}/28</b><span>🪙 ${P.gold}</span><span>🧪 ${P.fert||0}</span>${h.greenhouse?'<span>🏛️ Sera</span>':''}
    </div>`;

    if(this.uiTab==='beds'){
      const ownedSeeds=Object.keys(P.seeds).filter(k=>(P.seeds[k]||0)>0&&CROPS[k]);
      html+=`<div style="display:flex;align-items:center;gap:4px;flex-wrap:wrap;background:#0a1929;padding:6px 8px;border-radius:7px;border:1px solid #334155;margin-bottom:6px;font-size:10px">
        <strong style="color:#fde047">🌱 Tohum:</strong>
        ${ownedSeeds.length?ownedSeeds.map(k=>{
          const c=CROPS[k],act=k===sk,ok=this.canGrowInSeason(k,s);
          return `<button type="button" data-g-seed="${k}" style="padding:3px 7px;font-size:10px;background:${act?'#16a34a':'#1e293b'};border-color:${act?'#86efac':ok?'#64748b':'#ef4444'}">${c.icon} ${c.n} (${P.seeds[k]})</button>`;
        }).join(''):`<span style="color:#fca5a5">Tohumun yok</span> <button type="button" data-gtab-jump="seeds" style="padding:3px 8px;font-size:10px;background:#2563eb">Tohum Al</button>`}
      </div>`;

      const acts=[];
      if(ripeN)acts.push(`<button type="button" data-g-act="harvest-all" style="background:#16a34a;border-color:#86efac">🧺 Hasat (${ripeN})</button>`);
      if(emptyN&&sk)acts.push(`<button type="button" data-g-act="plant-all" style="background:#0d9488;border-color:#5eead4">🌱 Ek (${Math.min(emptyN,P.seeds[sk]||0)})</button>`);
      if(dryN)acts.push(`<button type="button" data-g-act="water-all" style="background:#0284c7;border-color:#7dd3fc">💧 Sula (${dryN})</button>`);
      if((P.fert||0)>0&&plots.some(p=>p.crop&&!p.dead&&!p.fert))acts.push(`<button type="button" data-g-act="fert-all" style="background:#7c3aed">✨ Gübre (${P.fert})</button>`);
      html+=acts.length?`<div class="garden-actions-bar">${acts.join('')}</div>`:`<p style="text-align:center;font-size:11px;color:#94a3b8;margin:4px 0 8px">Şimdilik yapılacak iş yok. Ürünler büyüyor 🌱</p>`;

      const selP=plots.find(p=>p.id===this.selectedPlotId);
      if(selP){
        const c=selP.crop?CROPS[selP.crop]:null;
        html+=`<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;flex-wrap:wrap;background:#13283c;border:1px solid #60a5fa66;border-radius:7px;padding:6px 8px;margin-bottom:6px;font-size:10px">
          <span><b>Parsel #${selP.id+1} (Yatak ${selP.bed||1}):</b> ${selP.dead?'🥀 Solmuş Ekin':c?`${c.icon} <b>${c.n}</b> · ${this.ripe(selP)?'<b style="color:#4ade80">HASADA HAZIR!</b>':`${selP.age||0}/${c.d} gün`} · ${selP.watered?'💧 Sulu':'⚠ Kuru'}${selP.fert?' · ✨ Gübreli':''}`:'Boş Verimli Toprak (Ekime Hazır)'}</span>
          <div style="display:flex;gap:4px">
            ${this.ripe(selP)?`<button type="button" data-g-plot-act="harvest" data-pid="${selP.id}" style="padding:3px 8px;background:#16a34a">🧺 Hasat</button>`:''}
            ${!selP.crop&&sk?`<button type="button" data-g-plot-act="plant" data-pid="${selP.id}" style="padding:3px 8px;background:#0d9488">🌱 ${CROPS[sk].n} Ek</button>`:''}
            ${selP.crop&&!selP.watered?`<button type="button" data-g-plot-act="water" data-pid="${selP.id}" style="padding:3px 8px;background:#0284c7">💧 Sula</button>`:''}
            ${selP.crop&&!selP.fert&&(P.fert||0)>0?`<button type="button" data-g-plot-act="fert" data-pid="${selP.id}" style="padding:3px 8px;background:#7c3aed">✨ Gübrele</button>`:''}
            ${selP.crop||selP.dead?`<button type="button" data-g-plot-act="clear" data-pid="${selP.id}" style="padding:3px 8px;background:#7f1d1d">🧹 Sök</button>`:''}
          </div>
        </div>`;
      }

      for(const bId of [1,2,3]){
        const bed=GARDEN_BEDS[bId],open=h.beds>=bId;
        const bPlots=plots.filter(p=>(p.bed||1)===bId);
        html+=`<div class="garden-bed-box">
          <div class="garden-bed-head">
            <span><b style="color:#f0d7a3">${bId} · ${(bed.name.match(/\((.*)\)/)||[0,bed.name])[1]}</b></span>
            ${open?`<span style="color:#94a3b8;font-size:10px">${bPlots.length} parsel</span>`:`<button type="button" data-g-unlock-bed="${bId}" style="padding:3px 8px;font-size:10px;background:#b45309">🔓 +${bed.coords.length} parsel · ${bed.cost.gold}🪙 ${bed.cost.wood}🪵 ${bed.cost.stone}🪨</button>`}
          </div>`;
        if(open){
          html+=`<div class="garden-grid ${bId===3?'bed3':''}">`;
          for(const p of bPlots){
            const c=p.crop?CROPS[p.crop]:null,isRipe=this.ripe(p);
            const cls=`g-plot${p.watered?' wet':''}${isRipe?' ripe':''}${this.selectedPlotId===p.id?' sel':''}`;
            html+=`<button type="button" class="${cls}" data-g-plot="${p.id}" title="Dokun: Akıllı İşlem (Hasat / Ek / Sula)">
              ${p.fert?'<span class="gp-fert">✨</span>':''}
              <span class="gp-badge">${isRipe?'★':p.watered?'💧':c&&!p.dead?'🏜️':''}</span>
              <span class="gp-ico">${p.dead?'🥀':c?c.icon:'🟫'}</span>
              <span class="gp-sub">${p.dead?'Solmuş · Temizle':c?(isRipe?'HAZIR!':`${p.watered?'':'Sula · '}${Math.max(0,c.d-(p.age||0))} gün`):'Boş · Dokun'}</span>
            </button>`;
          }
          html+=`</div>`;
        }else{
          /* kilitli yatak: açıklama gereksiz */
        }
        html+=`</div>`;
      }
      html+=`<p class="inventory-help">💡 <b>İpucu:</b> Herhangi bir parsele dokunduğunda olgunsa biçer, boşsa seçili tohumu eker ve sular, kuruysa sular!</p>`;
    }else if(this.uiTab==='seeds'){
      const bagCrops=Object.keys(CROPS).filter(k=>countInv(k)>0);
      html+=`<div class="journey-box" style="margin-bottom:8px">
        <b>🧬 Tohum Üret & ♻️ Kompost</b>
        <p>1 mahsulden 2–3 tohum üret. %25 şansla nadir tohum çıkar ⭐</p>
        <div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:6px">
          ${bagCrops.length?bagCrops.map(k=>`<button type="button" data-g-extract="${k}" style="background:#0d9488;font-size:10px;padding:4px 8px">🧬 ${CROPS[k].icon} ${CROPS[k].n} ×${countInv(k)} → Tohum</button>`).join(''):'<span style="color:#94a3b8;font-size:10px">Çantanda işlenecek hasat edilmiş mahsul yok.</span>'}
          <button type="button" data-g-compost="1" style="background:#15803d;font-size:10px;padding:4px 8px">♻️ Kompost (2 mahsul/odun → +2 🧪)</button>
        </div>
      </div>`;
      html+=this.shopHTML();
    }else if(this.uiTab==='orchard'){
      const readyCount=(WORLD_DATA.home.fruitTrees||[]).filter(t=>t.fruitReady).length;
      const floral=this.hasFlowerInGarden();
      const curCask=CASK_RECIPES[P.caskItem];
      html+=`<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;gap:8px">
        <span style="font-size:10.5px;color:#cbd5e1">Ağaçlar her sabah meyve verir.</span>
        <button type="button" data-g-act="orchard-harvest" style="padding:6px 10px;font-size:10.5px;background:${readyCount?'#16a34a':'#334155'};white-space:nowrap">🧺 Topla (${readyCount})</button>
      </div>
      <div class="orchard-grid">`;
      for(const slot of ORCHARD_SLOTS){
        const planted=h.orchard.includes(slot.slot),tDef=ORCHARD_TREES[slot.type];
        const treeObj=(WORLD_DATA.home.fruitTrees||[]).find(t=>t.slot===slot.slot);
        const ready=!!treeObj?.fruitReady;
        html+=`<div class="orchard-card">
          <div class="oc-ico">${tDef.icon}</div>
          <div style="flex:1;min-width:0">
            <b style="color:#f0d7a3">${tDef.n}</b><br>
            <small style="color:#94a3b8">${tDef.desc} · ${tDef.val}🪙</small><br>
            ${planted
              ? (ready
                  ? `<button type="button" data-g-tree-harvest="${slot.slot}" style="margin-top:4px;padding:3px 8px;font-size:10px;background:#16a34a">🍎 Meyveyi Topla</button>`
                  : `<span style="color:#86efac;font-size:9.5px">✔ Toplandı</span>`)
              : `<button type="button" data-g-tree-plant="${slot.slot}" style="margin-top:4px;padding:3px 8px;font-size:10px;background:#b45309">🌱 Fidan Dik (${tDef.cost.gold}🪙${tDef.cost.gems?` · ${tDef.cost.gems}💎`:''} · ${tDef.cost.wood}🪵)</button>`}
          </div>
        </div>`;
      }
      html+=`</div>
      <div class="journey-box" style="margin-top:8px">
        <b>🐝 Arı Kovanı · ${P.hasBeehive?(P.honeyReady?'<span style="color:#fde047">🍯 BAL HAZIR!</span>':'Arılar çalışıyor'):'Kurulu Değil'}</b>
        <p>${floral?'🌸 Çiçek bonusu aktif: bal 120🪙 değerinde!':'💡 Bahçene çiçek ekersen bal 2 kat değerli olur.'}</p>
        ${!P.hasBeehive
          ? `<button type="button" data-g-artisan="beehive" style="background:#ca8a04">🐝 Arı Kovanı Kur (80🪙 · 8 Odun)</button>`
          : P.honeyReady
            ? `<button type="button" data-g-beehive="collect" style="background:#16a34a">🍯 ${floral?'Kraliyet Çiçek Balını Topla (120🪙)':'Doğal Çiçek Balını Topla (60🪙)'}</button>`
            : `<span style="color:#86efac;font-size:10px">✔ Bugünkü bal toplandı · Yarın sabah yenilenir.</span>`}
      </div>
      <div class="journey-box">
        <b>🛢️ Mayalama Fıçısı · ${P.hasCask?(P.caskReady?'<span style="color:#4ade80">★ ÜRÜN HAZIR!</span>':curCask?`Mayalanıyor (${curCask.item.n})`:'Boş · Üretime Hazır'):'Kurulu Değil'}</b>
        <p>Mahsulü 3 kat değerli reçel, turşu, şarap gibi ürünlere çevir.</p>
        ${!P.hasCask
          ? `<button type="button" data-g-artisan="cask" style="background:#854d0e">🛢️ Mayalama Fıçısı Kur (100🪙 · 10 Odun)</button>`
          : P.caskReady
            ? `<button type="button" data-g-cask-collect="1" style="background:#16a34a">✓ Hazır Ürünü Al: ${curCask?.item.icon||''} ${curCask?.item.n||''}</button>`
            : curCask
              ? `<span style="color:#38bdf8;font-size:10px">⏳ ${curCask.item.icon} ${curCask.item.n} hazırlanıyor (${Math.ceil(P.caskTimer)} sn veya uyuyunca hazır).</span>`
              : `<div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:4px">
                  ${Object.entries(CASK_RECIPES).map(([k,r])=>`<button type="button" data-g-cask-start="${k}" style="font-size:10px;padding:4px 8px;background:#1e293b">${r.item.icon} ${r.item.n} (${Object.entries(r.needs).map(([nk,nn])=>`${countInv(nk)}/${nn} ${CROPS[nk]?.n||nk}`).join(', ')}) · ${r.item.val}🪙</button>`).join('')}
                </div>`}
      </div>`;
    }else if(this.uiTab==='contracts'){
      const perks=this.combatPerks(),contracts=this.dailyContracts();
      const nextTarget=((h.milestoneClaimed||0)+1)*15,prog=Math.min(nextTarget,h.totalHarvests||0);
      html+=`<div class="journey-box">
        <b>🌿 Çiftlik Bereketi</b>
        <p>Bakımlı çiftlik seni savaşta güçlendirir:</p>
        <div style="display:flex;flex-direction:column;gap:4px;margin-top:5px;font-size:10px">
          <span style="color:${perks.vitality?'#4ade80':'#94a3b8'}">${perks.vitality?'✔':'○'} <b>💧 Sulu ekin ${perks.wetLive}/6:</b> +%12 Can</span>
          <span style="color:${perks.orchard?'#4ade80':'#94a3b8'}">${perks.orchard?'✔':'○'} <b>🍎 Meyve ağacı ${perks.trees}/6:</b> +%8 Hız, +%5 Kritik</span>
          <span style="color:${perks.master?'#4ade80':'#94a3b8'}">${perks.master?'✔':'○'} <b>👑 Cam Sera + 3 Yatak:</b> +%15 Saldırı ve Zırh</span>
        </div>
      </div>
      <div class="journey-box">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
          <div>
            <b>🎁 Hasat Sandığı (${prog}/${nextTarget})</b>
            <p>Her 15 hasatta ödül sandığı açılır.</p>
          </div>
          <button type="button" data-g-milestone="1" style="background:${prog>=nextTarget?'#16a34a':'#334155'};white-space:nowrap">${prog>=nextTarget?'🎁 Ödülü Al!':`${nextTarget-prog} Hasat Kaldı`}</button>
        </div>
      </div>
      <b style="color:var(--gd);font-size:11.5px">📜 Günlük Kontratlar</b>`;
      for(const ord of contracts){
        const done=h.contractsDone.includes(ord.idx),have=countInv(ord.reqK),can=have>=ord.qty&&!done;
        const sr=CROPS[ord.seedReward];
        html+=`<div class="journey-box" style="display:flex;justify-content:space-between;align-items:center;gap:8px">
          <div>
            <b>${ord.reqIcon} ${ord.title} <small style="color:#94a3b8">(${ord.giver})</small></b>
            <p>İstenen: <b>${have}/${ord.qty} ${ord.reqName}</b><br>
            Ödül: <span style="color:#fde047">+${ord.gold}🪙 · +${ord.gems}💎 · +${ord.fert}🧪 Gübre · +1 ${sr.icon} ${sr.n} Tohumu</span></p>
          </div>
          ${done?'<span style="color:#4ade80;font-weight:800;font-size:10.5px">✔ Teslim Edildi</span>':`<button type="button" data-g-contract="${ord.idx}" style="background:${can?'#16a34a':'#334155'};white-space:nowrap">${can?'📦 Teslim Et':'Eksik Ürün'}</button>`}
        </div>`;
      }
    }else if(this.uiTab==='upgrades'){
      const nextSoil=SOIL_UPGRADES[h.soilLv+1];
      const nextSpr=SPRINKLER_UPGRADES[h.sprinklerLv+1];
      html+=`<div style="display:flex;flex-direction:column;gap:8px">
        <div class="journey-box">
          <b>🏛️ Cam Sera · ${h.greenhouse?'<span style="color:#4ade80">✔ KURULU</span>':'Kurulu değil'}</b>
          <p>Kış dahil her mevsim tüm tohumları ekebilirsin; ekinler solmaz.</p>
          ${h.greenhouse?'<span style="color:#86efac;font-size:10px">✔ Aktif</span>':`<button type="button" data-g-up="greenhouse" style="background:#0d9488">🏛️ Cam Sera İnşa Et (850🪙 · 6💎 · 12 Odun · 8 Taş)</button>`}
        </div>
        <div class="journey-box">
          <b>🚰 Otomatik Sulama · Sv.${h.sprinklerLv}/3</b>
          <p>${h.sprinklerLv?SPRINKLER_UPGRADES[h.sprinklerLv].desc:'Her sabah yatakları otomatik sular.'}</p>
          ${nextSpr?`<button type="button" data-g-up="sprinkler" style="background:#0284c7">🚰 Sv.${nextSpr.lv} ${nextSpr.name} (${nextSpr.cost.gold}🪙${nextSpr.cost.gems?` · ${nextSpr.cost.gems}💎`:''}${nextSpr.cost.iron_ore?` · ${nextSpr.cost.iron_ore} Demir`:''})</button>`:'<span style="color:#86efac;font-size:10px">✔ Maksimum seviye fıskiye sistemi aktif!</span>'}
        </div>
        <div class="journey-box">
          <b>✨ Toprak Kalitesi · Sv.${h.soilLv}/3</b>
          <p>${h.soilLv?SOIL_UPGRADES[h.soilLv].desc:'Daha hızlı büyüme, fazla mahsul ve yüksek kalite şansı.'}</p>
          ${nextSoil?`<button type="button" data-g-up="soil" style="background:#7c3aed">✨ Sv.${nextSoil.lv} ${nextSoil.name} (${nextSoil.cost.gold}🪙${nextSoil.cost.gems?` · ${nextSoil.cost.gems}💎`:''} · ${nextSoil.cost.fert}🧪 Gübre)</button>`:'<span style="color:#86efac;font-size:10px">✔ Maksimum seviye kristal toprak aktif!</span>'}
        </div>
        <div class="journey-box">
          <b>📐 Bahçe Yatakları Genişletme · ${h.beds}/3 Yatak Açık (${plots.length}/42 Parsel)</b>
          <p>Taş patikalarla ayrılmış 2. ve 3. bahçe yataklarını açarak üretim kapasiteni 42 parsele çıkar.</p>
          ${h.beds<3?`<button type="button" data-g-unlock-bed="${h.beds+1}" style="background:#b45309">🔓 ${GARDEN_BEDS[h.beds+1].name} Aç (${GARDEN_BEDS[h.beds+1].cost.gold}🪙 · ${GARDEN_BEDS[h.beds+1].cost.wood}🪵 · ${GARDEN_BEDS[h.beds+1].cost.stone}🪨)</button>`:'<span style="color:#86efac;font-size:10px">✔ Tüm bahçe yatakları (42/42 parsel) açık!</span>'}
        </div>
      </div>`;
    }
    box.innerHTML=html;
  },

  /* --- Çizim --- */
  sprite(c,s,cx,by,sw,key=''){
    const L=c.leaf,F=c.fruit;
    if(s===0){R(cx-2,by-1,4,2,'#3f2712');R(cx-1,by-3,2,3,'#65a30d');R(cx+1,by-4,2,2,'#a3e635');return}
    // Kök sebzeleri aynı yeşil şekil yerine kendilerine özgü yaprak, çiçek ve ürünle göster.
    if(['potato','carrot','onion','yam','turnip'].includes(key)){
      if(key==='potato'){
        const h=s===1?4:s===2?7:9;R(cx-4,by-h,8,h,'#166534');R(cx-5+sw,by-h+2,4,3,'#22c55e');R(cx+1+sw,by-h,4,3,'#4ade80');
        if(s>=2){R(cx-3,by-h-1,2,2,'#e9d5ff');R(cx+2,by-h+1,2,2,'#f5d0fe')}
        if(s===3){R(cx-5,by-2,3,3,'#a16207');R(cx,by-3,4,3,'#ca8a04');R(cx+3,by-1,2,2,'#92400e')}
        return;
      }
      if(key==='carrot'){
        const h=s===1?4:s===2?7:10;R(cx-1+sw,by-h,2,h,'#15803d');R(cx-4,by-h+2,3,2,'#22c55e');R(cx+1,by-h+1,3,2,'#4ade80');
        if(s===3){R(cx-2,by-4,4,4,'#f97316');R(cx-1,by,2,2,'#ea580c')}
        return;
      }
      if(key==='onion'){
        const h=s===1?5:s===2?8:10;R(cx-3,by-h+2,1,h-2,'#4ade80');R(cx,by-h,1,h,'#22c55e');R(cx+3,by-h+1,1,h-1,'#86efac');
        if(s===3){R(cx-3,by-4,6,4,'#e9d5ff');R(cx-2,by-5,4,1,'#f5f3ff');R(cx-1,by,2,1,'#a16207')}
        return;
      }
      if(key==='yam'){
        const w=s===1?5:s===2?8:10;R(cx-w/2,by-4,w,4,'#7e22ce');R(cx-3+sw,by-7,3,4,'#a855f7');R(cx+1+sw,by-6,3,3,'#9333ea');
        if(s===3){R(cx-3,by-3,6,4,'#b45309');R(cx-1,by+1,2,1,'#78350f')}
        return;
      }
      const h=s===1?4:s===2?7:9;R(cx-3,by-h,3,h,'#22c55e');R(cx+1,by-h+1,3,h-1,'#4ade80');
      if(s===3){R(cx-3,by-4,6,5,'#e9d5ff');R(cx-1,by,2,2,'#c084fc')}
      return;
    }
    // Yaygın ürünler için ayırt edilebilir gövde, yaprak ve meyve siluetleri.
    if(key==='corn'){
      const h=s===1?6:s===2?10:13;R(cx-1+sw,by-h,2,h,'#15803d');R(cx-5,by-h+4,4,2,'#22c55e');R(cx+1,by-h+6,4,2,'#4ade80');
      if(s===3){R(cx-3,by-10,3,6,'#fde047');R(cx-2,by-10,1,6,'#facc15');R(cx+1,by-13,2,4,'#84cc16')}return;
    }
    if(['tomato','pepper','eggplant'].includes(key)){
      const h=s===1?5:s===2?8:9;R(cx-4,by-h,8,h,'#166534');R(cx-5+sw,by-h+2,4,3,'#15803d');R(cx+1+sw,by-h,4,3,'#22c55e');
      if(s===3){R(cx-4,by-7,3,3,F);R(cx+1,by-5,3,3,F);R(cx-1,by-9,2,2,key==='tomato'?'#f87171':F);if(key==='pepper')R(cx+3,by-3,2,4,'#dc2626')}return;
    }
    if(['berry','blueberry','cranberry','star_berry'].includes(key)){
      const h=s===1?4:s===2?7:8;R(cx-5,by-h+2,10,h-2,'#14532d');R(cx-3,by-h,6,4,'#15803d');
      if(s===3)for(const [ox,oy] of [[-4,-6],[1,-7],[-1,-3],[3,-4]])R(cx+ox,by+oy,2,2,F);return;
    }
    if(['pumpkin','melon','sun_melon'].includes(key)){
      const w=s===1?6:s===2?10:13;R(cx-w/2,by-3,w,3,'#15803d');R(cx-5,by-6,4,4,'#22c55e');R(cx+2,by-5,4,3,'#4ade80');
      if(s===3){R(cx-4,by-7,8,7,F);R(cx-3,by-7,1,6,'#ffffff44');R(cx,by-9,2,3,'#166534')}return;
    }
    if(['cabbage','kale'].includes(key)){
      const size=s===1?4:s===2?7:10;R(cx-size/2,by-size/2-1,size,size/2+1,'#166534');R(cx-size/2+1,by-size+2,size-2,size-2,'#22c55e');
      if(s===3){R(cx-4,by-9,8,8,F);R(cx-2,by-8,4,6,'#4ade80');R(cx-3,by-6,6,2,'#86efac')}return;
    }
    if(['sunflower','tulip','snowdrop','mana_rose'].includes(key)){
      const h=s===1?5:s===2?9:12;R(cx-1+sw,by-h,2,h,'#15803d');if(s>=2){R(cx-4,by-h+4,3,2,'#22c55e');R(cx+1,by-h+6,3,2,'#4ade80')}
      if(s===3){R(cx-4+sw,by-h-4,8,7,F);R(cx-1+sw,by-h-2,2,3,key==='sunflower'?'#78350f':'#fff')}return;
    }
    if(['grape','pea'].includes(key)){
      const h=s===1?5:s===2?8:11;R(cx-4,by-h,1,h,'#784421');R(cx+3,by-h,1,h,'#784421');R(cx-3,by-h+2,6,1,'#784421');R(cx-2+sw,by-h+1,2,h-2,'#166534');
      if(s===3){R(cx,by-h+3,3,3,F);R(cx+1,by-h+6,3,3,F);R(cx-2,by-h+5,2,2,F)}return;
    }
    switch(c.shape){
      case 'grain':
        if(s===1){R(cx-2,by-4,1,4,L);R(cx+1,by-3,1,3,L)}
        else for(const k of [-3,0,3]){const h=s===2?7:11;R(cx+k+sw,by-h,1,h,s===2?L:'#ca8a04');if(s===3)R(cx+k-1+sw,by-h-3,3,4,F)}
        break;
      case 'root':
        R(cx-2,by-(s===1?3:5),4,s===1?3:5,L);
        if(s>=2){R(cx-4+sw,by-7,2,3,L);R(cx+2+sw,by-7,2,3,L)}
        if(s===3){R(cx-2,by-2,4,3,F);R(cx-1,by+1,2,1,F)}
        break;
      case 'leaf':
        R(cx-3,by-3,6,3,L);
        if(s>=2)R(cx-4,by-5,8,5,L);
        if(s===3){R(cx-3,by-7,6,6,F);R(cx-1,by-6,2,4,L)}
        break;
      case 'bush':{
        const h=s===1?4:s===2?7:8;
        R(cx-3,by-h,6,h,L);R(cx-2,by-h-1,4,1,'#22c55e');
        if(s===3){R(cx-3,by-7,2,2,F);R(cx+1,by-5,2,2,F);R(cx-1,by-3,2,2,F);R(cx+2,by-8,2,2,F)}
        break}
      case 'tall':{
        const t=s===1?5:s===2?10:14;
        R(cx-1+sw,by-t,2,t,'#15803d');
        if(s>=2){R(cx-4,by-t+3,3,1,L);R(cx+1,by-t+5,3,1,L)}
        if(s===3){
          if(c.flower){R(cx-3+sw,by-t-3,6,5,F);R(cx-1+sw,by-t-1,2,2,'#78350f')}
          else{R(cx-2,by-9,3,5,F);R(cx-1,by-10,1,1,'#fef08a')}
        }
        break}
      case 'vine':{
        const w=s===1?4:s===2?8:10;
        R(cx-w/2,by-3,w,3,L);
        if(s>=2)R(cx-w/2-1,by-5,3,3,'#22c55e');
        if(s===3){R(cx-3,by-7,6,6,F);R(cx-3,by-7,6,1,'#ffffff55');R(cx-1,by-9,2,2,'#15803d')}
        break}
      case 'flower':
        R(cx-1,by-(s===1?3:6),2,s===1?3:6,'#16a34a');
        if(s===2)R(cx-2,by-8,4,2,L);
        if(s===3){R(cx-3,by-10,6,5,F);R(cx-1,by-8,2,2,'#fff')}
        break;
    }
  }
};

window.FARM=FARM;window.CROPS=CROPS;window.GARDEN_BEDS=GARDEN_BEDS;window.ORCHARD_SLOTS=ORCHARD_SLOTS;
