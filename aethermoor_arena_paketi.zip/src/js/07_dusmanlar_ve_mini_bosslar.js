/* ===== DÜŞMANLAR VE MİNİ-BOSSLAR ===== */


const tel=[],prj=[],loot=[];
const ENCOUNTER_VARIANTS=window.ENCOUNTER_VARIANTS={
  defs:{swift:{icon:'⚡',name:'Atik',color:'#fde047'},armored:{icon:'🛡️',name:'Zırhlı',color:'#94a3b8'},volatile:{icon:'💥',name:'Patlayıcı',color:'#fb923c'},treasure:{icon:'💰',name:'Hazine Taşıyan',color:'#facc15'}},
  hash(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0},
  prepare(e){
    if(e.variantPrepared)return;e.variantPrepared=true;if(!['world','frontier'].includes(curMap)||P.lvl<3||e.d.boss||e.el||e.trial)return;
    const key=String(e.saveId||`${e.k}:${Math.round(e.hx)}:${Math.round(e.hy)}`),h=this.hash(key+'|'+(P.adventure?.seed||79));if(h%100>=24)return;const ids=['swift','armored','volatile','treasure'],id=ids[(h>>>8)%ids.length];e.variant=id;e.variantDef=this.defs[id];
    if(id==='swift'){e.speedMod=1.2;e.xpMod=1.2}
    else if(id==='armored'){e.mhp=Math.round(e.mhp*1.35);e.hp=Math.round(e.hp*1.35);e.maxStagger=Math.round((e.maxStagger||50)*1.25);e.xpMod=1.3}
    else if(id==='volatile')e.xpMod=1.25;
    else{e.mhp=Math.round(e.mhp*1.15);e.hp=Math.round(e.hp*1.15);e.xpMod=1.15;e.goldMod=2;e.guaranteedLoot=true}
  },
  restore(e,id){const d=this.defs[id];if(!d)return;e.variantPrepared=true;e.variant=id;e.variantDef=d;if(id==='swift'){e.speedMod=1.2;e.xpMod=1.2}else if(id==='armored'){e.maxStagger=Math.round((e.maxStagger||50)*1.25);e.xpMod=1.3}else if(id==='volatile')e.xpMod=1.25;else{e.xpMod=1.15;e.goldMod=2;e.guaranteedLoot=true}},
  label(e){const d=e.variantDef||this.defs[e.variant];return d?`${d.icon} ${d.name}`:''}
};

function go(e,tx,ty,sp,dt){
  const dx=tx-e.x,dy=ty-e.y,d=Math.hypot(dx,dy);
  if(d>2){
    const slow=e.chill>0?0.4:1;
    mv(e,dx/d*sp*slow*dt,dy/d*sp*slow*dt,e.d.r*.6);
    e.f=dx<0?-1:1;
  }
}


function doParry(e){
  P.parryWindow=0;COMBAT.train('dodge');
  P.rage=Math.min(100,(P.rage||0)+25);
  P.iv=0.6;
  FX.hitStop(5);FX.flash(P.x,P.y-8,58,0,.25);
  shk=7;
  playChord([659,880,1046],.25,'triangle',.08);
  sfx(950,.2,'sine',.08);
  if(!FX.options.reducedMotion)haptic([40,30,80]);

  // Altın şok dalgası
  for(let a=0;a<6.28;a+=0.2){
    FX.emit(P.x,P.y-8,Math.cos(a)*120,Math.sin(a)*120,.25,'#ffd23f',2,60,1);
  }

  // Düşmanı sersemlet
  e.st='rec';
  e.t=2.8;
  e.staggeredT=3.2;
  e.fl=0.2;

  // Otomatik Mükemmel Karşı Saldırı (Counter Finisher)
  const counterDmg=Math.round(S.a*3.2*rnd(0.95,1.15));
  hitMob(e,counterDmg,true,P.f*120,0);
  fl(e.x,e.y-e.d.r*2-16,`⚡ PARİ! ${counterDmg}`,'#ffd23f',true);
}

function hurtP(raw){
  if(P.dead||P.iv>0)return;
  let dm=Math.max(1,Math.round(raw*GAME_BALANCE.profile().damage*rnd(.9,1.1)-S.d*.48));
  if(P.shld>0){
    const absorb=Math.min(P.shld,dm);
    P.shld-=absorb;dm-=absorb;
    fl(P.x,P.y-26,'🛡 -'+absorb,'#38bdf8');
    spark(P.x,P.y-10,8,'#38bdf8',40);
  }
  if(dm>0&&P.merc?.type==='knight'&&P.merc.hp>0&&Math.hypot(P.merc.x-P.x,P.merc.y-P.y)<45){const absorb=Math.min(P.merc.hp,Math.floor(dm*.35));P.merc.hp-=absorb;dm-=absorb;if(absorb)fl(P.merc.x,P.merc.y-20,'🛡 -'+absorb,'#b5d5e9')}
  if(dm>0){
    const balance=GAME_BALANCE.profile();if(balance.lastStand&&dm>=P.hp&&P.hp>S.h*.35&&(P.lastStandCd||0)<=0){dm=Math.max(1,P.hp-1);P.lastStandCd=60;fl(P.x,P.y-44,'✨ SON ŞANS · 1 CAN!','#fde68a',true);playChord([392,523,784],.2,'triangle',.06);haptic([35,35,70])}
    P.rage=Math.min(100,(P.rage||0)+9);
    P.hp=Math.max(0,P.hp-dm);P.iv=.5;hf=.3;shk=Math.max(shk,4);BOND.dismount();P.combatTimer=5;
    fl(P.x,P.y-26,'-'+dm,'#ff5d5d');
    if(P.hp>0&&P.hp<=S.h*.3&&!P.lowHpWarned){P.lowHpWarned=true;fl(P.x,P.y-40,'❤ CAN AZ · İKSİR KULLAN!','#6dff9c',true);sfx(760,.12,'sine',.05)}
    spark(P.x,P.y-10,10,'#e5302f',60);
    sfx(110,.15,'sawtooth',.06);haptic([18,22,32]);
    // Aegis ve Phoenix Pasifleri
    for(const k in P.eq){
      const pass=(P.eq[k]||{}).passive;
      if(!pass)continue;
      if(pass.id==='aegis'&&Math.random()<.25){
        grantShield(70,200);
        fl(P.x,P.y-26,'🛡️ KADİM KALKAN!','#ffd23f',true);
        sfx(600,.15,'sine',.05);
      }else if(pass.id==='phoenix'&&P.hp<=S.h*0.35&&(!P.phoenixCd||P.phoenixCd<=0)){
        P.phoenixCd=25;
        shk=8;
        playChord([523,659,784,1046],.35,'triangle',.07);
        fl(P.x,P.y-26,'🔥 ANKA DİRİLİŞİ!','#ffd23f',true);
        P.hp=Math.min(S.h,P.hp+Math.round(S.h*0.3));
        for(let i=0;i<60;i++){
          const a=i/60*6.283,r=rnd(10,50);
          FX.emit(P.x+Math.cos(a)*r,P.y-8+Math.sin(a)*r*.8,Math.cos(a)*110,Math.sin(a)*110,.5,i%2?'#ffd23f':'#ff8e58',2.4,60,1);
        }
        for(const m of mobs){
          if(!m.dead&&Math.hypot(m.x-P.x,m.y-P.y)<65){
            hitMob(m,Math.round(S.a*2.2),true,m.x>P.x?140:-140,m.y>P.y?140:-140);
          }
        }
      }
    }
    if(P.hp<=0){P.hp=0;P.dead=true;P.fs=null;death()}
  }
}

function hitMob(e,dm,crit,kx=0,ky=0,isIce=false,isFire=false,isLightning=false,secondary=false){
  if(P.buffs.holy>0&&!secondary){
    dm = Math.round(dm * 1.35); // Şapel Işık Kutsaması!
  }
  if(e.dead)return;P.combatTimer=5;
  const shock=isLightning||!isIce&&!isFire&&!secondary&&P.eq.weapon?.element==='lightning';
  if(isIce){e.chill=Math.max(e.chill||0,2.5);e.wet=Math.max(e.wet||0,8)}
  // Kalkanlı Muhafız (Phalanx) Ön Blok Mantığı
  if(e.k==='phalanx'&&!secondary&&!shock&&e.chill<=0&&(!e.staggeredT||e.staggeredT<=0)){
    const dx=P.x-e.x;
    const isFront=(e.f>0&&dx>0)||(e.f<0&&dx<0);
    if(isFront){
      fl(e.x,e.y-22,'🛡️ BLOKE!','#94a3b8',true);
      sfx(160,.12,'square',.06);
      spark(e.x+e.f*6,e.y-10,6,'#fff',40);
      return;
    }
  }

  // Element Reaksiyonu: Buz + Alev = Eriyik Patlaması (Vaporize)
  if(e.chill>0&&isFire){
    const vapDmg=Math.round(S.a*2.2);
    dm+=vapDmg;
    e.chill=0;
    shk=Math.max(shk,5);
    fl(e.x,e.y-e.d.r*2-20,'💥 ERİYİK PATLAMASI!','#fdba74',true);
    playChord([523,740,1046],.25,'triangle',.06);
    for(let a=0;a<6.28;a+=0.3){
      FX.emit(e.x,e.y-8,Math.cos(a)*90,Math.sin(a)*90,.35,'#fed7aa',2,60,1);
    }
  }

  // Denge Kırılması (Sersemlemişken +%50 Savunmasız Hasarı)
  if(e.staggeredT>0){
    dm=Math.round(dm*1.5);
  }

  // Denge Barı İlerlemesi (Posture / Stagger Impact)
  const impact=(crit?25:14)*(isIce?1.4:1);
  e.maxStagger=e.maxStagger||(e.d.boss?150:e.el?90:50);
  e.stagger=(e.stagger||0)+impact;
  if(e.stagger>=e.maxStagger&&(!e.staggeredT||e.staggeredT<=0)){
    e.stagger=0;
    e.staggeredT=3.2;
    e.st='rec';e.t=3.2;
    sfx(750,.25,'sine',.06);
    fl(e.x,e.y-e.d.r*2-14,'💫 SERSEMLEDİ! (+%50 Hasar)','#facc15',true);
    spark(e.x,e.y-10,18,'#facc15',70);
  }
  e.hp-=dm;
  if(!secondary)COMBAT.train('hit');
  const livingProfile=BOSS_SYSTEM.ensure(e);if(livingProfile&&e.hp>0)BOSS_SYSTEM.wake(e,livingProfile);
  if(!secondary&&P.tl&&P.tl.v)P.hp=Math.min(S.h,P.hp+dm*.03*P.tl.v);
  e.fl=.1;e.hv=3.5;
  if(!e.d.boss){e.kx+=kx;e.ky+=ky}
  if(e.st==='idle'||e.st==='ret')e.st='chase';
  
  const col=crit?'#ffe394':isIce?'#7dd3fc':'#fff';
  fl(e.x,e.y-e.d.r*2-6,dm,col,crit,crit?'critical':isIce?'ice':'');
  spark(e.x,e.y-8,crit?14:7,isIce?'#38bdf8':crit?'#ffd23f':'#d33',70);
  sfx(crit?270:isIce?440:190,.08,isIce?'sine':'square',.04);
  if(crit)shk=Math.max(shk,2.6);
  COMBAT.fx(e.x,e.y-8,isIce?'#7dd3fc':isFire?'#fb923c':crit?'#ffd23f':'#fff',crit);

  if(!secondary&&shock)ELEMENTS.chain(e,dm);
  // İkincil hasar pasifleri tekrar tetiklemez; ölüm/ödül yine ortak hitMob yolundan geçer.
  if(!secondary)for(const k in P.eq){
    const pass=(P.eq[k]||{}).passive;
    if(!pass)continue;
    if(pass.id==='lightning'){
      P.hitN=(P.hitN||0)+1;
      if(P.hitN%3===0){
        sfx(160,.2,'sawtooth',.08);
        shk=Math.max(shk,4);
        FX.flash(e.x,e.y-12,52,1,.23);
        for(let k=0;k<12;k++)FX.emit(e.x+FX.rand(-6,6),e.y-40+k*3.5,0,0,.22,'#9be5ff',2);
        fl(e.x,e.y-e.d.r*2-14,'⚡ ŞİMŞEK!','#38bdf8',true);
        e.hp-=Math.round(S.a*1.4);
        for(const m of mobs)if(m!==e&&!m.dead&&m.hp>0&&Math.hypot(m.x-e.x,m.y-e.y)<45)ELEMENTS.strike(m,Math.round(S.a*1.4));
      }
    }else if(pass.id==='vampiric'){
      const vHp=Math.max(1,Math.round(dm*0.08));
      P.hp=Math.min(S.h,P.hp+vHp);
      fl(P.x,P.y-24,'+'+vHp+' 🩸','#f43f5e');
    }else if(pass.id==='frost_shards'&&Math.random()<.35){
      for(let a=0;a<6.28;a+=2.1){
        prj.push({x:e.x,y:e.y-6,vx:Math.cos(a)*180,vy:Math.sin(a)*180,t:.35,dmg:Math.round(S.a*.8),col:'#7dd3fc',isHero:true,isIce:true});
      }
    }
  }

  if(e.hp<=0&&!e.dead){
    e.dead=true;
    e.rt=e.d.boss===1?90:e.d.boss===2?45:18;
    e.tel=0;
    spark(e.x,e.y-8,30,'#ff9f1c',110);
    shk=Math.max(shk,e.d.boss?9:2.2);FX.hitStop(e.d.boss?8:5);
    if(!e.d.boss){fl(e.x,e.y-e.d.r*2-24,`✓ ${e.d.n} YENİLDİ`,'#86efac',true);playChord([392,523,659],.12,'triangle',.025)}
    if(e.variant==='volatile'){tel.push({x:e.x,y:e.y,r:30,t:.9,max:.9,dmg:e.a*.65,c:'255,130,40'});fl(e.x,e.y-30,'💥 PATLAYACAK!','#fb923c',true);sfx(180,.14,'sawtooth',.045)}
    P.kills++;JOURNAL.kill(e);if(!e.trial){DAILY_FOCUS.event('combat',1);EXPEDITIONS.event('kill',e.k,1)}
    const firstDragonVictory=QUEST_FLOW.recordDragon(e);
    if(curMap==='frontier'&&e.k==='boar'){
      P.frontierBoarsKilled=(P.frontierBoarsKilled||0)+1;
      if(P.frontierMission===2){
        const count=Math.min(3,P.frontierBoarsKilled-(P.frontierBoarStart||0));
        fl(e.x,e.y-28,`🧭 Gözcü: ${count}/3 Domuz`,'#c3e8b8',true);
      }
    }
    if(e.trial){
      addXp(Math.max(1,Math.round(e.d.xp*.2*GAME_BALANCE.profile().xp*WORLD_EVENTS.xpMultiplier()*(e.xpMod||1)))); // Yeniden deneyerek ganimet/görev farmı yapılmaz.
    }else{
      addXp(Math.round(e.d.xp*(1+(e.lv-e.d.lv)*.15)*(e.el?3:1)*(P.buffs.grace>0?1.5:1)*GAME_BALANCE.profile().xp*WORLD_EVENTS.xpMultiplier()*(e.xpMod||1)));
      const huntingSlime=e.k==='slime'&&!e.trial&&QS[P.q]?.k==='slime';
    drop(e);qp(e.k);qp('any');
    if(huntingSlime){
      const items=[{s:'mat',k:'wood',qty:2},{s:'mat',k:'stone',qty:1}];
      if(ITEMS.addMany(P.inv,items))fl(e.x,e.y-42,'+2 odun · +1 taş','#d6b48a',true);
      else fl(e.x,e.y-42,'Çanta dolu','#fca5a5',true);
    }
      if(e.el)qp('elite');
    }
    if(e.k==='treant'&&!e.trial){P.ach.treant_killed=1;checkAch('treant')}
    if(e.k==='crab'&&!e.trial){P.ach.crab_killed=1;checkAch('crab')}
    if(e.k==='golem'&&!e.trial){P.ach.golem_killed=1;checkAch('golem')}
    if(e.k==='dragon'&&!e.trial){
      checkAch('dragon');
      ban(firstDragonVictory?'🐉 KIZIL EJDER YENİLDİ!':'🐉 EJDER KARŞILAŞMASI KAZANILDI','#ffd23f');
      chat('SİSTEM','',firstDragonVictory?'Kızıl Ejder zaferin doğrulandı. Gölgeköy’deki hayatını büyütmeye devam edebilirsin.':'Bu tekrar karşılaşmasıydı; önceki ejder zaferin korunuyor.',1);
      playChord([392,523,659,784,1046],.5,'triangle',.06);sv();
    }
    checkAch('first_kill');
    checkAch('slimer');
    if(curMap==='mine'){
      const md=WORLD_DATA.mine;
      const anyAlive=md&&md.mobs.some(m=>!m.dead&&m!==e);
      if(!anyAlive&&md?.ladder&&!md.ladder.uncovered){
        const seal=md.resources.find(r=>r.hasLadder);
        if(seal){revealMineLadder(seal);fl(P.x,P.y-24,'🪜 Tüm canavarlar yenildi, geçit açıldı!','#6ee7b7',true)}
      }
    }
    if(e.k==='colossus'&&!e.trial){
      ban('👑 KRİSTAL MUHAFIZI YENİLDİ! KAT 50 FETHEDİLDİ!','#ffd23f');
      P.gold+=1000;P.gems+=50;
      awardInventoryItem({s:'mat',k:'skull_key',n:'Kafatası Anahtarı',icon:'🗝️',val:500,desc:'Kadim madenlerin fatihi nişanı'});
      sv();
      playChord([523,659,784,1046],.5,'triangle',.08);
      fl(P.x,P.y-28,'+1000 Altın & +50 Elmas & Kafatası Anahtarı!','#ffd23f',true);
    }
    if(curMap==='frontier'&&e.k==='boar')sv();
  }
}

function drop(e){
  const d=e.d,n=ri(1,3);
  const isBMGold = weather.type==='blood_moon';
  const gMult=(isBMGold?3:1)*(P.buffs.grace>0?1.5:1)*GAME_BALANCE.profile().loot*WORLD_EVENTS.lootMultiplier()*(e.goldMod||1);
  for(let i=0;i<n;i++)loot.push({t:'g',v:Math.round((ri(d.g[0],d.g[1])+1)*gMult),x:e.x+rnd(-8,8),y:e.y+rnd(-6,6),vy:-rnd(40,70),z:0,a:0});
  const isB=d.boss||e.el;
  let ni=d.boss===1?3:d.boss===2?2:e.el?2:e.guaranteedLoot?1:Math.random()<.16?1:0;
  if(isB)P.adventure.lootPity=0;else if(ni>0)P.adventure.lootPity=0;else{P.adventure.lootPity=(P.adventure.lootPity||0)+1;if(P.adventure.lootPity>=8){ni=1;P.adventure.lootPity=0;fl(e.x,e.y-30,'🎁 UZUN AV ÖDÜLÜ!','#fde68a',true)}}
  for(let i=0;i<ni;i++){
    const isBM = weather.type==='blood_moon';
    loot.push({t:'i',v:gen(Math.max(P.lvl,e.lv),(d.boss===1||isBM)?3:d.boss===2?2:e.el?1:0),x:e.x+rnd(-14,14),y:e.y+rnd(-8,8),vy:-50,z:0,a:0});
  }
  if(isB||Math.random()<.14)loot.push({t:'p',v:1,x:e.x,y:e.y,vy:-50,z:0,a:0});
  if(d.boss||e.el||Math.random()<.25)loot.push({t:'gem',v:ri(1,d.boss?5:2),x:e.x+rnd(-10,10),y:e.y,vy:-50,z:0,a:0});
}

function bossAI(e,dt,dd,dx,dy){
  const profile=BOSS_SYSTEM.ensure(e),living=!!profile;
  if(living){if(!BOSS_SYSTEM.update(e,dt,dd,dx,dy,profile))return}
  else if(!e.act){
    if(!P.dead&&dd<e.d.ag){
      e.act=true;e.t=1.2;
      ban('⚔ '+e.d.n+' uyandı!','#ff5d5d');
      sfx(70,.6,'sawtooth',.08);
    }else{
      e.hp=Math.min(e.mhp,e.hp+e.mhp*dt*.15);
      return;
    }
  }
  if(!living&&(P.dead||dd>340)){e.act=false;return}
  if(!e.act)return;
  e.cast=Math.max(0,e.cast-dt);
  e.t-=dt;
  const chaseSpeed=profile?profile.huntSpeed:e.d.sp*.7;
  if(chaseSpeed>0&&e.cast<=0&&dd>e.d.r+26)go(e,P.x,P.y,chaseSpeed,dt);
  if(!e.p2&&e.hp<e.mhp*.5){
    e.p2=1;e.t=1.6;e.cast=1.2;
    tel.push({x:e.x,y:e.y,r:e.d.r*5,t:1.1,max:1.1,dmg:e.a*.9,c:'255,60,40'});
    ban('🔥 '+e.d.n+' öfkelendi! (2. FAZ)','#ff7a1a');shk=Math.max(shk,8);sfx(60,.7,'sawtooth',.09);
  }
  
  if(e.t<=0){
    const p2=e.hp<e.mhp*.5;
    if(e.k==='dragon'){
      // Kızıl Ejder
      const r=Math.random();
      if(r<.38){
        tel.push({x:P.x,y:P.y,r:36,t:1,max:1,dmg:e.a,c:'255,110,30'});
      }else if(r<.75){
        const a=Math.atan2(dy,dx),count=p2?5:3;
        for(let i=-(count-1)/2;i<=(count-1)/2;i++){
          const b=a+i*.26;
          prj.push({x:e.x,y:e.y-30,vx:Math.cos(b)*110,vy:Math.sin(b)*110,t:3,dmg:e.a*.7});
        }
        e.cast=.6;sfx(160,.3,'sawtooth',.06);
      }else{
        tel.push({x:e.x,y:e.y,r:p2?92:68,t:1.2,max:1.2,dmg:e.a*1.3,c:'255,40,40'});
        e.cast=.9;
      }
      if(p2){
        // Enraged phase: Meteor rain
        for(let k=0;k<2;k++){
          tel.push({x:P.x+rnd(-50,50),y:P.y+rnd(-50,50),r:28,t:1.1,max:1.1,dmg:e.a,c:'255,110,30'});
        }
      }
      e.t=p2?1.5:2.3;
    }else if(e.k==='treant'){
      // Orman Muhafızı: Kök patlaması
      tel.push({x:P.x,y:P.y,r:30,t:1,max:1,dmg:e.a*1.1,c:'120,200,60'});
      tel.push({x:e.x+rnd(-30,30),y:e.y+rnd(-30,30),r:25,t:1.2,max:1.2,dmg:e.a,c:'120,200,60'});
      e.t=2.6;
    }else if(e.k==='crab'){
      // Kral Yengeç: Su baloncukları
      const a=Math.atan2(dy,dx);
      for(let i=-1;i<=1;i++){
        const b=a+i*.3;
        prj.push({x:e.x,y:e.y-10,vx:Math.cos(b)*95,vy:Math.sin(b)*95,t:2.5,dmg:e.a*.8,col:'#38bdf8'});
      }
      e.t=2.5;
    }else if(e.k==='golem'){
      // Kum Golemi: Şok dalgası ve kaya fırlatma
      tel.push({x:e.x,y:e.y,r:50,t:1.1,max:1.1,dmg:e.a*1.2,c:'220,160,60'});
      const a=Math.atan2(dy,dx);
      prj.push({x:e.x,y:e.y-16,vx:Math.cos(a)*100,vy:Math.sin(a)*100,t:2.5,dmg:e.a,col:'#d97706'});
      e.t=2.8;
    }else if(e.k==='gladiator'){
      const a=Math.atan2(dy,dx);
      if(Math.random()<.5){
        for(let i=1;i<=3;i++)tel.push({x:e.x+Math.cos(a)*i*26,y:e.y+Math.sin(a)*i*26,r:20,t:.8+i*.12,max:.8+i*.12,dmg:e.a,c:'220,220,240'});
      }else{tel.push({x:e.x,y:e.y,r:p2?80:60,t:1,max:1,dmg:e.a*1.2,c:'255,80,80'});e.cast=.8}
      if(p2)for(let k=0;k<2;k++)tel.push({x:P.x+rnd(-40,40),y:P.y+rnd(-40,40),r:24,t:1,max:1,dmg:e.a*.9,c:'255,200,80'});
      e.t=p2?1.7:2.4;
    }else if(e.k==='magma_golem'){
      for(let i=0;i<(p2?4:2);i++)tel.push({x:P.x+rnd(-60,60),y:P.y+rnd(-60,60),r:26,t:1.2,max:1.2,dmg:e.a,c:'255,110,30'});
      const a=Math.atan2(dy,dx);
      for(let i=-1;i<=1;i++){const b=a+i*.35;prj.push({x:e.x,y:e.y-10,vx:Math.cos(b)*100,vy:Math.sin(b)*100,t:2.5,dmg:e.a*.8,col:'#f97316'})}
      e.t=2.7;
    }else if(e.k==='colossus'){
      const n=p2?8:5;
      for(let i=0;i<n;i++){const b=i/n*6.283;prj.push({x:e.x,y:e.y-14,vx:Math.cos(b)*105,vy:Math.sin(b)*105,t:3,dmg:e.a*.7,col:'#67e8f9'})}
      tel.push({x:P.x,y:P.y,r:34,t:1,max:1,dmg:e.a*1.1,c:'103,232,249'});
      if(p2)tel.push({x:e.x,y:e.y,r:100,t:1.4,max:1.4,dmg:e.a*1.3,c:'200,120,255'});
      e.t=p2?1.9:2.6;
    }
  }
}
const BOSS_SYSTEM=window.BOSS_SYSTEM={
  traces:[],
  profile(e){return curMap==='world'?BOSS_CONFIG.profiles[e?.k]||null:null},
  // Başka haritadaki/maden bossları bu açık-dünya rutinine dahil değildir.
  isLiving(e){return !!this.profile(e)},
  ensure(e){
    const p=this.profile(e);if(!p)return null;
    if(!e.bossLivingInit){
      e.bossLivingInit=true;e.bossLairX=e.hx;e.bossLairY=e.hy;e.bossState='sleep';
      e.bossTimer=rnd(BOSS_CONFIG.rules.sleepMin,BOSS_CONFIG.rules.sleepMax);e.bossTargetX=e.x;e.bossTargetY=e.y;e.bossPatrols=0;
      e.bossTraceX=e.x;e.bossTraceY=e.y;e.bossTraceTimer=rnd(1,2);e.act=false;
    }
    return p;
  },
  reset(e){e.bossLivingInit=false;e.bossLairX=e.hx;e.bossLairY=e.hy;e.bossState='sleep';e.act=false;this.ensure(e)},
  safePoint(x,y){
    return Math.hypot(x-C*TS,y-C*TS)<130||
      Object.values(WORLD_OUTPOSTS).some(s=>Math.hypot(x-(s.x*TS+8),y-(s.y*TS+8))<55)||
      Math.hypot(x-(LAKE_DOCK.x*TS+8),y-(LAKE_DOCK.y*TS+8))<80||
      Math.hypot(x-(WORLD_GATE.x*TS+8),y-(WORLD_GATE.y*TS+8))<60;
  },
  playerSafe(){return curMap==='world'&&this.safePoint(P.x,P.y)},
  chooseWaypoint(e,p){
    const map=WORLD_DATA.world,radius=p.patrolTiles*TS;
    for(let i=0;i<36;i++){
      const angle=rnd(0,Math.PI*2),dist=rnd(2,Math.max(2,p.patrolTiles))*TS,x=e.bossLairX+Math.cos(angle)*dist,y=e.bossLairY+Math.sin(angle)*dist;
      const tx=x/TS|0,ty=y/TS|0;
      if(tx<3||ty<3||tx>=map.N-3||ty>=map.N-3||zoneOf(tx,ty)!==p.zone||Math.hypot(x-e.bossLairX,y-e.bossLairY)>radius||this.safePoint(x,y)||bl(x,y,e.d.r*.65))continue;
      if(mobs.some(other=>other!==e&&!other.dead&&other.d.boss&&Math.hypot(other.x-x,other.y-y)<38))continue;
      return{x,y};
    }
    return{x:e.bossLairX,y:e.bossLairY};
  },
  setPatrol(e,p){
    const target=this.chooseWaypoint(e,p);e.bossTargetX=target.x;e.bossTargetY=target.y;
    e.bossTimer=rnd(BOSS_CONFIG.rules.patrolMin,BOSS_CONFIG.rules.patrolMax);e.bossState='patrol';e.act=false;
  },
  wake(e,p){
    if(e.bossState==='retreat'||e.bossState==='hunt'&&e.act)return;
    e.bossState='hunt';e.act=true;e.t=Math.max(Number(e.t)||0,1.15);
    ban('⚔ '+p.name+' seni fark etti!','#ff5d5d');sfx(70,.35,'sawtooth',.06);
  },
  retreat(e){e.bossState='retreat';e.bossTimer=0;e.act=false;e.cast=0;ban('⚠ '+e.d.n+' yaralı halde yuvasına çekiliyor.','#e9c27a')},
  update(e,dt,dd,dx,dy){
    const p=this.ensure(e);if(!p||e.dead)return false;
    const rules=BOSS_CONFIG.rules,safe=this.playerSafe(),lairDistance=Math.hypot(e.x-e.bossLairX,e.y-e.bossLairY),wounded=e.hp<=e.mhp*rules.retreatHp;
    if(wounded&&['hunt','patrol','sleep'].includes(e.bossState)){this.retreat(e)}
    if(e.bossState==='sleep'){
      e.act=false;e.hp=Math.min(e.mhp,e.hp+e.mhp*dt*.012);
      if(!P.dead&&!safe&&dd<p.sense){this.wake(e,p);return true}
      e.bossTimer-=dt;if(e.bossTimer<=0)this.setPatrol(e,p);return false;
    }
    if(e.bossState==='patrol'){
      e.act=false;e.hp=Math.min(e.mhp,e.hp+e.mhp*dt*.006);
      if(!P.dead&&!safe&&dd<p.sense){this.wake(e,p);return true}
      e.bossTimer-=dt;
      if(e.bossTimer<=0||Math.hypot(e.x-e.bossTargetX,e.y-e.bossTargetY)<9){
        e.bossPatrols=(e.bossPatrols||0)+1;
        if(e.bossPatrols>=2){e.bossPatrols=0;e.bossState='return';e.act=false;return false}
        this.setPatrol(e,p);
      }
      const vx=e.bossTargetX-e.x,vy=e.bossTargetY-e.y;if(Math.hypot(vx,vy)>8){go(e,e.bossTargetX,e.bossTargetY,p.patrolSpeed,dt);e.f=vx<0?-1:1}
      return false;
    }
    if(e.bossState==='hunt'){
      if(wounded){this.retreat(e);return false}
      if(P.dead||safe||dd>p.leashTiles*TS){e.bossState='return';e.act=false;return false}
      e.act=true;return true;
    }
    if(e.bossState==='retreat'){
      e.act=false;go(e,e.bossLairX,e.bossLairY,p.returnSpeed,dt);
      if(lairDistance<20){e.bossState='rest';e.bossTimer=8}
      return false;
    }
    if(e.bossState==='return'){
      e.act=false;
      if(!P.dead&&!safe&&dd<p.sense&&e.hp>e.mhp*rules.retreatHp){this.wake(e,p);return true}
      go(e,e.bossLairX,e.bossLairY,p.returnSpeed,dt);e.hp=Math.min(e.mhp,e.hp+e.mhp*dt*.01);
      if(lairDistance<20){if(e.hp<e.mhp*rules.recoverHp){e.bossState='rest';e.bossTimer=8}else{e.bossState='sleep';e.bossTimer=rnd(rules.sleepMin,rules.sleepMax)}}
      return false;
    }
    if(e.bossState==='rest'){
      e.act=false;e.bossTimer-=dt;e.hp=Math.min(e.mhp,e.hp+e.mhp*dt*rules.restRegen);
      if(!P.dead&&!safe&&dd<p.sense){this.wake(e,p);return true}
      if(e.hp>=e.mhp*rules.recoverHp||e.bossTimer<=0)this.setPatrol(e,p);
      return false;
    }
    e.bossState='sleep';e.bossTimer=rnd(rules.sleepMin,rules.sleepMax);e.act=false;return false;
  },
  tick(dt){
    let write=0;for(const t of this.traces){t.life-=dt;if(t.life>0)this.traces[write++]=t}this.traces.length=write;
    if(curMap!=='world')return;
    for(const e of mobs){const p=this.ensure(e);if(!p||e.dead)continue;
      e.bossTraceTimer=Math.max(0,(e.bossTraceTimer||0)-dt);
      const dx=e.x-e.bossTraceX,dy=e.y-e.bossTraceY,d=Math.hypot(dx,dy);
      if(d>=BOSS_CONFIG.rules.traceDistance&&e.bossTraceTimer<=0){
        this.traces.push({boss:e.k,name:p.name,icon:p.icon,clue:p.clue,color:p.trace,x:e.bossTraceX,y:e.bossTraceY,dx,dy,life:BOSS_CONFIG.rules.traceLife,maxLife:BOSS_CONFIG.rules.traceLife,read:false});
        if(this.traces.length>BOSS_CONFIG.rules.traceLimit)this.traces.splice(0,this.traces.length-BOSS_CONFIG.rules.traceLimit);
        e.bossTraceX=e.x;e.bossTraceY=e.y;e.bossTraceTimer=BOSS_CONFIG.rules.traceInterval;
      }else if(d>BOSS_CONFIG.rules.traceDistance*3){e.bossTraceX=e.x;e.bossTraceY=e.y}
    }
  },
  nearestTrace(){if(curMap!=='world')return null;let found=null,dist=BOSS_CONFIG.rules.traceRadius;for(const t of this.traces){if(t.read)continue;const d=Math.hypot(P.x-t.x,P.y-t.y);if(d<dist){found=t;dist=d}}return found},
  inspectTrace(t){
    if(!t||t.read||!this.traces.includes(t)||Math.hypot(P.x-t.x,P.y-t.y)>BOSS_CONFIG.rules.traceRadius+8)return false;
    t.read=true;const angle=(Math.atan2(t.dy,t.dx)*180/Math.PI+360)%360,dirs=['doğu','güneydoğu','güney','güneybatı','batı','kuzeybatı','kuzey','kuzeydoğu'],dir=dirs[Math.round(angle/45)%8];
    const text=`${t.icon} ${t.name}: ${t.clue}. İzler ${dir} yönüne gidiyor.`;ban('🔎 '+t.name+' izi bulundu','#d8c69a');chat('İZ SÜRÜCÜ','',text,1);fl(P.x,P.y-28,'👣 '+dir+' yönünde','#e8d2a4',true);return true;
  },
  drawTrack(t,x,y){
    g.save();g.globalAlpha=Math.min(.72,.72*(t.life/t.maxLife));g.fillStyle=t.color;g.fillRect(x-3,y-1,6,2);g.fillRect(x-2,y+2,2,2);g.fillRect(x+1,y-3,2,2);g.globalAlpha*=.65;g.fillStyle='#f3e6c7';g.fillRect(x-1,y-1,2,1);g.restore();
  }
};

function hitCritter(c){
  if(c.tamed)return;
  if(c.dead||c.st==='flee')return;
  // Nötr yaban hayatı bedava şifa kaynağı değil; ürküp uzaklaşır.
  c.st='flee';c.t=2.2;c.hopT=0;
  spark(c.x,c.y-4,6,'#a7f3d0',35);
  sfx(620,.06,'sine',.025);
  fl(c.x,c.y-14,'Yaban hayvanı kaçtı','#a7f3d0');
}

function updCritters(dt){
  if(!critters)return;
  const climate=curMap==='frontier'?frontierClimate():null;
  for(const c of critters){
    if(c.tamed)continue;
    if(c.dead){
      c.rt-=dt;
      if(c.rt<=0){c.dead=false;c.x=c.hx;c.y=c.hy;c.st='idle';c.t=rnd(1,3)}
      continue;
    }
    c.t-=dt;
    const dP=Math.hypot(P.x-c.x,P.y-c.y);
    if(c.st!=='flee'&&dP<42){
      c.st='flee';c.t=2.2;
      fl(c.x,c.y-10,'!','#fff');sfx(650,.04,'sine',.02);
    }
    // Yaylada yağmur/sis/gece kuşları ve keçileri sürüklenmeden yuvalarına toplar.
    const shelter=!!(climate&&(c.type==='mountain_goat'||c.type==='bird')&&
      (climate.storm||climate.night||(climate.season===3&&c.type==='mountain_goat')));
    if(shelter&&c.st!=='flee')c.st='shelter';
    if(c.st==='flee'){
      const dx=c.x-P.x,dy=c.y-P.y,d=Math.hypot(dx,dy)||1;
      mv(c,dx/d*52*dt,dy/d*52*dt,3);
      c.f=dx>0?1:-1;c.hopT+=dt*10;
      if(c.type==='bird')c.z=Math.min(18,c.z+30*dt);
      if(c.t<=0){c.st='idle';c.t=rnd(2,4);c.z=0}
    }else if(c.st==='shelter'){
      if(!shelter){c.st='idle';c.t=rnd(.5,1.1)}
      else{
        const dx=c.hx-c.x,dy=c.hy-c.y,d=Math.hypot(dx,dy);
        if(d>3)mv(c,dx/d*20*dt,dy/d*20*dt,3);
        if(c.type==='bird')c.z=0;
      }
    }else if(c.st==='hop'){
      c.hopT+=dt*7;
      const nx=c.x+c.vx*dt,ny=c.y+c.vy*dt;
      if(climate&&c.type==='mountain_goat'&&![16,9,2].includes(tAt(nx,ny))){
        c.st='idle';c.t=rnd(1,2);c.vx=c.vy=0;
      }else mv(c,c.vx*dt,c.vy*dt,3);
      if(c.t<=0){c.st='idle';c.t=rnd(2,5);c.hopT=0}
    }else if(c.t<=0){
      c.st='hop';c.t=rnd(.8,1.6);
      const a=climate&&Math.hypot(c.x-c.hx,c.y-c.hy)>64?Math.atan2(c.hy-c.y,c.hx-c.x):rnd(0,6.283);
      const sp=c.type==='frog'?34:c.type==='lizard'?40:c.type==='mountain_goat'?26:24;
      c.vx=Math.cos(a)*sp;c.vy=Math.sin(a)*sp;c.f=c.vx>0?1:-1;
    }
  }
}

function updMobs(dt){
  const climate=curMap==='frontier'?frontierClimate():null;
  for(const e of mobs){
    if(e.dead){
      if(e.trial||curMap==='mine')continue; // Zindan ilerlemesi o oyun günü boyunca korunur.
      e.rt-=dt;
      if(e.rt<=0){
        e.dead=false;e.hp=e.mhp;e.x=e.hx;e.y=e.hy;e.st='idle';e.act=false;e.p2=0;
        if(BOSS_SYSTEM.isLiving(e))BOSS_SYSTEM.reset(e);
      }
      continue;
    }
    e.t-=dt;e.fl=Math.max(0,e.fl-dt);e.hv=Math.max(0,e.hv-dt);
    if(e.chill>0)e.chill-=dt;
    if(e.wet>0)e.wet=Math.max(0,e.wet-dt);
    if(Math.hypot(P.x-e.x,P.y-e.y)<150)JOURNAL.see(e);ENCOUNTER_VARIANTS.prepare(e);
    if(e.staggeredT>0){
      e.staggeredT-=dt;
      continue; // Sersemlemişken hareket ve saldırı yapamaz!
    }
    e.ph+=dt*(e.st==='chase'||['hunt','retreat'].includes(e.bossState)?9:4)*(e.chill>0?.5:1);
    const dx=P.x-e.x,dy=P.y-e.y,dd=Math.hypot(dx,dy),d=e.d,moveSpeed=d.sp*(e.speedMod||1);
    
    if(d.boss){
      bossAI(e,dt,dd,dx,dy);
      e.f=['retreat','return'].includes(e.bossState)?(e.bossLairX<e.x?-1:1):(dx<0?-1:1);
      continue;
    }
    
    mv(e,e.kx*dt,e.ky*dt,d.r*.6);
    e.kx*=Math.pow(.02,dt);e.ky*=Math.pow(.02,dt);
    const hd=Math.hypot(e.x-e.hx,e.y-e.hy);
    const scent=climate&&e.k==='boar'?(weather.type==='fog'?.7:climate.season===3?1.25:1):1;
    const safe=curMap==='world'?
      (Math.hypot(P.x-C*TS,P.y-C*TS)<130||
       Object.values(WORLD_OUTPOSTS).some(s=>Math.hypot(P.x-(s.x*TS+8),P.y-(s.y*TS+8))<55)||
       Math.hypot(P.x-(LAKE_DOCK.x*TS+8),P.y-(LAKE_DOCK.y*TS+8))<80||
       Math.hypot(P.x-(WORLD_GATE.x*TS+8),P.y-(WORLD_GATE.y*TS+8))<60):
      curMap==='frontier'?
        (Math.hypot(P.x-(FRONTIER.gate.x*TS+8),P.y-(FRONTIER.gate.y*TS+8))<60||
         (P.hasFieldCamp&&Math.hypot(P.x-(FRONTIER.camp.x*TS+8),P.y-(FRONTIER.camp.y*TS+8))<70)||
         (P.frontierMission>=1&&Math.hypot(P.x-(FRONTIER_STATION.x*TS+8),P.y-(FRONTIER_STATION.y*TS+8))<62)):
      curMap==='mine'?Math.hypot(P.x-(4*TS+8),P.y-(5*TS+8))<55:
      curMap==='home'||curMap==='inside';
    
    switch(e.st){
      case'idle':
        if(e.t<=0){const w=e.guard?0:40;e.tx=e.hx+rnd(-w,w);e.ty=e.hy+rnd(-w,w);e.t=rnd(2,4)}
        go(e,e.tx,e.ty,moveSpeed*.4,dt);
        if(!P.dead&&!safe&&dd<d.ag*scent){e.st='chase';if(e.variant&&!e.variantWarned){e.variantWarned=true;const v=e.variantDef;fl(e.x,e.y-e.d.r*2-18,`${v.icon} ${v.name} ${d.n}` ,v.color,true)}if((e.lv||d.lv)>=P.lvl+4&&!e.levelWarned){e.levelWarned=true;fl(e.x,e.y-e.d.r*2-16,`☠ SV.${e.lv||d.lv} · ÇOK GÜÇLÜ`,'#fca5a5',true);sfx(120,.22,'sawtooth',.05)}}
        break;
      case'chase':
        go(e,P.x,P.y,moveSpeed,dt);
        if(dd<COMBAT.trig(e))COMBAT.wind(e,dx,dy);
        if(P.dead||safe||hd>220||dd>d.ag*2.6*scent)e.st='ret';
        break;
      case'wind':
        if(COMBAT.tick(e,dx,dy,dd)==='parry')continue;
        break;
      case'rec':
        COMBAT.lungeHit(e,dd,dt);
        if(e.t<=0)e.st='chase';
        break;
      default:
        go(e,e.hx,e.hy,moveSpeed*1.3,dt);
        e.hp=Math.min(e.mhp,e.hp+e.mhp*dt*.3);
        if(hd<8)e.st='idle';
    }
  }
}

/* ===== DÜNYA GEZGİNLERİ: KASABANIN İŞÇİ/NPC LİSTESİNİ EZMEMELİ ===== */
const PN=['Phantomb','Stone','nano_16','GölgeAv','EjderAvcı','Zeynep','KaanX','Mavi','Rüzgar','Lordum','Ayla','Bora'],TG=['[WG3]','[GXC]','[STS]','','[ALP]','[TURK]'];
function safeWorldNpcPosition(z){
  const map=WORLD_DATA.world,home=ZC[z];
  for(let i=0;i<160;i++){
    const tx=cl(Math.round(home[0]+rnd(-7,7)),3,map.N-4),ty=cl(Math.round(home[1]+rnd(-7,7)),3,map.N-4);
    const x=tx*TS+8,y=ty*TS+8,t=map.tl[ty*map.N+tx];
    if(t===1||t===13||Math.hypot(x-50*TS,y-50*TS)<22)continue;
    if(map.objs.some(o=>Math.abs(o.x-x)<14&&Math.abs(o.y-y)<14&&Math.hypot(o.x-x,o.y-y)<o.r+4))continue;
    if(map.hs.some(h=>x>h.x-28&&x<h.x+28&&y>h.y-10&&y<h.y+4))continue;
    if(map.mobs.some(e=>e.d.boss&&Math.hypot(e.x-x,e.y-y)<100))continue;
    return{x,y};
  }
  return{x:54*TS+8,y:54*TS+8};
}
WORLD_DATA.world.npcs=PN.map((n,i)=>{
  const z=i<5?0:pick([1,2,3]),pos=safeWorldNpcPosition(z);
  return{
    n,tag:pick(TG),lv:ri(5,50),
    x:pos.x,y:pos.y,bx:pos.x,by:pos.y,
    tx:pos.x,ty:pos.y,t:rnd(0,3),f:0,w:0,sw:0,
    c:pick(['#c0392b','#2980b9','#27ae60','#8e44ad','#d68910']),
    h:pick(['#4a2c1a','#222','#d4a017','#7a1f5c']),
    cape:pick(['#c0392b','#16a085','#f1c40f']),
    d:{r:4},hp:1
  };
});

