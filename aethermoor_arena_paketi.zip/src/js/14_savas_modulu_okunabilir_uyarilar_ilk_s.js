/* ===== SAVAŞ MODÜLÜ: okunabilir uyarılar, ilk savaş dersi ve hedef durumu ===== */
function closeCombatGuide(){$('combat-guide-modal').classList.add('h');GAME_CORE.resetInput()}
function openCombatGuide(){
  if(P.adventure.combatLessonSeen)return;
  P.adventure.combatLessonSeen=true;
  P.adventure.combatTraining={hits:0,dodge:false,skill:false,done:false};sv();
  $('combat-guide-modal').classList.remove('h');GAME_CORE.resetInput();
}
function replayCombatGuide(){$('help').classList.add('h');$('combat-guide-modal').classList.remove('h');GAME_CORE.resetInput()}
$('combat-guide-close').onclick=closeCombatGuide;
$('combat-guide-resume').onclick=closeCombatGuide;
$('combat-guide-replay').onclick=replayCombatGuide;
const COMBAT=window.COMBAT={
  get mobs(){return mobs},get prj(){return prj},get tel(){return tel},
  training(){
    if(!P.adventure.combatLessonSeen)return null;
    if(!P.adventure.combatTraining)P.adventure.combatTraining={hits:0,dodge:false,skill:false,done:false};
    return P.adventure.combatTraining;
  },
  train(kind){
    const t=this.training();if(!t||t.done)return;
    if(kind!=='hit'&&!mobs.some(e=>!e.dead&&Math.hypot(e.x-P.x,e.y-P.y)<190))return;
    const before=`${t.hits}|${t.dodge}|${t.skill}`;
    if(kind==='hit')t.hits=Math.min(3,(t.hits||0)+1);
    else if(kind==='dodge')t.dodge=true;
    else if(kind==='skill')t.skill=true;
    if(before===`${t.hits}|${t.dodge}|${t.skill}`)return;
    if(t.hits>=3&&t.dodge&&t.skill){
      t.done=true;P.pots++;ban('⚔️ SAVAŞ ALIŞTIRMASI TAMAM! +1 CAN İKSİRİ','#86efac');playChord([523,659,784,1046],.3,'triangle',.055);fl(P.x,P.y-32,'+1 🧪 CAN İKSİRİ','#6dff9c',true);
    }
    sv();
  },
  // Düşman davranış tablosu: cone=yay şeklinde vuruş, lunge=atılma, ranged=menzilli mermi (w=uyarı süresi sn)
  AI:{wolf:{m:'lunge',w:.85,len:70},boar:{m:'lunge',w:.9,len:62},assassin:{m:'lunge',w:.72,len:88},scorpion:{m:'lunge',w:.8,len:56},lizard:{m:'lunge',w:.8,len:52},bat:{m:'lunge',w:.7,len:60},
      summoner:{m:'ranged',w:1.05,rng:120},skeleton:{m:'cone',w:.78},ice_skeleton:{m:'cone',w:.82},phalanx:{m:'cone',w:.92},slime:{m:'cone',w:.75}},
  ai(e){return this.AI[e.k]||{m:'cone',w:.78}},
  trig(e){const a=this.ai(e);return a.m==='ranged'?a.rng:a.m==='lunge'?e.d.rg+a.len*.55:e.d.rg},
  wind(e,dx,dy){
    const a=this.ai(e);e.st='wind';e.tgMax=e.t=a.w*GAME_BALANCE.profile().windup*(e.chill>0?1.5:1);e.tgA=Math.atan2(dy,dx);e.lu=0;e.lh=0;e.tgPing=0;P.combatTimer=5;
    if(Math.hypot(dx,dy)<135){fl(e.x,e.y-e.d.r*2-12,'⚠','#fbbf24',true);sfx(520,.07,'triangle',.035)}
    if(!P.adventure.combatLessonSeen)openCombatGuide();
  },
  // Uyarı süresince yön takip edilir, son 0.2 sn kilitlenir -> kaçınılabilir. 'parry' döndürürse pariden sonra çık.
  tick(e,dx,dy,dd){
    const a=this.ai(e),d=e.d;
    e.f=dx<0?-1:1;
    if(e.t>.2)e.tgA=Math.atan2(dy,dx);
    if(e.t<=.24&&!e.tgPing){e.tgPing=1;fl(e.x,e.y-e.d.r*2-16,'❗ ŞİMDİ SIYRIL!','#fca5a5',true);sfx(880,.08,'square',.055)}
    if(e.t>0)return;
    const ca=Math.cos(e.tgA),sa=Math.sin(e.tgA);
    if(a.m==='ranged'){
      prj.push({x:e.x,y:e.y-8,vx:ca*125,vy:sa*125,t:2,dmg:e.a,col:'#a78bfa'});
      spark(e.x+ca*8,e.y-10,8,'#a78bfa',50);sfx(300,.12,'sine',.05);
      e.st='rec';e.t=1.2;return;
    }
    if(a.m==='lunge'){
      e.kx=ca*a.len*3.9;e.ky=sa*a.len*3.9;e.lu=.28;e.lh=0;
      spark(e.x,e.y-6,6,'#fff',50);sfx(240,.1,'sawtooth',.04);
      e.st='rec';e.t=1;return;
    }
    let df=Math.atan2(P.y-e.y,P.x-e.x)-e.tgA;df=Math.abs(Math.atan2(Math.sin(df),Math.cos(df)));
    if(dd<d.rg+6&&df<.95){
      if(P.parryWindow>0){doParry(e);return'parry'}
      hurtP(e.a);
    }
    spark(e.x+ca*8,e.y-8,6,'#fff',50);
    e.st='rec';e.t=.9*(e.chill>0?1.4:1);
  },
  lungeHit(e,dd,dt){
    if(e.lu>0){e.lu-=dt;if(!e.lh&&dd<e.d.rg+8){e.lh=1;if(P.parryWindow>0)doParry(e);else hurtP(Math.round(e.a*1.1))}}
  },
  drawTg(){
    for(const e of mobs){
      if(e.dead||e.st!=='wind'||!e.tgMax)continue;
      const a=this.ai(e),k=cl(1-e.t/e.tgMax,0,1),R0=e.d.rg+6;
      const hot=k>.7?`255,${Math.round(220-k*180)},40`:'255,200,60';
      g.save();g.translate(e.x,e.y-4);g.rotate(e.tgA||0);
      if(a.m==='cone'){
        g.beginPath();g.moveTo(0,0);g.arc(0,0,R0,-.95,.95);g.closePath();
        g.fillStyle=`rgba(${hot},${.12+.18*k})`;g.fill();g.strokeStyle=`rgba(${hot},.85)`;g.lineWidth=1;g.stroke();
        g.beginPath();g.moveTo(0,0);g.arc(0,0,R0*k,-.95,.95);g.closePath();
        g.fillStyle=`rgba(${hot},${.2+.3*k})`;g.fill();
      }else{
        const L=a.m==='lunge'?a.len:a.rng,W=a.m==='lunge'?e.d.r*.8:2;
        g.fillStyle=`rgba(${hot},${.12+.18*k})`;g.fillRect(0,-W,L,W*2);
        g.strokeStyle=`rgba(${hot},.85)`;g.lineWidth=1;g.strokeRect(0,-W,L,W*2);
        g.fillStyle=`rgba(${hot},${.2+.3*k})`;g.fillRect(0,-W,L*k,W*2);
      }
      g.restore();
    }
  },
  // --- Kahraman saldırıları ---
  aim(reach){
    const t=near(reach);
    if(t){const dx=t.x-P.x,dy=t.y-P.y,d=Math.hypot(dx,dy)||1;P.ax=dx/d;P.ay=dy/d;P.f=dirOf(dx,dy)}
    else{P.ax=[0,0,-1,1][P.f];P.ay=[1,-1,0,0][P.f]}
  },
  orb(big){
    const sp=big?190:235;
    prj.push({x:P.x+P.ax*8,y:P.y-10+P.ay*8,vx:P.ax*sp,vy:P.ay*sp,t:big?.95:.75,dmg:big?Math.round(S.a*2.4):S.a,
      col:big?'#e879f9':'#818cf8',kind:'orb',big:big?1:0,isHero:true,boom:big?46:24,bm:big?.8:.5,critBonus:big?.2:0});
  },
  arrow(big){
    const sp=big?400:300;
    prj.push({x:P.x+P.ax*8,y:P.y-10+P.ay*8,vx:P.ax*sp,vy:P.ay*sp,t:.7,dmg:big?Math.round(S.a*2.5):S.a,
      col:big?'#fde047':'#facc15',kind:'arrow',big:big?1:0,isHero:true,critBonus:big?.35:.15,pierce:big?4:0});
  },
  // Ağır saldırı (tuşu basılı tut): büyücü=patlayıcı küre, avcı=delici ok. Mana yetmezse normal atış.
  strike(ch){
    const cls=P.cls||'warrior';
    if(!ch||cls==='warrior'){attack();return}
    if(P.dead||P.fs||P.cd>0||P.sw>0)return;
    const cost=cls==='mage'?12:10;
    if(P.mp<cost){fl(P.x,P.y-24,'Mana yetersiz','#60a5fa');attack();return}
    P.mp-=cost;this.aim(160);P.sw=.22;P.cd=.6;
    if(cls==='mage'){
      this.orb(true);sfx(180,.3,'sawtooth',.06);playChord([392,587],.2,'sine',.05);
      fl(P.x,P.y-28,'🔮 KAOS KÜRESİ','#e879f9',true);spark(P.x+P.ax*12,P.y-10+P.ay*12,14,'#e879f9',60);
    }else{
      this.arrow(true);sfx(260,.2,'triangle',.07);
      fl(P.x,P.y-28,'🏹 DELİCİ ATIŞ','#fde047',true);spark(P.x+P.ax*12,P.y-10+P.ay*12,10,'#fde047',60);
    }
    shk=Math.max(shk,2);
  },
  // Küre patlaması: isabet edilen hedef dışındakilere alan hasarı
  boom(p){
    const R0=p.boom,c=p.col;
    for(let a=0;a<6.283;a+=p.big?.25:.45)FX.emit(p.x,p.y,Math.cos(a)*R0*3.2,Math.sin(a)*R0*3.2,.28,c,p.big?2:1.4,55,1);
    FX.flash(p.x,p.y,R0*1.6,c,p.big?.35:.22);spark(p.x,p.y,p.big?16:7,'#fff',60);
    if(p.big){shk=Math.max(shk,4);FX.hitStop(5);sfx(120,.3,'sawtooth',.07)}else sfx(300,.08,'sine',.04);
    for(const e of mobs){
      if(e.dead||e===p.main)continue;
      if(Math.hypot(e.x-p.x,e.y-p.y)<R0+e.d.r*.6&&BOND.lineClear(p,e))hitMob(e,Math.round(p.dmg*p.bm),false,(e.x-p.x)*3,(e.y-p.y)*3);
    }
  },
  // Vuruş efekti: halka + kritikte çizgiler, hit-stop
  fx(x,y,c,crit){FX.impact(x,y,c,crit)},
  drawP(p){
    FX.glow(p.x,p.y,p.big?23:p.kind==='arrow'?8:14,p.col||'#ff704e',p.kind==='arrow'?.3:.7);
    if(p.kind==='arrow'){
      const a=Math.atan2(p.vy,p.vx),L=p.big?13:10;
      g.save();g.translate(p.x,p.y);g.rotate(a);
      g.fillStyle='#8b5a2b';g.fillRect(-L,-.5,L,1);
      g.fillStyle=p.big?'#fde047':'#e2e8f0';g.fillRect(0,-1.5,3,3);g.fillRect(3,-.5,2,1);
      g.fillStyle='#fff';g.fillRect(-L,-2,3,1);g.fillRect(-L,1,3,1);
      g.restore();
    }else if(p.kind==='orb'){
      const r=(p.big?5:3.5)+Math.sin(P.t*30)*.7;
      g.fillStyle=p.col;g.beginPath();g.arc(p.x,p.y,r,0,6.283);g.fill();
      g.fillStyle='#fff';g.beginPath();g.arc(p.x,p.y,r*.5,0,6.283);g.fill();
    }else{R(p.x-3,p.y-3,6,6,p.col||'#ff9f1c');R(p.x-1,p.y-1,2,2,'#fff')}
  },
  // Test yardımcısı: verilen noktada düşman oluşturur
  spawn(k,x,y){
    const d=MT[k],m={k,d,x,y,hx:x,hy:y,lv:d.lv,mhp:d.hp,hp:d.hp,a:d.a,el:false,st:'idle',t:0,kx:0,ky:0,fl:0,dead:false,rt:0,f:1,ph:0,tx:x,ty:y,v:0,hv:0,cast:0,act:false,r:d.r,chill:0};
    mobs.push(m);return m;
  }
};

function attack(){
  if(P.dead||P.fs||P.cd>0||P.sw>0||BUILD.active)return;
  BOND.dismount();
  const cls=P.cls||"warrior";
  COMBAT.aim(cls==="warrior"?54:130);
  if(cls==="mage"){
    P.sw=.2;P.cd=.36;COMBAT.orb(false);
    sfx(620,.08,"sine",.04);
    spark(P.x+P.ax*12,P.y-10+P.ay*12,6,"#c084fc",35);
  }else if(cls==="ranger"){
    P.sw=.2;P.cd=.26;COMBAT.arrow(false);
    sfx(540,.06,"triangle",.04);
    spark(P.x+P.ax*12,P.y-10+P.ay*12,4,"#fef08a",40);
  }else{
    P.cb=P.ct>0?(P.cb+1)%3:0;
    P.ct=.85;P.sw=.26;P.hd=false;P.cd=.32;
    sfx(380+P.cb*50,.06,"square",.025);
    showCombo();
  }
}

function showCombo(){
  const ch=$("combo-hud");
  ch.textContent=`KOMBO x${P.cb+1}${P.cb===2?" ★ BİTİRİCİ":""}`;
  ch.style.opacity=1;
  clearTimeout(showCombo.t);
  showCombo.t=setTimeout(()=>ch.style.opacity=0,700);
}

function doHit(){
  const cb=P.cb,reach=34+cb*7;let any=false;
  FX.slash(P.x,P.y-10,Math.atan2(P.ay,P.ax),reach*.83,cb===2?0:1,cb===2,2.2+cb*.4);
  for(const e of mobs){
    if(e.dead)continue;
    const dx=e.x-P.x,dy=e.y-P.y,d=Math.hypot(dx,dy);
    if(d>reach+e.d.r*.6||!BOND.lineClear(P,e))continue;
    if(d>14&&(dx*P.ax+dy*P.ay)/d<.1)continue;
    
    const cr=Math.random()<(S.c+(cb===2?.2:0));
    P.rage=Math.min(100,(P.rage||0)+(cr?12:6));
    hitMob(e,Math.round(S.a*(1+.28*cb)*rnd(.9,1.1)*(cr?1.8:1)),cr,dx/(d||1)*(60+cb*45),dy/(d||1)*(60+cb*45));
    any=true;
  }
  for(const c of critters){
    if(c.dead||c.tamed)continue;
    if(Math.hypot(c.x-P.x,c.y-P.y)<reach+6){hitCritter(c);any=true}
  }
  // Çiftlikteki Kütük ve Taşları Temizleme (Odun & Taş Toplama)
  if(curMap==='home'){
    for(let i=objs.length-1;i>=0;i--){
      const o=objs[i];
      if(o.k==='stump'||o.k==='boulder'){
        const d=Math.hypot(o.x-P.x,o.y-P.y);
        if(d<reach+o.r+4)any=strikeFarmDebris(o)||any;
      }
    }
  }

  for(const res of resources){
    if(res.mined||!res.isOre)continue;
    const dx=res.x-P.x,dy=res.y-P.y,d=Math.hypot(dx,dy);
    if(d<reach+res.r+4)any=strikeOre(res,(P.skills?.mine?.lvl||1)>=2?2:1)||any;
  }
  if(any){
    shk=Math.max(shk,1+cb*1.2);
    FX.hitStop(cb===2?5:3);
  }
}

/* 1. Sınıf Yeteneği [K] */
function skill1(){
  if(BUILD.active)return;BOND.dismount();
  const cls=P.cls||"warrior";
  const cData=CLASSES[cls]||CLASSES.warrior;
  if(P.dead||P.cs>0||P.mp<cData.s1Mp)return;
  P.mp-=cData.s1Mp;P.cs=5.5;COMBAT.train('skill');

  if(cls==="warrior"){
    shk=6;FX.hitStop(4);FX.slash(P.x,P.y-8,0,47,1,true,6);sfx(220,.4,"sawtooth",.06);
    for(let i=0;i<40;i++){
      const a=i/40*6.283,r=rnd(14,56);
      FX.emit(P.x+Math.cos(a)*r,P.y-8+Math.sin(a)*r*.8,Math.cos(a+1.6)*80,Math.sin(a+1.6)*80,FX.rand(.2,.5),'#e2e8f0',2,60,1);
    }
    for(const e of mobs){
      if(e.dead)continue;
      const dx=e.x-P.x,dy=e.y-P.y,d=Math.hypot(dx,dy);
      if(d>62+e.d.r)continue;
      const cr=Math.random()<S.c;
      hitMob(e,Math.round(S.a*2.5*rnd(.9,1.1)*(cr?1.8:1)),cr,dx/(d||1)*150,dy/(d||1)*150);
    }
  }else if(cls==="mage"){
    shk=7;FX.hitStop(5);FX.flash(P.x,P.y-8,90,4,.4);sfx(150,.5,"sawtooth",.07);
    for(let i=0;i<70;i++){
      const a=i/70*6.283,r=rnd(10,52);
      FX.emit(P.x+Math.cos(a)*r,P.y-8+Math.sin(a)*r*.8,Math.cos(a+1.6)*50,Math.sin(a+1.6)*50-15,FX.rand(.3,.7),i%2?'#ffd23f':'#ff8d55',2,40,1);
    }
    for(const e of mobs){
      if(e.dead)continue;
      const dx=e.x-P.x,dy=e.y-P.y,d=Math.hypot(dx,dy);
      if(d>54+e.d.r)continue;
      const cr=Math.random()<S.c;
      hitMob(e,Math.round(S.a*2.6*rnd(.9,1.1)*(cr?1.8:1)),cr,dx/(d||1)*140,dy/(d||1)*140,false,true);
    }
  }else if(cls==="ranger"){
    shk=4;playChord([587,740,880],.2,"triangle",.04);
    const angles=[-0.36,-0.18,0,0.18,0.36];
    const baseA=Math.atan2(P.ay,P.ax);
    angles.forEach(offset=>{
      const a=baseA+offset;
      prj.push({
        x:P.x,y:P.y-10,vx:Math.cos(a)*270,vy:Math.sin(a)*270,t:0.65,
        dmg:Math.round(S.a*1.5),col:"#f59e0b",kind:"arrow",isHero:true,critBonus:0.2
      });
    });
  }
}

/* 2. Sınıf Yeteneği [U] */
function skill2(){
  if(BUILD.active)return;BOND.dismount();
  const cls=P.cls||"warrior";
  const cData=CLASSES[cls]||CLASSES.warrior;
  if(P.dead||P.ci>0||P.mp<cData.s2Mp)return;
  P.mp-=cData.s2Mp;P.ci=6.5;COMBAT.train('skill');

  if(cls==="warrior"){
    shk=5;sfx(160,.2,"square",.06);
    grantShield(80,160);
    fl(P.x,P.y-26,"+80 🛡️ KALKAN","#38bdf8",true);
    mv(P,P.ax*65,P.ay*65,4);
    FX.flash(P.x,P.y-10,48,1,.3);
    for(let i=0;i<20;i++)FX.emit(P.x+FX.rand(-10,10),P.y-10+FX.rand(-10,10),FX.rand(-30,30),FX.rand(-30,30),.3,'#8addff',2);
    for(const e of mobs){
      if(e.dead)continue;
      const dx=e.x-P.x,dy=e.y-P.y,d=Math.hypot(dx,dy);
      if(d>52+e.d.r)continue;
      e.chill=2.5;
      hitMob(e,Math.round(S.a*1.8),false,P.ax*120,P.ay*120);
    }
  }else if(cls==="mage"){
    shk=5;playChord([587,740,880,1175],.3,"sine",.05);
    for(let i=0;i<60;i++){
      const a=i/60*6.283,r=rnd(8,56);
      FX.emit(P.x+Math.cos(a)*r,P.y-8+Math.sin(a)*r*.8,Math.cos(a)*70,Math.sin(a)*70,FX.rand(.3,.6),i%2?'#e0f2fe':'#7dd3fc',2,30,1);
    }
    for(const e of mobs){
      if(e.dead)continue;
      const dx=e.x-P.x,dy=e.y-P.y,d=Math.hypot(dx,dy);
      if(d>60+e.d.r)continue;
      e.chill=3.5;
      hitMob(e,Math.round(S.a*2.0*rnd(.9,1.1)),false,dx/(d||1)*90,dy/(d||1)*90,true);
    }
  }else if(cls==="ranger"){
    shk=4;sfx(780,.15,"sine",.05);
    const baseA=Math.atan2(P.ay,P.ax);
    prj.push({
      x:P.x,y:P.y-10,vx:Math.cos(baseA)*290,vy:Math.sin(baseA)*290,t:0.7,
      dmg:Math.round(S.a*2.1),col:"#38bdf8",kind:"arrow",big:1,isHero:true,isIce:true,critBonus:0.1,pierce:2
    });
    for(let i=0;i<15;i++)FX.emit(P.x,P.y-8,FX.rand(-20,20),FX.rand(-20,20),.25,'#a5f3fc',1.5);
  }
}

function potion(){
  if(P.dead||P.cp>0||P.pots<=0||(P.hp>=S.h&&P.mp>=S.m))return;
  P.pots--;P.cp=1.2;
  const h=Math.round(S.h*.5),m=Math.round(S.m*.4);
  P.hp=Math.min(S.h,P.hp+h);
  P.mp=Math.min(S.m,P.mp+m);
  fl(P.x,P.y-26,"+"+h+" ❤","#6dff9c");
  spark(P.x,P.y-8,22,"#6dff9c",45);
  sfx(700,.15,"sine",.05);
}

function dash(){
  if(BUILD.active)return;BOND.dismount();
  if(P.dead||P.fs||P.cd2>0)return;
  const cls=P.cls||"warrior";
  const v=In.vec();let dx=v.x,dy=v.y;
  if(Math.hypot(dx,dy)<.1){dx=P.ax;dy=P.ay}
  const m=Math.hypot(dx,dy)||1;
  P.dx=dx/m;P.dy=dy/m;P.parryWindow=0.25;COMBAT.train('dodge');

  if(cls==="mage"){
    P.cd2=2.4;P.iv=.4;
    for(let i=0;i<18;i++)FX.emit(P.x,P.y-10,FX.rand(-40,40),FX.rand(-40,40),.3,'#c084fc',2);
    mv(P,P.dx*75,P.dy*75,4);
    for(let i=0;i<18;i++)FX.emit(P.x,P.y-10,FX.rand(-40,40),FX.rand(-40,40),.3,'#818cf8',2);
    fl(P.x,P.y-22,"IŞINLANMA!","#c084fc",false,"dodge");
    sfx(720,.12,"sine",.04);
  }else if(cls==="ranger"){
    P.ds=.2;P.cd2=2.2;P.iv=.35;P.buffs.spd=2.5;S=st();
    fl(P.x,P.y-22,"GÖLGE ADIMI!","#6ee7b7",false,"dodge");
    sfx(440,.12,"sine",.04);
  }else{
    P.ds=.2;P.cd2=2.4;P.iv=.38;
    fl(P.x,P.y-22,"SIYRILMA!","#67e8f9",false,"dodge");
    sfx(280,.15,"sine",.04);
  }
}
function spark(x,y,n,c,s){FX.sparks(x,y,n,c,s)}
function fl(x,y,t,c,big,extraClass){FX.text(x,y,t,c,big,extraClass)}

/* ===== MÜZİK VE ÇEVRE AMBİYANSI ===== */
let mT=0,mI=0;
const SCALES=[
  [0,4,7,11,12],     // Gölgeköy: Sıcak huzurlu majör
  [0,3,7,10,12],     // Zümrüt Orman: Mistik dorian
  [0,2,5,7,9],       // Sığ Göl: Dingin akan melodi
  [0,1,5,7,8],       // Kızıl Çöl: Egzotik çöl
  [0,1,4,7,8]        // Ejder İni: Gergin karanlık frijyen
];

const TRACK_MELODIES = {
  // Track 0: Huzurlu Çiftlik Valsi
  0: [
    { n: 261.6, d: 0.38 }, { n: 329.6, d: 0.38 }, { n: 392.0, d: 0.42 },
    { n: 493.9, d: 0.38 }, { n: 523.3, d: 0.55 }, { n: 392.0, d: 0.38 },
    { n: 329.6, d: 0.38 }, { n: 293.7, d: 0.48 },
    { n: 261.6, d: 0.38 }, { n: 349.2, d: 0.38 }, { n: 440.0, d: 0.42 },
    { n: 392.0, d: 0.55 }, { n: 329.6, d: 0.38 }, { n: 261.6, d: 0.55 }
  ],
  // Track 1: Yağmurlu Kahve Molası (Lo-Fi Akorları)
  1: [
    { n: 349.2, d: 0.48 }, { n: 440.0, d: 0.42 }, { n: 523.3, d: 0.42 }, { n: 659.3, d: 0.58 },
    { n: 329.6, d: 0.48 }, { n: 392.0, d: 0.42 }, { n: 493.9, d: 0.42 }, { n: 587.3, d: 0.58 },
    { n: 293.7, d: 0.48 }, { n: 349.2, d: 0.42 }, { n: 440.0, d: 0.42 }, { n: 523.3, d: 0.58 },
    { n: 261.6, d: 0.52 }, { n: 329.6, d: 0.48 }, { n: 392.0, d: 0.58 }
  ],
  // Track 2: Aethermoor Efsanesi (Epik Fantastik Ezgi)
  2: [
    { n: 293.7, d: 0.32 }, { n: 349.2, d: 0.32 }, { n: 440.0, d: 0.38 },
    { n: 523.3, d: 0.32 }, { n: 587.3, d: 0.52 }, { n: 440.0, d: 0.38 },
    { n: 392.0, d: 0.32 }, { n: 349.2, d: 0.32 }, { n: 329.6, d: 0.38 }, { n: 293.7, d: 0.65 }
  ],
  // Track 3: Yıldızlı Gece Ninnisi
  3: [
    { n: 523.3, d: 0.55 }, { n: 659.3, d: 0.55 }, { n: 523.3, d: 0.55 },
    { n: 392.0, d: 0.65 }, { n: 440.0, d: 0.55 }, { n: 523.3, d: 0.65 },
    { n: 392.0, d: 0.85 }, { n: 329.6, d: 0.65 }, { n: 261.6, d: 0.85 }
  ]
};

let gramoNoteIdx = 0;
function music(dt){
  if(!AC||mute)return;
  mT-=dt;
  if(mT>0)return;

  if(curMap==='inside'||curMap==='home'){
    // Gramofon Müzik Kutusu Çalımı (Gerçek melodik akorlar!)
    const trk = TRACK_MELODIES[musicTrack||0] || TRACK_MELODIES[0];
    if(!trk || !trk.length) return;
    const item = trk[gramoNoteIdx % trk.length];
    if(!item) return;
    gramoNoteIdx++;
    mT = item.d || 0.4;
    sfx(item.n, (item.d || 0.4) * 0.95, 'triangle', (curMap==='inside'?0.026:0.016) * volMusic);
    if(gramoNoteIdx % 3 === 0){
      sfx(item.n / 2, (item.d || 0.4) * 1.3, 'sine', 0.018);
    }
  }else{
    // Açık Dünya / Savaş Bölgesi Atmosferi
    mT=.5;
    const base=[196,174,164,185,130][P.z||0];
    const scl=SCALES[P.z||0]||SCALES[0];
    const n=scl[(mI++*2+ri(0,2))%scl.length];
    sfx(base*Math.pow(2,n/12),.8,'triangle',0.016 * volMusic);
    if(mI%4===0)sfx(base/2,1.5,'sine',.02);
  }
}

