/* ===== ADIM 3: KASABA PARKI + MOZAİK BAHÇE (harita üretimi) ===== */
function buildTownPark(tl,objs,N){
  const TSZ=16,inZ=(x,y)=>(x>=23&&x<=29&&y>=9&&y<=19)||(x>=32&&x<=42&&y>=8&&y<=19);
  for(let i=objs.length-1;i>=0;i--){const o=objs[i];if((o.k==='tree'||o.k==='pine')&&inZ(Math.floor(o.x/TSZ),Math.floor(o.y/TSZ)))objs.splice(i,1)}
  for(let y=10;y<=18;y++)for(let x=24;x<=29;x++)tl[y*N+x]=3;            // mozaik bahçe zemini
  const cx=37,cy=12,A=2.7,B=1.9;                                          // park gölü + yürüyüş halkası
  for(let y=8;y<=18;y++)for(let x=32;x<=42;x++){
    if(tl[y*N+x]===1)continue;
    const q=Math.hypot((x-cx)/A,(y-cy)/B);
    if(q<=1)tl[y*N+x]=1;else if(q<=1.32)tl[y*N+x]=2;else if(q>=1.4&&q<=1.85)tl[y*N+x]=3;
  }
  for(let x=32;x<=33;x++){tl[13*N+x]=3;tl[14*N+x]=3}
  for(let y=15;y<=18;y++){tl[y*N+36]=3;tl[y*N+37]=3}
  const add=(k,x,y,r,extra)=>objs.push(Object.assign({k,x,y,r,v:H(Math.round(x),Math.round(y))},extra||{}));
  /* mozaik bahçe: çit, güneş saati, banklar */
  for(let x=388;x<=476;x+=9){add('pk_hedge',x,164,5);if(x<404||x>460)add('pk_hedge',x,300,5)}
  for(let y=173;y<=300;y+=9){add('pk_hedge',388,y,5);if(y<260||y>290)add('pk_hedge',476,y,5)}
  add('pk_sundial',432,232,5);add('pk_bench',402,222,5);add('pk_bench',432,196,5);
  /* park: banklar, lambalar, ağaçlar, piknik */
  [[37,9],[35,15],[39,15],[33,10],[41,11]].forEach(([x,y])=>add('pk_bench',x*TSZ+8,y*TSZ+12,5));
  [[560,150],[656,150],[560,262],[656,262]].forEach(([x,y])=>add('lamp',x,y,3));
  [[530,140],[562,138],[594,138],[626,138],[658,140],[526,170],[528,270],[528,302],[560,312],[600,308],[640,312],[668,302],[680,176],[680,262]]
    .forEach(([x,y],i)=>add(i%4===3?'pine':'tree',x,y,4));
  add('pk_picnic',566,286,-3);add('pk_picnic',662,286,-3);
  /* kafe terası */
  add('pk_table',470,376,6);add('pk_table',470,420,6);
}

function initHomeMap(){
  const hN=60,hC=30;
  const hTl=new Uint8Array(hN*hN),hObjs=[],hHs=[],hCritters=[];
  for(let i=0;i<hTl.length;i++)hTl[i]=0; // Yemyeşil çimenlik zemin

  // 1. Kıvrımlı Doğal Mavi Nehir (Kuzeyden Güneye Akış - Görsel 1 & 2 & 3)
  for(let y=0;y<hN;y++){
    const rx=Math.round(44+Math.sin(y*0.12)*3);
    for(let w=-2;w<=2;w++){
      hTl[y*hN+rx+w]=1; // nehir suyu
      hTl[y*hN+rx-3]=2; // kum sahil
      hTl[y*hN+rx+3]=2;
    }
  }

  // 2. Kasaba Çevre Surları & Taş Burçlar (Görsel 1 & 3)
  for(let x=4;x<56;x++){
    hTl[4*hN+x]=4; // kuzey suru
  }
  for(let y=4;y<56;y++){
    if(Math.abs(y-30)>2){
      hTl[y*hN+4]=4; // batı suru
      hTl[y*hN+56]=4; // doğu suru
    }
  }

  // Nehir kıvrıldığı için her köprü iki kuru kıyıya kadar uzanır.
  for(const y of [16,30,44]){
    const rx=Math.round(44+Math.sin(y*.12)*3);
    for(let x=Math.min(40,rx-4);x<=Math.max(48,rx+4);x++)hTl[y*hN+x]=3;
  }

  // 4. Arnavut Kaldırımı Büyük Pazar Meydanı (Görsel 1 & 2)
  for(let y=20;y<=36;y++)for(let x=24;x<=38;x++){
    hTl[y*hN+x]=3;
  }

  // 5. Ana Yollar, Caddeler ve 4 Bölgeli Taş Patikalı Çiftlik Kampüsü
  for(let y=8;y<=20;y++)for(let b=0;b<2;b++)hTl[y*hN+30+b]=3; // Şapele giden kuzey caddesi
  for(let x=4;x<=24;x++)for(let b=0;b<2;b++)hTl[(30+b)*hN+x]=3; // Çiftliğe giden batı yolu
  for(let x=48;x<=56;x++)for(let b=0;b<2;b++)hTl[(30+b)*hN+x]=3; // Doğu kapısı yolu
  for(let y=36;y<=44;y++)for(let b=0;b<2;b++)hTl[y*hN+30+b]=3; // Güneye giden cadde
  // Doğu köprüsünden demirci kapısına uzanan, oyuncunun izleyebileceği taş yol.
  for(let y=31;y<=41;y++)for(let x=49;x<=51;x++)if(hTl[y*hN+x]!==1)hTl[y*hN+x]=3;
  for(let x=48;x<=51;x++)hTl[40*hN+x]=3;

  // --- YENİ 4 BÖLGELİ ÇİFTLİK KAMPÜSÜ TAŞ PATİKA AĞI ---
  // 1) Çiftlik Evi Avlusu & Bulvarı (Sevkiyat -> Ev -> Kuyu -> Bahçe Tabelası -> Pazar Meydanı)
  for(let y=24;y<=25;y++)for(let x=9;x<=24;x++)hTl[y*hN+x]=3;
  // 2) Kuzey-Güney Kampüs Yolu (Batı Hayvancılık Meraları ile Doğu Tarla/Meyve Bahçesini ayırır)
  for(let y=15;y<=35;y++)for(let x=13;x<=14;x++)hTl[y*hN+x]=3;
  // 3) Kuzey Meyve Bahçesi Yürüyüş Yolu
  for(let x=14;x<=22;x++)hTl[20*hN+x]=3;
  // 4) Sebze Tarlası Yatakları Arası Taş Yürüyüş Yolları (Yatak 1, Yatak 2 ve Yatak 3 ayrımı)
  for(let x=14;x<=23;x++){hTl[25*hN+x]=3;hTl[29*hN+x]=3;hTl[33*hN+x]=3}
  for(let y=25;y<=33;y++){hTl[y*hN+19]=3;hTl[y*hN+23]=3}
  // 5) Güney Zanaat & Arıcılık Terası (Arı Kovanı ve Mayalama Fıçısı ayrı taş kaidelerde)
  for(let y=34;y<=35;y++)for(let x=14;x<=21;x++)hTl[y*hN+x]=3;

  // 6. Binalar & Şehir Yapıları:
  // Bizim Çiftlik Evimiz (Batı Çiftlik)
  hHs.push({x:12*TS,y:24*TS,c:'#a65c5c',isPlayerHome:true,title:'Çiftlik Evimiz 🏡'});
  // Belediye Konağı (Kuzeybatı - Görsel 2)
  hHs.push({x:18*TS,y:12*TS,c:'#2563eb',isTownHall:true,title:'Belediye Konağı 🏛️'});
  // Kasaba Demircisi & Açık Hava Ocağı (Güneydoğu - Görsel 1)
  hHs.push({x:50*TS,y:38*TS,c:'#475569',isForge:true,title:'Kasaba Demircisi 🔨'});
  // Köy Tavernası & Hanı (Güneybatı)
  hHs.push({x:20*TS,y:40*TS,c:'#78350f',isTavern:true,title:'Köy Tavernası 🍺'});

  // 7. Kasaba ve Pazar Nesneleri:
  // Antik Taş Su Kuyusu (Meydanın Tam Ortasında)
  hObjs.push({k:'well',x:31*TS,y:30*TS,r:6,v:0});
  // Çiftlik Evi Yanı Su Kuyusu
  hObjs.push({k:'well',x:16*TS,y:24*TS,r:6,v:0});
  // Karanlık Kristal Madeni Giriş Tüneli (Kuzeybatı Kayalığı)
  hObjs.push({k:'mine_entrance',x:6*TS,y:8*TS,r:8,v:0});

  // Tarihi Su Değirmeni (Nehir kenarında su çarkı dönüyor)
  hObjs.push({k:'watermill',x:48*TS,y:22*TS,r:8,v:0});

  // İlan & Sipariş Panosu
  hObjs.push({k:'pillar',x:31*TS,y:24*TS,r:5,v:0.1});

  // Sokak Fenerleri (Meydan ve Kampüs Köşeleri)
  [[24,20],[38,20],[24,36],[38,36],[48,28],[14,24],[23,25]].forEach(([lx,ly])=>hObjs.push({k:'lamp',x:lx*TS,y:ly*TS,r:3,v:0}));

  // BÖLGE 2: Kuzey Meyve Bahçesi (Orchard - Taş Patika ile Çevrili Düzenli Ağaç Sırası)
  const homeFruitTrees = [
    { slot:0, k:'apple_tree', treeType:'apple', x:15*TS, y:16*TS, r:5, isPeach:false, fruitReady:true },
    { slot:1, k:'apple_tree', treeType:'apple', x:17*TS, y:16*TS, r:5, isPeach:false, fruitReady:true },
    { slot:2, k:'peach_tree', treeType:'peach', x:19*TS, y:16*TS, r:5, isPeach:true, fruitReady:true },
    { slot:3, k:'peach_tree', treeType:'peach', x:21*TS, y:16*TS, r:5, isPeach:true, fruitReady:true }
  ];
  homeFruitTrees.forEach(t=>hObjs.push(t));

  // Maden Önü Kütük ve Kaya Yığınları (Çiftlik avlusunu kapatmadan maden ağzı kenarında)
  const farmCleanups = [
    { k: 'stump', x: 9*TS, y: 9*TS, hp: 2, r: 5, v: 0.1 },
    { k: 'stump', x: 11*TS, y: 9*TS, hp: 2, r: 5, v: 0.2 },
    { k: 'boulder', x: 9*TS, y: 11*TS, hp: 2, r: 5, v: 0.1 },
    { k: 'boulder', x: 11*TS, y: 11*TS, hp: 2, r: 5, v: 0.2 }
  ];
  farmCleanups.forEach((o,i)=>{o.homeId='debris-'+i;hObjs.push(o)});

  // Çevre Ağaçları (Kampüs ve Meraların Dış Çevresi)
  for(let y=2;y<hN-2;y++)for(let x=2;x<hN-2;x++){
    const t=hTl[y*hN+x];
    if(t===1||t===3||t===4)continue;
    if(x>=24&&x<=28&&y>=38&&y<=45||x>=33&&x<=37&&y>=38&&y<=44)continue; // İnşa parselleri ve giriş şeridi.
    if((x>=5&&x<=24&&y>=7&&y<=38)||(x>=24&&x<=38&&y>=20&&y<=36)||(x>44&&y>14&&y<44))continue;
    const r=H(x*3+17,y*7+89);
    if(t===0&&r<0.16)hObjs.push({k:r<0.08?'pine':'tree',x:x*TS+8,y:y*TS+8,r:4,v:r});
  }

  buildTownPark(hTl,hObjs,hN);

  const homeChickens = [];
  const homeEggs = [];
  const homeCow = { id: 0, x: 8*TS, y: 32*TS };
  const homeSheep = { id: 0, x: 10*TS, y: 34*TS, f: 1, woolReady: true, t: 3 };

  // Göletteki Ördekler
  const homeDucks = [
    { id:0, x:44*TS, y:28*TS, f:1 },
    { id:1, x:45*TS, y:32*TS, f:-1 }
  ];

  // BÖLGE 1: Düzenli 1. Bahçe Yatağı (Başlangıç 4x3 = 12 Simetrik Parsel, x: 15..18, y: 26..28)
  const hPlots=[
    {id:0,bed:1,x:15*TS+8,y:26*TS+8,crop:'wheat',stage:3,age:4,t:0,watered:true,moisture:1,fert:0,dry:0},
    {id:1,bed:1,x:16*TS+8,y:26*TS+8,crop:'wheat',stage:3,age:4,t:0,watered:true,moisture:1,fert:0,dry:0},
    {id:2,bed:1,x:17*TS+8,y:26*TS+8,crop:'carrot',stage:2,age:2,t:0,watered:true,moisture:1,fert:0,dry:0},
    {id:3,bed:1,x:18*TS+8,y:26*TS+8,crop:'carrot',stage:2,age:2,t:0,watered:true,moisture:1,fert:0,dry:0},
    {id:4,bed:1,x:15*TS+8,y:27*TS+8,crop:'berry',stage:2,age:4,t:0,watered:true,moisture:1,fert:0,dry:0},
    {id:5,bed:1,x:16*TS+8,y:27*TS+8,crop:'potato',stage:1,age:2,t:0,watered:true,moisture:1,fert:0,dry:0},
    {id:6,bed:1,x:17*TS+8,y:27*TS+8,crop:null,stage:0,age:0,t:0,watered:false,moisture:0,fert:0,dry:0},
    {id:7,bed:1,x:18*TS+8,y:27*TS+8,crop:null,stage:0,age:0,t:0,watered:false,moisture:0,fert:0,dry:0},
    {id:8,bed:1,x:15*TS+8,y:28*TS+8,crop:null,stage:0,age:0,t:0,watered:false,moisture:0,fert:0,dry:0},
    {id:9,bed:1,x:16*TS+8,y:28*TS+8,crop:null,stage:0,age:0,t:0,watered:false,moisture:0,fert:0,dry:0},
    {id:10,bed:1,x:17*TS+8,y:28*TS+8,crop:null,stage:0,age:0,t:0,watered:false,moisture:0,fert:0,dry:0},
    {id:11,bed:1,x:18*TS+8,y:28*TS+8,crop:null,stage:0,age:0,t:0,watered:false,moisture:0,fert:0,dry:0}
  ];

  // Kasaba Halkı (Pazar Tezgahları Arkasında Çalışan Sakinler)
  const hNpcs=[
    {n:'Melis',tag:'🥐 Fırıncı',lv:10,x:27*TS,y:23*TS,bx:27*TS,by:23*TS,tx:0,ty:0,t:3,f:0,w:0,sw:0,c:'#ef4444',h:'#78350f',cape:'#f87171',d:{r:4},hp:1,stationary:true},
    {n:'Amca Osman',tag:'🥕 Manav',lv:12,x:35*TS,y:23*TS,bx:35*TS,by:23*TS,tx:0,ty:0,t:3,f:0,w:0,sw:0,c:'#2563eb',h:'#14532d',cape:'#60a5fa',d:{r:4},hp:1,stationary:true},
    {n:'Aylin',tag:'🌸 Botanik',lv:15,x:27*TS,y:35*TS,bx:27*TS,by:35*TS,tx:0,ty:0,t:4,f:0,w:0,sw:0,c:'#16a34a',h:'#831843',cape:'#4ade80',d:{r:4},hp:1,stationary:true},
    {n:'Çiftçi Dede',tag:'🌾 Başbahçıvan',lv:8,x:14*TS,y:21*TS,bx:14*TS,by:21*TS,tx:0,ty:0,t:4,f:0,w:0,sw:0,c:'#92400e',h:'#78350f',cape:'#fde047',d:{r:4},hp:1},
    {n:'Ozan Can',tag:'🎵 Ozan',lv:14,x:22*TS,y:21*TS,bx:22*TS,by:21*TS,tx:0,ty:0,t:4,f:0,w:0,sw:0,c:'#8b5cf6',h:'#4c1d95',cape:'#c084fc',d:{r:4},hp:1},
    {n:'Muhtar Hamdi',tag:'🏛️ Muhtar',lv:20,x:18*TS,y:14*TS,bx:18*TS,by:14*TS,tx:0,ty:0,t:4,f:0,w:0,sw:0,c:'#1e293b',h:'#0f172a',cape:'#dc2626',d:{r:4},hp:1,stationary:true}
  ];

  for(let i=0;i<12;i++){
    hCritters.push({type:i<6?'rabbit':i<9?'bird':'frog',x:ri(8,38)*TS,y:ri(8,44)*TS,hx:20*TS,hy:20*TS,vx:0,vy:0,f:1,st:'idle',t:rnd(1,3),hopT:0,z:0,dead:false,rt:0,r:4});
  }

  // Zenginleştirilmiş Mini Harita Canvası
  const hMmc=document.createElement('canvas');hMmc.width=hMmc.height=hN;
  {
    const m=hMmc.getContext('2d');
    for(let y=0;y<hN;y++)for(let x=0;x<hN;x++){m.fillStyle=MAP_COLORS[hTl[y*hN+x]];m.fillRect(x,y,1,1)}
    // Bahçe Yatakları
    m.fillStyle='#78350f';m.fillRect(15,26,4,3);m.fillRect(15,30,4,3);m.fillRect(20,26,3,6);
    // Binalar ve Çatılar
    hHs.forEach(h=>{
      m.fillStyle=h.c||'#854d0e';
      m.fillRect(h.x/TS-3,h.y/TS-3,6,5);
    });
    // Şapel (Kuzey)
    m.fillStyle='#475569';m.fillRect(29,9,6,6);
    m.fillStyle='#facc15';m.fillRect(31,8,2,2);
    // Pazar Tenteleri
    m.fillStyle='#ef4444';m.fillRect(26,24,3,2);
    m.fillStyle='#2563eb';m.fillRect(34,24,3,2);
    m.fillStyle='#16a34a';m.fillRect(26,32,3,2);
    m.fillStyle='#eab308';m.fillRect(34,32,3,2);
    // Merkez Su Kuyusu
    m.fillStyle='#38bdf8';m.fillRect(30,29,2,2);
    // Su Değirmeni
    m.fillStyle='#854d0e';m.fillRect(47,21,5,4);
  }

  // Maden Kaynak Damarları (Hayvan otlağından çıkarılıp Kristal Madeni girişinin önüne taşındı)
  const hRes = [
    { k:'ore_stone', x:6*TS, y:11*TS, r:7, hp:3, maxHp:3, col:'#94a3b8', gold:5, isOre:true, mined:false, respawnT:0 },
    { k:'ore_stone', x:7.5*TS, y:12*TS, r:7, hp:3, maxHp:3, col:'#94a3b8', gold:6, isOre:true, mined:false, respawnT:0 },
    { k:'ore_copper', x:6*TS, y:13*TS, r:8, hp:4, maxHp:4, col:'#ea580c', gold:15, isOre:true, mined:false, respawnT:0 },
    { k:'ore_iron', x:8*TS, y:13.5*TS, r:8, hp:5, maxHp:5, col:'#38bdf8', gold:25, isOre:true, mined:false, respawnT:0 }
  ];

  return {N:hN,TS:16,C:hC,tl:hTl,objs:hObjs,hs:hHs,chests:[],critters:hCritters,resources:hRes,mobs:[],npcs:hNpcs,mmc:hMmc,atlas:buildHomeAtlas(hTl,hObjs,hHs),farmPlots:hPlots,chickens:homeChickens,eggs:homeEggs,cow:homeCow,sheep:homeSheep,ducks:homeDucks,fruitTrees:homeFruitTrees};
}

// Kasabanın atlası, aynı nehir/sur/yol ve gerçek yapı koordinatlarından çizilir.
function buildHomeAtlas(tiles,objects,houses){
  const a=document.createElement('canvas');a.width=a.height=360;
  const m=a.getContext('2d');m.imageSmoothingEnabled=false;
  const B=(x,y,w,h,col)=>{m.fillStyle=col;m.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h))};
  const at=(x,y)=>x>=0&&x<60&&y>=0&&y<60?tiles[y*60+x]:1;
  for(let y=0;y<60;y++)for(let x=0;x<60;x++){
    const t=at(x,y),px=x*6,py=y*6,h=H(x+11,y+23);
    B(px,py,6,6,MAP_COLORS[t]);
    if(t===0){
      if(h>.83)B(px+2,py+1,2,2,'#e8e39a');
      else if(h>.64)B(px+1,py+4,2,1,'#8bc561');
    }else if(t===1){
      if(at(x-1,y)!==1)B(px,py,1,6,'#a4d9da');
      if(at(x,y-1)!==1)B(px,py,6,1,'#a4d9da');
      if(h>.56)B(px+1,py+3,3,1,'#66b6d2');
    }else if(t===3){
      B(px,py+2,6,1,'#cfc5ab');
      if((x+y)%2===0)B(px+2,py+4,2,1,'#8f8774');
    }else if(t===4){
      B(px,py,6,2,'#627180');B(px+1,py+4,3,1,'#253847');
      if(x%3===0)B(px+1,py-1,2,3,'#778390');
    }else if(t===2&&h>.6)B(px+1,py+2,3,1,'#fff0bb');
  }
  for(const o of objects){
    const x=o.x/TS*6,y=o.y/TS*6;
    if(o.k==='tree'||o.k==='pine'||o.k==='apple_tree'||o.k==='peach_tree'){
      B(x-1,y-2,3,7,'#685038');
      B(x-7,y-10,14,10,o.k==='pine'?'#235d46':'#2d7142');
      B(x-5,y-12,10,5,o.k==='pine'?'#46956a':'#60a650');
      B(x-4,y-9,3,2,'#83c96c');
      if(o.k==='apple_tree'||o.k==='peach_tree'){
        B(x-2,y-8,2,2,o.k==='apple_tree'?'#d64641':'#f9a276');
        B(x+4,y-6,2,2,'#ef7b69');
      }
    }else if(o.k==='fence'||o.k==='gate'){
      B(x-3,y-2,7,1,'#b1834e');B(x,y-5,2,6,'#684633');
    }else if(o.k==='lamp'){
      B(x,y-9,2,9,'#4a4b53');B(x-2,y-11,6,3,'#f6dc93');
    }else if(o.k==='mine_entrance'){
      B(x-9,y-6,18,12,'#586878');B(x-6,y-4,12,11,'#122839');
      B(x-9,y-8,18,3,'#a29c93');B(x-3,y-4,4,3,'#69d9ed');
    }else if(o.k==='watermill'){
      B(x-10,y-7,20,14,'#ac7650');B(x-12,y-10,24,5,'#754638');
      B(x+6,y-2,10,9,'#344960');B(x+8,y,6,5,'#c1d5d5');
    }else if(o.k==='well'){
      B(x-5,y-4,10,8,'#858e90');B(x-3,y-2,6,4,'#3998c1');
    }else if(o.k==='campfire'){
      B(x-3,y-2,6,4,'#ad5e38');B(x-1,y-6,3,5,'#ffd165');
    }
  }
  for(const h of houses){
    const x=h.x/TS*6,y=h.y/TS*6;
    B(x-15,y-11,30,15,'#493d37');B(x-13,y-10,26,14,'#d0b894');
    B(x-17,y-13,34,6,h.isForge?'#546773':h.isTownHall?'#315588':h.isPlayerHome?'#a74445':'#79513a');
    B(x-12,y-15,24,2,h.isForge?'#bfc7d0':'#e5c386');
    B(x-2,y-4,4,8,'#664433');B(x-11,y-5,3,3,'#ffe0a0');B(x+8,y-5,3,3,'#ffe0a0');
    if(h.isForge){B(x+9,y-22,5,9,'#56616b');B(x+8,y-23,7,2,'#bcc8cc')}
  }
  // Çizimde gerçekten bulunan şapel, tezgâhlar, tarla ve kümes de atlas üzerinde görünür.
  const chapelX=31*6,chapelY=12*6;
  B(chapelX-13,chapelY-10,26,19,'#83929e');B(chapelX-15,chapelY-13,30,5,'#526477');
  B(chapelX-5,chapelY-22,10,10,'#63778b');B(chapelX-1,chapelY-26,3,12,'#f4d172');
  B(chapelX-4,chapelY-23,9,3,'#f4d172');B(chapelX-3,chapelY+2,6,7,'#3e4f68');
  for(const [tx,ty,col] of [[27,25,'#db5148'],[35,25,'#4385bf'],[27,33,'#50ae69'],[35,33,'#d5ae46']]){
    const x=tx*6,y=ty*6;
    B(x-10,y-4,20,9,'#77563c');B(x-12,y-8,24,6,col);
    for(let k=0;k<4;k++)B(x-12+k*6,y-8,3,6,'#fff5d9');
    B(x-7,y+1,14,2,'#e1bb71');
  }
  for(let x=16;x<=20;x++)for(let y=26;y<=29;y++){
    B(x*6+1,y*6+1,4,4,'#8a694b');
    if((x+y)%3!==0)B(x*6+2,y*6-1,2,4,'#d7b660');
  }
  for(const [x,y,color] of [[8,17,'#f1eee2'],[10,18,'#f2eee5'],[9,32,'#e0d2bd']]){
    B(x*6-3,y*6-3,6,6,color);B(x*6+2,y*6-2,2,2,'#674e34');
  }
  return a;
}


/* --- 4. KARANLIK KRİSTAL MADENİ (50 KATLI ZİNDAN SİSTEMİ) --- */
function initMineFloor(floor){
  floor=cl(Number(floor)||1,1,50)|0;
  const random=CAVE.rng(floor),ri=(a,b)=>Math.floor(random()*(b-a+1))+a,rnd=(a,b)=>a+random()*(b-a);
  const mN=28,mC=14;
  const mTl=new Uint8Array(mN*mN);
  const mObjs=[],mChests=[],mMobs=[],mRes=[];
  const biome=floor<=10?'earth':floor<=25?'ice':floor<=40?'magma':'iridium';
  const groundTile=biome==='ice'?7:biome==='iridium'?11:biome==='magma'?4:15;
  const wallTile=14;
  const ladderX=ri(19,22)*TS,ladderY=ri(18,22)*TS;
  mTl.fill(wallTile);
  const rooms=[
    {x:4,y:5,r:3},
    {x:ri(10,13),y:ri(5,9),r:3},
    {x:ri(6,10),y:ri(16,20),r:3},
    {x:ladderX/TS,y:ladderY/TS,r:3},
    {x:floor===50?14:ri(14,18),y:floor===50?16:ri(11,15),r:floor===50?5:3}
  ];
  const carve=(x,y,r=0)=>{
    for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){
      const xx=x+dx,yy=y+dy;
      if(xx>=2&&xx<=mN-3&&yy>=2&&yy<=mN-3)mTl[yy*mN+xx]=groundTile;
    }
  };
  for(const room of rooms)for(let dy=-room.r;dy<=room.r;dy++)for(let dx=-room.r;dx<=room.r;dx++){
    if(Math.max(Math.abs(dx),Math.abs(dy))<room.r||H(room.x+dx+floor*7,room.y+dy+floor*3)>.28)carve(room.x+dx,room.y+dy);
  }
  const connect=(a,b)=>{
    let x=a.x,y=a.y;carve(x,y,1);
    const goX=()=>{while(x!==b.x){x+=Math.sign(b.x-x);carve(x,y,1)}};
    const goY=()=>{while(y!==b.y){y+=Math.sign(b.y-y);carve(x,y,1)}};
    if(H(a.x+floor,a.y+b.y)>.5){goX();goY()}else{goY();goX()}
  };
  connect(rooms[0],rooms[1]);connect(rooms[1],rooms[4]);
  connect(rooms[4],rooms[3]);connect(rooms[1],rooms[2]);connect(rooms[2],rooms[3]);
  carve(4,4,1);carve(4,5,1);carve(6,4,1);carve(ladderX/TS,ladderY/TS,1);
  // Kenarda tek başına kalan rastlantısal kareleri duvara çevir; her cevher yürünebilir olsun.
  const caveReach=new Uint8Array(mN*mN),caveQueue=[5*mN+4];caveReach[caveQueue[0]]=1;
  for(let i=0;i<caveQueue.length;i++)for(const j of [caveQueue[i]-1,caveQueue[i]+1,caveQueue[i]-mN,caveQueue[i]+mN]){
    if(j<0||j>=mTl.length||caveReach[j]||mTl[j]!==groundTile)continue;
    caveReach[j]=1;caveQueue.push(j);
  }
  for(let i=0;i<mTl.length;i++)if(mTl[i]===groundTile&&!caveReach[i])mTl[i]=wallTile;

  // Ladder Up (Exit to Surface) at (4*TS, 4*TS)
  mObjs.push({ k: 'ladder_up', x: 4*TS, y: 4*TS, r: 6 });

  // Elevator if multiple of 5
  if(floor % 5 === 0){
    mObjs.push({ k: 'elevator', x: 6*TS, y: 4*TS, r: 6 });
  }

  // Torches on walls
  mObjs.push({ k: 'torch', x: 3*TS, y: 6*TS, r: 3, v: 0.1 });
  mObjs.push({ k: 'torch', x: (mN-4)*TS, y: 6*TS, r: 3, v: 0.1 });
  mObjs.push({ k: 'torch', x: 3*TS, y: (mN-5)*TS, r: 3, v: 0.1 });
  mObjs.push({ k: 'torch', x: (mN-4)*TS, y: (mN-5)*TS, r: 3, v: 0.1 });

  // Merdiven o katta TEK bir kayanın altında, bulunduğu odanın merkezindedir.
  // Oda zeminindeki benzersiz kayalar: giriş, asansör ve boss alanı boş kalır.
  const candidates=[];
  for(let y=3;y<mN-3;y++)for(let x=3;x<mN-3;x++){
    if(mTl[y*mN+x]!==groundTile||Math.hypot(x-4,y-5)<4.5)continue;
    if(x===ladderX/TS&&y===ladderY/TS)continue;
    if(floor===50&&Math.hypot(x-14,y-16)<6)continue;
    candidates.push({x,y});
  }
  const used=new Set();
  function placeRock(x,y,hasLadder=false){
    const key=y*mN+x;
    if(used.has(key))return;
    used.add(key);
    let k='ore_stone',col='#94a3b8',hp=2,gold=5;
    const roll=random();
    if(biome==='earth'){
      if(roll<.23){k='ore_copper';col='#ea580c';hp=3;gold=15}
      else if(roll<.39){k='ore_coal';col='#1e293b';gold=10}
    }else if(biome==='ice'){
      if(roll<.14){k='ore_crystal';col='#c084fc';hp=4;gold=45}
      else if(roll<.47){k='ore_iron';col='#38bdf8';hp=4;gold=25}
    }else if(biome==='magma'){
      if(roll<.14){k='ore_ruby';col='#ef4444';hp=5;gold=60}
      else if(roll<.47){k='ore_gold';col='#ffd23f';hp=5;gold=40}
    }else{
      if(roll<.13){k='ore_diamond';col='#67e8f9';hp=6;gold=100}
      else if(roll<.49){k='ore_iridium';col='#a855f7';hp=6;gold=80}
    }
    mRes.push({k,x:x*TS+8,y:y*TS+8,r:7,hp,maxHp:hp,col,gold,isOre:true,mined:false,respawnT:0,hasLadder});
  }
  if(floor<50)placeRock(ladderX/TS,ladderY/TS,true);
  const rockCount=floor===50?8:ri(16,24);
  for(let i=mRes.length;i<rockCount&&candidates.length;i++){
    const chosen=candidates.splice(ri(0,candidates.length-1),1)[0];
    placeRock(chosen.x,chosen.y);
  }

  // Enemies generator
  if(floor === 50){
    mMobs.push({
      k: 'colossus', d: MT.colossus, x: 14*TS, y: 16*TS, hx: 14*TS, hy: 16*TS,
      lv: 20, mhp: MT.colossus.hp, hp: MT.colossus.hp, a: MT.colossus.a,
      el: true, st: 'chase', t: 0, kx: 0, ky: 0, fl: 0, dead: false, rt: 0,
      f: 1, ph: 0, tx: 14*TS, ty: 16*TS, v: 0, hv: 0, cast: 0, act: true, r: MT.colossus.r, chill: 0
    });
  }else{
    const mobCount=ri(3,6);
    const mobTiles=candidates.filter(c=>!used.has(c.y*mN+c.x)&&Math.hypot(c.x-4,c.y-5)>6&&Math.hypot(c.x-ladderX/TS,c.y-ladderY/TS)>2);
    for(let i=0;i<mobCount&&mobTiles.length;i++){
      const spot=mobTiles.splice(ri(0,mobTiles.length-1),1)[0];
      const mx=spot.x*TS+8,my=spot.y*TS+8;
      let mType = 'slime';
      if(biome === 'earth') mType = random() < 0.6 ? 'bat' : 'slime';
      else if(biome === 'ice') mType = random() < 0.5 ? 'ice_skeleton' : 'bat';
      else if(biome === 'magma') mType = random() < 0.5 ? 'magma_golem' : 'assassin';
      else mType = random() < 0.5 ? 'magma_golem' : 'summoner';

      const d = MT[mType] || MT.slime;
      mMobs.push({
        k: mType, d, x: mx, y: my, hx: mx, hy: my,
        lv: Math.round(d.lv + floor * 0.25),
        mhp: Math.round(d.hp * (1 + floor * 0.04)),
        hp: Math.round(d.hp * (1 + floor * 0.04)),
        a: Math.round(d.a * (1 + floor * 0.03)),
        el: random() < 0.2, st: 'idle', t: rnd(.5,2), kx: 0, ky: 0, fl: 0, dead: false,
        rt: 0, f: 1, ph: 0, tx: mx, ty: my, v: 0, hv: 0, cast: 0, act: false, r: d.r, chill: 0
      });
    }
  }

  const mMmc = document.createElement('canvas'); mMmc.width = mMmc.height = mN;
  {
    const m = mMmc.getContext('2d');
    for(let y=0; y<mN; y++) for(let x=0; x<mN; x++){
      m.fillStyle = mTl[y*mN+x]===14?'#172131':mTl[y*mN+x]===4?'#292833':MAP_COLORS[mTl[y*mN+x]] || '#334155';
      m.fillRect(x,y,1,1);
    }
  }

  return CAVE.decorate({
    N:mN,TS:16,C:mC,tl:mTl,objs:mObjs,hs:[],chests:mChests,
    critters:[],resources:mRes,mobs:mMobs,npcs:[],mmc:mMmc,
    farmPlots:[],ladder:floor===50?null:{x:ladderX+8,y:ladderY+8,uncovered:false},floor,biome,rooms
  },random);
}

function revealMineLadder(rock){
  if(curMap!=='mine'||!rock?.hasLadder)return;
  const md=WORLD_DATA.mine;
  if(!md?.ladder||md.ladder.uncovered)return;
  md.ladder.x=rock.x;md.ladder.y=rock.y;md.ladder.uncovered=true;
  rock.mined=true;
  fl(rock.x,rock.y-20,'🪜 MERDİVEN BULUNDU!','#ffd23f',true);
  playChord([523,659,784,1046],.35,'triangle',.07);
  spark(rock.x,rock.y,24,'#ffd23f',80);
}

/* Haritalar Arası Işınlanma ve Geçit */
let mapTravelWarningAt=0;
function worldEntrySide(){
  if(window.ONBOARD&&ONBOARD.current&&ONBOARD.current()?.id==='forest')return 'forest';
  const k=typeof QS!=='undefined'?QS[P.q]?.k:'';
  if(k==='lizard'||k==='crab')return 'lake';
  if(k==='scorpion'||k==='golem')return 'desert';
  if(k==='skeleton'||k==='dragon')return 'pass';
  if(window.STORY&&STORY.needsOasis&&STORY.needsOasis())return 'desert';
  return 'west';
}
function switchMap(targetId,spawnSide,restoring=false){
  if(!['world','home','inside','frontier','mine'].includes(targetId))return false;
  const fromMap=curMap,mineFloor=cl(Number(P.mineFloor)||1,1,50)|0;
  if(targetId===curMap&&(targetId!=='mine'||WORLD_DATA.mine?.floor===mineFloor&&WORLD_DATA.mine?.day===P.day))return true;
  if(!restoring&&!GAME_CORE.canTravel()){
    const now=Date.now();if(now-mapTravelWarningAt>1800){mapTravelWarningAt=now;inventoryWarning('Savaş sürüyor. Güvenli mesafeye çıkmadan bölge değiştiremezsin.')}
    return false;
  }
  if(!restoring)GAME_CORE.leaveScene();else{prj.length=0;tel.length=0;loot.length=0;GAME_CORE.resetInput()}
  BUILD.cancel();BUILD.activeChest=null;BUILD.activeWorkshop=null;
  for(const id of ['bsh','bfg','bpr','bck','bhs','bcf','bmk','bbd','bst','bcs','bml','bbt','bchp','btav','bth','blb','btv','bgm'])$(id)?.classList.add('h');
  if(['mine','inside'].includes(targetId))BOND.dismount();
  $('journey-modal').classList.add('h');$('bond-modal').classList.add('h');BOND.current=null;
  // Depo ve kamp menüsü harita değiştirirken açık kalırsa yanlış bölgenin eşyası taşınabilir.
  $('storage-modal')?.classList.add('h');$('field-camp-modal')?.classList.add('h');$('frontier-station-modal')?.classList.add('h');
  
  if(targetId==='mine'){
    P.mineFloor=mineFloor;
    if(!WORLD_DATA.mine||WORLD_DATA.mine.floor!==mineFloor||WORLD_DATA.mine.day!==P.day)WORLD_DATA.mine=initMineFloor(mineFloor);
  }else if(!WORLD_DATA[targetId]){
    if(targetId==='home')WORLD_DATA.home=initHomeMap();
    else if(targetId==='frontier'){
      WORLD_DATA.frontier=initFrontierMap();
      restoreWildMap(WORLD_DATA.frontier,'frontier',wildStateCache.frontier);
    }
    else if(targetId==='inside')WORLD_DATA.inside=initInsideMap();
    else WORLD_DATA.world=initWorldMap();
  }
  curMap=targetId;
  const md=WORLD_DATA[targetId];GAME_CORE.tagMap(md,targetId);BOND.syncMap(md,targetId);
  if(targetId==='world'||targetId==='frontier')refreshWildResources(md);
  N=md.N; C=md.C; tl=md.tl; objs=md.objs; hs=md.hs; chests=md.chests; critters=md.critters; resources=md.resources; mobs=md.mobs; npcs=md.npcs; mmc=md.mmc; farmPlots=md.farmPlots||[];
  if(restoring){P.fs=null;FX.resetMap();S=st();FARM.updCal();return true}
  hf=0.4;
  sfx(300,.35,'sine',.06);

  if(targetId==='home'){
    if(spawnSide==='hamdi'){
      P.x=20*TS;P.y=13*TS;P.f=2;
      ban('🏛️ Belediye önü','#fde68a');
      chat('MUHTAR HAMDİ','','Buradayım. Acele etme.',1);
    }else{
      P.x=(N-4)*TS;P.y=30*TS;P.f=2;
      if(window.STORY&&STORY.cueHome&&STORY.cueHome()){
        ban('🏡 Gölgeköy','#e9d39d');
        chat('MUHTAR HAMDİ','','Kapıdasın. Belediye önündeyim. Rapor yok.',1);
      }else{
        ban('🏡 Huzurlu Çiftlik ve Evimiz','#a7f3d0');
        chat('SİSTEM','','Huzurlu Çiftlik ve Kasaba diyarına geldin.',1);
      }
    }
  }else if(targetId==='inside'){
    P.x=15*TS;P.y=18*TS;P.f=1;
    ban('🏡 Sıcak yuva','#fde047');
    chat('SİSTEM','','Ocak solda, yatak sağ üstte, kapı arkanda. Gece olunca yatak yeni günü açar.',1);
  }else if(targetId==='mine'){
    const f=P.mineFloor;
    P.x=4*TS+8;P.y=5*TS+8;P.f=0;
    ban(`⛏️ Kristal Madeni: Kat ${f}`, '#ffd23f');
    chat('SİSTEM','',`Kat ${f}: bağlı odaları keşfet, merdivenli kayayı kır veya canavarları temizle!`,1);
  }else if(targetId==='frontier'){
    P.x=(FRONTIER.gate.x+.5)*TS;P.y=(FRONTIER.gate.y-2+.5)*TS;P.f=1;
    P.z=1;P.biome='highland';P.frontierDiscovered=true;
    ban('🌫️ Sisli Yayla · Yeni Keşif Bölgesi','#c5f2d4');
    chat('SİSTEM','',"Sisli Yayla'ya ulaştın: kaynakları topla, kampı kur ve harabeyi keşfet!",1);
    sv();
  }else if(spawnSide==='forest'){
    P.x=50*TS;P.y=26*TS;P.f=1;P.z=1;P.biome='forest';
    ban('🌲 Slime açıklığı','#86efac');
    chat('SİSTEM','','Altı slime patikanın hemen kuzeyinde. Her biri odun ve taş bırakır. Turuncu uyarıdan sıyrıl, sonra vur.',1);
  }else if(spawnSide==='lake'){
    P.x=38*TS;P.y=54*TS;P.f=2;P.z=2;
    ban('🎣 İskele ağzı','#7dd3fc');
  }else if(spawnSide==='desert'){
    P.x=64*TS;P.y=50*TS;P.f=3;P.z=3;
    ban('🏜️ Çöl ağzı','#f6d7a3');
  }else if(spawnSide==='pass'){
    P.x=50*TS;P.y=62*TS;P.f=0;P.z=zoneOf(50,62);
    ban('💀 Kül Geçidi','#fca5a5');
  }else{
    if(spawnSide==='west'){P.x=5*TS;P.y=50*TS;P.f=3}
    else if(spawnSide==='east'){P.x=(N-5)*TS;P.y=50*TS;P.f=2}
    else{P.x=C*TS;P.y=(C+3)*TS;P.f=0}
    ban('🌲 Aethermoor Vahşi Dünyası','#ffd23f');
    chat('SİSTEM','','Aethermoor Vahşi Dünyasına döndün.',1);
  }
  P.fs=null;if(P.pet){P.pet.x=P.x-12;P.pet.y=P.y}if(P.merc){P.merc.x=P.x+10;P.merc.y=P.y}
  FX.resetMap();S=st();FARM.updCal();
  if(targetId==='home')EXPEDITIONS.event('return','home',1);
  if(targetId==='inside')ONBOARD.event('home');
  if(fromMap==='home'&&targetId==='inside'&&P.guideStep===0)advanceGuide(1);
  else if(targetId==='world'&&P.guideStep<3)advanceGuide(3);
  if(!GAME_CORE.loading)svNow();return true;
}
window.switchMap = switchMap;
window.WORLD_DATA = WORLD_DATA;
window.getFarmPlots = () => farmPlots;
window.getS = () => S;


// Tüm diyarları baştan oluştur ve oyunu Huzurlu Çiftlikte başlat!
WORLD_DATA.world = initWorldMap();
WORLD_DATA.home = initHomeMap();
WORLD_DATA.inside = initInsideMap();

curMap = 'home';
{
  const md = WORLD_DATA.home;
  N=md.N; C=md.C; tl=md.tl; objs=md.objs; hs=md.hs; chests=md.chests; critters=md.critters; resources=md.resources; mobs=md.mobs; npcs=md.npcs; mmc=md.mmc; farmPlots=md.farmPlots;
}

const tAt=(x,y)=>tl[cl(y/TS|0,0,N-1)*N+cl(x/TS|0,0,N-1)];
function bl(x,y,r,skipObjs){
  if(curMap==='home'&&BUILD.blocks(x,y,r))return true;
  const ground=tAt(x,y);
  if(x<10||y<12||x>N*TS-10||y>N*TS-4||ground===1||(curMap==='world'&&ground===13)||(curMap==='home'&&ground===4)||(curMap==='inside'&&ground===4)||(curMap==='mine'&&ground===14)||(curMap==='frontier'&&ground===17))return true;
  if(!skipObjs)for(const o of objs)if(Math.abs(o.x-x)<14&&Math.abs(o.y-y)<14&&Math.hypot(o.x-x,o.y-y)<o.r+r)return true;
  for(const h of hs)if(x>h.x-24-r&&x<h.x+24+r&&y>h.y-10&&y<h.y+4)return true;
  return curMap==='world'&&Math.hypot(x-C*TS,y-C*TS)<14;
}
function mv(e,dx,dy,r){
  if(![e.x,e.y,dx,dy,r].every(Number.isFinite))return;
  // Dash/geri tepme de duvarın ötesine atlayamaz. Normal yürüyüş tek alt adımdır.
  const steps=Math.max(1,Math.min(64,Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))/6))),sx=cl(dx/steps,-6,6),sy=cl(dy/steps,-6,6);
  // Bir nesnenin/lambanın çarpışma alanının içinde doğan varlık sıkışıp kalmasın: sıkışıksa serbestçe dışarı yürüyebilir.
  for(let i=0;i<steps;i++){
    // Yalnızca bir nesnenin içindeysen (harita/duvar değil) nesneyi geçip çıkabilirsin.
    const stuck=bl(e.x,e.y,r)&&!bl(e.x,e.y,r,true);
    if(!bl(e.x+sx,e.y,r)||(stuck&&!bl(e.x+sx,e.y,r,true)))e.x+=sx;
    if(!bl(e.x,e.y+sy,r)||(stuck&&!bl(e.x,e.y+sy,r,true)))e.y+=sy;
  }
}
const dirOf=(dx,dy)=>Math.abs(dx)>Math.abs(dy)?(dx<0?2:3):(dy<0?1:0);

