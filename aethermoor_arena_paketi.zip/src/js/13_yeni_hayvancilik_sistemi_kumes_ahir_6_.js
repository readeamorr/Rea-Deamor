/* ===== YENİ HAYVANCILIK SİSTEMİ: Kümes, Ahır, 6 Hayvan Türü, Sevgi, Yem, Ürün Kalitesi ===== */
const HTYPES={
  chicken:{n:'Tavuk',icon:'🐔',cost:120,pen:'coop',baby:3,every:1,names:['Çilli','Pamuk','Gıdık','Fındık','Karabaş','Cıvıl'],
    prod:{k:'egg',n:'Köy Yumurtası',icon:'🥚',val:20,s:'food_ing',d:'Taze çiftlik yumurtası'}},
  duck:{n:'Ördek',icon:'🦆',cost:180,pen:'coop',baby:4,every:2,names:['Vak','Çamur','Gaga','Süzgün'],
    prod:{k:'duck_egg',n:'Ördek Yumurtası',icon:'🥚',val:45,s:'food_ing',d:'Zengin ve iri yumurta'}},
  cow:{n:'İnek',icon:'🐄',cost:600,pen:'pasture',baby:5,every:1,names:['Sarıkız','Benekli','Alaca','Bulut'],
    prod:{k:'milk',n:'Taze Çiftlik Sütü',icon:'🥛',val:30,s:'food_ing',d:'Mutfakta kullanılır'}},
  goat:{n:'Keçi',icon:'🐐',cost:350,pen:'pasture',baby:5,every:2,names:['Boncuk','Tosun','Fındıkkıran'],
    prod:{k:'goat_milk',n:'Keçi Sütü',icon:'🥛',val:55,s:'food_ing',d:'Yoğun ve besleyici'}},
  sheep:{n:'Koyun',icon:'🐑',cost:300,pen:'pasture',baby:4,every:3,names:['Kıvırcık','Pamuk','Bulut','Kuzu'],
    prod:{k:'wool',n:'Doğal Koyun Yünü',icon:'🧶',val:35,s:'mat',d:'Dokuma kumaş ve giysi yapımında kullanılır'}},
  pig:{n:'Domuz',icon:'🐖',cost:800,pen:'pasture',baby:6,every:2,names:['Pembe','Trüfçü','Hortum','Cüce'],
    prod:{k:'truffle',n:'Trüf Mantarı',icon:'🍄',val:150,s:'food_ing',d:'Çok değerli bir lezzet'}}
};
const HPENS={
  coop:{x0:7*16,x1:11.5*16,y0:15*16,y1:19.5*16},
  pasture:{x0:7*16,x1:12.5*16,y0:31.5*16,y1:35.5*16}
};

const HERD={
  list(){return P.herd||(P.herd=[])},
  cap(pen){
    if(pen==='coop')return P.hasCoop?4*(P.coopLv||1):0;
    return 2+(P.hasBarn?4*(P.barnLv||1):0);
  },
  count(pen){return this.list().filter(a=>HTYPES[a.type].pen===pen).length},
  hasWheat(){return P.inv.some(i=>i.k==='wheat')},
  readyCount(pen){return this.list().filter(a=>a.ready&&HTYPES[a.type].pen===pen).length},
  heartsOf(a){return Math.floor(a.love/100)},
  adult(a){return a.age>=HTYPES[a.type].baby},

  make(type,opts={}){
    const T=HTYPES[type],pen=HPENS[T.pen];
    const used=this.list().map(a=>a.name);
    const pool=T.names.filter(n=>!used.includes(n));
    return Object.assign({
      id:Date.now()+Math.floor(Math.random()*1e5),type,name:pool.length?pick(pool):pick(T.names)+ri(2,9),
      x:rnd(pen.x0,pen.x1),y:rnd(pen.y0,pen.y1),f:Math.random()<.5?1:-1,t:rnd(1,4),
      age:0,love:100,fed:false,petted:false,ready:false,pc:0
    },opts);
  },
  init(){
    P.herd=[];
    P.herd.push(this.make('cow',{name:'Sarıkız',age:99,love:200,ready:true}));
    P.herd.push(this.make('sheep',{name:'Kıvırcık',age:99,love:200,ready:true}));
    if(P.hasCoop){
      if(!P.coopLv)P.coopLv=1;
      for(let i=0;i<4;i++)P.herd.push(this.make('chicken',{age:99,love:150,ready:i<2}));
    }
    if(P.hay===undefined)P.hay=6;
  },

  /* --- Günlük döngü --- */
  newDay(){
    let ready=0,hungry=0;
    for(const a of this.list()){
      const T=HTYPES[a.type];
      a.age++;
      if(a.fed){
        a.love=Math.min(1000,a.love+20+(a.petted?25:0));
        if(this.adult(a)&&!a.ready){a.pc++;if(a.pc>=T.every){a.ready=true;a.pc=0}}
      }else{
        a.love=Math.max(0,a.love-35);
      }
      a.fed=false;a.petted=false;
    }
    if(P.autoFeed){
      for(const a of this.list()){
        if(P.hay>0){P.hay--;a.fed=true}
      }
    }
    for(const a of this.list()){if(a.ready)ready++;if(!a.fed)hungry++}
    setTimeout(()=>{
      if(this.list().length){
        if(ready)fl(P.x,P.y-70,`🥛 ${ready} hayvanda ürün hazır`,'#67e8f9',true);
        if(hungry)fl(P.x,P.y-82,`🌾 ${hungry} hayvan aç`,'#fca5a5',true);
      }
    },900);
  },

  /* --- Etkileşim --- */
  nearest(){
    if(curMap!=='home')return null;
    let b=null,bd=24;
    for(const a of this.list()){const d=Math.hypot(P.x-a.x,P.y-a.y);if(d<bd){bd=d;b=a}}
    return b;
  },
  promptFor(a){
    const T=HTYPES[a.type];
    if(a.ready)return{text:`${T.icon} ${a.name} (${T.prod.n} Topla)`,fn:()=>this.collect(a)};
    if(!a.fed&&(P.hay>0||this.hasWheat()))return{text:`${T.icon} ${a.name} (Besle ${P.hay>0?'🌾 '+P.hay:'buğday'})`,fn:()=>this.feed(a)};
    return{text:`${T.icon} ${a.name} (${a.petted?'❤'+this.heartsOf(a):'Sev ❤️'})`,fn:()=>this.pet(a)};
  },
  feed(a){
    if(a.fed){fl(a.x,a.y-20,'Tok!','#a7f3d0');return}
    if(P.hay>0)P.hay--;
    else if(this.hasWheat())consumeInv('wheat',1);
    else{fl(a.x,a.y-20,'Yem yok! Pazardan al.','#ff5d5d');return}
    a.fed=true;a.love=Math.min(1000,a.love+10);
    fl(a.x,a.y-22,'🌾 Ham ham!','#fde68a',true);spark(a.x,a.y-6,8,'#fde68a',30);sfx(520,.08,'triangle',.04);sv();
  },
  pet(a){
    if(a.petted){fl(a.x,a.y-22,'❤️ Mutlu!','#f43f5e');return}
    a.petted=true;a.love=Math.min(1000,a.love+15);
    fl(a.x,a.y-22,'❤️ Sevildi!','#f43f5e',true);spark(a.x,a.y-8,8,'#f43f5e',40);
    playChord([659,784,987],.2,'sine',.04);
    const bubbles={chicken:'Gıdak gıdak! ❤️',duck:'Vak vak! ❤️',cow:'Möö! ❤️',goat:'Meee! ❤️',sheep:'Me-e-e! ❤️',pig:'Hort hort! ❤️'};
    say(a,bubbles[a.type],2.0);sv();
  },
  collect(a){
    if(!a.ready)return;
    const T=HTYPES[a.type],pr=T.prod,q=a.love/1000;
    const r=Math.random(),star=r<q*.35?3:r<q*.6+.1?2:1;
    const mult=star===3?3:star===2?1.7:1,tag=star===3?'★★★ Altın ':star===2?'★ Gümüş ':'';
    if(!ITEMS.add(P.inv,{s:pr.s,k:pr.k,star,n:tag+pr.n,icon:pr.icon,val:Math.round(pr.val*mult),desc:pr.d})){
      fl(a.x,a.y-24,'Çanta dolu; hayvanın ürünü korunuyor.','#facc15');return;
    }
    a.ready=false;a.love=Math.min(1000,a.love+5);
    fl(a.x,a.y-24,`+1 ${pr.icon} ${tag}${pr.n}`,star===3?'#ffd23f':star===2?'#c084fc':'#6ee7b7',true);
    spark(a.x,a.y-8,10,'#fff',40);sfx(850,.08,'sine',.05);
    addMasteryXp('farm',8);sv();
  },

  /* --- Hareket --- */
  update(dt){
    for(const a of this.list()){
      const pen=HPENS[HTYPES[a.type].pen],sp=(a.type==='chicken'||a.type==='duck')?18:12;
      a.t-=dt;a.peck=Math.max(0,(a.peck||0)-dt);
      if(a.t<=0){
        a.t=rnd(2,6);
        if(Math.random()<.4)a.peck=.8;
        else{a.tx=rnd(pen.x0,pen.x1);a.ty=rnd(pen.y0,pen.y1)}
      }
      if(a.tx!==undefined){
        const dx=a.tx-a.x,dy=a.ty-a.y,d=Math.hypot(dx,dy);
        if(d>2){a.x+=dx/d*sp*dt;a.y+=dy/d*sp*dt;a.f=dx>0?1:-1;a.walk=true}else a.walk=false;
      }
    }
  },

  /* --- Çizim --- */
  draw(a){
    const x=Math.round(a.x),y=Math.round(a.y),f=a.f||1,k=this.adult(a)?1:.62;
    const bob=a.walk?Math.round(Math.sin(P.t*10+a.id)*1):0;
    const r=(dx,dy,w,h,c)=>R(f>0?x+dx*k:x-(dx+w)*k,y+(dy+bob)*k,w*k,h*k,c);
    R(x-6*k,y-1,12*k,2,'#0003');
    switch(a.type){
      case 'chicken':{
        const col=a.id%3===0?'#f8fafc':a.id%3===1?'#b45309':'#e7e5e4';
        r(-4,-6,8,6,col);r(3,-9,3,4,col);r(4,-10,2,1,'#dc2626');r(6,-8,2,1,'#f59e0b');r(5,-7,1,1,'#111');
        r(-3,-5,4,3,'#00000018');r(-6,-8,2,3,col);
        r(-1,0,1,2,'#f59e0b');r(1,0,1,2,'#f59e0b');
        if(a.peck>0)r(5,-4,1,1,'#fde68a');break}
      case 'duck':
        r(-4,-5,8,5,'#f8fafc');r(3,-8,3,4,'#15803d');r(6,-6,2,1,'#f59e0b');r(4,-7,1,1,'#111');
        r(-3,-4,4,2,'#cbd5e1');r(-1,0,1,2,'#f59e0b');r(1,0,1,2,'#f59e0b');break;
      case 'cow':
        r(-8,-10,16,9,'#f8fafc');r(-5,-9,4,4,'#292524');r(2,-7,4,3,'#292524');
        r(7,-12,6,7,'#f8fafc');r(11,-8,2,3,'#f9a8d4');r(8,-14,1,2,'#fde68a');r(12,-14,1,2,'#fde68a');r(9,-10,1,1,'#111');
        r(-7,-1,2,4,'#e2e8f0');r(-3,-1,2,4,'#e2e8f0');r(2,-1,2,4,'#e2e8f0');r(5,-1,2,4,'#e2e8f0');
        r(-10,-9,2,6,'#292524');break;
      case 'goat':
        r(-6,-8,12,7,'#d6d3d1');r(5,-11,5,5,'#e7e5e4');r(6,-13,1,2,'#78716c');r(8,-13,1,2,'#78716c');
        r(8,-6,1,2,'#a8a29e');r(8,-9,1,1,'#111');
        r(-5,-1,2,3,'#a8a29e');r(-1,-1,2,3,'#a8a29e');r(2,-1,2,3,'#a8a29e');r(4,-1,2,3,'#a8a29e');r(-8,-8,2,2,'#a8a29e');break;
      case 'sheep':
        r(-7,-10,14,9,a.ready?'#f8fafc':'#d4d4d8');
        if(a.ready){r(-8,-9,2,6,'#f8fafc');r(-4,-12,8,3,'#f1f5f9')}
        r(6,-9,5,5,'#292524');r(8,-8,1,1,'#fff');
        r(-5,-1,2,3,'#292524');r(-1,-1,2,3,'#292524');r(2,-1,2,3,'#292524');r(5,-1,2,3,'#292524');break;
      case 'pig':
        r(-7,-8,14,8,'#f9a8d4');r(6,-9,6,6,'#f472b6');r(11,-7,2,3,'#ec4899');r(7,-11,2,2,'#f472b6');r(9,-8,1,1,'#111');
        r(-5,0,2,3,'#ec4899');r(-1,0,2,3,'#ec4899');r(2,0,2,3,'#ec4899');r(5,0,2,3,'#ec4899');r(-9,-7,2,2,'#ec4899');break;
    }
    const HT=HTYPES[a.type],by=Math.sin(P.t*3+a.id)*1.5;
    if(a.ready){R(x-6,y-26+by,12,10,'#fff');R(x-5,y-25+by,10,8,'#fef9c3');T2(HT.prod.icon,x,y-18+by)}
    else if(!a.fed){R(x-3,y-22+by,6,7,'#fff');T2('🌾',x,y-16+by)}
    if(Math.hypot(P.x-a.x,P.y-a.y)<46){
      T(a.name,x,y-(a.ready||!a.fed?30:16),'#fff');
      const hp=this.heartsOf(a);
      for(let i=0;i<5;i++)R(x-10+i*5,y+4,4,3,i<Math.ceil(hp/2)?'#f43f5e':'#4b5563');
    }
  },
  barnD(x,y){
    x=Math.round(x);y=Math.round(y);
    if(P.hasBarn){
      const lv=P.barnLv||1;
      R(x-20,y-22,40,22,'#b91c1c');R(x-22,y-30,44,8,'#7f1d1d');R(x-17,y-35,34,5,'#991b1b');
      R(x-6,y-15,12,15,'#451a03');R(x-6,y-15,12,1,'#fef2f2');R(x-6,y-1,12,1,'#fef2f2');R(x-1,y-15,2,15,'#fef2f2');
      R(x-3,y-27,6,5,'#facc15');R(x-16,y-14,6,6,'#fef2f2');R(x+10,y-14,6,6,'#fef2f2');
      if(this.readyCount('pasture')>0){R(x+14,y-36,8,8,'#fff');T2('🥛',x+18,y-30)}
      if(labelNear(x,y,70))T(`Ahır 🐄 Sv.${lv}`,x,y-40,'#ffd23f');
    }else{
      R(x-18,y-6,36,6,'#78350f');R(x-16,y-12,3,6,'#92400e');R(x+13,y-12,3,6,'#92400e');
      if(labelNear(x,y,70))T('🐄 Ahır Yap',x,y-18,'#ffd23f');
    }
  },

  /* --- Arayüz --- */
  items(k){return countInv(k)},
  buildCost(bld){
    if(bld==='coop'){const lv=P.hasCoop?(P.coopLv||1):0;return lv>=3?null:[{g:120,w:10,s:6},{g:250,w:15,s:0},{g:500,w:25,s:10}][lv]}
    const lv=P.hasBarn?(P.barnLv||1):0;return lv>=3?null:[{g:400,w:25,s:15},{g:800,w:20,s:10},{g:1600,w:30,s:20}][lv];
  },
  build(bld){
    const c=this.buildCost(bld);if(!c)return;
    if(P.gold<c.g||this.items('wood')<c.w||this.items('stone')<c.s){fl(P.x,P.y-22,`Gereken: ${c.g}🪙, ${c.w} Odun, ${c.s} Taş`,'#ff5d5d');return}
    if(!tryInventoryRecipe({wood:c.w,stone:c.s},[],{gold:c.g}))return;
    if(bld==='coop'){
      if(!P.hasCoop){P.hasCoop=true;P.coopLv=1;for(let i=0;i<2;i++)P.herd.push(this.make('chicken',{age:99,love:150}))}
      else P.coopLv=(P.coopLv||1)+1;
    }else{
      if(!P.hasBarn){P.hasBarn=true;P.barnLv=1}else P.barnLv=(P.barnLv||1)+1;
    }
    fl(P.x,P.y-26,bld==='coop'?'🐔 KÜMES HAZIR!':'🐄 AHIR HAZIR!','#ffd23f',true);
    playChord([523,659,784,1046],.35,'triangle',.07);sv();this.ui();
  },
  buyAnimal(type){
    const T=HTYPES[type];
    if(!(T.pen==='coop'?P.hasCoop:P.hasBarn)){fl(P.x,P.y-22,T.pen==='coop'?'Önce kümes inşa et!':'Önce ahır inşa et!','#ff5d5d');return}
    if(this.count(T.pen)>=this.cap(T.pen)){fl(P.x,P.y-22,'Barınak dolu! Yükselt.','#ff5d5d');return}
    if(P.gold<T.cost){fl(P.x,P.y-22,'Yetersiz altın!','#ff5d5d');return}
    P.gold-=T.cost;const a=this.make(type);P.herd.push(a);
    fl(P.x,P.y-26,`${T.icon} ${a.name} çiftliğe katıldı!`,'#6ee7b7',true);sfx(700,.1,'sine',.05);sv();this.ui();
  },
  sellAnimal(id){
    const i=this.list().findIndex(a=>a.id===id);if(i<0)return;
    const a=this.list()[i],T=HTYPES[a.type];
    if(this.list().length<=1){fl(P.x,P.y-22,'Son hayvanı satamazsın!','#ff5d5d');return}
    const price=Math.round(T.cost*(this.adult(a)?.5:.3)*(.6+a.love/1000*.8));
    P.gold+=price;this.list().splice(i,1);fl(P.x,P.y-26,`${T.icon} ${a.name} satıldı +${price}🪙`,'#ffd23f',true);sv();this.ui();
  },
  buyHay(n){
    const c=8*n;if(P.gold<c){fl(P.x,P.y-22,'Yetersiz altın!','#ff5d5d');return}
    P.gold-=c;P.hay=(P.hay||0)+n;sfx(700,.1,'sine',.05);sv();this.ui();
  },
  feedAll(){
    let n=0;
    for(const a of this.list()){if(!a.fed&&P.hay>0){P.hay--;a.fed=true;a.love=Math.min(1000,a.love+10);n++}}
    fl(P.x,P.y-26,n?`🌾 ${n} hayvan beslendi!`:'Beslenecek hayvan/yem yok','#fde68a',true);sv();this.ui();
  },
  openBuilding(bld){
    if(bld==='coop'&&!P.hasCoop){this.build('coop');return}
    if(bld==='barn'&&!P.hasBarn){this.build('barn');return}
    $('herd-modal').classList.remove('h');this.ui();
  },
  ui(){
    const el=$('herd-content');if(!el)return;
    const btn=(a,l,bg)=>`<button ${a} style="padding:3px 8px;font-size:10px;${bg?'background:'+bg:''}">${l}</button>`;
    const bc=b=>{const c=this.buildCost(b);return c?`${c.g}🪙 ${c.w}🪵 ${c.s}🪨`:null};
    let h=`<p>🪙 <b>${P.gold}</b> · 🌾 Yem: <b>${P.hay||0}</b> ${btn('data-h="hay1"','+1 (8🪙)')} ${btn('data-h="hay10"','+10','#2563eb')} ${btn('data-h="feedall"','Hepsini Besle','#16a34a')}</p>`;
    h+=`<div style="display:flex;flex-direction:column;gap:4px;margin:6px 0">`;
    for(const [b,nm,ico] of [['coop','Kümes','🐔'],['barn','Ahır','🐄']]){
      const has=b==='coop'?P.hasCoop:P.hasBarn,lv=b==='coop'?(P.coopLv||1):(P.barnLv||1),pen=b==='coop'?'coop':'pasture',cost=bc(b);
      h+=`<div style="display:flex;justify-content:space-between;align-items:center;background:#1e293b;padding:3px 8px;border-radius:6px;gap:6px"><span>${ico} ${nm} ${has?'Sv.'+lv:'(yok)'} · ${this.count(pen)}/${this.cap(pen)}</span>${cost?btn(`data-h="build-${b}"`,(has?'Yükselt ':'İnşa ')+cost,'#b45309'):'<small>MAKS</small>'}</div>`;
    }
    h+=`<div style="display:flex;justify-content:space-between;align-items:center;background:#1e293b;padding:3px 8px;border-radius:6px;gap:6px"><span>⚙️ Otomatik Yemlik ${P.autoFeed?'(AKTİF)':''}<br><small style="color:#94a3b8">Her sabah yem stoğundan hayvanları besler</small></span>${P.autoFeed?'':btn('data-h="autofeed"','600🪙 10🪵','#b45309')}</div></div>`;
    h+=`<b style="color:var(--gd)">🐾 Hayvanların:</b><div style="display:flex;flex-direction:column;gap:3px;margin:5px 0;max-height:150px;overflow:auto">`;
    for(const a of this.list()){
      const T=HTYPES[a.type],hp=this.heartsOf(a);
      h+=`<div style="display:flex;justify-content:space-between;align-items:center;background:#0f172a;padding:2px 8px;border-radius:6px;gap:6px;font-size:10.5px"><span>${T.icon} <b>${a.name}</b> ${this.adult(a)?'':'(yavru)'} <span style="color:#f43f5e">${'♥'.repeat(Math.min(10,hp))}</span><span style="color:#475569">${'♥'.repeat(10-Math.min(10,hp))}</span> ${a.ready?'· '+T.prod.icon+' hazır':''} ${a.fed?'':'· 🌾 aç'}</span>${btn(`data-h="sell-${a.id}"`,'Sat','#7f1d1d')}</div>`;
    }
    h+=`</div><b style="color:var(--gd)">🛒 Hayvan Satın Al:</b><div style="display:flex;flex-direction:column;gap:3px;margin:5px 0">`;
    for(const k in HTYPES){
      const T=HTYPES[k];
      h+=`<div style="display:flex;justify-content:space-between;align-items:center;background:#1e293b;padding:2px 8px;border-radius:6px;gap:6px;font-size:10.5px"><span>${T.icon} ${T.n} (${T.cost}🪙)<br><small style="color:#94a3b8">${T.prod.icon} ${T.prod.n} · her ${T.every} günde · ${T.pen==='coop'?'Kümes':'Ahır'}</small></span>${btn(`data-h="buy-${k}"`,'Satın Al','#2563eb')}</div>`;
    }
    el.innerHTML=h+'</div>';
  }
};
function T2(s,x,y){g.font='8px sans-serif';g.textAlign='center';g.fillStyle='#000';g.fillText(s,Math.round(x),Math.round(y));g.textAlign='left'}
window.HERD=HERD;
(()=>{
  const c=$('herd-content'),cl=$('herdc');
  if(cl)cl.onclick=()=>$('herd-modal').classList.add('h');
  if(c)c.onclick=e=>{
    const b=e.target.closest('[data-h]');if(!b)return;const a=b.dataset.h;
    if(a==='hay1')HERD.buyHay(1);else if(a==='hay10')HERD.buyHay(10);
    else if(a==='feedall')HERD.feedAll();
    else if(a==='build-coop')HERD.build('coop');else if(a==='build-barn')HERD.build('barn');
    else if(a==='autofeed'){
      if(!P.autoFeed&&tryInventoryRecipe({wood:10},[],{gold:600})){P.autoFeed=true;fl(P.x,P.y-26,'⚙️ Otomatik Yemlik kuruldu!','#ffd23f',true);sv();HERD.ui()}
      else fl(P.x,P.y-22,'Gereken: 600🪙, 10 Odun','#ff5d5d');
    }
    else if(a.startsWith('buy-'))HERD.buyAnimal(a.slice(4));
    else if(a.startsWith('sell-'))HERD.sellAnimal(+a.slice(5));
  };
})();

function harvestPlot(p){FARM.harvest(p)}
function plantSeedInPlot(p){FARM.plant(p)}

function quickEatFood(){
  const fIdx = P.inv.findIndex(i => i.s === 'food');
  if(fIdx !== -1){
    const it = P.inv.splice(fIdx, 1)[0];
    if(it.hp) P.hp = Math.min(S.h, P.hp + it.hp);
    if(it.mp) P.mp = Math.min(S.m, P.mp + it.mp);
    if(it.buff)P.buffs[it.buff]=Math.max(P.buffs[it.buff]||0,it.duration||180);
    fl(P.x, P.y-26, `🍽️ ${it.n} Tüketildi!`, '#6ee7b7', true);
    playChord([523, 659, 784], .25, 'triangle', .05);
    sv();
  }else if(P.pots > 0){
    potion();
  }else{
    fl(P.x, P.y-22, 'Çantada yiyecek veya iksir yok!', '#ff5d5d');
  }
}

function cycleTool(dir=1){
  const tools = ['sword','hoe','can','pickaxe',...(FEATURES.is('fishing')?['rod']:[]),'food','seed'];
  let idx = tools.indexOf(P.activeTool||'sword');
  idx = (idx + dir + tools.length) % tools.length;
  selectTool(tools[idx]);
}

function useActiveTool(isCharged=false){
  if(BUILD.active)return;
  const tool = P.activeTool || 'sword';
  const dirOffsets = [[0,1],[0,-1],[-1,0],[1,0]];
  const off = dirOffsets[P.f] || [0,1];
  if(curMap === 'home' && tool === 'sword' && !isCharged){
    const frontPlot = FARM.plotAt((Math.floor(P.x/TS)+off[0])*TS+8, (Math.floor(P.y/TS)+off[1])*TS+8) || FARM.plotAt((Math.floor(P.x/TS))*TS+8, (Math.floor(P.y/TS))*TS+8);
    if(frontPlot && FARM.smartTileAction(frontPlot)){ P.sw = .22; return; }
  }
  // Savaş aracı: savaşçı şarjlı hortumu eski yoldan gider, diğer her şey COMBAT modülünden
  if(tool === 'sword' && !(isCharged && (P.cls||'warrior') === 'warrior')){ COMBAT.strike(isCharged); return; }
  P.sw = .24;
  P.ax = off[0]; P.ay = off[1];

  const perpOffsets = (P.f === 0 || P.f === 1) ? [[-1, 0], [0, 0], [1, 0]] : [[0, -1], [0, 0], [0, 1]];
  const sweepOffsets = isCharged ? perpOffsets : [[0, 0]];

  if(tool === 'hoe'){
    FARM.useHoe(off, sweepOffsets, isCharged);
  }else if(tool === 'seed'){
    FARM.useSeed(off, sweepOffsets, isCharged);
  }else if(tool === 'can'){
    const tgtGx=Math.floor(P.x/TS)+off[0];
    const tgtGy=Math.floor(P.y/TS)+off[1];
    const px = tgtGx * TS + 8;
    const py = tgtGy * TS + 8;
    const targetPlot=FARM.plotAt(px,py);
    const isWater=tAt(px,py)===1||(!targetPlot&&curMap==='home'&&(Math.hypot(px-16*TS,py-24*TS)<24||Math.hypot(px-31*TS,py-30*TS)<24));
    if(isWater){
      P.waterCan = 20;
      fl(P.x, P.y-18, '💧 Kova Dolduruldu! (20/20)', '#38bdf8', true);
      sfx(540, .14, 'sine', .05);
      spark(px, py, 14, '#38bdf8', 40);
      updHotbarUI();
    }else if(ELEMENTS.splash(px,py)){
      updHotbarUI();
    }else{
      let wateredCount = 0;
      sweepOffsets.forEach(so => {
        const gx = tgtGx + so[0];
        const gy = tgtGy + so[1];
        const plot = farmPlots && farmPlots.find(p => Math.abs(p.x - (gx*TS+8)) < 12 && Math.abs(p.y - (gy*TS+8)) < 12);
        if(plot && P.waterCan > 0){
          const moisture=friendHearts('dede')>=5?2:1;
          if(plot.watered&&(plot.moisture||1)>=moisture)return;
          plot.watered=true;plot.moisture=moisture;if(plot.introPlant)ONBOARD.event('water');
          P.waterCan--;
          spark(plot.x, plot.y - 6, 12, '#38bdf8', 40);
          wateredCount++;
        }
      });
      if(wateredCount > 0){
        sfx(800, .1, 'sine', .04);
        if(isCharged) playChord([440, 554, 659], .25, 'sine', .05);
        fl(P.x, P.y - 20, isCharged ? '💧 3\'LÜ SULAMA!' : `💧 Sulandı! (${P.waterCan}/20)`, '#38bdf8', true);
        addMasteryXp('farm', 4 * wateredCount);
        updHotbarUI();
        sv();
      }else if(P.waterCan <= 0){
        fl(P.x, P.y - 22, '💧 Kova Boş! Kuyudan Doldur!', '#ff5d5d');
        sfx(200, .1, 'sawtooth', .04);
      }
    }
  }else if(tool === 'pickaxe'){
    const tgtGx=Math.floor(P.x/TS)+off[0];
    const tgtGy=Math.floor(P.y/TS)+off[1];
    const px = tgtGx * TS + 8;
    const py = tgtGy * TS + 8;
    const oreRes = resources && resources.find(r => !r.mined && r.isOre && Math.hypot(r.x - px, r.y - py) < 22);
    if(oreRes){
      const mLvlHit=P.skills?.mine?.lvl||1;
      strikeOre(oreRes,(mLvlHit>=2?2:1)*(isCharged?3:1),isCharged);
    }else{
      const resting=resources.find(r=>r.mined&&r.isOre&&r.readyDay>P.day&&Math.hypot(r.x-px,r.y-py)<22);
      if(resting)fl(P.x,P.y-23,`⛏️ ${resting.readyDay-P.day} oyun günü sonra yenilenir`,'#a7f3d0');
      else{ sfx(300, .08, 'square', .04);spark(px, py, 6, '#cbd5e1', 30); }
    }
  }else if(tool === 'rod'){
    fish();
  }else if(tool === 'food'){
    quickEatFood();
  }else{
    if(isCharged){
      shk = Math.max(shk, 3);
      playChord([392, 523, 659, 784], .3, 'triangle', .06);
      fl(P.x, P.y - 26, '🌪️ HORTUM VURUŞU!', '#ffd23f', true);
      FX.slash(P.x,P.y-8,Math.atan2(P.ay,P.ax),46,0,true,5.5);FX.hitStop(5);
      for(let a=0; a<6.28; a+=0.5){
        FX.emit(P.x+Math.cos(a)*22,P.y-8+Math.sin(a)*18,Math.cos(a)*100,Math.sin(a)*100,.25,'#ffd23f',2,60,1);
      }
      for(const m of mobs){
        if(!m.dead && Math.hypot(m.x - P.x, m.y - P.y) < 55){
          hitMob(m, Math.round(S.a * 2.2), true, m.x > P.x ? 120 : -120, m.y > P.y ? 120 : -120);
        }
      }
    }else{
      attack();
    }
  }
}

