/* ===== KASABALILARLA DOSTLUK VE İLİŞKİ SİSTEMİ ===== */
const TOWNSFOLK = {
  melis: {
    id: 'melis', name: 'Barista Melis', icon: '☕',
    role: 'Güneşli Kafe & Fırın İşletmecisi',
    favs: ['Çilek', 'Köy Yumurtası', 'Çilekli Turta', 'Kruvasan'],
    favKeys: ['berry', 'egg', 'c_pie', 'croissant'],
    quotes: [
      '"Günaydın! Sabah kahvesinin kokusu tüm kasabaya yayılıyor."',
      '"Çiftlikten gelen taze çileklerle yaptığım tatlılar bir harika oluyor!"',
      '"Seninle sohbet etmek günümü aydınlatıyor, kahraman dostum!"',
      '"Biliyor musun? Kasabaya geldiğin günden beri burası çok daha neşeli."',
      '"Sen benim en kıymetli dostumsun. Bu özel kahve tarifini sadece senin için hazırladım!"'
    ],
    perks: ['2 Kalp: Kafede tüm içeceklerde %20 indirim!', '5 Kalp: Melis\'in Gizli Karamel Lattesi (+%40 Hız & Mana)!']
  },
  osman: {
    id: 'osman', name: 'Amca Osman', icon: '🛒',
    role: 'Kasaba Manavı & Eski Çiftçi',
    favs: ['Havuç', 'Buğday', 'Havuç Çorbası'],
    favKeys: ['carrot', 'wheat', 'c_soup'],
    quotes: [
      '"Selam evlat! Toprağın kokusunu içine çek, çiftçilik en kutsal iştir."',
      '"Tarlanın bereketi daim olsun. Eski günlerde ben de genç bir çiftçiydim."',
      '"Sert çalışmanın değerini bilen insanları her zaman takdir etmişimdir."',
      '"Senin gibi çalışkan bir komşuya sahip olmak kasabamız için büyük şans."',
      '"Al bakalım evlat, bu bereket kesesi nesillerdir bizdedir. Sana uğur getirsin!"'
    ],
    perks: ['2 Kalp: Markette tohumlarda %20 indirim!', '5 Kalp: Bereket Çantası (Tohum ekerken tohum harcamama şansı)!']
  },
  dede: {
    id: 'dede', name: 'Çiftçi Dede', icon: '🌾',
    role: 'Bilge Çiftlik Ağası',
    favs: ['Taze Köy Ekmeği', 'Sazan', 'Güneş Çiçeği', 'Alabalık'],
    favKeys: ['c_bread', 'fish', 'herb_sun'],
    quotes: [
      '"Ah genç dostum... Toprağa ne verirsen, toprak sana fazlasıyla geri verir."',
      '"Güneş açtığında tohumu ek, yağmur yağdığında şükret."',
      '"Eski Aethermoor toprakları büyü doludur, her bitkide bir sır gizlidir."',
      '"Senin ellerinden çıkan ekinleri görmek eski günlerimi hatırlatıyor bana."',
      '"Bu kadim yadigarı sana emanet ediyorum. Toprak sana her zaman fısıldayacak."'
    ],
    perks: ['2 Kalp: Çiftçilik XP\'si %25 daha hızlı kazanılır!', '5 Kalp: Antik Sulama Yadigarı (Tarlalar kalıcı 2 kat uzun sulu kalır)!']
  },
  boran: {
    id: 'boran', name: 'Demirci Boran', icon: '🔨',
    role: 'Köy Demircisi',
    favs: ['Bakır Cevheri', 'Demir Cevheri', 'Köy Omleti', 'Taş'],
    favKeys: ['copper_ore', 'iron_ore', 'c_omelet', 'stone'],
    quotes: [
      '"Kılıç dövmek sabır ister evlat. Ateş ve çelik yalan söylemez."',
      '"Güçlü bir zırh hayat kurtarır. Madenlerden taze cevher getirmeyi unutma."',
      '"Hımm... Savaşta fena değilsin, kılıcın dengesini iyi tutuyorsun."',
      '"Benim atölyeme her zaman hoş geldin. Senin gibi sağlam dövüşen az bulunur."',
      '"Bu benim başyapıtım evlat. Sana layık bir demirci işçiliği armağanım olsun!"'
    ],
    perks: ['2 Kalp: Eşya geliştirme altın maliyetinde %20 indirim!', '5 Kalp: Geliştirme başarı şansı +%15 artar!']
  }
};
const NPC_BOND_STORIES={
  melis:[
    'Melis kafeyi yalnız bir dükkân değil, kasabanın insanların birbirini bulduğu sıcak köşesi olarak görüyor.',
    'Çocukken annesiyle aynı fırında sabaha kadar ekmek yaptığını anlatıyor; kahve kokusunun ona evini hatırlattığını söylüyor.',
    'Kasaba büyürken eski samimiyetin kaybolmasından korkuyor. Çiftlik ürünlerinin insanları yeniden aynı sofrada topladığına inanıyor.',
    'Yeni tariflerini önce sana tattırmaya başlıyor; artık seni müşteri değil, kafenin hikâyesinin bir parçası sayıyor.',
    'Melis gelecekteki bütün kutlamalarda senin çiftliğinin ürünlerini kullanmak istiyor. Gölgeköy artık ikiniz için de gerçek bir yuva.'
  ],
  osman:[
    'Osman toprağı sabırla dinleyen insanların aceleci dünyadan daha çok şey öğrendiğine inanıyor.',
    'Gençliğinde kasabanın en büyük tarlasını işlettiğini, büyük bir fırtınadan sonra manavlığa geçtiğini anlatıyor.',
    'Eski tohum çeşitlerinin kaybolmasından endişeli. Senin bahçende onları yeniden çoğaltabileceğine güveniyor.',
    'Pazar hesabını ve yıllardır sakladığı ekim notlarını seninle paylaşmaya başlıyor.',
    'Bereket kesesini sana emanet ediyor; toprağın geleceğini artık yalnız kendi omuzlarında taşımadığını hissediyor.'
  ],
  dede:[
    'Çiftçi Dede her bitkinin mevsimi ve her insanın kendine ait bir büyüme zamanı olduğunu söylüyor.',
    'Aethermoor’un eski bahçelerini koruyan ailesinden kalan hikâyeleri anlatmaya başlıyor.',
    'Toprağın büyüsünün zayıfladığını hissediyor; yeniden canlanması için genç bir çiftçinin sabrına ihtiyaç olduğunu düşünüyor.',
    'Seni öğrencisi değil, toprağın yeni koruyucusu olarak görmeye başlıyor.',
    'Kadim sulama yadigârını sana bırakıyor. Bundan sonra toprağın fısıltılarını senin de duyacağına inanıyor.'
  ],
  boran:[
    'Boran için iyi bir silah yalnız keskin değil, sahibinin neden savaştığını bilen bir araçtır.',
    'İlk yaptığı kılıcın bir yolcuyu koruyamadığını ve o günden beri her parçayı iki kez kontrol ettiğini anlatıyor.',
    'Ejder tehdidi büyürken yetersiz kalmaktan korkuyor; güçlü cevherlerle yeni bir alaşım denemek istiyor.',
    'Atölyesinin kapısını sana her saat açık tutuyor ve tasarımlarını birlikte tartışıyor.',
    'Başyapıtını sana emanet ediyor. Onun gözünde artık müşteri değil, çeliğine anlam veren yol arkadaşısın.'
  ]
};
const NPC_PERSONAL_REQUESTS={
  melis:{title:'Kafenin Yeni Tatlısı',desc:'Melis kasabanın ortak sofrası için taze çilekli bir tarif denemek istiyor.',needs:{berry:2},reward:{gold:40,pots:1},rewardText:'+40🪙 · +1🧪',done:'Bu tatlı kasabayı aynı masada buluşturacak. İlk dilim her zaman senin.'},
  osman:{title:'Eski Tohumları Canlandır',desc:'Osman bereketli tohumları ayırmak için taze havuç örnekleri istiyor.',needs:{carrot:3},reward:{gold:45,seeds:{wheat:6}},rewardText:'+45🪙 · +6 Buğday Tohumu',done:'Bu tohumlar artık kaybolmayacak. Senin tarlana emanetler.'},
  dede:{title:'Toprağın Hatırası',desc:'Dede eski bahçe töreni için bir Taze Köy Ekmeği istiyor.',needs:{c_bread:1},reward:{gold:30,fert:3},rewardText:'+30🪙 · +3 Gübre',done:'Ekmeği bölüşünce toprak da bizi ailesinden sayar.'},
  boran:{title:'Yeni Alaşım Deneyi',desc:'Boran daha dengeli bir alaşım için 2 Bakır Cevheri istiyor.',needs:{copper_ore:2},reward:{gold:80,gems:2},rewardText:'+80🪙 · +2💎',done:'Alaşım tuttu. Bir sonraki silahın eskisinden çok daha dengeli olacak.'}
};
function friendshipStory(id,hearts){const list=NPC_BOND_STORIES[id]||[];return list[cl((hearts||1)-1,0,list.length-1)]||''}
function npcLifeState(id){const name=Object.keys(TOWN_LIFE.JOBS).find(k=>TOWN_LIFE.JOBS[k].id===id);return name?TOWN_LIFE.state(name):{mood:75}}
const FRIEND_WORLD_NAMES={melis:'Melis',osman:'Amca Osman',dede:'Çiftçi Dede'};
function friendPosition(id){
  if(id==='boran')return{x:50*TS,y:39*TS,activity:'Demirci atölyesinde çalışıyor',available:true};
  const worldName=FRIEND_WORLD_NAMES[id],obj=(WORLD_DATA.home?.npcs||[]).find(n=>n.n===worldName),jobName=Object.keys(TOWN_LIFE.JOBS).find(k=>TOWN_LIFE.JOBS[k].id===id),row=jobName?TOWN_LIFE.slot(jobName):null,job=TOWN_LIFE.JOBS[jobName];
  if(obj&&!obj.hidden)return{x:obj.x,y:obj.y,activity:row?.[4]||'Kasabada',available:true};
  const spot=row?.[2]||job?.home||[31,30];return{x:spot[0]*TS,y:spot[1]*TS,activity:row?.[6]?'Evinde dinleniyor · yarın ziyaret et':row?.[4]||'Kasabada',available:false};
}
function nearFriend(id,range=58){if(curMap!=='home')return false;const p=friendPosition(id);return p.available!==false&&Math.hypot(P.x-p.x,P.y-p.y)<=range}
function trackFriend(id){if(!TOWNSFOLK[id])return;P.adventure.trackedFriend=id;$('friends-modal').classList.add('h');const p=friendPosition(id);ban(`❤️ ${TOWNSFOLK[id].name} takip ediliyor`,'#f9a8d4');if(curMap!=='home')chat('REHBER','','Kasabalıyı bulmak için Huzurlu Çiftlik haritasına dön.',1);else fl(P.x,P.y-28,`Takip başladı · ${p.activity}`,'#f9a8d4',true);sv()}
function updateFriendTracker(){
  const el=$('friend-tracker'),id=P.adventure?.trackedFriend,npc=TOWNSFOLK[id];if(!el||!npc){el?.classList.add('h');return}
  const pos=friendPosition(id);if(curMap!=='home'){if((P.combatTimer||0)>0){el.classList.add('h');return}el.textContent=`🗺️ ${npc.name} · Çiftliğe dön`;el.classList.remove('h');return}
  const dx=pos.x-P.x,dy=pos.y-P.y,tiles=Math.round(Math.hypot(dx,dy)/TS),a=Math.atan2(dy,dx),arrows=['→','↘','↓','↙','←','↖','↑','↗'],arrow=arrows[(Math.round(a/(Math.PI/4))+8)%8];
  el.textContent=tiles<=4?`❤️ ${npc.name} · Yakında, konuş`:`${arrow} ${npc.name} · ${tiles} kare · ${pos.activity}`;el.classList.remove('h');
}
$('friend-tracker').onclick=()=>{const id=P.adventure?.trackedFriend;if(!id)return;if(curMap!=='home'){openMap('home');return}if(nearFriend(id)){openDialogue(id);return}const p=friendPosition(id);fl(P.x,P.y-30,`${TOWNSFOLK[id].name}: ${p.activity}`,'#f9a8d4',true)};
function npcContextLine(id){
  const story=window.STORY&&STORY.npcLine&&STORY.npcLine(id);if(story)return `📜 “${story}”`;
  const q=QS[P.q],npc=TOWNSFOLK[id];if(q?.giver&&q.giver.includes(npc.name.split(' ').pop()))return `📜 “${q.t} görevin için dikkatli ol. ${q.tip}”`;
  if(weather.type==='rain'||weather.type==='storm')return id==='dede'?'🌧️ “Yağmur toprağın eski şarkısıdır; bugün onu dinle.”':'🌧️ “Bu havada sıcak bir çatı ve dost sesi daha kıymetli.”';
  if(DAY_CLOCK.night())return '🌙 “Geç oldu. Yola çıkacaksan hazırlığını iki kez kontrol et.”';
  return '';
}
function giftReaction(id,item,favorite){
  if(!favorite)return `“${item.n} için teşekkür ederim. Beni düşünmen asıl değerli olan.”`;
  const lines={melis:'“Tam aradığım tazelik! Bununla hazırlayacağım tarifi ilk sen tadacaksın.”',osman:'“İşte iyi toprağın ürünü böyle olur. Tohumunu mutlaka ayıracağım.”',dede:'“Toprağın emeğini paylaşman, ona duyduğun saygıyı gösterir.”',boran:'“Kaliteli malzeme. Bunu sıradan bir işte harcamayacağım.”'};
  return lines[id]||'“Buna bayıldım. Beni gerçekten tanıyorsun.”';
}

function initFriendship(){
  if(!P.friendship)P.friendship={};
  ['melis','osman','dede','boran'].forEach(k=>{
    if(!P.friendship[k])P.friendship[k]={hearts:1,pts:0,talkedToday:false,giftedToday:false};
  });
}

function addFriendship(npcId, pts){
  initFriendship();
  const fs=P.friendship[npcId],npc=TOWNSFOLK[npcId],before=fs.hearts;pts=Math.max(0,Math.round(pts*WORLD_EVENTS.friendshipMultiplier()));fs.pts=Math.max(0,(fs.pts||0)+pts);
  while(fs.hearts<5&&fs.pts>=fs.hearts*60){fs.pts-=fs.hearts*60;fs.hearts++}if(fs.hearts>=5)fs.pts=0;
  if(fs.hearts>before){
    fs.newScene=fs.hearts;fs.lastHeartDay=P.day;
    fl(P.x,P.y-26,`❤️ ${npc.name} ile ${fs.hearts} Kalp Oldun!`,'#f43f5e',true);playChord([523,659,784,1046],.35,'sine',.06);spark(P.x,P.y-10,24,'#f43f5e',80);
    const perk=fs.hearts===2?npc.perks[0]:fs.hearts===5?npc.perks[1]:null;if(perk)chat('DOSTLUK','',`🔓 ${npc.name}: ${perk}`,1);
  }
  sv();return pts;
}

function unlockedItemCount(k){return P.inv.reduce((n,it)=>n+(!it.locked&&(k==='fish'?it.s==='fish':ITEMS.key(it.k)===ITEMS.key(k))?ITEMS.qty(it):0),0)}
function takeUnlockedItem(k,n){if(unlockedItemCount(k)<n)return false;let left=n;for(let i=0;i<P.inv.length&&left>0;){const it=P.inv[i],match=!it.locked&&(k==='fish'?it.s==='fish':ITEMS.key(it.k)===ITEMS.key(k));if(!match){i++;continue}const used=Math.min(left,ITEMS.qty(it));ITEMS.removeAt(P.inv,i,used);left-=used;if(i<P.inv.length&&P.inv[i]===it)i++}return left===0}
function completePersonalRequest(npcId){
  const npc=TOWNSFOLK[npcId],req=NPC_PERSONAL_REQUESTS[npcId],fs=P.friendship?.[npcId];if(!npc||!req||!fs||fs.hearts<3||fs.personalDone)return false;if(!nearFriend(npcId)){fl(P.x,P.y-26,'Teslim etmek için kasabalıyı ziyaret et.','#facc15',true);return false}
  const missing=Object.entries(req.needs).filter(([k,n])=>unlockedItemCount(k)<n);if(missing.length){fl(P.x,P.y-26,'Kişisel istek için malzemeler eksik.','#facc15',true);return false}
  for(const [k,n]of Object.entries(req.needs))if(!takeUnlockedItem(k,n))return false;
  fs.personalDone=true;fs.lastReaction=req.done;npcLifeState(npcId).mood=Math.min(100,npcLifeState(npcId).mood+15);const r=req.reward||{};P.gold+=r.gold||0;P.gems+=r.gems||0;P.pots+=r.pots||0;P.fert=(P.fert||0)+(r.fert||0);if(r.seeds)for(const [k,n]of Object.entries(r.seeds))P.seeds[k]=(P.seeds[k]||0)+n;updHotbarUI();
  P.townWorkDay=P.day;SESSION_COACH.event('social',1);addFriendship(npcId,75);ban(`${npc.icon} ${req.title} TAMAMLANDI`,'#f9a8d4');playChord([523,659,784,1046],.35,'triangle',.055);sv();openDialogue(npcId);return true;
}
function friendsUI(){
  initFriendship();
  let h = '';
  Object.values(TOWNSFOLK).forEach(npc=>{
    const fs = P.friendship[npc.id] || { hearts: 1, pts: 0 };
    const req=fs.hearts*60,pct=fs.hearts>=5?100:Math.round((fs.pts||0)/req*100),heartIcons='❤️'.repeat(fs.hearts)+'🖤'.repeat(5-fs.hearts),request=NPC_PERSONAL_REQUESTS[npc.id],mood=Math.round(npcLifeState(npc.id).mood||0),position=friendPosition(npc.id),tracked=P.adventure.trackedFriend===npc.id;
    h += `<div class="ach-item">
      <div class="ach-info">
        <div class="ach-title">${npc.icon} ${npc.name} <span style="font-size:12px;margin-left:4px">${heartIcons}</span></div>
        <div class="ach-desc">${npc.role} · Ruh hâli ${mood}/100</div>
        <div class="friend-progress"><i style="width:${pct}%"></i></div>
        <div class="friend-status-row"><span class="friend-chip ${fs.talkedToday?'done':''}">${fs.talkedToday?'✓ Konuşuldu':'○ Sohbet bekliyor'}</span><span class="friend-chip ${fs.giftedToday?'done':''}">${fs.giftedToday?'✓ Hediye verildi':'○ Hediye verilebilir'}</span>${fs.hearts>=3?`<span class="friend-chip ${fs.personalDone?'done':''}">${fs.personalDone?'✓ Kişisel istek tamam':'! Kişisel istek hazır'}</span>`:''}</div>
        <div class="friend-presence">📍 ${position.activity}${position.available===false?' · Şu an görüşülemez':''}</div>
        <div style="font-size:8.5px;color:#a7f3d0;margin-top:4px">Sevdikleri: ${npc.favs.join(', ')}${request&&fs.hearts<3?' · Kişisel isteği 3 kalpte açılır':''}</div>
      </div>
      <div class="friend-card-actions"><button type="button" data-open-dlg="${npc.id}">Profili Gör</button><button type="button" class="visit" data-track-friend="${npc.id}">${tracked?'Takip Ediliyor':'Ziyaret Et'}</button></div>
    </div>`;
  });
  $('friends-list').innerHTML = h;
}

$('friends-list').onclick=e=>{
  const track=e.target.closest('[data-track-friend]');if(track){const id=track.dataset.trackFriend;if(P.adventure.trackedFriend===id){P.adventure.trackedFriend=null;sv();friendsUI()}else trackFriend(id);return}
  const card=e.target.closest('[data-open-dlg]');if(!card)return;$('friends-modal').classList.add('h');openDialogue(card.dataset.openDlg);
};

let curDlgNpc = null;
function openDialogue(npcId){
  initFriendship();
  curDlgNpc = npcId;
  const npc = TOWNSFOLK[npcId];
  const fs = P.friendship[npcId];
  $('dlg-name').textContent = `${npc.icon} ${npc.name}`;
  const heartIcons='❤️'.repeat(fs.hearts)+'🖤'.repeat(5-fs.hearts),reqPts=fs.hearts*60,pct=fs.hearts>=5?100:Math.round((fs.pts||0)/reqPts*100);
  const quote=npc.quotes[Math.min(npc.quotes.length-1,fs.hearts-1)],memory=TOWN_LIFE.memoryLine(npcId),story=friendshipStory(npcId,fs.hearts),context=npcContextLine(npcId),personal=NPC_PERSONAL_REQUESTS[npcId],newScene=fs.newScene===fs.hearts,inPerson=nearFriend(npcId);
  const needText=personal?Object.entries(personal.needs).map(([k,n])=>{const name=CROPS[k]?.n||MATERIALS[k]?.n||({c_bread:'Taze Köy Ekmeği'}[k]||k);return `${unlockedItemCount(k)}/${n} ${name}`}).join(' · '):'';

  // Hediyelik eşyalar
  const giftables = P.inv.filter(i=>!i.locked&&(i.s==='crop'||i.s==='food'||i.s==='food_ing'||i.s==='fish'||ITEMS.stackable(i)||i.k==='herb_sun'));

  $('dlg-content').innerHTML = `
    <div style="font-size:16px;margin-bottom:4px">${heartIcons} <span style="font-size:11px;color:#94a3b8">(Dostluk: ${fs.hearts}/5 Kalp)</span></div>
    ${!inPerson?`<div class="remote-notice">📍 Bu ekran profili ve hatıraları gösteriyor. Sohbet etmek, hediye vermek ve kişisel isteği teslim etmek için kasabalıyı ziyaret et.<br><button id="btn-track-dialogue" type="button" style="margin-top:6px">❤️ Haritada Takip Et</button></div>`:''}
    <div class="friend-progress"><i style="width:${pct}%"></i></div><p style="font-size:8.5px;color:#94a3b8;text-align:right">${fs.hearts>=5?'Dostluk tamamlandı':`${fs.pts||0}/${reqPts} · sonraki kalp`}</p>
    <div style="background:#020617;border:2px solid #334155;border-radius:8px;padding:10px;margin:8px 0;font-size:11.5px;color:#fde047;line-height:1.5">${quote}</div>
    ${fs.lastReaction?`<div class="journey-box" style="font-size:10px;color:#f9a8d4">🎁 Son hediyen: ${escapeHTML(fs.lastReaction)}</div>`:''}
    ${context?`<div class="journey-box" style="font-size:10px;color:#c9d7dc">${context}</div>`:''}
    <div class="bond-story"><b>${newScene?'✨ YENİ HATIRA · ':''}${npc.name}</b><p>${story}</p></div>
    <div class="journey-box" style="font-size:9px"><b>🤝 Dostluk Avantajları</b><p style="color:${fs.hearts>=2?'#86efac':'#64748b'}">${fs.hearts>=2?'✓':'🔒'} ${npc.perks[0]}</p><p style="color:${fs.hearts>=5?'#86efac':'#64748b'}">${fs.hearts>=5?'✓':'🔒'} ${npc.perks[1]}</p></div>
    ${memory?`<div class="journey-box" style="font-size:10px;color:#b7ccd7">🧠 ${escapeHTML(memory)}</div>`:''}
    ${personal?fs.hearts<3?`<div class="personal-request"><b>🔒 Kişisel İstek · 3 Kalpte Açılır</b><p>${personal.title}: ${personal.desc}</p></div>`:fs.personalDone?`<div class="personal-request done"><b>✓ ${personal.title}</b><p>${personal.done}</p></div>`:`<div class="personal-request"><b>📜 ${personal.title}</b><p>${personal.desc}<br><strong>Gereken:</strong> ${needText}<br><strong>Ödül:</strong> ${personal.rewardText}</p><button id="btn-personal-request" type="button" ${inPerson?'':'disabled'}>${inPerson?'İsteği Teslim Et':'Teslim İçin Ziyaret Et'}</button></div>`:''}
    <div style="display:flex;gap:6px;margin:8px 0">
      <button id="btn-talk" class="m" ${inPerson?'':'disabled'} style="flex:1;padding:8px;font-size:12px;margin:0;background:${fs.talkedToday||!inPerson?'#475569':'#2563eb'}">
        ${!inPerson?'📍 Sohbet İçin Ziyaret Et':fs.talkedToday?'💬 Bugün Konuşuldu':'💬 Günaydın Sohbeti (+15 ❤️)'}
      </button>
    </div>
    <div style="font-size:11px;font-weight:900;color:var(--gd);text-align:left;margin-top:6px">🎁 Çantandan Hediye Ver (${!inPerson?'önce ziyaret et':fs.giftedToday?'Bugün Verildi':'1 adet vermek için dokun'}):</div>
    <div id="dlg-gift-grid" class="gr">
      ${giftables.length ? giftables.map((it,idx)=>slotH(it,'gift',idx)).join('') : '<div style="grid-column:span 5;font-size:10px;color:#64748b;padding:6px">Çantanda hediye verilebilecek meyve, yemek veya çiçek yok.</div>'}
    </div>
  `;
  if(newScene){delete fs.newScene;fs.sceneSeen=fs.hearts;sv()}
  const personalBtn=$('btn-personal-request');if(personalBtn)personalBtn.onclick=()=>completePersonalRequest(npcId);
  const trackBtn=$('btn-track-dialogue');if(trackBtn)trackBtn.onclick=()=>{$('dialogue-modal').classList.add('h');trackFriend(npcId)};

  $('btn-talk').onclick = () => {
    if(!inPerson)return;
    // Karakterler arası canlı konuşma balonu
    const pQuotes = {
      melis: 'SELAM MELIS! TAZE KAHVE?',
      osman: 'KOLAY GELSIN OSMAN AMCA!',
      dede: 'SELAM DEDE! BEREKET OLSUN',
      boran: 'SELAM BORAN! KILICIMI BILE'
    };
    say(P, pQuotes[npcId] || 'MERHABA!', 3.0);
    setTimeout(()=>{
      const nObj = (npcs||[]).find(x=>x.n===npc.name) || {x:P.x+20, y:P.y};
      const nReply = {
        melis: 'KAHVEN HAZIR! ☕',
        osman: 'BEREKET OLSUN!',
        dede: 'TOPRAGA IYI BAK!',
        boran: 'GETIR DOVELIM! 🔨'
      }[npcId] || 'HOS GELDIN!';
      say(nObj, nReply, 3.2);
    }, 450);
    if(!fs.talkedToday){
      fs.talkedToday = true;
      TOWN_LIFE.remember(npcId,'talk');npcLifeState(npcId).mood=Math.min(100,npcLifeState(npcId).mood+5);SESSION_COACH.event('social',1);
      const gained=addFriendship(npcId,15);
      fl(P.x,P.y-26,`+${gained} ❤️ Dostluk Arttı!`,'#f43f5e',true);
      playChord([523, 659, 784], .2, 'sine', .05);
      sv();
      openDialogue(npcId);
    }
  };

  $('dlg-gift-grid').onclick = e => {
    if(!inPerson){fl(P.x,P.y-26,'Hediye vermek için kasabalıyı ziyaret et.','#facc15',true);return}
    if(fs.giftedToday){
      fl(P.x, P.y-26, 'Bugün zaten hediye verdin!', '#cbd5e1');
      return;
    }
    const sl = e.target.closest('[data-w="gift"]');
    if(!sl) return;
    const gIdx = +sl.dataset.i;
    const item = giftables[gIdx];
    if(item){
      // consume item from bag
      const realIdx = P.inv.indexOf(item);
      if(realIdx<0||!ITEMS.removeAt(P.inv,realIdx,1))return; // Yığından yalnızca bir hediye.

      fs.giftedToday = true;
      TOWN_LIFE.remember(npcId,'gift');
      const isFav = npc.favKeys.some(fk => ITEMS.key(item.k) === ITEMS.key(fk) || (fk==='fish' && item.s==='fish'));
      const gain = isFav ? 45 : 25;fs.lastReaction=giftReaction(npcId,item,isFav);npcLifeState(npcId).mood=Math.min(100,npcLifeState(npcId).mood+(isFav?12:7));SESSION_COACH.event('social',1);
      const gained=addFriendship(npcId,gain);
      fl(P.x,P.y-26,isFav?`❤️ BAYILDI! +${gained} Dostluk!`:`❤️ Teşekkür etti! +${gained} Dostluk!`,'#f43f5e',true);
      playChord([523, 659, 784, 1046], .3, 'triangle', .06);
      spark(P.x, P.y-10, 20, '#f43f5e', 60);
      sv();
      openDialogue(npcId);
    }
  };

  $('dialogue-modal').classList.remove('h');
}


/* ===== ZANAAT MAKİNELERİ (ARI KOVANI & MAYALAMA FIÇISI) ===== */

/* ===== ÇİFTLİK VE KASABA YAPILARI (DEĞİRMEN, KUYU, MEYVE AĞAÇLARI, LAMBALAR) ===== */

