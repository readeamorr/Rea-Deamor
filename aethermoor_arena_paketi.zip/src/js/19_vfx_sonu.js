/* ===== VFX SONU ===== */

// Derinlik kuyruğu: kare başına yüzlerce nesne/closure üretmek yerine sabit kayıtları tekrar kullan.
const DRAW=(()=>{
  const pool=Array.from({length:1024},()=>({kind:'',ref:null,x:0,y:0,variant:0,order:0})),active=[];
  let count=0;
  const byDepth=(a,b)=>a.y-b.y||(a.kind==='placed'&&b.kind==='placed'?a.variant-b.variant:0)||a.order-b.order;
  const stalls=[['#b95751','Fırın & Kafe','☕'],['#4978a6','Manav','🛒'],['#4b8160','Botanik','🌸'],['#b6954e','Zanaat','🍯']];
  const treeKinds=new Set(['tree','pine','snow_pine','apple_tree','peach_tree','shroom']);
  const town=[
    ['#8a5a2b','#e8e8e8','#2e7d32','sword','Tüccar','#ffd23f'],
    ['#475569','#222','#b45309','sword','Demirci Boran','#f59e0b'],
    ['#e2e8f0','#fef08a','#38bdf8','staff','Rahibe Elara','#67e8f9'],
    ['#4f46e5','#312e81','#a855f7','staff','Sınıf Ustası','#c084fc']
  ];
  function begin(){count=0;active.length=0}
  function add(kind,ref,x=ref?.x||0,y=ref?.y||0,variant=0){
    if(count>=pool.length||!FX.visible(x,y,75))return;
    const job=pool[count];job.kind=kind;job.ref=ref;job.x=x;job.y=y;job.variant=variant;job.order=count++;active.push(job);
  }
  function player(){
    const cls=CLASSES[P.cls]||CLASSES.warrior,riding=!!P.adventure?.mounted;
    if(riding)BOND.drawMount(P.x,P.y);
    if(P.iv<=0||Math.floor(P.iv*20)%2){
      const weapon=P.activeTool&&P.activeTool!=='sword'?P.activeTool:cls.wpn;
      hero(P.x,P.y-(riding?7:0),P.f,P.w,cls.c,cls.h,cls.cape,P.sw,P.ax,P.ay,weapon);FX.torch();
      if((P.chargeT||0)>.1){
        const pct=Math.min(1,P.chargeT/.35);g.strokeStyle=pct>=1?'#ffe6a1':'#8cdbff';g.lineWidth=1.4;
        g.beginPath();g.arc(P.x,P.y-8,11,-Math.PI/2,-Math.PI/2+pct*Math.PI*2);g.stroke();
        if(pct>=1){FX.glow(P.x,P.y-8,17,0,.35);for(let i=0;i<3;i++){const a=P.t*10+i*2.09;R(P.x+Math.cos(a)*13,P.y-8+Math.sin(a)*10,1.5,1.5,'#fff')}}
      }
    }
    if(P.adventure?.title&&P.adventure.title!=='traveler')T(JOURNAL.label(),P.x,P.y-(riding?31:23),'#ffe1a1');
  }
  function draw(){
    active.sort(byDepth);
    // Tüm ayak gölgeleri zemine, karakter ve eşyaların çiziminden ÖNCE bırakılır.
    for(const job of active){
      let rx=7,ry=3;const r=job.ref;
      if(job.kind==='plot'||job.kind==='sprinkler'||job.kind==='bosstrack'||job.kind==='obj'&&r.k==='barn_col'||job.kind==='placed'&&['floor','roof'].includes(r.kind))continue;
      if(job.kind==='placed'){rx=BUILD.defs[r.kind].w*8;ry=r.kind==='workshop'?6:3}
      else if(job.kind==='player'&&P.adventure?.mounted){rx=13;ry=5}
      else if(job.kind==='house'||job.kind==='chapel'||job.kind==='stall'||job.kind==='mill'||job.kind==='barn'){rx=26;ry=8}
      else if(job.kind==='mob'){rx=Math.max(7,r.d.r);ry=Math.max(3,r.d.r*.38)}
      else if(job.kind==='obj'){rx=treeKinds.has(r.k)?13:7;ry=rx*.35}
      else if(job.kind==='resource'){if(r.mined)continue;rx=r.isOre?8:5;ry=2.8}
      else if(job.kind==='herd'){rx=['cow','pig','sheep','goat'].includes(r.type)?9:5;ry=rx*.35}
      FX.shadow(job.x,job.y,rx,ry,job.kind==='duck'?.35:.63);
    }
    for(const job of active){
      const r=job.ref,x=job.x,y=job.y;
      switch(job.kind){
        case 'placed':BUILD.draw(r);break;
        case 'bosstrack':BOSS_SYSTEM.drawTrack(r,x,y);break;
        case 'buildsite':R(x-1,y-15,2,15,'#806346');R(x-7,y-19,17,8,'#b39a66');R(x-5,y-17,13,4,'#395a58');if(labelNear(x,y,72))T('İnşa Arazisi',x,y-26,'#ecd7a4');break;
        case 'obj':obj(r);break;
        case 'inside':insideObjD(r);break;
        case 'house':houseD(r);if(r.title&&labelNear(x,y,62)&&!(ONBOARD.current()?.target==='home'&&/Çiftlik Evi/i.test(r.title)))T(r.title,x,y-36,'#ffd23f');break;
        case 'chest':chestD(r);break;
        case 'chapel':chapelD(x,y);break;
        case 'well':wellD(x,y);break;
        case 'stall':{const colors=stalls[job.variant];marketStallD(x,y,colors[0],'#f1e5c8',colors[1],colors[2]);break}
        case 'fire':campfireD(x,y);break;
        case 'cart':cartD(x,y);break;
        case 'mill':watermillD(x,y);break;
        case 'shipping':shippingBinD(x,y);break;
        case 'coop':coopD(x,y);break;
        case 'barn':HERD.barnD(x,y);break;
        case 'herd':HERD.draw(r);break;
        case 'beehive':beehiveD(x,y);break;
        case 'cask':caskD(x,y);break;
        case 'duck':duckD(r);break;
        case 'plot':farmPlotD(r);break;
        case 'resource':resD(r);break;
        case 'critter':critterD(r);if(r.bondId&&P.adventure.taming[r.bondId]?.trust&&Math.hypot(r.x-P.x,r.y-P.y)<60)T(`${r.bondName} ${P.adventure.taming[r.bondId].trust}/3`,r.x,r.y-23,'#bde3bf');break;
        case 'pet':petD(r);break;
        case 'merc':mercD(r);break;
        case 'sprinkler':sprinklerD();break;
        case 'autost':AUTO.drawStation(x,y);break;
        case 'golem':AUTO.drawGolem(x,y);break;
        case 'fountain':fountain();break;
        case 'town':{const c=town[job.variant];hero(x,y,0,0,c[0],c[1],c[2],0,1,0,c[3]);if(labelNear(x,y,72))T(c[4],x,y-23,c[5]);break}
        case 'ladder':ladderD(x,y,!!job.variant);break;
        case 'elevator':elevatorD(x,y);break;
        case 'mob':mobD(r);break;
        case 'npc':hero(x,y,r.f,r.w,r.c,r.h,r.cape,r.sw,1,0,'sword');if(labelNear(x,y,68))T(r.n+' Sv'+r.lv,x,y-23,'#b3e1e8');break;
        case 'player':player();break;
      }
    }
  }
  return {begin,add,draw,get count(){return count},capacity:pool.length};
})();

const PAL3=[
  ['#69a844','#518f38','#86be53'], // 0: çayır
  ['#277cb3','#236b9e','#54add1'], // 1: su
  ['#ead6a4','#d3bc88','#fff0c1'], // 2: kıyı
  ['#b7ad96','#948d7b','#ded5bd'], // 3: taş yol
  ['#3f4b5c','#2d394b','#59677a'], // 4: bazalt
  ['#dbb574','#c49a5d','#ebc991'], // 5: çöl
  ['#397b41','#285b34','#54a653'], // 6: orman
  ['#e0f1f0','#b9d8e2','#fffefa'], // 7: kar
  ['#526e50','#344f46','#79a073'], // 8: mantar bataklığı
  ['#cda971','#aa845b','#e9c990'], // 9: toprak patika
  ['#9dcdda','#75b2cb','#e5faff'], // 10: buzul
  ['#6b21a8','#4c167c','#b365e2'], // 11: iridyum madeni
  ['#a57149','#805337','#d2a578'], // 12: ahşap iskele
  ['#ba4828','#6b3029','#ffac51'], // 13: lav yarığı
  ['#172131','#0b1423','#304152'], // 14: katı mağara duvarı
  ['#756858','#594e47','#a08d77'], // 15: toprak mağara zemini
  ['#789765','#527752','#b4c17d'], // 16: sisli yayla çayırı
  ['#4e6070','#334552','#8b9ea5']  // 17: dik kaya sırtı
];

const TA=PAL3.map((p,t)=>[0,1,2,3].map(v=>{
  const c=document.createElement('canvas');c.width=c.height=TS;
  const x=c.getContext('2d'),P2=(i,j,col)=>{x.fillStyle=col;x.fillRect(i,j,1,1)};
  const q=k=>Math.floor(H(v*5+k*11+t,k*3+v)*13)+1;
  x.fillStyle=p[0];x.fillRect(0,0,TS,TS);
  for(let j=0;j<TS;j++)for(let i=0;i<TS;i++){
    const r=H(i*7+v*31+t*101,j*13+v*17+t);
    if(r<.2)P2(i,j,p[1]);else if(r>.93)P2(i,j,p[2]);
  }
  if(t===0||t===6){
    for(let k=0;k<3;k++){
      const i=q(k),j=q(k+9)+1;
      P2(i,j,p[1]);P2(i,j-1,p[2]);P2(i-1,j-2,p[2]);
    }
    if((t===0||t===6)&&v===3){P2(q(1),q(2),'#fff');P2(q(1)+1,q(2),'#ffd23f');P2(q(1),q(2)+1,'#ff8fb1')}
    if(v===2){P2(q(4),q(5),'#8a8f98');P2(q(4)+1,q(5),'#a8adb6')}
  }else if(t===1){
    x.fillStyle=p[2];for(let k=0;k<3;k++)x.fillRect(q(k)-1,q(k+4),3,1);
  }else if(t===2){
    for(let k=0;k<3;k++){
      const i=q(k),j=q(k+6);x.fillStyle=p[1];x.fillRect(i-2,j,4,1);P2(i-1,j-1,p[2]);
    }
  }else if(t===5){
    for(let k=0;k<3;k++){
      const i=q(k),j=q(k+6);x.fillStyle=p[2];x.fillRect(i-3,j,6,1);
      x.fillStyle=p[1];x.fillRect(i-1,j+2,4,1);
    }
  }else if(t===7){
    for(let k=0;k<3;k++){
      const i=q(k),j=q(k+6);x.fillStyle=p[2];x.fillRect(i-1,j,3,1);P2(i,j-1,'#fff');
    }
  }else if(t===8){
    x.fillStyle='#304d52';x.fillRect(q(7)-2,q(9),5,2); // küçük su birikintisi
    for(let k=0;k<3;k++){
      const i=q(k),j=q(k+7);P2(i,j,'#a5c078');P2(i,j-1,'#dbd486');
      if(k===1){P2(i+2,j-1,'#a855a7');P2(i+3,j-1,'#e4a0e1')}
    }
  }else if(t===9){
    for(let k=0;k<3;k++){
      const i=q(k),j=q(k+5);x.fillStyle=p[1];x.fillRect(i-2,j,4,1);
      P2(i,j-1,p[2]);
    }
  }else if(t===10){
    x.fillStyle='#dcf8fa';x.fillRect(0,0,TS,1);
    for(let k=0;k<3;k++){const i=q(k),j=q(k+4);P2(i,j,'#e9fcff');P2(i+1,j+1,'#6aabc1')}
  }else if(t===11){
    for(let k=0;k<3;k++){
      const i=q(k),j=q(k+7);P2(i,j,'#d8b4fe');P2(i+1,j,'#c084fc');P2(i,j-1,'#7c3aed');
    }
  }else if(t===12){
    for(let j=0;j<TS;j+=4){x.fillStyle=p[2];x.fillRect(0,j,TS,1);P2((j*3+v*5)%13+1,j+2,p[1])}
    x.fillStyle='#594639';x.fillRect(0,0,2,TS);x.fillRect(TS-2,0,2,TS);
  }else if(t===13){
    x.fillStyle=p[1];for(let j=0;j<TS;j+=5)x.fillRect(q(j)-4,j,10,2);
    x.fillStyle=p[2];x.fillRect(q(3)-2,q(4),6,2);P2(q(2),q(7),'#ffe495');
  }else if(t===14){
    x.fillStyle=p[1];for(let j=0;j<TS;j+=5)x.fillRect(0,j,TS,2);
    x.fillStyle=p[2];for(let k=0;k<3;k++){const i=q(k),j=q(k+3);x.fillRect(i-2,j,5,1);P2(i,j-2,'#455269')}
  }else if(t===15){
    for(let k=0;k<4;k++){
      const i=q(k),j=q(k+6);x.fillStyle=p[1];x.fillRect(i-2,j,5,1);
      P2(i,j-1,p[2]);if(k===2)P2(i+2,j+1,'#b7a68c');
    }
  }else if(t===16){
    for(let k=0;k<3;k++){const i=q(k),j=q(k+6);P2(i,j,p[1]);P2(i+1,j-1,p[2])}
    if(v===2){P2(q(1),q(2),'#d9b4df');P2(q(1)+1,q(2),'#f5d3eb')}
  }else if(t===17){
    x.fillStyle=p[1];for(let j=0;j<TS;j+=5)x.fillRect(0,j+3,TS,2);
    x.fillStyle=p[2];x.fillRect(q(3)-2,q(5),6,2);P2(q(7),q(2),'#d8e6dc');
  }else{
    x.fillStyle=p[1];
    for(let j=0;j<TS;j+=4){
      x.fillRect(0,j,TS,1);for(let i=((j/4)&1)*4;i<TS;i+=8)x.fillRect(i,j,1,4);
    }
    x.fillStyle=p[2];
    for(let j=1;j<TS;j+=4)for(let i=((j/4|0)&1)*4+1;i<TS;i+=8)x.fillRect(i,j,4,1);
  }
  // === DETAY KATMANI (adım 1: zemin dokuları) ===
  {
    const water=t===1,struct=[3,4,12,13,14,17,18].includes(t),jit=water?3:struct?4:9;
    const img=x.getImageData(0,0,TS,TS),a=img.data;
    for(let j=0;j<TS;j++)for(let i=0;i<TS;i++){
      const o=(j*TS+i)*4,d=Math.round((H(i*17+v*53+t*7,j*29+v*11+t*3)-.5)*jit*2);
      a[o]=Math.max(0,Math.min(255,a[o]+d));a[o+1]=Math.max(0,Math.min(255,a[o+1]+d));a[o+2]=Math.max(0,Math.min(255,a[o+2]+d));
    }
    x.putImageData(img,0,0);
    const sh=(col,al)=>{x.globalAlpha=al;x.fillStyle=col;};
    if(t===0||t===6||t===16){
      // çimen tutamları: gölge + gövde + parlak uç
      for(let k=0;k<6;k++){
        const i=q(k+20),j=q(k+30)+1;
        P2(i+1,j,p[1]);P2(i,j,p[0]);P2(i,j-1,p[2]);if(k%2)P2(i-1,j-2,p[2]);
        P2(i,j+1,p[1]);
      }
      if(t!==6&&(v===1||v===3)){
        const fi=q(41),fj=q(42)+1,pet=t===16?['#f5d3eb','#d9b4df']:v===1?['#fff7d6','#ffe27a']:['#ffb3c9','#ff7da3'];
        P2(fi,fj-1,pet[0]);P2(fi-1,fj,pet[0]);P2(fi+1,fj,pet[0]);P2(fi,fj+1,pet[0]);P2(fi,fj,pet[1]);P2(fi,fj+2,p[1]);
      }
      if(v===0){P2(q(43),q(44),p[2]);P2(q(43)+1,q(44),p[2])}
    }else if(t===2||t===5){
      for(let k=0;k<2;k++){
        const i=q(k+20),j=q(k+30)+1;
        x.fillStyle=p[2];x.fillRect(i-3,j,7,1);x.fillStyle=p[1];x.fillRect(i-2,j+1,6,1);
      }
      if(v===2){P2(q(45),q(46),'#f2b8a8');P2(q(45)+1,q(46),'#fff0e8');P2(q(45),q(46)+1,'#c98a7c')}
    }else if(t===3||t===9||t===15){
      for(let k=0;k<3;k++){
        const i=q(k+20),j=q(k+30);
        P2(i,j,p[2]);P2(i+1,j,p[2]);P2(i,j+1,p[1]);P2(i+1,j+1,p[1]);P2(i+2,j+1,p[1]);
      }
      if(t===9&&v%2===0){x.fillStyle=p[1];x.fillRect(0,5,TS,1);x.fillRect(0,11,TS,1)}
    }else if(t===7||t===10){
      for(let k=0;k<2;k++){
        const i=q(k+20),j=q(k+30);
        x.fillStyle=t===7?'#c4dce8':'#8bc0d4';x.fillRect(i-1,j+1,4,1);P2(i,j,p[2]);P2(i+1,j,p[2]);
      }
      P2(q(47),q(48),'#ffffff');
    }else if(t===4||t===17){
      const i=q(20),j=q(21);
      x.fillStyle=p[1];x.fillRect(i,j,1,3);x.fillRect(i+1,j+3,1,2);x.fillRect(i+1,j+5,2,1);
      P2(i-1,j,p[2]);P2(i,j-1,p[2]);
    }else if(t===8){
      for(let k=0;k<3;k++){const i=q(k+20),j=q(k+30);P2(i,j,p[2]);P2(i,j+1,p[1]);P2(i+1,j,p[2])}
    }else if(t===11){
      const i=q(20),j=q(21);P2(i,j,'#f0d6ff');P2(i-1,j,'#c084fc');P2(i+1,j,'#c084fc');P2(i,j-1,'#c084fc');P2(i,j+1,'#c084fc');
    }
    x.globalAlpha=1;
  }
  return c;
}));

const FN={},TC=new Map(),SC=new Map();
'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ!+-*[]_:?.,\x27)('.split('').forEach((ch,i)=>
  FN[ch]='75557 26227 71747 71717 55711 74717 74757 71111 75757 75717 25755 65656 34443 65556 74647 74644 34553 55755 72227 11152 55655 44447 57755 65555 25552 65644 25573 65655 34216 72222 55557 55552 55775 55255 55222 71247 22202 02720 00700 52725 32223 62226 00007 02020 61202 00002 00024 22000 42224 12221'.split(' ')[i]
);
Object.assign(FN,{Ç:'0344432',Ğ:'5034553',İ:'2722270',Ö:'5255520',Ş:'0342162',Ü:'5055557'});

const LBL=Array.from({length:192},()=>[0,0,0,0]);const LABEL_SCALE=.86;let labelCount=0,spriteDepth=0;
/* Dünya yazıları artık canvas'a piksel piksel değil, gerçek HTML katmanına çizilir.
   Böylece her ekran yoğunluğunda keskin kalır, Türkçe karakterler ve emoji doğru görünür. */
const WLAB=window.WLAB={
  el:null,pool:[],n:0,bpool:[],bn:0,frame:0,seen:new Set(),
  mk(){let e=document.getElementById('wl');if(!e){e=document.createElement('div');e.id='wl';document.body.appendChild(e)}this.el=e},
  begin(){if(!this.el)this.mk();this.n=0;this.bn=0;this.frame++;this.seen.clear()},
  push(text,x,y,color,icon,key){
    const vw=window.innerWidth||360,vh=window.innerHeight||640;
    // T() dünya koordinatı verir; kamera kaydırmasını çıkarıp ekran koordinatına çevir.
    if(this.seen.has(text))return;            // aynı yazıyı aynı karede iki kez basma
    this.seen.add(text);
    let px=(x-FX.viewX)/LW*vw, py=(y-FX.viewY)/LH*vh;
    const estW=Math.min(vw-16,text.length*(icon?14:6.3)+20); // etiketin yaklaşık genişliği
    px=Math.max(estW/2+5,Math.min(vw-estW/2-5,px));          // ekran kenarında kırpılmasın
    py=Math.max(88,py);                        // üst HUD ile çakışmasın
    let nd=this.pool[this.n];
    if(!nd){nd=document.createElement('span');nd.className='wl';this.el.appendChild(nd);this.pool.push(nd)}
    const sig=text+'|'+color+'|'+(icon?1:0)+'|'+(key?1:0);
    if(nd.__k!==sig){nd.__k=sig;nd.textContent=text;nd.style.color=color||'#ffe9b0';nd.classList.toggle('ico',!!icon);nd.classList.toggle('key',!!key)}
    if(Math.abs((nd.__x||-1e9)-px)>.4||Math.abs((nd.__y||-1e9)-py)>.4){
      nd.__x=px;nd.__y=py;
      nd.style.transform=`translate3d(${px.toFixed(1)}px,${py.toFixed(1)}px,0) translate(-50%,-100%)`;
    }
    if(nd.style.display==='none')nd.style.display='';
    this.n++;
  },
  bubble(text,x,y){
    const vw=window.innerWidth||360,vh=window.innerHeight||640;
    const px=x/LW*vw,py=y/LH*vh;
    let nd=this.bpool[this.bn];
    if(!nd){nd=document.createElement('div');nd.className='wlb';this.el.appendChild(nd);this.bpool.push(nd)}
    if(nd.style.display==='none')nd.style.display='';
    if(nd.__t!==text){nd.__t=text;nd.textContent=text;nd.__w=nd.offsetWidth||0}
    const half=(nd.__w||nd.offsetWidth||120)/2;
    const pxC=Math.min(Math.max(px,half+6),Math.max(half+6,vw-half-6));
    const pyC=Math.max(py,76);
    if(Math.abs((nd.__x||-1e9)-pxC)>.4||Math.abs((nd.__y||-1e9)-pyC)>.4){
      nd.__x=pxC;nd.__y=pyC;
      nd.style.transform=`translate3d(${pxC.toFixed(1)}px,${pyC.toFixed(1)}px,0) translate(-50%,-100%)`;
    }
    this.bn++;
  },
  flush(hideAll){
    if(hideAll){
      for(const nd of this.pool)if(nd.style.display!=='none')nd.style.display='none';
      for(const nd of this.bpool)if(nd.style.display!=='none')nd.style.display='none';
      return;
    }
    for(let i=this.n;i<this.pool.length;i++){const nd=this.pool[i];if(nd.style.display!=='none')nd.style.display='none'}
    for(let i=this.bn;i<this.bpool.length;i++){const nd=this.bpool[i];if(nd.style.display!=='none')nd.style.display='none'}
  }
};
function T(s,x,y,c,force){
  const raw=String(s==null?'':s).replace(/\s+/g,' ').trim();
  if(!raw)return;
  if(spriteDepth)return; // sprite içine gömülen yazı yok; güvenlik guard'ı
  const unit=(window.innerHeight||640)/LH;              // 1 canvas birimi kaç CSS px
  const iconOnly=/^[^\p{L}\p{N}]+$/u.test(raw);
  const fpx=Math.max(9.5,Math.min(13,unit*5.1));         // etiket yazı boyu
  const cssW=raw.length*(iconOnly?fpx*.75:fpx*.56)+16, cssH=fpx*1.5;
  const lw=Math.max(8,Math.round(cssW/unit)), lh=Math.max(7,Math.round(cssH/unit));
  let lx=Math.round(x-lw/2),ly=Math.round(y-lh);
  const minX=Math.round(camX+3),maxX=Math.round(camX+LW-lw-3);if(maxX>=minX)lx=cl(lx,minX,maxX);
  for(let tries=0;tries<16;tries++){
    let hit=false;
    for(let i=0;i<labelCount;i++){const r=LBL[i];if(lx<r[0]+r[2]+1&&lx+lw+1>r[0]&&ly<r[1]+r[3]+1&&ly+lh+1>r[1]){hit=true;break}}
    if(!hit)break;
    if(!force)return;
    ly-=lh+2;
  }
  if(labelCount<LBL.length){const r=LBL[labelCount++];r[0]=lx;r[1]=ly;r[2]=lw;r[3]=lh}
  WLAB.push(raw,lx+lw/2,ly+lh,c,iconOnly,force);
}
function labelNear(x,y,range=60){return Math.hypot(P.x-x,P.y-y)<=range}

function outline(c){
  const x=c.getContext('2d'),w=c.width,h=c.height,a=x.getImageData(0,0,w,h).data,o=new Uint8ClampedArray(a);
  const A=(i,j)=>i>=0&&j>=0&&i<w&&j<h&&a[(j*w+i)*4+3]>100;
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){
    const p=(j*w+i)*4;
    if(a[p+3]>100){
      const up=!A(i,j-1),dn=!A(i,j+1);
      if(up||dn){
        const m=up?45:-50;
        for(let k=0;k<3;k++)o[p+k]=cl(a[p+k]+m,0,255);
      }
    }else if(A(i-1,j)||A(i+1,j)||A(i,j-1)||A(i,j+1)){
      o[p]=24;o[p+1]=16;o[p+2]=34;o[p+3]=255;
    }
  }
  x.putImageData(new ImageData(o,w,h),0,0);
}

function spr(k,w,h,ox,oy,fn){
  let s=SC.get(k);
  if(!s){
    const c=document.createElement('canvas');c.width=w;c.height=h;
    const p=g;g=c.getContext('2d');spriteDepth++;
    try{fn(ox,oy)}finally{g=p;spriteDepth--}
    outline(c);s={c,ox,oy};
    if(SC.size>=768)SC.delete(SC.keys().next().value);
    SC.set(k,s);
  }
  return s;
}

function hero(x,y,f,w,c,h,cape,sw,ax,ay,wpn){
  const q=sw>0?Math.min(3,Math.floor((1-sw/.28)*4)):-1;
  const an=Math.round(Math.atan2(ay,ax)*3)/3;
  const sq=q>=0?(1-(q+.5)/4)*.28:0;
  const wType=wpn||'sword';
  const s=spr(['h',f,Math.floor(w)%2,c,h,cape,q,an,wType].join(),48,52,24,42,(X,Y)=>heroRaw(X,Y,f,w,c,h,cape,sq,Math.cos(an),Math.sin(an),wType));
  g.drawImage(s.c,Math.round(x)-s.ox,Math.round(y)-s.oy);
}

function tn(hex,d){
  if(typeof hex!=='string'||hex.length!==7||hex[0]!=='#')return hex;
  const n=parseInt(hex.slice(1),16);if(Number.isNaN(n))return hex;
  const r=Math.max(0,Math.min(255,(n>>16)+d)),g2=Math.max(0,Math.min(255,((n>>8)&255)+d)),b2=Math.max(0,Math.min(255,(n&255)+d));
  return '#'+((1<<24)|(r<<16)|(g2<<8)|b2).toString(16).slice(1);
}

function heroRaw(x,y,f,w,c,h,cape,sw,ax,ay,wpn){
  x=Math.round(x);y=Math.round(y);const b=Math.floor(w)%2;
  R(x-6,y-2,12,3,'#0003');
  const back=f===1,skin='#f2c9a0',skinD='#d9a982',cm=tn(c,-38),cl=tn(c,26);
  // bacaklar + çizmeler
  R(x-4,y-6,3,6-b,'#2a2f4a');R(x+1,y-6,3,5+b,'#2a2f4a');R(x-4,y-6,1,6-b,'#3c4366');R(x+1,y-6,1,5+b,'#3c4366');
  R(x-5,y-b-2,4,2,'#4a3322');R(x-5,y-b-2,4,1,'#6b4a2e');R(x+1,y+b-3,4,2,'#4a3322');R(x+1,y+b-3,4,1,'#6b4a2e');
  // gövde: sol aydınlık, sağ gölge, etek payı
  R(x-5,y-13,10,8,back?cape:c);
  if(back){
    R(x-5,y-13,1,8,tn(cape,16));R(x+4,y-13,1,8,tn(cape,-30));R(x-2,y-12,1,7,tn(cape,-22));R(x+2,y-12,1,7,tn(cape,12));R(x-5,y-6,10,1,tn(cape,-40));
  }else{
    R(x-5,y-13,2,8,cl);R(x+3,y-13,2,8,cm);R(x-5,y-6,10,1,tn(c,-48));
    R(x-3,y-12,3,2,tn(c,38));R(x-1,y-11,2,2,'#e8c25a');R(x-3,y-13,6,1,tn(cape,-10));
  }
  // pazı + kemer
  R(x-6,y-13,2,3,'#9aa8c8');R(x+4,y-13,2,3,'#9aa8c8');R(x-6,y-13,2,1,'#d3dcf0');R(x+4,y-13,2,1,'#d3dcf0');R(x-6,y-11,2,1,'#6f7d9e');R(x+4,y-11,2,1,'#6f7d9e');
  R(x-3,y-12,6,1,'#ffffff24');
  // kollar: kol + el
  R(x-7,y-11+b,2,3,tn(c,-10));R(x-7,y-8+b,2,2,skin);R(x+5,y-11+(1-b),2,3,tn(c,-10));R(x+5,y-8+(1-b),2,2,skin);
  if(!back){R(x-5,y-8,10,2,'#6b4a2a');R(x-5,y-8,10,1,'#8a6238');R(x-1,y-8,2,2,'#e8c25a')}
  // kafa: ten gölgesi, çene, saç parlaması
  if(back){
    R(x-4,y-19,8,7,h);R(x-4,y-19,8,1,tn(h,34));R(x-3,y-16,2,3,tn(h,-24));R(x+1,y-15,3,3,tn(h,-24));
  }else{
    R(x-4,y-19,8,7,skin);R(x-4,y-13,8,1,skinD);R(x+3,y-18,1,5,skinD);
  }
  R(x-5,y-21,10,4,h);R(x-5,y-18,2,4,back?h:tn(h,-22));R(x-4,y-22,6,1,h);R(x-3,y-21,4,1,tn(h,42));R(x-4,y-22,2,1,tn(h,24));
  if(f!==1){
    const o=f===2?-1:f===3?1:0;
    R(x-3+o,y-16,1,2,'#1b1b2b');R(x+1+o,y-16,1,2,'#1b1b2b');
    R(x-3+o,y-17,2,1,tn(h,-12));R(x+1+o,y-17,2,1,tn(h,-12));
    if(f===0){R(x-3,y-14,1,1,'#ec9f8c');R(x+2,y-14,1,1,'#ec9f8c')}
  }
  if(sw>0&&(wpn==='staff'||wpn==='bow')){
    const k=1-sw/.28,hx=x+ax*5,hy=y-10+ay*5,Q=(px,py,w,h,c)=>R(Math.round(px),Math.round(py),w,h,c);
    if(wpn==='staff'){
      for(let i=0;i<9;i++)Q(hx+ax*i*1.6-1,hy+ay*i*1.6-1,2,2,'#78350f');
      const tx=hx+ax*16,ty=hy+ay*16,r=2+k*3;
      Q(tx-r,ty-r,r*2,r*2,'#c084fc');Q(tx-1,ty-1,2,2,'#fff');
    }else{
      const bx=hx+ax*7,by=hy+ay*7,px=-ay,py=ax,nx=bx-ax*(2.5+4*(1-k)),ny=by-ay*(2.5+4*(1-k));
      for(let i=-5;i<=5;i++){const o=-Math.abs(i)*.45;Q(bx+px*i+ax*o-.5,by+py*i+ay*o-.5,2,2,'#854d0e')}
      for(let i=0;i<=5;i++){const t=i/5;Q(bx+px*5*(1-t)+(nx-bx)*t-.5,by+py*5*(1-t)+(ny-by)*t-.5,1,1,'#e2e8f0');Q(bx-px*5*(1-t)+(nx-bx)*t-.5,by-py*5*(1-t)+(ny-by)*t-.5,1,1,'#e2e8f0')}
      for(let i=0;i<10;i++)Q(nx+ax*i-.5,ny+ay*i-.5,1,1,i>7?'#fde047':'#fff');
    }
  }else if(sw>0){
    const k=1-sw/.28;
    for(let i=0;i<9;i++){
      const a=Math.atan2(ay,ax)-1+k*2;
      let col=wpn==='staff'?'#c084fc':wpn==='bow'?'#fde047':'#bfe8ff';
      if(wpn==='hoe') col='#facc15';
      else if(wpn==='can') col='#38bdf8';
      else if(wpn==='pickaxe') col='#fb923c';
      else if(wpn==='rod') col='#60a5fa';
      else if(wpn==='food') col='#4ade80';
      R(x+Math.cos(a)*(6+i*2.2),y-10+Math.sin(a)*(6+i*2.2),2,2,i>6?'#fff':col);
    }
  }else{
    const sx=f===2?-8:f===3?8:7;
    if(wpn==='hoe'){
      R(x+sx,y-17,2,10,'#854d0e');
      R(x+sx+(f===2?-2:1),y-18,4,3,'#94a3b8');
    }else if(wpn==='can'){
      R(x+sx-1,y-12,5,4,'#0284c7');
      R(x+sx+(f===2?-3:3),y-14,3,2,'#38bdf8');
    }else if(wpn==='pickaxe'){
      R(x+sx,y-17,2,10,'#78350f');
      R(x+sx-2,y-19,6,3,'#cbd5e1');
    }else if(wpn==='rod'){
      R(x+sx,y-20,1,13,'#ca8a04');
      R(x+sx+(f===2?-2:2),y-12,1,6,'#e2e8f0');
    }else if(wpn==='food'){
      R(x+sx-1,y-12,4,4,'#ef4444');
      R(x+sx,y-14,1,2,'#15803d');
    }else if(wpn==='staff'){
      R(x+sx,y-19,2,13,'#78350f');
      R(x+sx-1,y-22,4,4,'#38bdf8');
      R(x+sx,y-21,2,2,'#fff');
    }else if(wpn==='bow'){
      R(x+sx,y-18,2,11,'#854d0e');
      R(x+sx+(f===2?1:-1),y-19,1,13,'#e2e8f0');
    }else{
      R(x+sx,y-17,2,9,'#dfe9f3');
      R(x+sx-1,y-9,4,2,'#d4a437');
    }
  }
}

function mobD(e){
  const d=e.d,r=d.r,bs=d.boss,b=Math.round(Math.sin(e.ph));
  const wg=Math.round(Math.sin(e.ph*.6)*3),fl=e.fl>0?1:0,ca=e.cast>0?1:0;
  const x=Math.round(e.x),y=Math.round(e.y);
  const sW=bs===1?88:bs===2?56:44;
  const sH=bs===1?68:bs===2?52:44;
  const ox=sW/2,oy=sH-4;
  
  const s=spr(['m',e.k,e.v,b,bs===1?wg:0,e.f,fl,ca,e.chill>0?1:0].join(),sW,sH,ox,oy,(X,Y)=>
    mobRaw({x:X,y:Y,k:e.k,d,fl,ph:bs===1?Math.asin(wg/3)/.6:b*Math.PI/2,f:e.f,v:e.v,cast:ca,st:'',el:0,hv:0,hp:1,mhp:1,chill:e.chill})
  );
  
  if(e.el)FX.glow(x,y-r,r*2.6,2,.45);if(e.variant)FX.glow(x,y-r,r*2.2,e.variant==='volatile'?4:e.variant==='armored'?1:0,.3);
  
  g.drawImage(s.c,x-s.ox,y-s.oy);
  if(BOSS_SYSTEM.isLiving(e)){
    if(e.bossState==='sleep'&&Math.hypot(P.x-e.x,P.y-e.y)<130)T('💤',x,y-r*2-18,'#dce8f0');
    else if(e.bossState==='retreat')T('⚠ Yuvaya dönüyor',x,y-r*2-18,'#e9c27a');
  }
  if(e.chill>0){
    T('❄',x,y-r*2-15,'#7dd3fc');
  }
  if(e.st==='wind')T('!',x,y-r*2-13,'#ff5d5d');
  if(e.el&&e.hv<=0)T('★ '+d.n,x,y-r*2-9,'#ffd23f');else if(e.variant&&e.hv<=0)T(`${e.variantDef.icon} ${e.variantDef.name}`,x,y-r*2-9,e.variantDef.color);
  if(e.hv>0&&bs!==1){
    R(x-12,y-r*2-7,24,3,'#000');
    R(x-12,y-r*2-7,24*Math.max(0,e.hp/e.mhp),3,bs===2?'#f59e0b':'#e5302f');
    const stgPct=Math.min(1,(e.stagger||0)/(e.maxStagger||60));
    if(stgPct>0.04){
      R(x-12,y-r*2-3,24,1.5,'#1e293b');
      R(x-12,y-r*2-3,24*stgPct,1.5,'#facc15');
    }
    if(e.staggeredT>0){
      T('💫 SERSEM',x,y-r*2-13,'#facc15');
    }else{
      T((e.variant?e.variantDef.name+' ':'')+d.n+' Sv'+e.lv,x,y-r*2-10,e.variant?e.variantDef.color:'#fff');
    }
  }
}

function mobRaw(e){
  const x=Math.round(e.x),y=Math.round(e.y),fl=e.fl>0,k=e.k,b=Math.round(Math.sin(e.ph)),s=e.f,r=e.d.r;
  const isChilled=e.chill>0;
  if(e.d.boss!==1)R(x-r,y-2,r*2,3,'#0003');
  
  if(k==='slime'){
    const c=fl?'#fff':isChilled?'#67e8f9':'#4ade80',w=12+b;
    R(x-w/2,y-9-b,w,9+b,c);R(x-w/2+1,y-10-b,w-2,1,c);
    R(x-3,y-6,2,3,'#143');R(x+2,y-6,2,3,'#143');R(x-w/2+2,y-8-b,3,2,'#bbf7d0');
  }else if(k==='wolf'||k==='frost_wolf'){
    const cold=k==='frost_wolf',c=fl?'#fff':isChilled?'#93c5fd':cold?'#c7e5e8':'#9ca3af';
    R(x-8,y-9,16,7,c);R(x+s*6-3,y-13,7,7,c);R(x+s*6-3,y-16,2,3,c);R(x+s*6+2,y-16,2,3,c);
    R(x-s*10,y-9,3,3,c);R(x-6,y-3,2,3+b,c);R(x+4,y-3,2,3-b,c);
    if(cold){R(x-3,y-10,7,2,'#78afc9');R(x+s*7,y-12,2,2,'#15749b')}
    else R(x+s*8,y-11,1,2,'#f33');
  }else if(k==='boar'){
    const c=fl?'#fff':isChilled?'#a5d8e9':'#85533d';
    R(x-10,y-10,19,8,c);R(x+s*7-2,y-14,8,8,'#a56a4d');
    R(x+s*11,y-9,4,3,'#c8845f');R(x+s*7,y-11,1,1,'#201e1c');
    R(x+s*8,y-6,2,3,'#faf2d6');R(x-7,y-3,3,3+b,c);R(x+4,y-3,3,3-b,c);
  }else if(k==='mire_wisp'){
    const c=fl?'#fff':isChilled?'#67e8f9':'#8fe2ac';
    R(x-6,y-8+b,12,5,'#315a55');R(x-4,y-14+b,8,8,c);
    R(x-2,y-16+b,4,3,'#d8ffbc');R(x-2,y-11+b,1,2,'#315a55');R(x+2,y-11+b,1,2,'#315a55');
    R(x-8,y-9-b,2,2,'#b5ecc8');R(x+7,y-16+b,2,3,'#b5ecc8');
  }else if(k==='treant'){ 
    // Kadim Orman Muhafızı (Mini-Boss)
    const c=fl?'#fff':isChilled?'#6ee7b7':'#5a3a22';
    R(x-12,y-24,24,22,c);R(x-14,y-4,9,5,'#3d2817');R(x+5,y-4,9,5,'#3d2817');
    R(x-16,y-34,32,14,'#2d6a2e');R(x-12,y-38,24,8,'#3d8b3f');R(x-6,y-42,12,6,'#5bb85e');
    R(x-6,y-18,3,3,'#ffd23f');R(x+3,y-18,3,3,'#ffd23f');
  }else if(k==='lizard'){
    const c=fl?'#fff':isChilled?'#7dd3fc':e.v?'#d9534f':'#3fb56a';
    R(x-7,y-9,14,6,c);R(x+s*7-3,y-12,7,6,c);R(x-s*11,y-7,5,2,c);
    R(x-6,y-3,2,3+b,c);R(x+4,y-3,2,3-b,c);
    for(let i=0;i<4;i++)R(x-5+i*3,y-11,2,2,'#e8b04a');
    R(x+s*8,y-11,1,2,'#fff');
  }else if(k==='crab'){
    // Kral Yengeç (Mini-Boss)
    const c=fl?'#fff':isChilled?'#67e8f9':'#dc2626';
    R(x-14,y-16,28,14,c);R(x-11,y-14,22,3,'#ef4444');
    R(x-18,y-20,7,8,'#b91c1c');R(x+11,y-20,7,8,'#b91c1c');
    R(x-6,y-19,3,4,'#fff');R(x+3,y-19,3,4,'#fff');
    R(x-5,y-19,1,2,'#000');R(x+4,y-19,1,2,'#000');
    for(let i=0;i<3;i++){R(x-15+i*13,y-2,4,4+b,c)}
  }else if(k==='scorpion'){
    const c=fl?'#fff':isChilled?'#93c5fd':'#c98a3c';
    R(x-7,y-7,14,5,c);R(x+s*7-2,y-9,6,3,c);R(x-s*6,y-12,3,6,c);
    R(x-s*5,y-16,3,4,c);R(x-s*3,y-17,2,2,'#e33');
    for(let i=0;i<3;i++)R(x-6+i*5,y-2,2,2+b,c);
  }else if(k==='golem'){
    // Kum Golemi (Mini-Boss)
    const c=fl?'#fff':isChilled?'#7dd3fc':'#b45309';
    R(x-13,y-26,26,24,c);R(x-10,y-24,20,5,'#d97706');
    R(x-16,y-22,6,16,'#78350f');R(x+10,y-22,6,16,'#78350f');
    R(x-8,y-32,16,8,c);R(x-4,y-30,8,3,'#38bdf8');
    R(x-10,y-4,7,5,'#78350f');R(x+3,y-4,7,5,'#78350f');
  }else if(k==='skeleton'){
    const c=fl?'#fff':isChilled?'#bae6fd':'#e9e9e1';
    R(x-4,y-6,3,6-b,c);R(x+1,y-6,3,5+b,c);R(x-5,y-13,10,7,c);
    for(let i=0;i<3;i++)R(x-4,y-12+i*2,8,1,'#333');
    R(x-4,y-19,8,6,c);R(x-3,y-17,2,2,'#222');R(x+1,y-17,2,2,'#222');
    R(x+s*7,y-16,2,10,'#8a8a96');
  }else if(k==='phalanx'){
    const c=fl?'#fff':isChilled?'#94a3b8':'#475569';
    R(x-5,y-14,10,13,c);R(x-4,y-20,8,6,'#64748b');R(x-3,y-18,6,2,'#ef4444');
    R(x-4,y-2,3,4,c);R(x+1,y-2,3,4,c);
    R(x+s*6-2,y-18,5,18,'#94a3b8');R(x+s*6-1,y-16,3,14,'#f8fafc');R(x+s*6,y-10,1,2,'#ef4444');
  }else if(k==='assassin'){
    const c=fl?'#fff':isChilled?'#818cf8':'#1e1b4b';
    R(x-4,y-12,8,11,c);R(x-3,y-18,6,6,'#312e81');R(x-2,y-16,4,2,'#ef4444');
    R(x-3,y-2,2,4,c);R(x+1,y-2,2,4,c);
    R(x+s*6,y-12,2,8,'#e2e8f0');R(x-s*6,y-12,2,8,'#e2e8f0');
  }else if(k==='summoner'){
    const c=fl?'#fff':isChilled?'#c084fc':'#581c87';
    R(x-5,y-15,10,14,c);R(x-4,y-21,8,6,'#3b0764');R(x-3,y-20,6,4,'#e2e8f0');
    R(x-2,y-19,2,2,'#22c55e');R(x+1,y-19,2,2,'#22c55e');
    R(x+s*7,y-22,2,18,'#78350f');R(x+s*6,y-24,4,4,'#4ade80');
  }else if(k==='gladiator'){
    const c=fl?'#fff':isChilled?'#7dd3fc':'#78350f';
    R(x-12,y-24,24,22,c);R(x-10,y-22,20,8,'#b45309');R(x-8,y-32,16,10,'#451a03');
    R(x-10,y-34,3,6,'#d97706');R(x+7,y-34,3,6,'#d97706');
    R(x-4,y-28,8,3,'#ef4444');R(x-10,y-4,7,5,'#451a03');R(x+3,y-4,7,5,'#451a03');
  }else if(k==='bat'){
    const c=fl?'#fff':isChilled?'#93c5fd':'#475569';
    const flap=Math.sin(P.t*25)>0?3:-3;
    R(x-3,y-8,6,6,c);R(x-1,y-7,1,1,'#ef4444');R(x+1,y-7,1,1,'#ef4444');
    R(x-9,y-10+flap,6,4,c);R(x+3,y-10+flap,6,4,c);
  }else if(k==='ice_skeleton'){
    const c=fl?'#fff':'#7dd3fc';
    R(x-3,y-16,6,5,c);R(x-2,y-11,4,6,c);R(x-4,y-5,2,5,c);R(x+2,y-5,2,5,c);
    R(x+s*5,y-13,2,8,'#38bdf8');R(x-1,y-14,1,1,'#0284c7');R(x+1,y-14,1,1,'#0284c7');
  }else if(k==='magma_golem'){
    const c=fl?'#fff':'#27272a';
    R(x-12,y-24,24,22,c);R(x-10,y-22,20,4,'#ea580c');R(x-8,y-16,16,3,'#f97316');
    R(x-15,y-20,6,15,'#18181b');R(x+9,y-20,6,15,'#18181b');
    R(x-7,y-30,14,7,c);R(x-4,y-28,8,2,'#facc15');
    R(x-9,y-3,6,4,'#18181b');R(x+3,y-3,6,4,'#18181b');
  }else if(k==='colossus'){
    const c=fl?'#fff':'#1e1b4b';
    R(x-18,y-34,36,32,c);R(x-14,y-30,28,6,'#c084fc');R(x-10,y-20,20,4,'#38bdf8');
    R(x-24,y-30,8,24,'#0f172a');R(x+16,y-30,8,24,'#0f172a');
    R(x-12,y-44,24,11,c);R(x-6,y-40,12,3,'#facc15');
    R(x-14,y-4,10,6,'#0f172a');R(x+4,y-4,10,6,'#0f172a');
  }else{
    // Kızıl Ejder (Boss)
    const c=fl?'#fff':isChilled?'#93c5fd':'#c0392b',d='#7b1e1e',w=Math.round(Math.sin(e.ph*.6)*3);
    R(x-34,y-42+w,22,24,d);R(x+12,y-42+w,22,24,d);
    R(x-38,y-48+w,10,10,d);R(x+28,y-48+w,10,10,d);
    R(x-14,y-30,28,26,c);R(x-10,y-46,20,16,c);
    R(x-13,y-54,4,9,'#eee');R(x+9,y-54,4,9,'#eee');
    R(x-7,y-42,4,3,'#ffd23f');R(x+3,y-42,4,3,'#ffd23f');
    R(x-5,y-34,10,5,e.cast>0?'#ff9f1c':'#5a1010');
    R(x-14,y-6,8,6,c);R(x+6,y-6,8,6,c);
    R(x+14,y-16,10,4,d);R(x+22,y-20,4,6,d);
    R(x-18,y-24,4,14,d);R(x-24,y-40,4,6,d);
  }
}

function chestD(c){
  const x=Math.round(c.x),y=Math.round(c.y);
  R(x-7,y-2,14,3,'#0003');
  R(x-6,y-9,12,8,c.opened?'#52341b':'#854d0e');
  R(x-7,y-11,14,3,c.opened?'#a16207':'#ca8a04');
  R(x-2,y-7,4,3,'#facc15');
  if(!c.opened){
    R(x-1,y-12,2,2,'#fff8');
  }
}

function obj(o){
  if(o.k&&o.k.charCodeAt(0)===112&&o.k.slice(0,3)==='pk_')return TOWN_PARK.drawObj(o);
  const f6=tAt(o.x,o.y)===6?1:0,w=Math.round(Math.sin(P.t*1.4+o.v*40)),fl=Math.sin(P.t*10+o.v*20)>0?1:0;
  const stage=o.k==='frontier_station'?P.frontierMission||0:0;
  const s=spr(['o',o.k,f6,w,fl,stage,o.treeType||(o.isPeach?'peach':'apple'),o.fruitReady?1:0].join(),48,56,24,50,(X,Y)=>objRaw({k:o.k,x:X,y:Y,v:o.v,f6,w,fl,stage,treeType:o.treeType,isPeach:o.isPeach,fruitReady:o.fruitReady}));
  g.drawImage(s.c,Math.round(o.x)-s.ox,Math.round(o.y)-s.oy);
}

