/* ===== DEMİRCİ VE GELİŞTİRME SİSTEMİ ===== */
// Yalnızca ekipman yükseltilebilir; çantadaki odun/yiyecek/maden demirciyi çökertmemeli.
const forgeItems=()=>[...Object.values(P.eq).filter(i=>i&&SL[i.s]),...P.inv.filter(i=>i&&SL[i.s])];
let forgeSel=null;
const FORGE=window.FORGE={
  cost(it){
    if(!it||!SL[it.s])return null;const up=cl(Math.floor(Number(it.up)||0),0,15);if(up>=15)return null;
    if(up===0&&QS[P.q]?.k==='forge')return {target:1,gold:40,gems:0,needs:{},chance:100,story:true};
    const rarity=RAR[it.r]||RAR[0],needs={};
    if(up>=5){needs.iron_ore=2+Math.floor((up-5)/2);needs.coal=1+Math.floor((up-5)/3)}
    if(up>=10)needs.iridium_ore=1+Math.floor((up-10)/2);
    return {target:up+1,gold:friendPrice('boran',Math.round((50+up*80+Math.max(0,up-4)**2*12)*rarity[2])),gems:1+up,needs,chance:Math.min(100,(up<5?Math.max(60,100-up*10):Math.max(45,90-up*3))+(it.forgePity||0)*10+(friendHearts('boran')>=5?15:0))};
  },
  upgrade(it,random=Math.random){
    if(!forgeItems().includes(it))return {ok:false,message:'Ekipman artık çantanda veya üstünde değil.'};
    const cost=this.cost(it);if(!cost)return {ok:false,message:'En yüksek geliştirme: +15.'};
    const paid=inventoryRecipe(cost.needs,[],{gold:cost.gold,gems:cost.gems});if(!paid.ok)return {ok:false,message:'Altın, elmas veya cevher eksik; hiçbir şey harcanmadı.'};
    const success=random()*100<cost.chance;
    if(success){it.up=cost.target;it.forgePity=0;if(it.up>=15)P.adventure.stats.forge15=true;qp('forge');if(it.up>=3){P.ach.forge_3=1;checkAch('forge3')}}
    else it.forgePity=(it.forgePity||0)+1;
    S=st();sv();return {ok:true,success,message:success?`✓ Geliştirme başarılı: +${it.up}`:'Başarısız. Seviye korunur; sonraki deneme şansı +10 puan.'};
  }
};
function forgeUI(){
  const story=QS[P.q]?.k==='forge';
  if(story&&!forgeItems().length){
    P.eq.weapon={s:'weapon',r:0,n:'Boran’ın Kılıcı',up:0,atk:12};
    S=st();chat('DEMİRCİ BORAN','','Çıplak elle ejder yoluna çıkılmaz. Bu kılıç senin. Bir kez döveyim.',1);
  }
  const all=forgeItems();
  if(story&&(!forgeSel||!all.includes(forgeSel)))forgeSel=Object.values(P.eq).find(i=>i&&i.s==='weapon'&&SL[i.s])||all[0]||null;
  const crafts=[
    '<button data-forge-craft="sprinkler" style="padding:4px 8px;font-size:10px;background:#0d9488;margin-bottom:4px">🚰 Fıskiye Üret (150🪙)</button>',
    '<button data-forge-craft="beehive" style="padding:4px 8px;font-size:10px;background:#ca8a04;margin-bottom:4px">🐝 Arı Kovanı Üret (80🪙, 8 Odun)</button>',
    '<button data-forge-craft="cask" style="padding:4px 8px;font-size:10px;background:#854d0e;margin-bottom:6px">🛢️ Mayalama Fıçısı Üret (100🪙, 10 Odun)</button>'
  ].join('');
  let h=`<p>🪙 <b>${P.gold}</b> · 💎 <b>${P.gems}</b></p>
  ${story?'<p style="font-size:12px;color:#fde68a">Boran’ın tek işi: kılıcı +1 yap. 40 altın, kesin. Fıskiye ve kovan bu işin parçası değil.</p>':'<p style="font-size:11px;color:#cbd5e1">Ekipman yükselt veya çiftliğin için yeni araçlar üret.</p>'}
  <p style="font-size:10px;color:#a5f3fc">Çantanda: 🪵 ${countInv('wood')} Odun · 🪨 ${countInv('stone')} Taş · ⛓️ ${countInv('iron_ore')} Demir</p>
    ${story?'':crafts}<div class="gr">`;
  all.forEach((it,idx)=>{
    const rarity=RAR[it.r]||RAR[0];
    h+=`<div class="sl" data-fidx="${idx}" style="border-color:${rarity[1]};box-shadow:inset 0 0 8px ${rarity[1]}66">
      ${SL[it.s]}<small>${it.up?'+'+it.up:''}</small>
    </div>`;
  });
  h+='</div><div id="fg-dt" style="min-height:80px;background:#0a1230;border-radius:6px;padding:8px;text-align:left;border:1px solid #22325c">';
  h+=all.length?'Geliştirmek istediğin bir ekipmana dokun.':'Yükseltilecek ekipmanın yok. Kılıç veya zırh bulduğunda buraya getir; üretim tezgâhı yine de kullanılabilir.';
  $('fg').innerHTML=h+'</div>'+(story?'<div style="margin-top:8px;opacity:.72">'+crafts+'</div>':'');
  if(all.includes(forgeSel))updateForgeDetail();
}

$('fg').onclick=e=>{
  const sl=e.target.closest('[data-fidx]');
  if(sl){forgeSel=forgeItems()[+sl.dataset.fidx]||null;updateForgeDetail();return}
  const craft=e.target.closest('[data-forge-craft]');
  if(!craft)return;
  const type=craft.dataset.forgeCraft;
  const recipe={sprinkler:{gold:150,wood:0,flag:'hasSprinkler'},beehive:{gold:80,wood:8,flag:'hasBeehive'},cask:{gold:100,wood:10,flag:'hasCask'}}[type];
  if(!recipe)return;
  if(P[recipe.flag]){fl(P.x,P.y-26,'Bu yapı zaten kurulu!','#cbd5e1');return}
  if(!tryInventoryRecipe({wood:recipe.wood},[],{gold:recipe.gold}))return;
  P[recipe.flag]=true;
  if(type==='beehive')P.honeyReady=true;
  fl(P.x,P.y-26,{sprinkler:'🚰 Fıskiye Tarlaya Kuruldu!',beehive:'🐝 Arı Kovanı Kuruldu!',cask:'🛢️ Mayalama Fıçısı Kuruldu!'}[type],'#6ee7b7',true);
  playChord([523,659,784],.3,'triangle',.06);
  sv();forgeUI();
};

function updateForgeDetail(){
  const dt=$('fg-dt');if(!forgeSel||!dt)return;
  const it=forgeSel,rarity=RAR[it.r]||RAR[0],cost=FORGE.cost(it);
  dt.innerHTML=`<b style="color:${rarity[1]}">${escapeHTML(it.n)} [+${it.up||0}]</b>${cost?` ➜ <span style="color:#a7f3d0">+${cost.target}</span>`:' · MAKSİMUM +15'}<br>${itx(it)}
    ${cost?`${cost.story?'<p style="color:#fde68a">Hikâye dövmesi. 40 altın, elmas yok, sonuç kesin +1.</p>':''}<p style="margin-top:8px">🪙 ${cost.gold}${cost.gems?` · 💎 ${cost.gems}`:''}${Object.entries(cost.needs).map(([k,n])=>` · ${n} ${MATERIALS[k].n}`).join('')}</p><p>Başarı: %${cost.chance}${cost.story?'':' · Başarısızlıkta eşya ve seviye kaybolmaz.'}</p><button id="do-upgrade" class="m" style="padding:8px 12px">${cost.story?'🔨 Kılıcı +1 Yap':'🔨 Geliştir'}</button>`:'<p style="color:#e9d092">Bu eşya son geliştirme seviyesine ulaştı.</p>'}
    ${it.s==='weapon'&&QS[P.q]?.k!=='forge'?`<div style="margin-top:10px;border-top:1px solid #78908755;padding-top:7px"><b>⚡ Fırtına Rünü</b><p>2 Bakır · 2 Kömür · 60🪙. Islak hedefte zincirlenen alan elektriği.</p><button id="forge-lightning" ${it.element==='lightning'?'disabled':''}>${it.element==='lightning'?'✓ Rün İşlendi':'Rün İşle'}</button></div>`:''}<p id="forge-result" role="status" class="inventory-status"></p>`;
  if($('do-upgrade'))$('do-upgrade').onclick=()=>{
    const result=FORGE.upgrade(it);forgeUI();$('forge-result').textContent=result.message;
    if(result.success){playChord([523,659,784],.2,'triangle',.05);spark(P.x,P.y-10,18,'#e9cf88',65)}else sfx(160,.1,'triangle',.03);
  };
  if($('forge-lightning'))$('forge-lightning').onclick=()=>{if(ELEMENTS.enchant(it)){forgeUI();$('forge-result').textContent='✓ Silaha fırtına rünü işlendi.'}};
}

/* ===== RAHİBE VE ŞİFA TAPINAĞI ===== */
function priestUI(){
  $('pr').innerHTML=`
    <p>🪙 <b>${P.gold}</b></p>
    <p style="font-size:11px;color:#a7f3d0">"Işığın bereketi seninle olsun, yolcu."</p>
    <button data-p="heal" style="display:block;width:100%;margin:6px 0">✨ Tam İyileşme (Can & Mana) - Ücretsiz</button>
    <button data-p="shield" style="display:block;width:100%;margin:6px 0">🛡️ Işık Kalkanı (+100 Kalkan) - 40🪙</button>
    <button data-p="atk" style="display:block;width:100%;margin:6px 0">⚔️ Kutsal Kuvvet (+%22 Saldırı, 90sn) - 60🪙</button>
    <button data-p="spd" style="display:block;width:100%;margin:6px 0">👟 Rüzgar Çevikliği (+%22 Hız, 90sn) - 50🪙</button>
  `;
}

$('pr').onclick=e=>{
  const act=e.target.dataset.p;
  if(!act)return;
  if(act==='heal'){
    P.hp=S.h;P.mp=S.m;
    fl(P.x,P.y-26,'TAM ŞİFA!','#6dff9c',true);
    playChord([523,659,784],.3,'sine',.04);
  }else if(act==='shield'&&P.gold>=40){
    P.gold-=40;P.shld=Math.max(P.shld||0,100);
    fl(P.x,P.y-26,'+100 KALKAN','#38bdf8',true);
    sfx(600,.2,'sine',.05);
  }else if(act==='atk'&&P.gold>=60){
    P.gold-=60;P.buffs.atk=90;S=st();
    fl(P.x,P.y-26,'+SALDIRI KUTSAMASI','#ffd23f',true);
    sfx(700,.2,'sine',.05);
  }else if(act==='spd'&&P.gold>=50){
    P.gold-=50;P.buffs.spd=90;S=st();
    fl(P.x,P.y-26,'+HIZ KUTSAMASI','#a7f3d0',true);
    sfx(800,.2,'sine',.05);
  }else return;
  sv();priestUI();
};

/* ===== TÜCCAR SİSTEMİ ===== */
function shopUI(){
  $('sh').innerHTML=`
    <p>🪙 ${P.gold} · 🧪 ${P.pots}</p>
    <button data-b="p">🧪 İksir al (25🪙)</button>
    <button data-b="g">🎁 Nadir+ eşya kutusu (160🪙)</button>
    <button data-b="f">🐟 Tüm balıkları sat</button>
    <button data-b="c">🗑️ Yalnızca sıradan ekipmanı sat</button>
    ${ECONOMY.html()}
  `;
}

$('sh').onclick=e=>{
  if(ECONOMY.click(e))return;
  const b=e.target.dataset.b;if(!b)return;let t=0;
  if(b==='p'&&P.gold>=25){P.gold-=25;P.pots++}
  else if(b==='g'){if(!tryInventoryRecipe({},[gen(P.lvl+2,1)],{gold:160}))return}
  else if(b==='f'){
    ECONOMY.sellWhere(i=>i.s==='fish');
  }else if(b==='c'){
    P.inv=P.inv.filter(i=>{
      if(!SL[i.s]||(i.r||0)!==0)return true; // Odun, ürün, yemek ve nadir ekipman kalsın.
      t+=Math.round(8*(P.lvl+1));return false;
    });
  }else return;
  P.gold+=t;sfx(700,.1);sv();shopUI();
};

/* ===== BAŞARIMLAR LİSTESİ UI ===== */
function achUI(){
  let h='';
  ACH_LIST.forEach(a=>{
    const st=P.ach[a.id]||0;
    const canClaim=st===1;
    const isDone=st===2;
    h+=`<div class="ach-item">
      <div class="ach-info">
        <div class="ach-title">${a.t}</div>
        <div class="ach-desc">${a.d}</div>
        <div class="ach-reward">Ödül: +${a.g}🪙 +${a.m}💎</div>
      </div>
      <div>
        ${isDone?'<span style="color:#6ee7b7">✔ Alındı</span>':
          canClaim?`<button class="m" data-ach="${a.id}" style="padding:6px 12px;font-size:11px;margin:0">Ödülü Al</button>`:
          '<span style="color:#64748b">Devam Ediyor</span>'}
      </div>
    </div>`;
  });
  $('ac-list').innerHTML=h;
}

$('ac-list').onclick=e=>{
  const id=e.target.dataset.ach;
  if(!id)return;
  const a=ACH_LIST.find(x=>x.id===id);
  if(a&&P.ach[id]===1){
    P.ach[id]=2;
    P.gold+=a.g;P.gems+=a.m;
    fl(P.x,P.y-26,'+'+a.g+'🪙 +'+a.m+'💎','#ffd23f',true);
    playChord([523,659,784],.2,'sine',.05);
    sv();achUI();
  }
};

/* ===== YETENEK VE ÖLÜM ===== */
const TL=[['a','⚔ Hasar +%15'],['h','❤ Maks can +%20'],['c','🎯 Kritik +%10'],['s','👟 Hız +%12'],['v','🩸 Can emme %3']];
function talent(){GAME_CORE.offerTalent(true)}
$('cd').addEventListener('click',e=>{const b=e.target.closest('[data-t]');if(b)GAME_CORE.chooseTalent(b.dataset.t,b.dataset.talentToken)});

function death(){GAME_CORE.defeat()}

/* ===== BALIK TUTMA ===== */
const DR=[[0,1],[0,-1],[-1,0],[1,0]];
function waterDir(){
  for(let i=0;i<4;i++)
    if(tAt(P.x+DR[i][0]*20,P.y+DR[i][1]*20-2)===1||tAt(P.x+DR[i][0]*28,P.y+DR[i][1]*28-2)===1)
      return i;
  return -1;
}

function fish(){
  if(P.dead||!FEATURES.use('fishing'))return;
  if(P.fs){
    if(P.fs.st==='bite'){
      const inLake=P.fs.lake,inSea=P.fs.sea,usingBait=inLake&&(P.lakeBait||0)>0;
      let i=0;
      if(isWetWeather()&&Math.random()<(inLake?.2:inSea?.16:.35)){
        i=5; // Şimşek Balığı yağmurda nadir bir sürpriz.
      }else if(inLake){
        i=Math.random()<(usingBait?.48:.2)?7:6;
      }else if(inSea){
        const q=Math.random();i=q<.65?8:q<.93?9:10;
      }else{
        const q=Math.random();i=q<.5?0:q<.78?1:q<.93?2:q<.98?3:4;
      }
      if(usingBait&&(i===6||i===7))P.lakeBait--;
      const it={s:'fish',r:FISH_RARITY[i],n:FISH[i][0],val:FISH[i][1],origin:inSea?'sea':inLake?'lake':'freshwater'};
      if(!ITEMS.add(P.inv,it)){P.gold+=it.val;fl(P.x,P.y-40,`Çanta dolu · balık +${it.val}🪙 karşılığı satıldı.`,'#facc15')}
      fl(P.x,P.y-28,'🐟 '+it.n,RAR[it.r][1],true);
      spark(P.fs.bx,P.fs.by,18,'#bfe8ff',60);
      sfx(880,.2,'sine',.05);
      P.fs=null;qp('fish');
      P.ach.fish_caught=(P.ach.fish_caught||0)+1;SESSION_COACH.event('fish',1);EXPEDITIONS.event('fish',it.n,1);
      let fiLvl = P.skills?.fish?.lvl || 1;
      if(fiLvl>=7 && Math.random()<0.2){
        P.gold+=60; P.gems+=2;
        fl(P.x, P.y-34, '🎁 HAZİNE SANDIĞI ÇEKİLDİ!', '#ffd23f', true);
        playChord([523,659,784], .25, 'triangle', .05);
      }
      addMasteryXp('fish', 22);
      checkAch('fisher');
      sv();
    }else{
      P.fs=null;
      fl(P.x,P.y-28,QS[P.q]?.k==='fish'?'Biraz bekle · ÇEK çıkınca çek':'Çok erken!','#fff');
    }
    return;
  }
  const i=waterDir();if(i<0)return;
  P.f=i;
  const wx=P.x+DR[i][0]*20,wy=P.y+DR[i][1]*20-2;
  const dist=tAt(wx,wy)===1?20:28;
  const castX=P.x+DR[i][0]*dist,castY=P.y+DR[i][1]*dist-2;
  const tx=castX/TS|0,ty=castY/TS|0,water=tAt(castX,castY)===1;
  const atLake=curMap==='world'&&water&&lakeWater(tx,ty);
  const atSea=curMap==='world'&&water&&!atLake&&tx>=0&&ty>=0&&tx<N&&ty<N&&
    WORLD_DATA.world.seaMask[ty*N+tx]===1&&worldBiome(tx,ty)!=='marsh';
  P.fs={st:'wait',t:(QS[P.q]?.k==='fish'?rnd(.9,1.7):rnd(1.5,3.8))*WORLD_EVENTS.fishingWaitMultiplier(),bx:P.x+DR[i][0]*34,by:P.y+DR[i][1]*34-4,lake:atLake,sea:atSea};
  sfx(300,.12,'sine',.04);
}

