/* ===== ÇİFTLİK, EV VE GÜNDELİK YAŞAM FONKSİYONLARI ===== */
function sleepInBed(){
  if(curMap!=='inside'||Math.hypot(P.x-22*TS,P.y-8*TS)>=24)return false;
  if(!DAY_CLOCK.late()){fl(P.x,P.y-26,'Gece yarısından önce yeni gün başlayamaz.','#e9d092');return false}
  hf=0.9;
  playChord([523,659,784,1046],.5,'sine',.06);
  // Takvim ve sabah saati FARM.newDay() içinde birlikte güncellenir.
  say(P, 'Mışıl mışıl uyudum... Günaydın! ☀️', 3.0);
  if(P.orders)P.orders.forEach(o=>{if(o.done){const r=pick(ORDER_POOL);Object.assign(o,r);o.done=false}});
  P.hp=S.h;P.mp=S.m;
  if(!FARM.newDay())return false;
  if(window.STORY&&STORY.state().beats.rest){STORY.state().beats.rest=false;const nq=QS[P.q];setTimeout(()=>chat('REHBER','',nq?.k==='treant'?'Sabah oldu. Orman Muhafızı, slime açıklığının kuzeydoğusundaki koruda. Sarı hedef orayı gösterir.':'Sabah oldu. Sarı hedef sıradaki işi gösterir.',1),700)}
  P.cowMilkedToday = false;
  if(WORLD_DATA.home?.sheep) WORLD_DATA.home.sheep.woolReady = true;
  P.dailyIncomeCollected = false;
  if(P.friendship){
    for(const k in P.friendship){
      P.friendship[k].talkedToday = false;
      P.friendship[k].giftedToday = false;
    }
  }
  HERD.newDay();
  if(P.hasBeehive) P.honeyReady = true;
  if(WORLD_DATA.home?.fruitTrees) WORLD_DATA.home.fruitTrees.forEach(t=>t.fruitReady=true);
  if(P.hasCask&&P.caskItem&&(P.caskReadyDay||P.day)<=P.day)P.caskReady=true;

  if(P.shippingBin && P.shippingBin.length > 0){
    let cropTotal = 0, animalTotal = 0, fishTotal = 0, otherTotal = 0;
    P.shippingBin.forEach(i => {
      const v=unitSaleValue(i)*ITEMS.qty(i);
      if(i.s === 'crop') cropTotal += v;
      else if(i.k === 'egg' || i.k === 'milk' || i.k === 'wool' || i.k === 'honey') animalTotal += v;
      else if(i.s === 'fish') fishTotal += v;
      else otherTotal += v;
    });
    const grandTotal = cropTotal + animalTotal + fishTotal + otherTotal;
    ECONOMY.recordMany(P.shippingBin);P.gold += grandTotal;
    if(grandTotal>0)P.townWorkDay=P.day;
    P.shippingBin = [];

    $('earnings-content').innerHTML = `
      <div style="background:#020617;border:1px solid #334155;border-radius:6px;padding:8px">
        <div style="display:flex;justify-content:space-between;margin-bottom:4px">
          <span>🌾 Tarım Mahsulleri:</span><b style="color:#fde047">+${cropTotal} Altın</b>
        </div>
        <div style="display:flex;justify-content:space-between;margin-bottom:4px">
          <span>🥛 Hayvancılık (Süt, Yumurta, Yün):</span><b style="color:#67e8f9">+${animalTotal} Altın</b>
        </div>
        <div style="display:flex;justify-content:space-between;margin-bottom:4px">
          <span>🐟 Balıkçılık & Zanaat:</span><b style="color:#6ee7b7">+${fishTotal + otherTotal} Altın</b>
        </div>
        <hr style="border-color:#334155;margin:6px 0">
        <div style="display:flex;justify-content:space-between;font-size:13px;font-weight:900">
          <span style="color:#fff">TOPLAM GECE GELİRİ:</span><b style="color:#ffd23f">+${grandTotal} Altın</b>
        </div>
      </div>
    `;
    $('earnings-modal').classList.remove('h');
    playChord([523, 659, 784, 1046], .4, 'triangle', .08);
  }

  DAY_RECAP.startDay();ban('💤 Mışıl mışıl uyudun! Sabah oldu, tam can ve mana yenilendi!','#6ee7b7');
  sv();return true;
}
window.sleepInBed = sleepInBed;

function updHomeAnimals(dt){
  if(curMap!=='home')return;
  HERD.update(dt);
}


