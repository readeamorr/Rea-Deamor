/* ===== SADIK YOLDAŞ (PET) VE OTOMASYON SİSTEMİ ===== */
function petD(pet){
  if(!pet)return;
  const x=Math.round(pet.x),y=Math.round(pet.y),f=pet.f||1;
  R(x-5,y-2,10,2,'#0002');
  if(pet.type==='dragon'){
    // Yavru Ejderha (Baby Drake)
    const flap=Math.sin(P.t*22)*2.5;
    R(x-5,y-7,10,6,'#dc2626');
    R(x+f*4-2,y-10,6,5,'#b91c1c');
    R(x+f*3,y-9,2,1,'#fde047');
    R(x-f*6,y-6,3,2,'#991b1b');
    R(x-2,y-12+flap,5,4,'#ef4444');
  }else if(pet.type==='fox'){
    const wag=Math.sin(P.t*9)*1.5;R(x-6,y-7,12,6,'#c68448');R(x+f*5-2,y-11,6,6,'#e0a46c');R(x+f*4,y-15,2,5,'#b67642');R(x+f*7,y-14,2,4,'#b67642');R(x+f*7,y-9,1,1,'#1b2833');R(x-f*9,y-6+wag,6,3,'#daa46b');R(x-f*10,y-6+wag,2,3,'#fff0d3');R(x-4,y-1,2,3,'#564336');R(x+3,y-1,2,3,'#564336');
  }else{
    // Yavru Bozkurt (Wolf Pup)
    const wag=Math.sin(P.t*16)*2.5;
    R(x-5,y-6,10,5,'#e2e8f0');
    R(x+f*4-2,y-9,6,5,'#cbd5e1');
    R(x+f*5,y-7,2,2,'#475569');
    R(x+f*3,y-12,2,3,'#94a3b8');R(x+f*5,y-12,2,3,'#94a3b8');
    R(x-f*6,y-8+wag,2,4,'#e2e8f0');
    const runL=Math.sin(P.t*20)*2;
    R(x-3,y-2+runL,2,3,'#94a3b8');R(x+2,y-2-runL,2,3,'#94a3b8');
  }
  if(Math.hypot(x-P.x,y-P.y)>26)T(pet.name+' Sv'+pet.lvl,x,y-15,'#ffd23f'); // Oyuncunun yanındayken yazı kafasının üstüne binmesin
}

function sprinklerD(){
  const h=FARM.cfg(),lv=Math.max(h.sprinklerLv||0,P.hasSprinkler?1:0);
  if(curMap!=='home'||!lv)return;
  const bodyCol=lv>=3?'#38bdf8':lv===2?'#cbd5e1':'#ca8a04';
  const headCol=lv>=3?'#fde047':lv===2?'#38bdf8':'#fef08a';
  const points=[[17*TS,27.5*TS]];
  if(h.beds>=2)points.push([17*TS,31.5*TS]);
  if(h.beds>=3)points.push([21.5*TS,29.5*TS]);
  for(const [sx,sy] of points){
    R(sx-3,sy-3,6,6,'#475569');
    R(sx-2,sy-6,4,4,bodyCol);
    R(sx-1,sy-8,2,2,headCol);
  }
}

function updPet(dt){
  if(P.dead)return;
  if(!P.pet)P.pet={type:'wolf',name:'Bozkurt',lvl:1,xp:0,x:P.x-10,y:P.y,f:1,biteCd:0};
  const pet=P.pet;
  pet.biteCd=(pet.biteCd||0)-dt;pet.harvestCd=Math.max(0,(pet.harvestCd||0)-dt);
  if(Math.hypot(pet.x-P.x,pet.y-P.y)>220){pet.x=P.x-10;pet.y=P.y}

  // 1. Otomatik Ganimet Arama ve Koşma (Auto-Loot)
  let targetLoot=null,minD=145;
  for(const l of loot){
    const d=Math.hypot(l.x-pet.x,l.y-pet.y);
    if(d<minD){minD=d;targetLoot=l}
  }

  if(targetLoot){
    const dx=targetLoot.x-pet.x,dy=targetLoot.y-pet.y,d=Math.hypot(dx,dy)||1;
    const sp=145+(pet.lvl||1)*7;
    pet.x+=dx/d*sp*dt;pet.y+=dy/d*sp*dt;
    pet.f=dx>0?1:-1;

    if(d<10){
      // Ganimeti oyuncu adına topla!
      const l=targetLoot;
      if(l.t==='g'){P.gold+=l.v;fl(pet.x,pet.y-16,'+'+l.v+'🪙','#ffd23f');sfx(900,.06,'square',.03)}
      else if(l.t==='gem'){P.gems+=l.v;fl(pet.x,pet.y-16,'+'+l.v+'💎','#38bdf8');sfx(1050,.08,'sine',.04)}
      else if(l.t==='p'){P.pots++;fl(pet.x,pet.y-16,'+🧪','#6dff9c');sfx(750,.07,'sine',.03)}
      else if(ITEMS.add(P.inv,l.v)){
        fl(pet.x,pet.y-16,l.v.n,(RAR[l.v.r]||RAR[0])[1]);
        sfx(600,.15,'square',.05);
      }else{P.pendingRewards.push(l.v);fl(P.x,P.y-26,'🎒 Yoldaş eşyayı korudu · çantadan teslim al.','#d8e8c5')}

      const idx=loot.indexOf(l);
      if(idx!==-1)loot.splice(idx,1);

      spark(pet.x,pet.y-4,8,'#ffd23f',35);
      sfx(880,.07,'sine',.03);

      addPetXp(5);
      sv();
    }
  }else{
    // 2. Çiftlik Yardımcısı: Seviye 3+ Pet Olgun Ekinleri Otomatik Hasat Eder!
    if(pet.lvl>=3 && curMap==='home' && farmPlots){
      const ripePlot = farmPlots.find(p=>FARM.ripe(p));
      if(ripePlot){
        const px = ripePlot.x, py = ripePlot.y;
        const dCrop = Math.hypot(px-pet.x, py-pet.y);
        if(dCrop > 10){
          pet.x += (px-pet.x)/dCrop * 140 * dt;
          pet.y += (py-pet.y)/dCrop * 140 * dt;
          pet.f = px > pet.x ? 1 : -1;
          return;
        }else{
          if(pet.harvestCd>0)return;pet.harvestCd=1.5;
          if(FARM.harvest(ripePlot)){
            fl(ripePlot.x,ripePlot.y-34,'🐾 Yoldaş Hasat Etti!','#6ee7b7',true);
            addPetXp(8);sv(); // Çiftçilik XP’si zaten FARM.harvest içinde bir kez verildi.
          }
          return;
        }
      }
    }

    // Oyuncuyu Takip Etme
    const dx=P.x-pet.x,dy=P.y-pet.y,d=Math.hypot(dx,dy);
    if(d>32){
      const sp=120+(pet.lvl||1)*5;
      pet.x+=dx/d*sp*dt;pet.y+=dy/d*sp*dt;
      pet.f=dx>0?1:-1;
    }

    // Savaşta Isırık / Yardım Hasarı
    if(pet.biteCd<=0){
      for(const e of mobs){
        if(!e.dead&&Math.hypot(e.x-pet.x,e.y-pet.y)<50&&BOND.lineClear(pet,e)){
          pet.biteCd=2.4;
          const dmg=Math.round(S.a*0.35+pet.lvl*2);
          hitMob(e,dmg,false,pet.f*35,0);
          fl(e.x,e.y-16,`🐾 -${dmg}`,'#fbbf24');
          spark(e.x,e.y-6,6,'#fbbf24',35);
          sfx(440,.06,'triangle',.03);
          break;
        }
      }
    }
  }
}

function petUI(){
  const pet=P.pet||{type:'wolf',name:'Bozkurt',lvl:1,xp:0};
  const icon=pet.type==='dragon'?'🐉':pet.type==='fox'?'🦊':'🐺';
  const reqXp=pet.lvl*25;
  $('pet-info-card').innerHTML=`
    <div style="font-size:36px;margin:6px 0">${icon}</div>
    <div style="font-size:14px;font-weight:900;color:var(--gd)">${escapeHTML(pet.name)} <span style="font-size:11px;color:#a7f3d0">(Sv.${pet.lvl})</span></div>
    <div style="width:140px;height:6px;background:#000a;border-radius:3px;margin:6px auto;overflow:hidden">
      <div style="width:${(pet.xp/reqXp)*100}%;height:100%;background:#ffd23f"></div>
    </div>
    <div style="font-size:9.5px;color:#94a3b8;margin-bottom:8px">Tecrübe: ${pet.xp} / ${reqXp}</div>

    <div style="text-align:left;font-size:10.5px;background:#0d1633;padding:8px;border-radius:6px;margin:6px 0">
      <b style="color:#38bdf8">🐾 Yoldaş Yetenekleri:</b><br>
      • <b>🧲 Otomatik Ganimet:</b> Yerdeki altın, elmas ve eşyaları anında senin yerine toplar.<br>
      • <b>⚔️ Sadık Isırık:</b> Düşmanlara her 2.5 saniyede yardım hasarı vurur.<br>
      • <b>⚡ Seviye Bonusu:</b> Her seviyede koşu hızı ve ısırık hasarı artar.<br>
      • <b>🌾 Sv.3:</b> Yer varsa olgun ekinleri toplar; aynı hasat XP’si iki kez verilmez.
    </div>

    <b style="font-size:11px;color:var(--gd)">Yoldaş Türünü Değiştir:</b>
    <div style="display:flex;gap:6px;margin:6px 0">
      <button data-ptype="wolf" style="flex:1;background:${pet.type==='wolf'?'#1e3a8a':'#243258'}">🐺 Yavru Bozkurt</button>
      <button data-ptype="dragon" style="flex:1;background:${pet.type==='dragon'?'#7f1d1d':'#243258'}">🐉 Yavru Ejderha</button>
    </div><button id="pet-bonds" style="width:100%;padding:8px">🐾 Evcilleştirme & Binekler (${P.adventure.roster.length}/6)</button>
  `;
  $('pet-bonds').onclick=()=>{$('pet-modal').classList.add('h');ADVENTURE.open('bond')};
}

$('pet-info-card').onclick=e=>{
  const t=e.target.dataset.ptype;
  if(['wolf','dragon'].includes(t)&&P.pet){
    BOND.legacy(t);
    $('bpt').textContent=t==='dragon'?'🐉':'🐺';
    fl(P.x,P.y-26,`Yoldaş: ${P.pet.name}!`, '#ffd23f', true);
    playChord([523,659,784],.2,'sine',.05);
    sv();petUI();
  }
};


