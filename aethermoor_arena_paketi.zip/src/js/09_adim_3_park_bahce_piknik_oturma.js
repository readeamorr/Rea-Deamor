/* ===== ADIM 3: PARK / BAHÇE / PİKNİK / OTURMA ===== */
const TOWN_PARK=window.TOWN_PARK={
  cvM:null,cvP:null,goldSnap:0,
  build(){
    const tl=WORLD_DATA.home.tl,N=WORLD_DATA.home.N;
    /* mozaik */
    let c=document.createElement('canvas');c.width=96;c.height=144;let m=c.getContext('2d');
    const PAL=['#c8553d','#e9b44c','#2a7f8e','#f3e6c4','#2f4f8f','#6a9a4a'];
    for(let j=0;j<36;j++)for(let i=0;i<24;i++){
      const cx=i*4+2-48,cy=j*4+2-72,edge=Math.min(i,j,23-i,35-j),r=Math.hypot(cx,cy*.85),a=Math.atan2(cy,cx)+Math.PI;
      let col;
      if(edge<2)col=(i+j)%2?'#2a7f8e':'#f3e6c4';
      else if(edge===2)col='#c8553d';
      else if(r<10)col=Math.floor(a/(Math.PI/4))%2?'#e9b44c':'#c8553d';
      else col=PAL[(Math.floor(r/9)+(Math.floor(a/(Math.PI/6))&1))%PAL.length];
      m.fillStyle='#a99c74';m.fillRect(i*4,j*4,4,4);m.fillStyle=col;m.fillRect(i*4,j*4,3,3);
      if(H(i+5,j+9)<.1){m.fillStyle='#ffffff30';m.fillRect(i*4,j*4,3,3)}
    }
    this.cvM=c;
    /* park: çiçek + battaniye (512,128) */
    c=document.createElement('canvas');c.width=176;c.height=192;m=c.getContext('2d');
    const FL=['#f472b6','#fde047','#fb923c','#c084fc','#ffffff','#f87171'];
    for(let y=8;y<=19;y++)for(let x=32;x<=42;x++){
      if(tl[y*N+x]!==0)continue;
      const h=H(x*7+3,y*13+5);
      if(h<.3)for(let k=0;k<3;k++){m.fillStyle=FL[Math.floor(H(x*5+k,y*3+k*7)*FL.length)];m.fillRect((x-32)*16+2+Math.floor(H(x+k,y*2)*11),(y-8)*16+3+Math.floor(H(x*2,y+k)*10),2,2)}
    }
    [[552,282],[648,282]].forEach(([bx,by])=>{
      const ox=bx-512-16,oy=by-128-11;
      m.fillStyle='#00000030';m.fillRect(ox+1,oy+2,32,22);
      for(let j=0;j<5;j++)for(let i=0;i<8;i++){m.fillStyle=(i+j)%2?'#f3e6c4':'#c8453d';m.fillRect(ox+i*4,oy+j*4,4,4)}
      m.fillStyle='#8f2f2a';m.fillRect(ox,oy,32,1);m.fillRect(ox,oy+19,32,1);
    });
    this.cvP=c;
  },
  ground(){
    if(!this.cvM)this.build();
    g.drawImage(this.cvM,384,160);g.drawImage(this.cvP,512,128);
    const t=P.t;
    /* ördekler */
    for(let k=0;k<2;k++){
      const x=Math.round(600+Math.cos(t*.4+k*3)*26),y=Math.round(200+Math.sin(t*.53+k*2)*9),d=Math.sin(t*.4+k*3)>0?-1:1;
      R(x-3,y-2,6,4,'#f5f5f4');R(x+(d>0?2:-4),y-4,3,3,'#15803d');R(x+(d>0?5:-6),y-3,2,1,'#f59e0b');R(x-3,y+2,6,1,'#ffffff55');
    }
    /* kelebekler */
    const bc=['#f9a8d4','#fde047','#93c5fd','#fdba74','#c4b5fd','#fca5a5'];
    for(let i=0;i<6;i++){
      const mz=i<3,cx=mz?432:600,cy=mz?232:240,rx=mz?40:62,ry=mz?58:44;
      const x=Math.round(cx+Math.cos(t*.5+i*2.1)*rx),y=Math.round(cy+Math.sin(t*.7+i*1.3)*ry-6+Math.sin(t*3+i)*2),f=Math.sin(t*14+i)>0;
      R(x-2,y,f?2:1,2,bc[i]);R(x+1,y,f?2:1,2,bc[i]);R(x,y,1,2,'#3f3f46');
    }
    if(Math.hypot(P.x-432,P.y-232)<120)T('MOZAİK BAHÇE',432,152,'#ffd23f');
    if(Math.hypot(P.x-600,P.y-200)<130)T('KASABA PARKI',600,128,'#ffd23f');
  },
  drawObj(o){
    const x=Math.round(o.x),y=Math.round(o.y);
    switch(o.k){
      case 'pk_hedge':R(x-6,y-1,12,2,'#0003');R(x-6,y-9,12,9,'#2d6a35');R(x-6,y-9,12,2,'#4f9a4b');R(x-6,y-3,12,1,'#245a2c');
        if(o.v<.5){R(x-3,y-7,2,2,o.v<.17?'#f472b6':o.v<.34?'#fde047':'#ffffff');R(x+2,y-5,2,2,'#fb923c')}break;
      case 'pk_bench':R(x-8,y,16,2,'#0003');R(x-7,y-3,2,4,'#3b2a1a');R(x+5,y-3,2,4,'#3b2a1a');
        R(x-8,y-5,16,3,'#8a5a2b');R(x-8,y-10,16,3,'#6e4520');R(x-8,y-10,16,1,'#a3703a');break;
      case 'pk_sundial':R(x-6,y,12,2,'#0003');R(x-5,y-4,10,5,'#a8a29e');R(x-3,y-12,6,9,'#d6d3d1');R(x-1,y-16,2,5,'#78716c');R(x,y-16,5,1,'#fde047');break;
      case 'pk_table':R(x-8,y,16,2,'#0003');R(x-14,y-5,5,7,'#8a5a2b');R(x+9,y-5,5,7,'#8a5a2b');R(x-14,y-9,5,4,'#6e4520');R(x+9,y-9,5,4,'#6e4520');
        R(x-1,y-4,2,5,'#5b3a1a');R(x-7,y-9,14,5,'#f3e6c4');R(x-7,y-9,14,1,'#c8553d');R(x-3,y-12,3,3,'#fff');R(x+2,y-11,4,2,'#d97706');break;
      case 'pk_picnic':R(x-5,y-1,10,2,'#0003');R(x-5,y-7,10,7,'#b8864b');R(x-5,y-7,10,2,'#d6a35f');R(x-3,y-10,2,3,'#f87171');R(x+1,y-10,2,3,'#fde047');break;
    }
  },
  sit(x,y,f,kind,ex,ey){
    P.sit={x,y,f,kind,e:0,ex:ex??x,ey:ey??y};P.x=x;P.y=y;P.f=f;
    fl(P.x,P.y-26,kind==='bench'?'🪑 Dinleniyorsun… (hareket edince kalkarsın)':'😌','#bde8d8');
  },
  sitTick(dt,m){
    const s=P.sit;if(!s)return false;
    if(curMap!=='home'||P.dead||m>.3){P.x=s.ex;P.y=s.ey;P.sit=null;return false}
    P.x=s.x;P.y=s.y;P.f=s.f;
    const k=dt*(s.kind==='bench'?.025:.03);
    P.hp=Math.min(S.h,P.hp+S.h*k);P.mp=Math.min(S.m,P.mp+S.m*k*1.4);
    s.e-=dt;if(s.e<=0){s.e=2.4;fl(P.x,P.y-24,s.kind==='table'?'🍽️':s.kind==='picnic'?'🧺':'💤','#bde8d8')}
    return true;
  },
  spot(){
    if(curMap!=='home'||P.sit)return null;
    for(const o of objs){
      if(!o.k||o.k.slice(0,3)!=='pk_'||Math.hypot(P.x-o.x,P.y-o.y)>22)continue;
      if(o.k==='pk_bench')return{text:'🪑 Bankta otur (dinlen)',fn:()=>this.sit(o.x,o.y+1,0,'bench',o.x,o.y+11)};
      if(o.k==='pk_table')return{text:'🍽️ Masaya otur & yemek ye',fn:()=>this.eatAt(o)};
      if(o.k==='pk_picnic')return{text:'🧺 Piknik yap',fn:()=>this.picnic(o)};
    }
    return null;
  },
  eatAt(o){
    this.sit(o.x-13,o.y+3,3,'table');
    if(TOWN_LIFE.isOpen('cafe')){this.goldSnap=P.gold;$('cafe-modal').classList.remove('h');cafeUI()}
    else TOWN_LIFE.closedNotice('cafe','Melis');
  },
  picnic(o){
    if(P.picnicDay!==P.day){P.picnicDay=P.day;P.picnicN=0}
    if(P.picnicN>=2){fl(P.x,P.y-26,'Bugün yeterince piknik yaptın 🧺','#fde68a');return}
    const menu=[['apple','🍎'],['peach','🍑'],['berry','🍓'],['carrot','🥕'],['egg','🥚'],['milk','🥛'],['honey','🍯'],['jam','🫙'],['flour','🍞'],['wheat','🌾']];
    const have=menu.filter(([k])=>countInv(k)>0).slice(0,3);
    if(!have.length){fl(P.x,P.y-26,'🧺 Sepetin boş: meyve, süt, yumurta ya da ekmek getir','#fca5a5',true);return}
    const needs={};have.forEach(([k])=>needs[k]=1);
    if(!tryInventoryRecipe(needs,[]))return;
    const n=have.length;P.picnicN++;
    this.sit(o.x,o.y+8,0,'picnic');
    P.hp=Math.min(S.h,P.hp+S.h*.2*n);P.buffs.spd=Math.max(P.buffs.spd||0,90*n);S=st();addXp(6*n);
    fl(P.x,P.y-32,'🧺 Piknik! '+have.map(h=>h[1]).join(' '),'#fde68a',true);sfx(660,.2,'sine',.04);
  }
};
setTimeout(()=>{const cc=$('cafe-content');if(cc)cc.addEventListener('click',()=>setTimeout(()=>{
  if(P.sit&&P.sit.kind==='table'&&P.gold<TOWN_PARK.goldSnap){P.hp=Math.min(S.h,P.hp+S.h*.15);fl(P.x,P.y-30,'😋 Terasta yemek keyfi!','#fde68a',true)}
  TOWN_PARK.goldSnap=P.gold},0))},0);

