/* ===== SAVAŞ MEKANİKLERİ ===== */
let shk=0,tod=1/12,camX=0,camY=0,sc=2,LW=200,LH=300;
// Bir takvim günü, tek bir görsel gündür. Geç gece keşfi serbest; yeni gün yalnız uykuyla başlar.
const DAY_CLOCK=window.DAY_CLOCK={
  START:1/12,END:3/4,RATE:1/240,notifiedDay:-1,
  normalize(value){return Number.isFinite(value)&&value>=0&&value<=1?Math.min(this.END,value):this.START},
  restore(saved,legacyWeather){
    const value=saved?.v===1&&Number.isFinite(saved.phase)?saved.phase:legacyWeather?.tod;
    tod=this.normalize(value);this.notifiedDay=-1;
  },
  snapshot(){return {v:1,phase:this.normalize(tod)}},
  late(){return tod>=this.END-1e-9},
  night(){return tod>=.5},
  label(){
    if(this.late())return 'Gece';
    const minutes=Math.floor((6+this.normalize(tod)*24)*60+1e-6);
    return String(Math.floor(minutes/60)%24).padStart(2,'0')+':'+String(minutes%60).padStart(2,'0');
  },
  detail(){return this.late()?'Geç gece · Keşfe devam edebilirsin. Yeni gün için evde uyu.':'Saat '+this.label()+' · Takvim ve günlük haklar yalnız uyuyunca ilerler.'},
  tick(dt){
    if(!Number.isFinite(dt)||dt<=0)return;
    tod=Math.min(this.END,this.normalize(tod)+dt*this.RATE);
    if(this.late()&&this.notifiedDay!==P.day){this.notifiedDay=P.day;chat('REHBER','','Geç gece. Yeni gün uyuyunca başlar; dilersen keşfe devam et.',1)}
  },
  reset(){tod=this.START;this.notifiedDay=-1}
};

function addXp(n){
  if(!Number.isFinite(n)||n<0)return;
  const before=P.lvl;P.xp+=n;
  while(P.lvl<10000&&P.xp>=xpn()){P.xp-=xpn();P.lvl++;if(P.lvl%3===0)GAME_CORE.queueTalent(P.lvl)}
  if(P.lvl>=10000)P.xp=Math.min(P.xp,xpn()-1);
  if(P.lvl>before){
    S=st();P.hp=S.h;P.mp=S.m;spark(P.x,P.y-10,50,'#ffd23f',110);
    ban('SEVİYE ATLANDI: '+P.lvl+'!','#ffd23f');playChord([523,659,784,1046],.3,'triangle',.05);checkAch('lvl10');
  }
  GAME_CORE.offerTalent();sv();
}

function near(r){
  let b=null,bd=r;
  for(const e of mobs){
    if(e.dead)continue;
    const d=Math.hypot(e.x-P.x,e.y-P.y)-e.d.r*.5;
    if(d<bd){bd=d;b=e}
  }
  return b;
}

function selectTool(toolName){
  if(!['sword','hoe','can','pickaxe','rod','food','seed'].includes(toolName))return;
  if(toolName==='rod'&&!FEATURES.use('fishing'))return;
  In.cancelAttack();
  if(curMap==='home'&&(FARM.nearCampus()||FARM.nearOrchard())){
    if(toolName==='hoe'){
      const ripe=(WORLD_DATA.home?.farmPlots||[]).some(p=>FARM.ripe(p));
      if(ripe){FARM.harvestAll();return}
    }else if(toolName==='can'){
      const dry=(WORLD_DATA.home?.farmPlots||[]).some(p=>p.crop&&!p.dead&&!p.watered);
      if(dry){FARM.waterAll();return}
    }
  }
  if(toolName==='seed'&&P.activeTool==='seed'){FARM.cycleSeed();return}
  P.activeTool = toolName;
  const tools = {
    sword: { name: 'KILIC', col: '#ff8a8a' },
    hoe: { name: 'BAHCE CAPASI', col: '#ca8a04' },
    can: { name: 'SULAMA KABI', col: '#38bdf8' },
    pickaxe: { name: 'KAZMA', col: '#fb923c' },
    rod: { name: 'OLTA', col: '#38bdf8' },
    food: { name: 'ERZAK', col: '#6ee7b7' },
    seed: { name: 'TOHUM KESESI', col: '#a3e635' }
  };
  const t = tools[toolName] || tools.sword;
  fl(P.x, P.y - 24, `[${t.name}]`, t.col, true);
  sfx(600, .06, 'triangle', .03);
  updHotbarUI();
  if(toolName==='seed')FARM.announceSeed();
}

function updHotbarUI(){
  const tool = P.activeTool || 'sword';
  document.querySelectorAll('.hb-slot').forEach(sl => {
    const active=sl.dataset.tool===tool;sl.classList.toggle('act',active);sl.setAttribute('aria-pressed',String(active));
  });
  const wLbl = $('hb-water-lbl');
  if(wLbl) wLbl.textContent = `${P.waterCan || 0}/20`;
  const sLbl = $('hb-seed-lbl');
  if(sLbl){const sk=FARM.curSeed();sLbl.textContent=sk?(CROPS[sk].icon+(P.seeds[sk]||0)):'-'}
  const bA = $('bA');
  const svgs = {
    sword: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#f87171" stroke-width="2.2" stroke-linecap="round"><path d="M14.5 17.5L3 6V3h3l11.5 11.5"/><path d="M13 19l2 2"/><path d="M19 13l2 2"/><path d="M15 15l4 4"/></svg>',
    hoe: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#facc15" stroke-width="2.2" stroke-linecap="round"><path d="M4 19L16 7"/><path d="M13 4h7v4"/></svg>',
    can: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.2" stroke-linecap="round"><path d="M12 2.7l5.7 5.7a8 8 0 1 1-11.4 0z"/></svg>',
    pickaxe: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fb923c" stroke-width="2.2" stroke-linecap="round"><path d="M4 20l10-10"/><path d="M14 4l6 6"/><path d="M15 3a9 9 0 0 1 6 6"/></svg>',
    rod: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2.2" stroke-linecap="round"><path d="M3 21l16-16"/><path d="M19 5v8a4 4 0 0 1-4 4"/></svg>',
    food: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#4ade80" stroke-width="2.2" stroke-linecap="round"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/></svg>'
  };
  svgs.seed = '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#a3e635" stroke-width="2.2" stroke-linecap="round"><path d="M12 21v-9"/><path d="M12 12c0-4 3-6 7-6 0 4-3 6-7 6z"/><path d="M12 14c0-3-2-5-6-5 0 3 2 5 6 5z"/></svg>';
  const cIc=tool==='sword'?{mage:'🔮',ranger:'🏹'}[P.cls||'warrior']:null;
  const iconKey=tool+'|'+P.cls;
  if(bA&&bA.dataset.iconKey!==iconKey){bA.dataset.iconKey=iconKey;bA.innerHTML=cIc?'<span style="font-size:22px">'+cIc+'</span>':(svgs[tool]||svgs.sword)}
}

