/* ===== AETHERMOOR VFX · HAVUZLU GÖRSEL MOTOR ===== */
const FX=window.VFX=(()=>{
  const TAU=Math.PI*2,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const motionQuery=window.matchMedia('(prefers-reduced-motion: reduce)');
  const options={quality:'auto',lighting:true,shadows:true,particles:true,atmosphere:true,glow:true,torch:true,hitStop:true,smoothCamera:true,reducedMotion:motionQuery.matches,showStats:false,bloom:true,resolution:'auto'};
  const tiers=[
    {name:'Hafif',particles:128,ambient:14,weather:32,lights:10,rays:1,mask:.5,segments:5},
    {name:'Dengeli',particles:320,ambient:30,weather:64,lights:18,rays:2,mask:.75,segments:7},
    {name:'Yüksek',particles:640,ambient:52,weather:104,lights:30,rays:3,mask:1,segments:10}
  ];
  let tier=1,seed=0x71b43a29,time=0,stop=0,paused=true,manualMotion=false;
  function random(){seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return (seed>>>0)/4294967296}
  const rand=(lo,hi)=>lo+(hi-lo)*random();
  class Pool{
    constructor(cap,make){this.cap=cap;this.items=Array.from({length:cap},make);this.order=new Uint16Array(cap);this.free=new Uint16Array(cap);this.n=0;this.available=cap;this.dropped=0;for(let i=0;i<cap;i++)this.free[i]=cap-1-i}
    acquire(limit=this.cap){if(this.n>=Math.min(limit,this.cap)||!this.available){this.dropped++;return null}const id=this.free[--this.available];this.order[this.n++]=id;return this.items[id]}
    release(i){const id=this.order[i];this.order[i]=this.order[--this.n];this.free[this.available++]=id}
    clear(){while(this.n)this.release(this.n-1)}
  }
  const particles=new Pool(768,()=>({x:0,y:0,px:0,py:0,vx:0,vy:0,t:0,max:1,c:'#fff',s:1,grav:60,kind:0}));
  const slashes=new Pool(18,()=>({x:0,y:0,a:0,r:0,t:0,max:1,span:2.4,color:0,heavy:false}));
  const bursts=new Pool(24,()=>({x:0,y:0,r:0,t:0,max:1,color:0,ring:true}));
  const textRoot=$('fl');
  const texts=new Pool(32,()=>{
    const el=document.createElement('div');el.className='f';el.style.display='none';textRoot.appendChild(el);
    return {el,x:0,y:0,t:0,max:1,vx:0,vy:0,big:false};
  });
  const atmosphere=Array.from({length:64},()=>({x:0,y:0,s:0,p:0}));
  const drops=Array.from({length:112},()=>({x:0,y:0,s:0,p:0}));
  const lights=Array.from({length:32},()=>({x:0,y:0,r:0,color:0,power:0}));
  const sources=Array.from({length:384},()=>({ref:null,family:0,r:0,color:0,ox:0,oy:0}));
  let sourceN=0,lightN=0,sourceMap=null,sourceObjects=null,sourceResources=null,sourceHouses=null,sourceSizes='';
  const env={outside:true,forest:false,snow:false,rain:false,marsh:false,desert:false,volcano:false,night:0,ambient:0,precip:'clear'};
  let ambientMode='',precipMode='',ambientN=0,dropN=0,emitterClock=0;
  const palette=['#ffc777','#68ceff','#c293ff','#80ffc3','#ff704e','#f8dc82'];
  const canvas=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c};
  const mask=canvas(1,1),mc=mask.getContext('2d');let maskScale=1;
  const radial=canvas(96,96),rc=radial.getContext('2d');
  {const gradient=rc.createRadialGradient(48,48,0,48,48,48);gradient.addColorStop(0,'#fff');gradient.addColorStop(.15,'#fffffff5');gradient.addColorStop(.5,'#ffffffa6');gradient.addColorStop(.82,'#ffffff33');gradient.addColorStop(1,'#fff0');rc.fillStyle=gradient;rc.fillRect(0,0,96,96)}
  // shadowBlur sadece küçük, tekrar kullanılan atlaslarda çalışır; ana tuvalde her kare yeniden bulanıklaştırılmaz.
  const glowStamps=palette.map(color=>{
    const c=canvas(64,64),q=c.getContext('2d'),gradient=q.createRadialGradient(32,32,1,32,32,28);
    gradient.addColorStop(0,'#ffffffde');gradient.addColorStop(.13,color+'b8');gradient.addColorStop(.48,color+'40');gradient.addColorStop(1,color+'00');
    q.shadowColor=color;q.shadowBlur=10;q.fillStyle=gradient;q.beginPath();q.arc(32,32,25,0,TAU);q.fill();q.shadowBlur=0;return c;
  });
  const shadowStamp=canvas(64,32),shc=shadowStamp.getContext('2d');
  {shc.scale(1,.5);const gradient=shc.createRadialGradient(32,32,0,32,32,32);gradient.addColorStop(0,'#050b16b8');gradient.addColorStop(.4,'#050b1670');gradient.addColorStop(1,'#050b1600');shc.fillStyle=gradient;shc.fillRect(0,0,64,64)}
  const rayStamp=canvas(128,192),rayCtx=rayStamp.getContext('2d');
  {const grad=rayCtx.createLinearGradient(0,0,0,192);grad.addColorStop(0,'#dff5ff9c');grad.addColorStop(.3,'#b7e1ee48');grad.addColorStop(1,'#b7e1ee00');rayCtx.fillStyle=grad;rayCtx.beginPath();rayCtx.moveTo(52,0);rayCtx.lineTo(70,0);rayCtx.lineTo(128,192);rayCtx.lineTo(0,192);rayCtx.closePath();rayCtx.fill()}
  const hurtStamp=canvas(96,96),hurtCtx=hurtStamp.getContext('2d');
  {const grad=hurtCtx.createRadialGradient(48,48,15,48,48,67);grad.addColorStop(0,'#ef444400');grad.addColorStop(.7,'#b91c1c25');grad.addColorStop(1,'#ef4444a6');hurtCtx.fillStyle=grad;hurtCtx.fillRect(0,0,96,96)}
  const camera={ready:false,map:'',x:0,y:0,vx:0,vy:0,prevX:0,prevY:0,viewX:0,viewY:0,dx:0,dy:0};
  let frameCount=0,frameCursor=0,cpuEMA=0,frameEMA=16.67,slowTime=0,fastTime=0,qualityCooldown=3,meterClock=0;
  const cpuSamples=new Float32Array(240),frameSamples=new Float32Array(240);
  const bars={};
  for(const id of ['hp','mp','xp','rg']){
    const el=$(id),ghost=document.createElement('em');ghost.className='bar-ghost';el.before(ghost);
    el.parentElement.setAttribute('role','progressbar');el.parentElement.setAttribute('aria-label',({hp:'Can',mp:'Mana',xp:'Deneyim',rg:'Öfke'})[id]);
    el.parentElement.setAttribute('aria-valuemin','0');el.parentElement.setAttribute('aria-valuemax','100');
    bars[id]={el,ghost,value:id==='hp'||id==='mp'?1:0,target:0,lag:1,delay:0,level:0,wrap:0,initialized:false};
  }
  const visible=(x,y,pad=48)=>x>=camX-pad&&x<=camX+LW+pad&&y>=camY-pad&&y<=camY+LH+pad;
  const colorIndex=c=>typeof c==='number'?clamp(c|0,0,5):/7dd3|38bdf8|a5f3|68ce|e0f2|60a5|bfe8/i.test(c)?1:/c084|818c|e879|c293|a855/i.test(c)?2:/6ee7|6dff|4ade|80ff/i.test(c)?3:/ef444|ff4|f973|fb923|ff70/i.test(c)?4:0;
  function resize(geometry=true){
    document.documentElement.dataset.vfxQuality=['low','balanced','high'][tier];
    maskScale=tiers[tier].mask;const w=Math.max(1,Math.ceil(LW*maskScale)),h=Math.max(1,Math.ceil(LH*maskScale));
    if(mask.width!==w||mask.height!==h){mask.width=w;mask.height=h}
    if(geometry){camera.ready=false;ambientMode='';precipMode=''}
  }
  function setTier(next){
    next=clamp(next|0,0,2);if(next===tier)return;
    tier=next;while(particles.n>tiers[tier].particles)particles.release(particles.n-1);
    resize(false);qualityCooldown=5;slowTime=fastTime=0;
    if(options.resolution==='auto'&&window.__gfxReady)rs();
  }
  function setOption(k,v){
    if(!Object.prototype.hasOwnProperty.call(options,k))return false;
    if(k==='quality'){
      if(!['auto','low','balanced','high'].includes(v))return false;
      options.quality=v;setTier(v==='auto'?1:['low','balanced','high'].indexOf(v));
    }else if(k==='resolution'){
      if(!['auto','native','balanced','classic'].includes(v))return false;
      options.resolution=v;if(window.__gfxReady)rs();
    }else{
      if(typeof v!=='boolean')return false;options[k]=v;
      if(k==='reducedMotion')manualMotion=true;
      if(k==='particles'&&!v){particles.clear();slashes.clear()}
      if((k==='hitStop'&&!v)||(k==='reducedMotion'&&v))stop=0;
      if(k==='smoothCamera')camera.ready=false;
    }
    document.documentElement.classList.toggle('reduce-motion',options.reducedMotion);
    $('vfx-meter').classList.toggle('h',!options.showStats);return true;
  }
  function load(saved){
    if(saved&&typeof saved==='object')for(const k of Object.keys(options))if(Object.prototype.hasOwnProperty.call(saved,k))setOption(k,saved[k]);
    document.documentElement.classList.toggle('reduce-motion',options.reducedMotion);
  }
  motionQuery.addEventListener?.('change',e=>{if(!manualMotion){options.reducedMotion=e.matches;stop=0;document.documentElement.classList.toggle('reduce-motion',e.matches)}});
  function emit(x,y,vx,vy,life,c,s=2,gravity=60,kind=0){
    if(!options.particles||!Number.isFinite(x)||!Number.isFinite(y)||!Number.isFinite(life)||!Number.isFinite(vx)||!Number.isFinite(vy)||!visible(x,y,180))return;
    const p=particles.acquire(tiers[tier].particles);if(!p)return;
    p.x=p.px=x;p.y=p.py=y;p.vx=vx;p.vy=vy;p.t=p.max=Math.max(.02,life);p.c=c;p.s=s;p.grav=gravity;p.kind=kind;
  }
  function sparks(x,y,n,c,speed=70,streak=false){
    const amount=Math.ceil(n*(tier===0?.55:tier===1?.8:1));
    for(let i=0;i<amount;i++){const a=rand(0,TAU),v=rand(.3,1)*speed;emit(x,y,Math.cos(a)*v,Math.sin(a)*v-15,rand(.2,.55),c,streak?1.4:1.8,75,streak?1:0)}
  }
  function flash(x,y,r,color=0,life=.24,ring=true){
    const b=bursts.acquire(18);if(!b)return;b.x=x;b.y=y;b.r=r;b.color=colorIndex(color);b.t=b.max=life;b.ring=ring;
  }
  function impact(x,y,color,critical){
    sparks(x,y,critical?20:7,color,critical?140:70,true);
    if(critical){flash(x,y,42,color,.22);hitStop(5)}
  }
  function slash(x,y,angle,r=32,color=1,heavy=false,span=2.5){
    if(!options.particles)return;const s=slashes.acquire(tier===0?6:14);if(!s)return;
    s.x=x;s.y=y;s.a=angle;s.r=r;s.color=colorIndex(color);s.heavy=heavy;s.span=span;s.t=s.max=heavy?.25:.19;
  }
  function text(x,y,value,color='#fff',big=false,extra=''){
    const p=texts.acquire();if(!p)return;p.x=x+rand(-5,5);p.y=y;p.vx=rand(-5,5);p.vy=big?-22:-18;
    p.t=p.max=big?1.1:.85;p.big=big;
    p.el.className='f'+(big?' c':'')+(extra?' '+extra:'');p.el.textContent=String(value);p.el.style.color=color;
    p.el.style.display='block';p.el.style.opacity='0';
  }
  function hitStop(ms){if(Number.isFinite(ms)&&options.hitStop&&!options.reducedMotion)stop=Math.max(stop,clamp(ms,0,5)/1000)}
  function consumeHitStop(dt){const used=Math.min(dt,stop);stop=Math.max(0,stop-used);return Math.max(0,dt-used)}
  function updateCamera(dt){
    const maxX=Math.max(0,N*TS-LW),maxY=Math.max(0,N*TS-LH),tx=clamp(P.x-LW/2,0,maxX),ty=clamp(P.y-LH/2-8,0,maxY);
    const oldX=camX,oldY=camY,teleport=Math.hypot(P.x-camera.prevX,P.y-camera.prevY)>110;
    if(!camera.ready||camera.map!==curMap||teleport||!options.smoothCamera||options.reducedMotion){camera.x=tx;camera.y=ty;camera.vx=camera.vy=0;camera.ready=true;camera.map=curMap}
    else if(dt>0){
      const w=14,decay=Math.exp(-w*dt),dx=camera.x-tx,dy=camera.y-ty,ux=(camera.vx+w*dx)*dt,uy=(camera.vy+w*dy)*dt;
      camera.x=tx+(dx+ux)*decay;camera.y=ty+(dy+uy)*decay;camera.vx=(camera.vx-w*ux)*decay;camera.vy=(camera.vy-w*uy)*decay;
      if(Math.abs(camera.x-tx)<.015&&Math.abs(camera.vx)<.05){camera.x=tx;camera.vx=0}
      if(Math.abs(camera.y-ty)<.015&&Math.abs(camera.vy)<.05){camera.y=ty;camera.vy=0}
    }
    camX=clamp(camera.x,0,maxX);camY=clamp(camera.y,0,maxY);camera.dx=camX-oldX;camera.dy=camY-oldY;camera.prevX=P.x;camera.prevY=P.y;
    const mult=options.reducedMotion||shakeSetting==='off'?0:shakeSetting==='reduced'?.25:1;
    const amount=Math.min(7,shk)*mult;
    camera.viewX=Math.round(camX+(Math.sin(time*83)+Math.sin(time*147)*.35)*amount*.65);
    camera.viewY=Math.round(camY+(Math.sin(time*97+1)+Math.sin(time*131)*.3)*amount*.5);
  }
  function environment(){
    env.outside=curMap!=='mine'&&curMap!=='inside';env.night=clamp(.4-Math.sin(tod*TAU)*.9,0,.6);
    env.forest=curMap==='world'&&P.z===1;env.marsh=curMap==='world'&&P.biome==='marsh';env.desert=curMap==='world'&&P.z===3;env.volcano=curMap==='world'&&P.z===4;
    env.snow=env.outside&&((curMap==='world'&&P.biome==='frost')||(curMap==='frontier'&&FARM.seasonIdx()===3));
    env.rain=env.outside&&isWetWeather()&&!env.snow;
    env.precip=env.snow?'snow':env.rain?'rain':'clear';
    env.ambient=curMap==='mine'?clamp(.45+(P.mineFloor||1)*.006,.46,.76):curMap==='inside'?.17+env.night*.2:clamp(.025+env.night+(env.forest?.035:0)+(env.rain?.12:0),0,.71);
  }
  function updateAtmosphere(dt){
    environment();const cfg=tiers[tier],motion=options.reducedMotion?.35:1;
    const mode=curMap+':'+(env.forest?'forest':env.marsh?'marsh':env.volcano?'embers':env.desert?'sand':'dust');
    ambientN=options.atmosphere?Math.round(cfg.ambient*(options.reducedMotion?.5:1)):0;
    if(mode!==ambientMode){ambientMode=mode;for(const a of atmosphere){a.x=rand(0,LW);a.y=rand(0,LH);a.s=rand(.4,1.2);a.p=rand(0,TAU)}}
    if(env.precip!==precipMode){precipMode=env.precip;for(const d of drops){d.x=rand(0,LW);d.y=rand(0,LH);d.s=rand(.5,1.3);d.p=rand(0,TAU)}}
    dropN=options.atmosphere&&env.precip!=='clear'?Math.round(cfg.weather*(options.reducedMotion?.5:1)):0;
    for(let i=0;i<ambientN;i++){
      const a=atmosphere[i];a.p+=dt*.8*motion;a.x-=camera.dx*.3;a.y-=camera.dy*.3;
      a.x+=(Math.sin(a.p)*4+(env.desert?24:2))*dt*motion;a.y+=(env.volcano?-25:env.forest&&i%4===0?10:Math.cos(a.p)*2)*dt*a.s*motion;
      if(a.x<-8)a.x=LW+5;if(a.x>LW+8)a.x=-5;if(a.y<-8)a.y=LH+5;if(a.y>LH+8)a.y=-5;
    }
    for(let i=0;i<dropN;i++){
      const d=drops[i];d.x-=camera.dx*.18;d.y-=camera.dy*.18;
      d.x+=(env.snow?Math.sin(time+d.p)*7:weather.type==='storm'?-95:-65)*dt*d.s*motion;d.y+=(env.snow?18:weather.type==='storm'?310:235)*dt*d.s*motion;
      if(d.y>LH+8){d.y=-8;d.x=rand(-8,LW+24)}if(d.x<-16)d.x=LW+8;if(d.x>LW+24)d.x=-8;
    }
  }
  function source(ref,family,r,color,ox,oy){if(sourceN>=sources.length)return;const s=sources[sourceN++];s.ref=ref;s.family=family;s.r=r;s.color=color;s.ox=ox;s.oy=oy}
  function rebuildSources(){
    sourceN=0;
    for(const o of objs){
      if(o.k==='torch')source(o,0,54,1,0,-19);
      else if(o.k==='lamp')source(o,0,48,0,0,-16);
      else if(o.k==='in_fireplace')source(o,0,80,0,0,-10);
      else if(o.k==='ice_crystal'||o.k==='frontier_gate')source(o,0,32,1,0,-8);
      else if(o.k==='shroom')source(o,0,24,2,0,-16);
      else if(o.k==='obsidian_spire')source(o,0,32,4,0,-12);
    }
    for(const h of hs)source(h,1,h.type==='field_camp'?75:34,0,0,-12);
    for(const r of resources){const c=r.k==='ore_iridium'?2:r.k==='ore_ruby'?4:r.k==='ore_diamond'||r.k==='herb_mana'?1:r.k==='ore_crystal'?2:-1;if(c>=0)source(r,2,30,c,0,-7)}
    sourceMap=curMap;sourceObjects=objs;sourceResources=resources;sourceHouses=hs;sourceSizes=objs.length+':'+resources.length+':'+hs.length;
  }
  function addLight(x,y,r,color,power=1){
    if(lightN>=tiers[tier].lights||!visible(x,y,r))return;
    const l=lights[lightN++];l.x=x;l.y=y;l.r=r;l.color=color;l.power=power;
  }
  function collectLights(){
    lightN=0;if(!options.lighting)return;
    const flicker=options.reducedMotion?1:1+Math.sin(time*17)*.025+Math.sin(time*31)*.012;
    if(options.torch&&!P.dead)addLight(P.x+(P.f===2?7:-7),P.y-14,(curMap==='mine'?86:72)*flicker,0,.98);
    for(let i=0;i<bursts.n;i++){const b=bursts.items[bursts.order[i]];addLight(b.x,b.y,b.r*(1.4-b.t/b.max*.4),b.color,b.t/b.max*.95)}
    for(const p of prj)if(lightN<tiers[tier].lights-4&&p.t>0&&visible(p.x,p.y,60))addLight(p.x,p.y,p.kind==='arrow'?22:p.big?68:40,colorIndex(p.col||'#ff704e'),p.kind==='arrow'?.45:.88);
    if(sourceMap!==curMap||sourceObjects!==objs||sourceResources!==resources||sourceHouses!==hs||sourceSizes!==objs.length+':'+resources.length+':'+hs.length)rebuildSources();
    if(curMap==='home')addLight(18*TS,18*TS-8,86*flicker,0,1);
    for(let i=0;i<sourceN;i++){
      const s=sources[i],r=s.ref;if(s.family===2&&r.mined)continue;
      addLight(r.x+s.ox,r.y+s.oy,s.r*(s.color===0?flicker:1),s.color,s.family===1?.62:s.family===2?.57:.9);
    }
    for(const l of loot)if(l.t==='p'||l.t==='gem'||l.t==='i'&&l.v.r>=2)addLight(l.x,l.y+(l.z||0)-3,22,l.t==='p'?3:l.t==='gem'?1:l.v.r===3?0:2,.5);
  }
  function emitters(dt){
    if(!options.particles)return;emitterClock+=dt;if(emitterClock<.08)return;const elapsed=emitterClock;emitterClock=0;
    if(curMap==='home'&&visible(18*TS,18*TS,30))emit(18*TS+rand(-3,3),18*TS-11,rand(-6,6),-22,.6,'#ffbb64',1.2,-8,1);
    for(let i=0;i<sourceN;i++){
      const s=sources[i],r=s.ref;if(!visible(r.x,r.y,25)||s.family===2&&r.mined)continue;
      if(s.family===0&&(r.k==='torch'||r.k==='in_fireplace')&&random()<elapsed*9)emit(r.x+rand(-2,2),r.y-20,rand(-5,5),-22,.5,s.color===1?'#83deff':'#ffd18a',1,-4,1);
      if(s.family===1&&random()<elapsed*2)emit(r.x+14,r.y-42,rand(2,7),-14,1.3,'#9ba9b8',2,-4,2);
    }
    if(curMap==='home'){
      if(visible(48*TS,22*TS,35)&&random()<elapsed*12)emit(48*TS+16,22*TS,rand(5,15),rand(-3,1),.3,'#d9f6ff',1.5,15);
      if((P.hasSprinkler||FARM.cfg().sprinklerLv>=1)&&visible(17*TS,28*TS,35))for(let i=0;i<4;i++){const a=i*TAU/4+time*4.5;emit(17*TS+Math.cos(a)*12,27.5*TS+Math.sin(a)*8,Math.cos(a)*25,Math.sin(a)*15,.25,'#7dd3fc',1.5,20)}
      if(P.hasCask&&P.caskItem&&!P.caskReady&&visible(19*TS,35*TS,25)&&random()<elapsed*5)emit(19*TS+rand(-2,2),35*TS-10,0,-14,.45,'#fed7aa',1.4,0,2);
    }
  }
  function updateBars(dt){
    for(const id in bars){const b=bars[id];if(!b.initialized)continue;
      if(options.reducedMotion){b.value=b.lag=b.target;b.wrap=0}
      else{
        let goal=b.wrap>0?1:b.target;b.value+=(goal-b.value)*(1-Math.exp(-18*dt));
        if(b.wrap>0){b.wrap-=dt;if(b.wrap<=0||b.value>.995){b.wrap=0;b.value=0}}
        b.delay=Math.max(0,b.delay-dt);
        if(b.value>b.lag)b.lag=b.value;else if(!b.delay)b.lag+=(b.value-b.lag)*(1-Math.exp(-5*dt));
      }
      b.el.style.transform=`scaleX(${clamp(b.value,0,1).toFixed(4)})`;b.ghost.style.transform=`scaleX(${clamp(b.lag,0,1).toFixed(4)})`;
    }
  }
  function setBar(id,value,level=0){
    const b=bars[id];if(!b)return;value=clamp(Number(value)||0,0,1);
    if(!b.initialized){b.value=b.lag=value;b.initialized=true}
    if(value<b.target)b.delay=.16;
    if(id==='xp'&&b.level&&level>b.level&&!options.reducedMotion)b.wrap=.18;
    b.target=value;b.level=level;b.el.parentElement.setAttribute('aria-valuenow',String(Math.round(value*100)));
  }
  function step(dt,isPaused=false){
    dt=clamp(dt,0,.05);paused=isPaused;time+=dt;shk*=Math.exp(-10*dt);hf=Math.max(0,hf-dt*1.8);
    if(paused)stop=0;updateCamera(dt);updateBars(dt);
    const damping=Math.exp(-2.5*dt);
    for(let i=particles.n-1;i>=0;i--){const p=particles.items[particles.order[i]];p.t-=dt;if(p.t<=0){particles.release(i);continue}p.px=p.x;p.py=p.y;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=p.grav*dt;p.vx*=damping}
    for(let i=slashes.n-1;i>=0;i--){const s=slashes.items[slashes.order[i]];if((s.t-=dt)<=0)slashes.release(i)}
    for(let i=bursts.n-1;i>=0;i--){const b=bursts.items[bursts.order[i]];if((b.t-=dt)<=0)bursts.release(i)}
    for(let i=texts.n-1;i>=0;i--){
      const p=texts.items[texts.order[i]];p.t-=dt;if(p.t<=0){p.el.style.display='none';texts.release(i);continue}
      const age=1-p.t/p.max;if(!options.reducedMotion){p.x+=p.vx*dt;p.y+=p.vy*dt}
      const scale=options.reducedMotion?1:1+(p.big?.22:.1)*Math.exp(-age*16),x=(p.x-camera.viewX)*innerWidth/LW,y=(p.y-camera.viewY)*innerHeight/LH;
      p.el.style.transform=`translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0) translate(-50%,-50%) scale(${scale.toFixed(3)})`;
      p.el.style.opacity=String(clamp(p.t/(p.max*.32),0,1));
    }
    updateAtmosphere(paused?0:dt);if(!paused)emitters(dt);
  }
  function beginRender(){updateCamera(0);environment();g.setTransform(RS,0,0,RS,0,0);g.globalCompositeOperation='source-over';g.globalAlpha=1;g.shadowBlur=0;g.fillStyle='#101a2a';g.fillRect(0,0,LW,LH);g.setTransform(RS,0,0,RS,-Math.round(camera.viewX*RS),-Math.round(camera.viewY*RS));g.imageSmoothingEnabled=false}
  function shadow(x,y,rx=8,ry=3,alpha=.65){if(!options.shadows||!visible(x,y,rx))return;g.globalAlpha=alpha;g.drawImage(shadowStamp,x-rx,y-ry,rx*2,ry*2);g.globalAlpha=1}
  function glow(x,y,r=14,color=1,alpha=.6){
    if(!options.glow||!visible(x,y,r))return;g.save();g.globalCompositeOperation='lighter';g.globalAlpha=alpha*(options.reducedMotion?.6:1);g.imageSmoothingEnabled=true;
    g.drawImage(glowStamps[colorIndex(color)],x-r,y-r,r*2,r*2);g.restore();
  }
  function torch(){
    if(!options.torch||P.dead)return;const x=Math.round(P.x+(P.f===2?7:-7)),y=Math.round(P.y-12-(P.adventure?.mounted?7:0));
    R(x-1,y,2,9,'#7c4b29');R(x-2,y-1,4,2,'#ad854e');
    const flicker=options.reducedMotion?0:Math.sin(time*22)>.2?1:0;
    R(x-2,y-6-flicker,4,5+flicker,'#ed7d39');R(x-1,y-5,2,4,'#ffe4a5');R(x,y-7-flicker,1,3,'#fff4d4');glow(x,y-5,12,0,.42);
  }
  function paintParticles(){
    if(!options.particles)return;
    for(let pass=0;pass<2;pass++){
      g.globalCompositeOperation=pass?'lighter':'source-over';
      for(let i=0;i<particles.n;i++){
        const p=particles.items[particles.order[i]];if((p.kind===2?0:1)!==pass||!visible(p.x,p.y,8))continue;
        g.globalAlpha=clamp(p.t/p.max,0,1)*(options.reducedMotion?.65:1);g.fillStyle=g.strokeStyle=p.c;
        if(p.kind===1){g.lineWidth=Math.max(.6,p.s);g.beginPath();g.moveTo(p.x-p.vx*.025,p.y-p.vy*.025);g.lineTo(p.x,p.y);g.stroke()}
        else if(p.kind===2){const s=p.s+(1-p.t/p.max)*3;g.globalAlpha*=.38;g.fillRect(p.x-s/2,p.y-s/2,s,s)}
        else g.fillRect(Math.round(p.x),Math.round(p.y),p.s,p.s);
      }
    }
    g.globalAlpha=1;g.globalCompositeOperation='source-over';
  }
  function paintTrails(){
    if(!options.particles)return;
    g.save();g.globalCompositeOperation='lighter';g.lineCap='round';
    for(let i=0;i<slashes.n;i++){
      const s=slashes.items[slashes.order[i]],age=1-s.t/s.max,fade=Math.pow(1-age,.7)*(options.reducedMotion?.4:1),segments=tiers[tier].segments;
      g.save();g.translate(s.x,s.y);g.scale(1,.72);
      const head=s.a-s.span*.45+age*s.span;
      for(let k=0;k<segments;k++){
        const a0=head-(1-k/segments)*s.span*.6,a1=a0+s.span*.65/segments;
        g.globalAlpha=fade*(.08+.6*k/segments);g.strokeStyle=palette[s.color];g.lineWidth=(s.heavy?7:4)*(k+1)/segments;
        g.beginPath();g.arc(0,0,s.r,a0,a1);g.stroke();
      }
      g.globalAlpha=fade*.8;g.strokeStyle='#fff5db';g.lineWidth=1;g.beginPath();g.arc(0,0,s.r,head-.25,head+.04);g.stroke();g.restore();
    }
    for(let i=0;i<bursts.n;i++){
      const b=bursts.items[bursts.order[i]];if(!b.ring)continue;const age=1-b.t/b.max;
      g.globalAlpha=(1-age)*.6*(options.reducedMotion?.3:1);g.strokeStyle=palette[b.color];g.lineWidth=1.8*(1-age)+.3;
      g.beginPath();g.ellipse(b.x,b.y,b.r*(.15+age*.6),b.r*(.1+age*.4),0,0,TAU);g.stroke();
    }
    g.restore();
  }
  function paintRays(){
    if(!options.atmosphere||curMap!=='mine')return;
    const md=WORLD_DATA.mine,rooms=md?.rooms;if(!rooms?.length)return;
    let drawn=0;g.save();g.globalCompositeOperation='lighter';g.imageSmoothingEnabled=true;
    for(let i=0;i<rooms.length&&drawn<tiers[tier].rays;i++){
      const room=rooms[i],x=room.x*TS,y=(room.y-room.r+1)*TS;
      if(!visible(x,y,110))continue;
      g.globalAlpha=(options.reducedMotion?.18:.26+Math.sin(time*.6+i)*.025)*(1-(P.mineFloor||1)*.008);
      g.drawImage(rayStamp,x-28,y-25,66,115);drawn++;
    }
    g.restore();
  }
  function paintLighting(){
    collectLights();if(!options.lighting)return;
    mc.setTransform(1,0,0,1,0,0);mc.globalCompositeOperation='source-over';mc.globalAlpha=1;mc.clearRect(0,0,mask.width,mask.height);
    mc.fillStyle=curMap==='mine'?'#081629':env.outside&&weather.type==='blood_moon'?'#4b1829':curMap==='inside'?'#302536':'#182e51';
    mc.globalAlpha=env.ambient;mc.fillRect(0,0,mask.width,mask.height);mc.globalCompositeOperation='destination-out';
    for(let i=0;i<lightN;i++){
      const l=lights[i],r=l.r*maskScale;mc.globalAlpha=l.power;
      mc.drawImage(radial,(l.x-camera.viewX)*maskScale-r,(l.y-camera.viewY)*maskScale-r,r*2,r*2);
    }
    mc.globalAlpha=1;mc.globalCompositeOperation='source-over';
    g.save();g.setTransform(RS,0,0,RS,0,0);g.imageSmoothingEnabled=true;g.globalCompositeOperation='multiply';g.drawImage(mask,0,0,LW,LH);
    if(options.glow){
      g.globalCompositeOperation='screen';
      for(let i=0;i<lightN;i++){const l=lights[i],r=l.r*.7;g.globalAlpha=(.1+env.ambient*.23)*l.power*(options.reducedMotion?.65:1);g.drawImage(glowStamps[l.color],l.x-camera.viewX-r,l.y-camera.viewY-r,r*2,r*2)}
    }
    g.restore();
  }
  function paintAtmosphere(){
    if(!options.atmosphere)return;g.save();g.setTransform(RS,0,0,RS,0,0);
    if(env.outside&&weather.type==='fog'){g.fillStyle='#c4dbe519';g.fillRect(0,0,LW,LH)}
    for(let i=0;i<ambientN;i++){
      const a=atmosphere[i],pulse=.3+(Math.sin(time*.8+a.p)+1)*.22;
      g.globalAlpha=pulse*(env.night>.2?1:.55);
      if(env.forest&&i%4===0){g.fillStyle=i%8?'#dfba66':'#a1c975';g.save();g.translate(a.x,a.y);g.rotate(Math.sin(time+a.p)*.8);g.fillRect(-1.5,-.7,3,1.4);g.restore()}
      else{g.fillStyle=env.volcano?'#ffbf72':env.marsh?'#a8f6be':env.desert?'#e9cd9b':curMap==='mine'?'#b8dfed':'#f4e7ba';g.fillRect(a.x,a.y,a.s>1?1.4:.7,a.s>1?1.4:.7)}
    }
    if(dropN){
      if(env.rain){g.strokeStyle='#bfddf3';g.lineWidth=.65;g.globalAlpha=.32;g.beginPath();for(let i=0;i<dropN;i++){const d=drops[i];g.moveTo(d.x,d.y);g.lineTo(d.x-2*d.s,d.y+6*d.s)}g.stroke()}
      else{g.fillStyle='#f0faff';for(let i=0;i<dropN;i++){const d=drops[i];g.globalAlpha=.35+d.s*.4;const size=d.s>1?1.6:1;g.fillRect(d.x,d.y,size,size)}}
    }
    g.restore();
  }

  // Yumuşak ışık yayılımı: ekranın küçük bir kopyası "parlak bölge süzgeci" olarak kendisiyle çarpılır,
  // büyütülüp 'screen' ile eklenir. ctx.filter kullanılmaz; cihaz/tarayıcı uyumluluğu ayrıca test edilir.
  const bloomA=canvas(1,1),bloomB=canvas(1,1),ba=bloomA.getContext('2d'),bb=bloomB.getContext('2d');
  function paintBloom(){
    if(!options.bloom||!options.glow||options.reducedMotion||tier<1||RS<2)return;
    const w=Math.max(8,Math.ceil(LW/(tier>1?3:4))),h=Math.max(8,Math.ceil(LH/(tier>1?3:4)));
    if(bloomA.width!==w||bloomA.height!==h){bloomA.width=w;bloomA.height=h;bloomB.width=Math.max(4,w>>1);bloomB.height=Math.max(4,h>>1)}
    ba.globalCompositeOperation='source-over';ba.globalAlpha=1;ba.imageSmoothingEnabled=true;
    ba.drawImage(cv,0,0,cv.width,cv.height,0,0,w,h);
    ba.globalCompositeOperation='multiply';ba.drawImage(bloomA,0,0);ba.drawImage(bloomA,0,0);
    bb.globalCompositeOperation='source-over';bb.imageSmoothingEnabled=true;bb.drawImage(bloomA,0,0,w,h,0,0,bloomB.width,bloomB.height);
    g.save();g.setTransform(RS,0,0,RS,0,0);g.imageSmoothingEnabled=true;g.globalCompositeOperation='screen';
    g.globalAlpha=.34+env.night*.6;g.drawImage(bloomB,0,0,LW,LH);
    g.globalAlpha=.2+env.night*.35;g.drawImage(bloomA,0,0,LW,LH);
    g.restore();
  }

  let gradeC=null,gradeKey='';
  function paintGrade(){
    if(!options.bloom||options.reducedMotion||tier<1)return;
    const key=LW+'x'+LH+'x'+RS;
    if(!gradeC||gradeKey!==key){
      gradeC=canvas(LW*RS,LH*RS);gradeKey=key;const q=gradeC.getContext('2d');q.setTransform(RS,0,0,RS,0,0);
      const gr=q.createLinearGradient(0,0,LW*.85,LH);
      gr.addColorStop(0,'#ffd9a3');gr.addColorStop(.5,'#9aa8a0');gr.addColorStop(1,'#3d5fa8');
      q.fillStyle=gr;q.fillRect(0,0,LW,LH);
    }
    const day=Math.max(0,1-env.night*1.4);
    const a=env.outside?(.16+.26*day):.14;
    g.save();g.setTransform(RS,0,0,RS,0,0);g.globalCompositeOperation='soft-light';g.globalAlpha=a;g.drawImage(gradeC,0,0,LW,LH);g.restore();
  }
  function paintHurt(){if(hf<=0)return;g.save();g.setTransform(RS,0,0,RS,0,0);g.globalAlpha=Math.min(.8,hf)*(options.reducedMotion?.2:1);g.drawImage(hurtStamp,0,0,LW,LH);g.restore()}
  function sample(cpuMs,frameMs,isPaused){
    if(frameMs<=0||frameMs>120||document.hidden)return;
    const slot=frameCursor++%240;cpuSamples[slot]=cpuMs;frameSamples[slot]=frameMs;frameCount=Math.min(240,frameCount+1);
    cpuEMA+=.04*(cpuMs-cpuEMA);frameEMA+=.04*(frameMs-frameEMA);qualityCooldown-=frameMs/1000;
    if(options.quality==='auto'&&!isPaused&&qualityCooldown<=0){
      const slow=cpuEMA>12||frameEMA>21,fast=cpuEMA<7&&frameEMA<18;
      slowTime=slow?slowTime+frameMs/1000:Math.max(0,slowTime-.04);fastTime=fast?fastTime+frameMs/1000:0;
      if(slowTime>1.5&&tier>0)setTier(tier-1);else if(fastTime>8&&tier<2)setTier(tier+1);
    }
    meterClock+=frameMs/1000;
    if(options.showStats&&meterClock>.5){meterClock=0;$('vfx-meter').textContent=`${Math.round(1000/frameEMA)} FPS · ${tiers[tier].name} · ${particles.n} FX`}
  }
  function stats(){
    const c=Array.from(cpuSamples.subarray(0,frameCount)).sort((a,b)=>a-b),f=Array.from(frameSamples.subarray(0,frameCount)).sort((a,b)=>a-b);
    return {quality:options.quality,tier:tiers[tier].name,particleCount:particles.n,particleLimit:tiers[tier].particles,particleCapacity:particles.cap,textCount:texts.n,textCapacity:texts.cap,slashCount:slashes.n,burstCount:bursts.n,lightCount:lightN,lightLimit:tiers[tier].lights,ambientCount:ambientN,weatherCount:dropN,precipitation:env.precip,ambientDarkness:env.ambient,maskWidth:mask.width,maskHeight:mask.height,hitStopMs:stop*1000,fps:1000/frameEMA,cpuP95:c[Math.floor(c.length*.95)]||0,frameP95:f[Math.floor(f.length*.95)]||0,droppedParticles:particles.dropped,spriteCache:SC.size,textCache:TC.size};
  }
  function resetMap(){
    particles.clear();slashes.clear();bursts.clear();for(let i=texts.n-1;i>=0;i--){texts.items[texts.order[i]].el.style.display='none';texts.release(i)}
    stop=0;shk=0;camera.ready=false;sourceMap=null;sourceN=0;ambientMode=precipMode='';
  }
  return {options,rand,emit,sparks,flash,impact,slash,text,hitStop,consumeHitStop,step,beginRender,shadow,glow,torch,paintParticles,paintTrails,paintRays,paintLighting,paintBloom,paintGrade,paintAtmosphere,paintHurt,setBar,resize,setOption,load,sample,stats,resetMap,visible,get tier(){return tier},get viewX(){return camera.viewX},get viewY(){return camera.viewY}};
})();
