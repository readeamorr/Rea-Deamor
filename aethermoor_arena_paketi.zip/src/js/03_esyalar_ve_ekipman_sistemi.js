/* ===== EŞYALAR VE EKİPMAN SİSTEMİ ===== */
const RAR=[['Sıradan','#c8d0d8',1],['Nadir','#4cc9f0',1.5],['Epik','#c084fc',2.1],['Efsanevi','#ffb703',3]];
const SL={weapon:'🗡️',armor:'🛡️',helm:'⛑️',boots:'👢',ring:'💍'};
const NM={
  weapon:['Demir Kılıç','Alev Kılıcı','Elementarium','Ejder Biçağı'],
  armor:['Deri Yelek','Zincir Zırh','Ejder Zırhı','Kadim Cuirass'],
  helm:['Deri Başlık','Çelik Miğfer','Kızıl Taç','Gölge Miğferi'],
  boots:['Deri Çizme','Gezgin Botu','Rüzgar Çizmesi','Kanatlı Postallar'],
  ring:['Bakır Yüzük','Safir Yüzük','Kadim Yüzük','Ejder Gözü']
};

const PASSIVES=[
  {id:'lightning',name:'Yıldırım Çağıran',icon:'⚡',desc:'Her 3. vuruşta hedefe gökten şimşek indirir ve alan hasarı verir!'},
  {id:'vampiric',name:'Vampir Dişi',icon:'🩸',desc:'Verdiğin hasarın %8 kadarını can olarak yeniler.'},
  {id:'phoenix',name:'Anka Koruyucusu',icon:'🔥',desc:'Canın kritik seviyeye indiğinde alev patlaması yapar ve seni iyileştirir!'},
  {id:'frost_shards',name:'Buz Kristali',icon:'❄️',desc:'Vuruşlarda düşmanları donduran buz parçaları fırlatır.'},
  {id:'aegis',name:'Kadim Kalkan',icon:'🛡️',desc:'Hasar aldığında %25 şansla kalkan kazandırır.'},
  {id:'chrono',name:'Zaman Bükücü',icon:'⏳',desc:'Sıyrılma sonrasında hız ve ek hasar kazandırır.'}
];

function gen(lv,minR,random=Math.random){
  const choose=arr=>arr[Math.floor(random()*arr.length)];
  const s=choose(Object.keys(SL)),q=random(),r=Math.max(minR||0,q<.6?0:q<.88?1:q<.97?2:3),m=RAR[r][2];
  const name=RAR[r][0]+' '+NM[s][Math.min(NM[s].length-1,Math.floor(r*.8))];
  const i={s,r,n:name,up:0};
  if(s==='weapon')i.atk=Math.round((5+lv*2.4)*m);
  else if(s==='armor'){i.def=Math.round((2+lv*1.2)*m);i.hp=Math.round(lv*5*m)}
  else if(s==='helm'){i.def=Math.round((1+lv*.8)*m);i.hp=Math.round(lv*4*m)}
  else if(s==='boots'){i.def=Math.round((1+lv*.6)*m);i.spd=+(0.03*m).toFixed(3);i.hp=Math.round(lv*3*m)}
  else{i.atk=Math.round(lv*.9*m);i.crit=+(.018*m).toFixed(3)}
  if(r===3||(r===2&&random()<.5)){
    i.passive=choose(PASSIVES);
  }
  return i;
}

function upgradeMultiplier(i){const up=cl(Math.floor(Number(i?.up)||0),0,15);return 1+Math.min(5,up)*.2+Math.max(0,up-5)*.08}
const itemPower=i=>{
  if(!i)return 0;
  const upMult=upgradeMultiplier(i);
  return Math.round(((i.atk||0)*1.8+(i.def||0)*2+(i.hp||0)*0.2+(i.crit||0)*500+(i.spd||0)*300)*upMult);
};

const itx=i=>{
  if(!i) return '';
  if(i.desc)return escapeHTML(i.desc);
  if(i.s==='fish')return'Satış: '+unitSaleValue(i)+'🪙 (anlık pazar)';
  const upMult=upgradeMultiplier(i);
  let str=[
    i.atk?'⚔'+Math.round(i.atk*upMult):'',
    i.def?'🛡'+Math.round(i.def*upMult):'',
    i.hp?'❤'+Math.round(i.hp*upMult):'',
    i.crit?'🎯'+Math.round(i.crit*upMult*100)+'%':'',
    i.spd?'👟+'+Math.round(i.spd*upMult*100)+'%':''
  ].filter(Boolean).join(' ');
  if(i.passive){
    str+=`<br><span style="color:#ffd23f;font-size:9.5px">${i.passive.icon} <b>[${i.passive.name}]</b>: ${i.passive.desc}</span>`;
  }
  if(i.element==='lightning')str+='<br><span style="color:#a4e7ff">⚡ Fırtına Rünü · Islak hedefte alan elektriği</span>';
  return str || (i.val ? `Değer: ${i.val}🪙` : '');
};

const FISH=[['Sazan',5],['Alabalık',12],['Kılıç Balığı',25],['Altın Balık',75],['Kraliyet Koi',150],['Şimşek Balığı',180],['Göl Levreği',20],['Göl Turnası',48],['Uskumru',24],['Mercan Balığı',52],['Mavi Orkinos',95]];
const FISH_RARITY=[0,1,2,3,3,3,1,2,1,2,3];

