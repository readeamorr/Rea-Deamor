/* ===== EKOSİSTEM VE İŞLEVSEL BİNA SİSTEMLERİ (ŞAPEL, TAVERNA, BELEDİYE) ===== */
function chapelUI(){
  // Event delegation on chapel modal
}

$('chapel-modal').onclick = e => {
  const b = e.target.closest('[data-bless]');
  if(!b) return;
  const bl = b.dataset.bless;
  if(bl === 'light' && P.gold >= 50){
    P.gold -= 50; P.buffs.holy = 480; S = st();
    playChord([523, 659, 784, 1046], .5, 'sine', .08);
    fl(P.x, P.y-26, '✝️ IŞIK KUTSAMASI AKTİF (+%35 Hasar)', '#ffd23f', true);
    $('chapel-modal').classList.add('h'); sv();
  }else if(bl === 'aegis' && P.gold >= 80){
    P.gold -= 80; P.hp = S.h; P.mp = S.m; grantShield(150,250);
    playChord([523, 659, 784], .4, 'sine', .07);
    fl(P.x, P.y-26, '🛡️ 150 KUTSAL KALKAN & TAM CAN!', '#38bdf8', true);
    $('chapel-modal').classList.add('h'); sv();
  }else if(bl === 'grace' && P.gold >= 120){
    P.gold -= 120; P.buffs.grace = 480;
    playChord([659, 880, 1175], .5, 'triangle', .08);
    fl(P.x, P.y-26, '🌟 CENNETİN LÜTFU (+%50 XP & Altın)', '#c084fc', true);
    $('chapel-modal').classList.add('h'); sv();
  }else{
    fl(P.x, P.y-22, 'Yetersiz Altın!', '#ff5d5d');
  }
};

/* Taverna ve Paralı Askerler */
const MERCS = [
  { type: 'knight', name: 'Şövalye Demir', icon: '🛡️', role: 'Ağır Zırhlı Savunmacı (Tank)', cost: 150, mhp: 320, desc: 'Yakındayken kalkanından geçen hasarın %35’ini kendi canıyla karşılar; yakın dövüşte yardım eder.' },
  { type: 'archer', name: 'Okçu Selin', icon: '🏹', role: 'Keskin Nişancı Avcı (Menzilli)', cost: 120, mhp: 190, desc: 'Arkandan güvenle delici oklar fırlatarak ağır hasar desteği verir.' },
  { type: 'healer', name: 'Rahip Can', icon: '🕊️', role: 'Kutsal Şifacı (Destek)', cost: 180, mhp: 210, desc: 'Canın %50 altına indiğinde arkandan koşup anında +90 Can basar!' }
];

function tavernUI(){
  let h = '';
  MERCS.forEach(m => {
    const isHired = P.merc && P.merc.type === m.type;
    h += `<div class="ach-item" style="flex-direction:column;align-items:stretch">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:3px">
        <div style="font-weight:900;color:var(--gd);font-size:12px">${m.icon} ${m.name}</div>
        <div style="font-size:10px;color:#a7f3d0">${m.cost} Altın</div>
      </div>
      <div style="font-size:10px;color:#94a3b8">${m.role} · ${m.desc}</div>
      <div style="margin-top:5px;text-align:right">
        <button class="m" data-hire="${m.type}" style="padding:5px 14px;font-size:11px;margin:0;background:${isHired?'#16a34a':'#2563eb'}">
          ${isHired ? '✔ Ekibinde Aktif' : `Kirala (${m.cost} Altın)`}
        </button>
      </div>
    </div>`;
  });
  $('merc-hire-list').innerHTML = h;
}

$('tavern-modal').onclick = e => {
  const btn = e.target.closest('[data-hire]');
  if(!btn) return;
  const mType = btn.dataset.hire;
  const mData = MERCS.find(x => x.type === mType);
  if(!mData) return;
  if(P.merc && P.merc.type === mType){
    fl(P.x, P.y-22, `${mData.name} zaten ekibinde!`, '#38bdf8');
    return;
  }
  if(P.gold >= mData.cost){
    P.gold -= mData.cost;
    P.merc = {
      type: mData.type, name: mData.name, icon: mData.icon,
      hp: mData.mhp, mhp: mData.mhp,
      x: P.x + 15, y: P.y + 15, f: 1, cd: 0, healCd: 0
    };
    fl(P.x, P.y-26, `⚔️ ${mData.name} Ekibine Katıldı!`, '#6ee7b7', true);
    playChord([523, 659, 784, 1046], .35, 'triangle', .08);
    $('tavern-modal').classList.add('h'); sv();
  }else{
    fl(P.x, P.y-22, 'Yetersiz Altın!', '#ff5d5d');
  }
};

function updMerc(dt){
  if(!P.merc||P.dead)return;
  const m = P.merc;
  if(m.hp <= 0){
    fl(m.x, m.y-20, `🛡️ ${m.name} Yaralandı ve Çekildi!`, '#ff5d5d', true);
    P.merc = null;
    chat('SİSTEM', '', 'Paralı askerin savaşta yaralandı ve tedaviye çekildi.', 1);
    return;
  }

  m.cd = (m.cd || 0) - dt;
  m.healCd = (m.healCd || 0) - dt;

  // Takip
  const dx = P.x - m.x, dy = P.y - m.y, d = Math.hypot(dx, dy);
  if(d > 35){
    m.x += (dx/d) * 115 * dt;
    m.y += (dy/d) * 115 * dt;
    m.f = dx > 0 ? 1 : -1;
  }

  // Savaş Aksiyonları
  if(m.type === 'healer'){
    if(P.hp < S.h * 0.5 && m.healCd <= 0){
      m.healCd = 7.0;
      P.hp = Math.min(S.h, P.hp + 90);
      fl(P.x, P.y-26, `🕊️ +90 ŞİFA (${m.name})`, '#4ade80', true);
      spark(P.x, P.y-10, 15, '#4ade80', 40);
      sfx(750, .15, 'sine', .05);
    }
  }else if(m.type === 'archer'){
    if(m.cd <= 0){
      for(const e of mobs){
        if(!e.dead&&Math.hypot(e.x-m.x,e.y-m.y)<135&&BOND.lineClear(m,e)){
          m.cd = 1.4;
          const a = Math.atan2(e.y - m.y, e.x - m.x);
          prj.push({
            x: m.x, y: m.y-8, vx: Math.cos(a)*280, vy: Math.sin(a)*280, t: 0.55,
            dmg:Math.round(S.a*.8),col:'#facc15',kind:'arrow',pierce:1,isHero:true
          });
          sfx(540, .05, 'triangle', .03);
          break;
        }
      }
    }
  }else if(m.type === 'knight'){
    if(m.cd <= 0){
      for(const e of mobs){
        if(!e.dead&&Math.hypot(e.x-m.x,e.y-m.y)<45&&BOND.lineClear(m,e)){
          m.cd = 1.3;
          hitMob(e, Math.round(S.a * 0.75), false, m.f * 40, 0);
          spark(e.x, e.y-6, 8, '#cbd5e1', 35);
          sfx(380, .06, 'square', .03);
          // Savunma yardımı hurtP içinde gerçek kalkan paylaşımıyla uygulanır.
          break;
        }
      }
    }
  }
}

function mercD(m){
  if(!m) return;
  const x = Math.round(m.x), y = Math.round(m.y), f = m.f || 1;
  R(x-5, y-2, 10, 2, '#0002');
  if(m.type === 'knight'){
    // Ağır zırhlı şövalye
    R(x-5, y-13, 10, 11, '#64748b');
    R(x-4, y-19, 8, 6, '#94a3b8');
    R(x+f*5, y-16, 4, 14, '#38bdf8'); // kule kalkanı
    R(x-f*6, y-14, 2, 8, '#e2e8f0'); // kılıç
  }else if(m.type === 'archer'){
    // Yeşil avcı
    R(x-4, y-12, 8, 10, '#15803d');
    R(x-3, y-18, 6, 6, '#166534');
    R(x+f*5, y-14, 2, 10, '#854d0e'); // yay
  }else{
    // Beyaz şifacı
    R(x-5, y-13, 10, 11, '#f8fafc');
    R(x-4, y-18, 8, 5, '#e2e8f0');
    R(x-3, y-20, 6, 2, '#fde047'); // altın hale
    R(x+f*5, y-18, 2, 14, '#78350f'); // asa
  }
  T(`${m.icon} ${m.name}`, x, y-22, '#6ee7b7');
}

/* Belediye Binası ve Kasaba Geliri */
function townhallUI(){
  const tInfo = getRepTier(P.rep);
  const dailyGold = tInfo.tier === 4 ? 600 : tInfo.tier === 3 ? 280 : tInfo.tier === 2 ? 140 : 50;
  const dailyGems = tInfo.tier === 4 ? 10 : tInfo.tier === 3 ? 5 : tInfo.tier === 2 ? 2 : 0;
  const earnedToday=P.day===1||P.townWorkDay===P.day;
  $('townhall-content').innerHTML = `
    ${STORY.html()}
    <div style="background:#020617;border:2px solid #334155;border-radius:8px;padding:12px;margin:8px 0;text-align:left">
      <b style="color:var(--gd);font-size:13px">🏛️ Kasaba Refahı & Hazine Odası</b><br>
      <p style="font-size:10.5px;color:#cbd5e1;margin:4px 0">
        Kasaba İtibarı: <b>${P.rep||0}</b> · Ünvan: <b style="color:${tInfo.color}">${tInfo.name}</b><br>
        Günlük Kahramanlık Maaşı: 🪙 <b>${dailyGold}</b> · 💎 <b>${dailyGems}</b>
      </p>
      <div style="margin-top:8px">
        ${P.dailyIncomeCollected ?
          '<p style="color:#6ee7b7;font-size:11px">✔ Bugünkü kasaba payın toplandı. Yarın sabah tekrar gel!</p>' :
          earnedToday?`<button id="btn-collect-income" class="m" style="padding:7px 16px;font-size:12px;background:#16a34a">
            💰 ${dailyGold}🪙 ve ${dailyGems}💎 Kasaba Gelirini Topla
          </button>`:
          '<p style="color:#fcd34d;font-size:11px">Bugünün payı için bir görev, kasaba siparişi, Yayla teslimatı veya gece sevkiyatı yap.</p>'}
      </div>
    </div>
    <div style="font-size:10px;color:#94a3b8;text-align:left">
      • İlk gün başlangıç desteği ücretsizdir. Sonrasında çalıştığın oyun gününde kasaba payı açılır.<br>
      • Görev, sipariş, Yayla teslimatı veya sevkiyat katkı sağlar; uyumak tek başına maaş üretmez.
    </div>
  `;

  if($('story-close'))$('story-close').onclick=()=>STORY.finale();
  if($('btn-collect-income')){
    $('btn-collect-income').onclick = () => {
      if(P.dailyIncomeCollected||!(P.day===1||P.townWorkDay===P.day))return;
      P.dailyIncomeCollected = true;
      P.gold += dailyGold;
      P.gems += dailyGems;
      fl(P.x, P.y-26, `+${dailyGold}🪙 +${dailyGems}💎 Kasaba Geliri!`, '#ffd23f', true);
      playChord([523, 659, 784, 1046], .4, 'triangle', .08);
      spark(P.x, P.y-10, 25, '#ffd23f', 80);
      sv(); townhallUI();
    };
  }
}

function openAch(){$('ach').classList.remove('h');achUI()}

$('bi').onclick=openInv;
$('bsh').onclick=()=>{$('shop').classList.remove('h');shopUI()};
$('bfg').onclick=()=>{$('forge').classList.remove('h');forgeUI()};
$('bpr').onclick=()=>{$('priest').classList.remove('h');priestUI()};
$('bac').onclick=openAch;
$('bcl').onclick=openClass;
$('bhl').onclick=()=>$('help').classList.remove('h');$('bnotices').onclick=()=>NOTIFICATIONS.open();$('notifications-close').onclick=()=>$('notifications-modal').classList.add('h');$('notifications-read-all').onclick=()=>NOTIFICATIONS.readAll();$('notifications-clear').onclick=()=>{const b=$('notifications-clear');if(b.dataset.confirm!=='1'){b.dataset.confirm='1';b.textContent='Tekrar Bas · Temizle';setTimeout(()=>{if(b.dataset.confirm==='1'){b.dataset.confirm='';b.textContent='Temizle'}},2500);return}b.dataset.confirm='';b.textContent='Temizle';NOTIFICATIONS.clear()};
function rewardsUI(){const pending=P.adventure.chapterRewardPending,itemCount=ITEMS.count(P.pendingRewards||[]),talents=P.talentQueue?.length||0;let h='<div class="journey-lead"><small>BEKLEYEN VE SEÇİLEBİLİR ÖDÜLLER</small><h2>🎁 Ödül Merkezi</h2><p>Çanta doluluğu veya sessiz bildirim modu yüzünden hiçbir ödül kaybolmaz.</p></div>';if(pending)h+=QUEST_FLOW.chapterChoiceHTML(pending.index);if(itemCount)h+=`<div class="reward-pending"><h3>📦 Bekleyen Eşyalar · ${itemCount}</h3><p>Çanta doluyken korunan ganimet ve sandık ödülleri.</p><button type="button" data-reward-claim-items="1">Çantaya Sığanları Teslim Al</button></div>`;if(talents)h+=`<div class="reward-pending"><h3>✦ Yetenek Seçimleri · ${talents}</h3><p>Seviye atlamalarından kalan seçimler güvende bekliyor.</p><button type="button" data-reward-talents="1">Yetenek Seçimine Git</button></div>`;if(!pending&&!itemCount&&!talents)h+='<div class="journey-box">✓ Bekleyen ödül yok.</div>';$('rewards-content').innerHTML=h;$('rewards-modal').classList.remove('h')}
$('rewards-open').onclick=()=>{$('notifications-modal').classList.add('h');rewardsUI()};$('rewards-close').onclick=()=>$('rewards-modal').classList.add('h');
document.addEventListener('click',e=>{if(e.target.closest?.('[data-brief-open]')){$('guide-modal').classList.add('h');$('chapter-brief-content').innerHTML=STORY.briefHTML();$('chapter-brief-modal').classList.remove('h');GAME_CORE.resetInput();return}const choice=e.target.closest?.('[data-chapter-choice]');if(choice){QUEST_FLOW.claimChapterReward(Number(choice.dataset.chapterIndex),choice.dataset.chapterChoice);return}if(e.target.closest?.('[data-reward-claim-items]')){let claimed=0;P.pendingRewards=P.pendingRewards.filter(it=>{if(ITEMS.add(P.inv,it)){claimed+=ITEMS.qty(it);return false}return true});sv();rewardsUI();if(claimed)fl(P.x,P.y-28,`🎁 ${claimed} ödül teslim alındı`,'#a7f3d0',true);return}if(e.target.closest?.('[data-reward-talents]')){$('rewards-modal').classList.add('h');GAME_CORE.offerTalent(true)}});
$('bm').onclick=openMap;

const MENU_LABELS={btalent:'Yetenek',bm:'Harita',bi:'Çanta',bgarden:'Bahçe',bcl:'Sınıf',bck:'Mutfak',bhs:'Ev',bst:'Kiler',bpt:'Yoldaş',bms:'Beceri',bstg:'Ayarlar',bsv:'Kayıt',bjourney:'Defter',bfr:'Dostlar',bac:'Başarım',bnotices:'Bildirimler',bhl:'Yardım',bsn:'Ses',bsh:'Tüccar',bfg:'Demirci',bpr:'Tapınak',bcf:'Kafe',bmk:'Manav',bar:'Komutan',bbd:'Pano',bcs:'Fıçı',bml:'Değirmen',bbt:'Sera',bchp:'Şapel',btav:'Taverna',bth:'Belediye',blb:'Canavarlar',bride:'Binek',btv:'TV',bgm:'Gramofon'};
for(const id in MENU_LABELS){const el=$(id);if(el){el.dataset.l=MENU_LABELS[id];el.setAttribute('aria-label',MENU_LABELS[id])}}
function setQuickMenu(side=false){
  const open=side==='left'||side==='right';
  if(open)In.reset();
  $('bt').classList.toggle('expanded',open);
  $('bt').classList.toggle('left-open',side==='left');
  $('bt').classList.toggle('right-open',side==='right');
  $('hud').classList.toggle('menu-open',open);
  const leftOpen=side==='left',rightOpen=side==='right';
  $('bt-left').hidden=!leftOpen;$('bt-right').hidden=!rightOpen;
  $('bmenu-left').setAttribute('aria-expanded',String(leftOpen));
  $('bmenu-left').setAttribute('aria-label',leftOpen?'Karakter menüsünü kapat':'Karakter menüsünü aç');
  $('bmenu-left').textContent=leftOpen?'✕':'☰';
  $('bmenu').setAttribute('aria-expanded',String(rightOpen));
  $('bmenu').setAttribute('aria-label',rightOpen?'Araçlar ve yerler menüsünü kapat':'Araçlar ve yerler menüsünü aç');
  $('bmenu').textContent=rightOpen?'✕':'☰';
}
function closeQuickMenu(){setQuickMenu(false)}
function toggleQuickMenu(side){setQuickMenu($('bt').classList.contains(`${side}-open`)?false:side)}
$('bmenu-left').onclick=()=>toggleQuickMenu('left');
$('bmenu').onclick=()=>toggleQuickMenu('right');
$('bt').addEventListener('click',e=>{
  const button=e.target.closest('button');
  if(button&&!['bmenu','bmenu-left'].includes(button.id)&&$('bt').classList.contains('expanded'))closeQuickMenu();
});
document.addEventListener('pointerdown',e=>{
  if($('bt').classList.contains('expanded')&&!$('bt').contains(e.target))closeQuickMenu();
});
window.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&$('bt').classList.contains('expanded')){e.preventDefault();closeQuickMenu()}
});

$('ic').onclick=()=>$('inv').classList.add('h');
$('shc').onclick=()=>$('shop').classList.add('h');
$('fgc').onclick=()=>$('forge').classList.add('h');
$('prc').onclick=()=>$('priest').classList.add('h');
$('acc').onclick=()=>$('ach').classList.add('h');
$('clc').onclick=()=>$('class-modal').classList.add('h');
$('hlc').onclick=()=>$('help').classList.add('h');
$('mc').onclick=()=>$('map').classList.add('h');
$('ckc').onclick=()=>$('cook-modal').classList.add('h');
$('hsc').onclick=()=>$('house-modal').classList.add('h');
$('cfc').onclick=()=>$('cafe-modal').classList.add('h');
$('mkc').onclick=()=>$('market-modal').classList.add('h');
$('mlc').onclick=()=>$('mill-modal').classList.add('h');
$('btc').onclick=()=>$('botany-modal').classList.add('h');

$('bml').onclick=()=>{ $('mill-modal').classList.remove('h'); millUI(); };
$('bbt').onclick=()=>{ $('botany-modal').classList.remove('h'); botanyUI(); };
$('cskc').onclick=()=>$('cask-modal').classList.add('h');
$('svc').onclick=()=>$('save-modal').classList.add('h');
$('stgc').onclick=()=>$('settings-modal').classList.add('h');
$('bsc').onclick=()=>$('bestiary-modal').classList.add('h');
$('chpc').onclick=()=>$('chapel-modal').classList.add('h');
$('tavc').onclick=()=>$('tavern-modal').classList.add('h');
$('thc').onclick=()=>$('townhall-modal').classList.add('h');

$('bchp').onclick=()=>{ $('chapel-modal').classList.remove('h'); chapelUI(); };
$('btav').onclick=()=>{ $('tavern-modal').classList.remove('h'); tavernUI(); };
$('bth').onclick=()=>{ $('townhall-modal').classList.remove('h'); townhallUI(); };

$('bstg').onclick=settingsUI;
$('blb').onclick=()=>{ $('bestiary-modal').classList.remove('h'); bestiaryUI(); };
$('bsv').onclick=openSaveModal;
$('btn-sort-inv').onclick=sortInventory;
$('bcs').onclick=()=>{ $('cask-modal').classList.remove('h'); caskUI(); };
$('bdc').onclick=()=>$('board-modal').classList.add('h');
$('stc').onclick=()=>$('storage-modal').classList.add('h');
$('tvc').onclick=()=>$('tv-modal').classList.add('h');
$('gmc').onclick=()=>$('gramophone-modal').classList.add('h');

$('btv').onclick=()=>{ $('tv-modal').classList.remove('h'); tvUI('weather'); };
$('bgm').onclick=()=>{ $('gramophone-modal').classList.remove('h'); gramophoneUI(); };
$('ptc').onclick=()=>$('pet-modal').classList.add('h');
$('msc').onclick=()=>$('mastery-modal').classList.add('h');
$('frc').onclick=()=>$('friends-modal').classList.add('h');
$('dlc').onclick=()=>$('dialogue-modal').classList.add('h');
$('bfr').onclick=()=>{ $('friends-modal').classList.remove('h'); friendsUI(); };
$('bms').onclick=()=>{ $('mastery-modal').classList.remove('h'); masteryUI(); };
$('bpt').onclick=()=>{ $('pet-modal').classList.remove('h'); petUI(); };

$('bbd').onclick=()=>{ $('board-modal').classList.remove('h'); boardUI(); };
$('bst').onclick=()=>{ $('storage-modal').classList.remove('h'); storageUI(); };


$('bck').onclick=()=>{ $('cook-modal').classList.remove('h'); cookUI(); };
$('bhs').onclick=()=>{ $('house-modal').classList.remove('h'); houseUI(); };
$('bcf').onclick=()=>{ $('cafe-modal').classList.remove('h'); cafeUI(); };
$('bmk').onclick=()=>{ $('market-modal').classList.remove('h'); marketUI(); };

$('tab-world').onclick=()=>openMap('world');
$('tab-frontier').onclick=()=>{if(P.frontierDiscovered||curMap==='frontier')openMap('frontier')};
$('tab-home').onclick=()=>openMap('home');


$('bsn').onclick=()=>{
  mute=!mute;
  $('bsn').textContent=mute?'🔇':'🔊';$('bsn').dataset.l=mute?'Sessiz':'Ses';
};

