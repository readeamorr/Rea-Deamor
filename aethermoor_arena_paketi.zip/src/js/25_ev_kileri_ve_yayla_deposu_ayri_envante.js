/* ===== EV KİLERİ VE YAYLA DEPOSU: AYRI ENVANTER, AYNI GÜVENLİ ARAYÜZ ===== */
function activeStorageBox(){
  if(curMap==='home'&&BUILD.activeChest){const b=P.adventure.buildings.find(b=>b.id===BUILD.activeChest&&b.kind==='chest');if(b){const p=BUILD.pos(b);if(Math.hypot(P.x-p.x,P.y-p.y)<45)return {items:b.items,capacity:24,name:`📦 Depo Sandığı (${b.gx}, ${b.gy})`,label:'Sandıktaki Eşyalar'}}BUILD.activeChest=null}
  if(curMap==='frontier'&&P.hasFieldCamp&&P.fieldCampLevel>=2){
    if(!Array.isArray(P.fieldCampStorage))P.fieldCampStorage=[];
    return {items:P.fieldCampStorage,capacity:campStorageCapacity(),name:'🏕️ Yayla Saha Deposu',label:'Yayla Eşyaları'};
  }
  if(!Array.isArray(P.storage))P.storage=[];
  return {items:P.storage,capacity:30+10*(cl(houseLevel,1,3)-1),name:`📦 Ev Kileri · Seviye ${houseLevel}`,label:'Kiler Eşyaları'};
}
function storageUI(message=''){
  const box=activeStorageBox();
  $('storage-status').textContent=message;
  $('storage-bag-label').textContent=`Çantanız: ${P.inv.length}/${BAG_CAPACITY} göz · ${ITEMS.count(P.inv)} adet`;
  $('storage-title').textContent=box.name;
  $('storage-items-label').textContent=box.label;
  $('storage-count').textContent=box.items.length;
  $('storage-capacity').textContent=box.capacity;
  let sh='';
  for(let i=0;i<containerSlots(box.items,box.capacity);i++)sh+=slotH(box.items[i]||null,'st',i);
  $('storage-grid').innerHTML=sh;
  let bh='';
  for(let i=0;i<containerSlots(P.inv,BAG_CAPACITY);i++)bh+=slotH(P.inv[i]||null,'bag',i);
  $('bag-grid').innerHTML=bh;
}
$('storage-modal').onclick=e=>{
  const s=e.target.closest('[data-w]');if(!s)return;
  const box=activeStorageBox(),idx=+s.dataset.i,deposit=s.dataset.w==='bag';
  if(!deposit&&s.dataset.w!=='st')return;
  const from=deposit?P.inv:box.items,to=deposit?box.items:P.inv,it=from[idx];
  if(!it)return;
  const amount=transferAmount(it,'storage-amount');
  if(!ITEMS.transfer(from,to,idx,amount,deposit?box.capacity:BAG_CAPACITY)){
    storageUI('Seçilen miktar sığmıyor. Hiçbir eşya taşınmadı; miktarı azalt veya yer aç.');return;
  }
  sel=null;sfx(650,.08,'triangle',.04);sv();storageUI(`${amount} adet ${it.n} ${deposit?'depoya':'çantaya'} taşındı.`);
};
function quickDepositStorage(){
  const box=activeStorageBox();let moved=0,left=0;
  for(let i=0;i<P.inv.length;){
    const it=P.inv[i],eligible=['crop','seed','fish','food','food_ing'].includes(it.s)||ITEMS.stackable(it)||it.k==='wool';
    if(!eligible){i++;continue}
    const amount=Math.min(ITEMS.qty(it),ITEMS.room(box.items,it,box.capacity)),total=ITEMS.qty(it);
    if(amount>0&&ITEMS.transfer(P.inv,box.items,i,amount,box.capacity)){
      moved+=amount;left+=total-amount;if(amount===total)continue;
    }else left+=total;
    i++;
  }
  if(moved){sel=null;playChord([523,659,784],.2,'triangle',.04);sv()}
  storageUI(moved?`📦 ${moved} adet depolandı.${left?' Yer yetmeyen '+left+' adet çantanda kaldı.':''}`:'Depolanacak ürün yok veya uygun yığın/boş göz kalmadı.');
}
$('btn-quick-deposit').onclick=quickDepositStorage;


