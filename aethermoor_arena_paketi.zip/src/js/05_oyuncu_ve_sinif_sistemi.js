/* ===== OYUNCU VE SINIF SİSTEMİ ===== */
const CLASSES={
  warrior:{
    id:'warrior',name:'Savaşçı',icon:'⚔️',title:'Kudretli Savaşçı',
    desc:'Yüksek can ve zırh. Yakın dövüşte ağır kılıç darbeleri, hortum ve kalkan savunması.',
    hpM:1.35,defM:1.35,atkM:1.15,mpM:0.9,spdM:1.0,critM:0.08,
    s1Icon:'🌪️',s1Name:'Kılıç Kasırgası',s1Mp:25,s1Key:'K',
    s2Icon:'🛡️',s2Name:'Kalkan Hücumu',s2Mp:25,s2Key:'U',
    c:'#3b5fa8',h:'#475569',cape:'#d9382f',wpn:'sword'
  },
  mage:{
    id:'mage',name:'Büyücü',icon:'🔮',title:'Kadim Büyücü',
    desc:'Uzaktan büyü küresi atışları, yıkıcı alev patlaması ve donduran buz fırtınası.',
    hpM:0.9,defM:0.85,atkM:1.45,mpM:1.6,spdM:1.05,critM:0.12,
    s1Icon:'🔥',s1Name:'Alev Çemberi',s1Mp:25,s1Key:'K',
    s2Icon:'❄️',s2Name:'Buz Dalgası',s2Mp:30,s2Key:'U',
    c:'#4f46e5',h:'#312e81',cape:'#a855f7',wpn:'staff'
  },
  ranger:{
    id:'ranger',name:'Avcı',icon:'🏹',title:'Gölge Avcısı',
    desc:'Uzaktan seri delici oklar, 5\'li ok yağmuru ve yüksek hareket kabiliyeti.',
    hpM:1.05,defM:0.95,atkM:1.25,mpM:1.1,spdM:1.2,critM:0.22,
    s1Icon:'🎯',s1Name:'Çoklu Ok',s1Mp:20,s1Key:'K',
    s2Icon:'❄️',s2Name:'Buz Oku',s2Mp:25,s2Key:'U',
    c:'#15803d',h:'#14532d',cape:'#ca8a04',wpn:'bow'
  }
};

const P = window.P = {
  cls:'warrior',
  x:14*16,y:24*16,f:0,w:0,t:0,lvl:1,xp:0,gold:0,gems:8,pots:3,
  inv:[],pendingRewards:[],eq:{},q:0,qn:0,kills:0,hp:100,mp:50,shld:0,
  life:{v:1,defeats:0,defeat:null},talentQueue:[],combatTimer:0,
  cd:0,cs:0,ci:0,cp:0,cd2:0,ds:0,dx:0,dy:1,tl:{},sw:0,hd:true,cb:0,ct:0,iv:0,
  dead:false,ax:0,ay:1,fs:null,z:0,r:4,buffs:{atk:0,spd:0},ach:{},bounties:0,lastBountyDay:0,townWorkDay:0,restDays:{},biome:null,
  pet:{type:'wolf',name:'Bozkurt',lvl:1,xp:0,x:C*TS-12,y:(C+3)*TS,f:1,biteCd:0},
  rage:0,maxRage:100,merc:null,dailyIncomeCollected:false,arenaRewardDay:0,arenaPendingReward:false,arenaPts:0,arenaStreak:0,arenaWinsToday:0,arenaReward:null,
  activeTool:'sword',waterCan:20,lakeBait:0,lakeBaitDay:0,
  frontierDiscovered:false,hasFieldCamp:false,fieldCampLevel:0,fieldCampStorage:[],fieldCampRestDay:0,frontierRuinFound:false,
  frontierMission:0,frontierBoarsKilled:0,frontierBoarStart:0,frontierTradeDay:0,
  guideStep:0,
  hasSprinkler:false,parryWindow:0,hasCoop:false,eggsAvailable:0,cowMilkedToday:false,hasBeehive:false,honeyReady:false,hasCask:false,caskItem:null,caskTimer:0,caskReady:false,caskReadyDay:0,
  friendship:{
    melis:{hearts:1,pts:0,talkedToday:false,giftedToday:false},
    osman:{hearts:1,pts:0,talkedToday:false,giftedToday:false},
    dede:{hearts:1,pts:0,talkedToday:false,giftedToday:false},
    boran:{hearts:1,pts:0,talkedToday:false,giftedToday:false}
  }
};

const st=()=>{
  const curCls=CLASSES[P.cls]||CLASSES.warrior;
  let a=(8+P.lvl*3)*curCls.atkM,d=P.lvl*curCls.defM;
  let h=(80+P.lvl*18)*curCls.hpM,m=(40+P.lvl*6)*curCls.mpM;
  let c=curCls.critM,s=curCls.spdM;
  for(const k in P.eq){
    const i=P.eq[k];
    if(i){
      const upMult=upgradeMultiplier(i);
      a+=(i.atk||0)*upMult;
      d+=(i.def||0)*upMult;
      h+=(i.hp||0)*upMult;
      c+=(i.crit||0)*upMult;
      s+=(i.spd||0)*upMult;
    }
  }
  const T2=P.tl||{};
  if(P.buffs.atk>0)a*=1.22;
  if(P.buffs.spd>0)s*=1.22;
  if(P.buffs.def>0)d*=1.22;
  if(P.buffs.crit>0)c+=.08;
  // 🌿 ÇİFTLİK BEREKETİ: Bakımlı bahçe kahramana kalıcı savaş gücü kazandırır
  const FARM_REF=window.FARM; // FARM henüz başlatılmadıysa (TDZ) güvenli şekilde atla
  if(FARM_REF&&FARM_REF.combatPerks){
    const fp=FARM_REF.combatPerks();
    if(fp.vitality)h*=1.12;
    if(fp.orchard){s*=1.08;c+=.05}
    if(fp.master){a*=1.15;d=Math.round(d*1.15)+3}
  }
  return{
    a:Math.round(a*(1+.15*(T2.a||0))),
    d:Math.round(d),
    h:Math.round(h*(1+.2*(T2.h||0))),
    m:Math.round(m),
    c:Math.min(.85,c+.1*(T2.c||0)),
    s:s*(1+.12*(T2.s||0))
  };
};

let S=st();
const xpn=()=>Math.round(26*Math.pow(P.lvl,1.52));

