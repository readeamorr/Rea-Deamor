/* ===== ADIM 2: YAŞAYAN KASABA — İŞLER, GELİR, GÜNLÜK RUTİNLER ===== */
const NPC_NEEDS_CONFIG={
  initial:{hunger:18,fatigue:12,safety:92,mood:78},
  rates:{hungerAwake:3,hungerSleep:1.2,hungerMeal:55,fatigueAwake:5.2,fatigueSleep:32,fatigueMeal:1,safetyBadWeather:5,safetyCalm:1.4,safetyShelter:6},
  thresholds:{meal:56,mealClear:36,rest:86,restClear:42,safety:34},
  actions:{mealHours:.75,restHours:1.25},
  traits:{melis:{hunger:1.05,fatigue:.92},osman:{hunger:1,fatigue:1.02},aylin:{hunger:.92,fatigue:.9},dede:{hunger:.9,fatigue:1.15},ozan:{hunger:1.15,fatigue:.95},hamdi:{hunger:.95,fatigue:.95}},
  badWeather:['rain','storm','fog','blood_moon'],memoryLimit:8
};
const TOWN_LIFE=window.TOWN_LIFE={
  wallets:{},level:{},lastIncome:{},log:[],overrideRows:{},
  /* spot:[tileX,tileY]; shop: dükkân bu aralıkta açık; hide: bina içinde, görünmez */
  JOBS:{
    'Melis':{id:'melis',temperament:'Sıcakkanlı',meal:[34,17],job:'Fırıncı',base:70,shop:'cafe',home:[27,21],sched:[
      [6,8,[27,23],'🥖','Hamur yoğuruyor'],[8,12,[27,23],'🥐','Tezgâhta satış yapıyor',1],[12,13,[34,17],'🧺','Parkta piknik yapıyor'],
      [13,18.5,[27,23],'🥐','Tezgâhta satış yapıyor',1],[18.5,21,[20,43],'🍺','Tavernada dinleniyor'],[21,25,null,'😴','Uyuyor',0,1]]},
    'Amca Osman':{id:'osman',temperament:'Temkinli',meal:[32,31],job:'Manav',base:60,shop:'market',home:[35,21],sched:[
      [6,8,[35,23],'📦','Sepetleri diziyor'],[8,13,[35,23],'🥕','Tezgâhta satış yapıyor',1],[13,14,[32,31],'🍵','Çay molasında'],
      [14,18,[35,23],'🥕','Tezgâhta satış yapıyor',1],[18,20.5,[34,12],'🎣','Park gölünde balık tutuyor'],[20.5,25,null,'😴','Uyuyor',0,1]]},
    'Aylin':{id:'aylin',temperament:'Doğa dostu',meal:[26,12],job:'Botanikçi',base:55,shop:'botany',home:[27,37],sched:[
      [6,8,[27,35],'💧','Serayı suluyor'],[8,12,[27,35],'🌸','Serada müşteri ağırlıyor',1],[12,14,[26,12],'🌼','Mozaik bahçede çiçeklere bakıyor'],
      [14,18,[27,35],'🌸','Serada müşteri ağırlıyor',1],[18,20,[37,10],'🌇','Park bankında akşamı izliyor'],[20,25,null,'😴','Uyuyor',0,1]]},
    'Çiftçi Dede':{id:'dede',temperament:'Sabırlı',meal:[14,18],job:'Çiftçi',base:45,home:[13,17],sched:[
      [6,11,[14,18],'🌾','Tarlada çalışıyor'],[11,12,[16,26],'💧','Kuyudan su çekiyor'],[12,13,[14,19],'😪','Ağaç altında şekerleme yapıyor'],
      [13,17,[14,18],'🌾','Tarlada çalışıyor'],[17,20,[18,19],'🔥','Ateş başında ısınıyor'],[20,25,null,'😴','Uyuyor',0,1]]},
    'Ozan Can':{id:'ozan',temperament:'Sosyal',meal:[20,43],job:'Ozan',base:40,home:[17,21],sched:[
      [6,9,null,'😴','Uyuyor',0,1],[9,12,[31,31],'🎵','Meydanda saz çalıyor'],[12,14,[28,25],'☕','Kafede kahve içiyor'],
      [14,16,[39,16],'🎶','Parkta bankta saz çalıyor'],[16,18,[18,19],'🎶','Ateş başında beste yapıyor'],[18,23,[20,43],'🎻','Tavernada konser veriyor'],[23,25,null,'😴','Uyuyor',0,1]]},
    'Muhtar Hamdi':{id:'hamdi',temperament:'Düzenli',meal:[31,28],job:'Muhtar',base:30,home:[18,13],sched:[
      [6,8,null,'☕','Kahvaltı ediyor',0,1],[8,12,[18,14],'📜','Divan işleriyle uğraşıyor'],[12,13,[31,28],'🚶','Çarşıyı geziyor'],
      [13,17,[18,14],'📜','Divan işleriyle uğraşıyor'],[17,19,[29,27],'📌','İlan panosunu düzenliyor'],[19,25,null,'😴','Uyuyor',0,1]]}
  },
  hour(){return 6+Math.min(DAY_CLOCK.END,tod)*24},
  fmt(h){h=Math.floor(h*60+1e-6);return String(Math.floor(h/60)%24).padStart(2,'0')+':'+String(h%60).padStart(2,'0')},
  slot(name,h=this.hour()){
    const j=this.JOBS[name];if(!j)return null;
    return j.sched.find(r=>h>=r[0]&&h<r[1])||j.sched[j.sched.length-1];
  },
  state(name){
    const j=this.JOBS[name];if(!j)return null;const id=j.id||name,a=P.adventure;
    if(!a.npcLife||typeof a.npcLife!=='object')a.npcLife={};
    const base=NPC_NEEDS_CONFIG.initial,s=a.npcLife[id]||(a.npcLife[id]={hunger:base.hunger,fatigue:base.fatigue,safety:base.safety,mood:base.mood,mealHours:0,restHours:0,lastMealDay:P.day||1,memory:[]});
    s.hunger=cl(Number(s.hunger??base.hunger),0,100);s.fatigue=cl(Number(s.fatigue??base.fatigue),0,100);s.safety=cl(Number(s.safety??base.safety),0,100);s.mood=cl(Number(s.mood??base.mood),0,100);
    s.mealHours=cl(Number(s.mealHours)||0,0,2);s.restHours=cl(Number(s.restHours)||0,0,4);s.lastMealDay=Math.max(0,Math.floor(Number(s.lastMealDay)||0));if(!Array.isArray(s.memory))s.memory=[];else if(s.memory.length>NPC_NEEDS_CONFIG.memoryLimit)s.memory.length=NPC_NEEDS_CONFIG.memoryLimit;
    return s;
  },
  remember(id,kind){
    const name=Object.keys(this.JOBS).find(k=>this.JOBS[k].id===id||k===id);if(!name)return false;
    const s=this.state(name),last=s.memory[0];if(last?.kind===kind&&last.day===P.day)return false;
    s.memory.unshift({kind,day:P.day||1});s.memory=s.memory.slice(0,NPC_NEEDS_CONFIG.memoryLimit);sv();return true;
  },
  memoryLine(id){
    const name=Object.keys(this.JOBS).find(k=>this.JOBS[k].id===id||k===id);if(!name)return '';
    const entry=this.state(name).memory[0];if(!entry)return '';
    const labels={talk:'Yakın zamanda seninle sohbet etti.',gift:'Son verdiğin hediyeyi hâlâ hatırlıyor.',meal:'Bugün yemek molası verdi.',rest:'Biraz dinlenmeye ihtiyaç duydu.',shelter:'Son kötü havada evine sığındı.'};
    return labels[entry.kind]||'';
  },
  badWeather(){return NPC_NEEDS_CONFIG.badWeather.includes(weather.type)},
  atHome(name,row=this.slot(name)){
    const j=this.JOBS[name];if(!j)return true;const spot=row?.[2]||j.home;
    return Math.hypot(spot[0]-j.home[0],spot[1]-j.home[1])<=1.6;
  },
  needsShelter(name,row=this.slot(name)){
    if(!row||row[6]||this.atHome(name,row))return false;
    return this.badWeather()||this.state(name).safety<NPC_NEEDS_CONFIG.thresholds.safety;
  },
  override(name,type,spot,icon,text,hidden=false){
    const id=this.JOBS[name]?.id||name,bag=this.overrideRows[id]||(this.overrideRows[id]={});
    const row=bag[type]||(bag[type]=[0,25,spot,icon,text,0,hidden,type]);
    row[2]=spot;row[3]=icon;row[4]=text;row[6]=hidden;return row;
  },
  activity(n){
    const name=typeof n==='string'?n:n.n,j=this.JOBS[name],row=this.slot(name);if(!j||!row)return row;
    if(row[6])return row;
    const s=this.state(name);
    if(this.needsShelter(name,row))return this.override(name,'shelter',j.home,'🌧️',this.badWeather()?'Kötü havadan evinde sığınıyor':'Güvenlik için evine dönüyor',true);
    if(s.restHours>0)return this.override(name,'rest',j.home,'💤','Yorgun; evinde dinleniyor',true);
    if(s.mealHours>0)return this.override(name,'meal',j.meal||j.home,'🍲','Yemek molasında',false);
    return row;
  },
  needsText(name){
    const s=this.state(name);if(!s)return '';
    return `Açlık ${Math.round(s.hunger)} · Yorgunluk ${Math.round(s.fatigue)} · Güven ${Math.round(s.safety)} · Moral ${Math.round(s.mood)}`;
  },
  tick(dt){
    const hours=Math.max(0,Number(dt)||0)*DAY_CLOCK.RATE*24;if(!hours)return;
    const rate=NPC_NEEDS_CONFIG.rates,threshold=NPC_NEEDS_CONFIG.thresholds;
    for(const [name,j]of Object.entries(this.JOBS)){
      const s=this.state(name),row=this.slot(name),trait=NPC_NEEDS_CONFIG.traits[j.id]||{hunger:1,fatigue:1},sleep=!!row?.[6],sheltered=this.atHome(name,row)||this.needsShelter(name,row),meal=s.mealHours>0,rest=s.restHours>0;
      if(meal){s.mealHours=Math.max(0,s.mealHours-hours);s.hunger=Math.max(0,s.hunger-hours*rate.hungerMeal)}
      else s.hunger=cl(s.hunger+hours*(sleep?rate.hungerSleep:rate.hungerAwake*trait.hunger),0,100);
      if(rest)s.restHours=Math.max(0,s.restHours-hours);
      if(sleep||rest)s.fatigue=Math.max(0,s.fatigue-hours*rate.fatigueSleep);
      else if(meal)s.fatigue=Math.min(100,s.fatigue+hours*rate.fatigueMeal);
      else s.fatigue=Math.min(100,s.fatigue+hours*rate.fatigueAwake*trait.fatigue);
      if(!sleep&&!rest&&!meal&&s.hunger>=threshold.meal){s.mealHours=NPC_NEEDS_CONFIG.actions.mealHours;s.lastMealDay=P.day||1;this.remember(j.id,'meal')}
      if(!sleep&&!meal&&s.mealHours<=0&&s.restHours<=0&&s.fatigue>=threshold.rest){s.restHours=NPC_NEEDS_CONFIG.actions.restHours;this.remember(j.id,'rest')}
      if(sheltered)s.safety=Math.min(100,s.safety+hours*rate.safetyShelter);
      else if(this.badWeather()&&!sleep)s.safety=Math.max(0,s.safety-hours*rate.safetyBadWeather);
      else s.safety=Math.min(100,s.safety+hours*rate.safetyCalm);
      s.mood=cl(100-s.hunger*.42-s.fatigue*.3+s.safety*.12,0,100);
    }
  },
  attach(n){
    const j=this.JOBS[n.n];if(!j){n.job=false;return}
    n.job=j;n.stationary=false;
    if(this.wallets[n.n]==null){this.wallets[n.n]=rnd(40,120)|0;this.level[n.n]=1;this.lastIncome[n.n]=0}
    this.state(n.n);const r=this.activity(n);
    const sp=r[2]||j.home;n.x=n.tx=sp[0]*TS+8;n.y=n.ty=sp[1]*TS+8;
    n.hidden=!!r[6];n.act=r;n.stuck=0;
  },
  isOpen(shop){
    for(const n of npcs){
      if(!n.job||n.job.shop!==shop)continue;
      const r=this.activity(n);return !!r[5]&&!n.hidden&&Math.hypot(n.x-n.bx,n.y-n.by)<34;
    }
    return true;
  },
  hoursText(shop){
    for(const k in this.JOBS){const j=this.JOBS[k];if(j.shop===shop){const o=j.sched.filter(r=>r[5]);return this.fmt(o[0][0])+' – '+this.fmt(o[o.length-1][1])}}
    return '';
  },
  closedNotice(shop,who){
    const t=this.hoursText(shop);
    fl(P.x,P.y-22,`🔒 ${who} şu an tezgâhta değil`+(t?` (açık: ${t})`:''),'#fca5a5');
    ban(`🔒 ${who} şu an tezgâhta değil`,'#fca5a5');
  },
  update(n,dt){
    const j=n.job,r=this.activity(n);
    if(n.act!==r){
      n.act=r;n.stuck=0;
      if(r[7])this.remember(j.id,r[7]);
      if(r[6]===0&&n.hidden){n.hidden=false}
    }
    const sp=r[2]||j.home,tx=sp[0]*TS+8,ty=sp[1]*TS+8;
    n.tx=tx;n.ty=ty;
    const dx=tx-n.x,dy=ty-n.y,d=Math.hypot(dx,dy);
    if(d>5){
      n.hidden=false;
      const before=n.x+n.y;
      mv(n,dx/d*34*dt,dy/d*34*dt,4);
      n.f=dirOf(dx,dy);n.w+=dt*8;
      n.stuck=Math.abs(n.x+n.y-before)<.01?n.stuck+dt:0;
      if(n.stuck>3||d>1400){n.x=tx;n.y=ty;n.stuck=0}
    }else{
      /* varış: iş animasyonu ve gizlenme */
      n.hidden=!!r[6];
      if(!n.hidden){
        n.t-=dt;
        if(r[5]||r[3]){n.f=0}
        if(n.t<=0){
          n.t=rnd(5,9);
          if(Math.hypot(n.x-P.x,n.y-P.y)<110)fl(n.x+8,n.y-26,r[3],'#fff');
        }
      }
    }
  },
  line(n){
    const r=this.activity(n);if(!r||!n.job)return null;const s=this.state(n.n),t=this.fmt(this.hour());
    if(s.hunger>=NPC_NEEDS_CONFIG.thresholds.meal-5)return `🍲 ${n.n} açlık bastırmaya çalışıyor (${t})`;
    if(s.fatigue>=NPC_NEEDS_CONFIG.thresholds.rest-8)return `💤 ${n.n} çok yorgun (${t})`;
    if(s.safety<NPC_NEEDS_CONFIG.thresholds.safety+10)return `🏠 ${n.n} kendini güvende hissetmiyor (${t})`;
    return `${r[3]} ${r[4]} (${t})`;
  },
  settleDay(){
    let tax=0;
    const townNpcs=WORLD_DATA.home?.npcs||[],s=FARM.seasonIdx();
    // Uyku iç mekânda gerçekleşir; global npcs o sırada boştur. Günlük ekonomi her zaman kasaba listesini kullanmalı.
    for(const n of townNpcs){
      if(n.job===undefined)this.attach(n);
      const j=n.job;if(!j)continue;
      let inc=j.base*(.7+Math.random()*.7)*(1+(this.level[n.n]-1)*.35);
      if(n.n==='Çiftçi Dede')inc*=[1,1.2,1.4,.5][s];
      if(n.n==='Aylin')inc*=[1.4,1.2,1,.4][s];
      if(n.n==='Ozan Can')inc*=1.15;
      inc=Math.round(inc);
      if(j.shop){const t=Math.round(inc*.1);inc-=t;tax+=t}
      this.lastIncome[n.n]=inc;this.wallets[n.n]=(this.wallets[n.n]||0)+inc;
    }
    this.lastIncome['Muhtar Hamdi']=(Number(this.lastIncome['Muhtar Hamdi'])||0)+tax;
    this.wallets['Muhtar Hamdi']=(Number(this.wallets['Muhtar Hamdi'])||0)+tax;
    for(const n of townNpcs){
      if(!n.job||!n.job.shop)continue;
      const lv=this.level[n.n],cost=lv*450;
      if(lv<3&&this.wallets[n.n]>=cost){
        this.wallets[n.n]-=cost;this.level[n.n]++;
        const m=`${n.n} dükkânını genişletti! (Seviye ${this.level[n.n]})`;
        this.log.unshift(`Gün ${P.day}: ${m}`);
        setTimeout(()=>chat('KASABA','🏘️',m,1),1500);
      }
    }
    this.log=this.log.slice(0,6);
  },
  ui(){
    let m=document.getElementById('town-ledger');
    if(!m){
      m=document.createElement('div');m.id='town-ledger';
      m.style.cssText='position:fixed;inset:0;z-index:9000;display:flex;align-items:center;justify-content:center;background:rgba(5,10,20,.62)';
      m.onclick=e=>{if(e.target===m)m.style.display='none'};
      document.body.appendChild(m);
    }
    const h=this.hour(),rows=npcs.filter(n=>n.job).map(n=>{
      const r=this.activity(n),s=this.state(n.n),lv=n.job.shop?` · Dükkân Sv.${this.level[n.n]}`:'';
      const open=n.job.shop?(this.isOpen(n.job.shop)?'<span style="color:#86efac">● Açık</span>':'<span style="color:#fca5a5">● Kapalı</span>'):'';
      return `<div style="display:flex;gap:8px;align-items:center;padding:7px 0;border-bottom:1px solid #2a3a5a">
        <div style="font-size:22px;width:30px;text-align:center">${r[3]}</div>
        <div style="flex:1;min-width:0"><b>${n.n}</b> <small style="color:#9fb3d9">${n.job.job} · ${n.job.temperament}${lv}</small> ${open}<br>
        <small style="color:#cbd5e1">${r[4]}</small><br><small style="color:#a7c0cb">${this.needsText(n.n)}</small></div>
        <div style="text-align:right"><b style="color:#ffd23f">${this.wallets[n.n]}g</b><br><small style="color:#86efac">+${this.lastIncome[n.n]} dün</small></div></div>`}).join('');
    const lg=this.log.length?`<div style="margin-top:8px;font-size:12px;color:#fde68a">${this.log.map(x=>'🏘️ '+x).join('<br>')}</div>`:'';
    m.innerHTML=`<div style="background:#0f1a2e;color:#e5edff;border:2px solid #4a5d94;border-radius:10px;padding:14px 16px;width:min(92vw,430px);max-height:86vh;overflow:auto;font-family:sans-serif">
      <div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:16px">📒 Kasaba Defteri</b><button id="tl-x" style="background:#243455;color:#fff;border:0;border-radius:6px;padding:4px 10px;cursor:pointer">✖</button></div>
      <small style="color:#9fb3d9">Saat ${this.fmt(h)} · Muhtar, esnafın kazancından %10 vergi alır. Gece olunca herkes evine çekilir.</small>${rows}${lg}</div>`;
    m.style.display='flex';m.querySelector('#tl-x').onclick=()=>m.style.display='none';
  }
};
window.addEventListener('keydown',e=>{
  // Kasaba Defteri: Y tuşu (K zaten Yetenek 1 tuşu; çakışma yetenek kullanırken ekranı kaplıyordu). Esc ile kapanır.
  const m=document.getElementById('town-ledger');
  if(e.key==='Escape'&&m&&m.style.display==='flex'){m.style.display='none';return}
  if((e.key==='y'||e.key==='Y')&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&curMap==='home'&&!/INPUT|TEXTAREA/.test((e.target||{}).tagName||'')){
    if(m&&m.style.display==='flex')m.style.display='none';else TOWN_LIFE.ui();
  }
});

function updNpcs(dt){
  for(const n of npcs){
    if(curMap==='home'&&n.job===undefined)TOWN_LIFE.attach(n);
    if(n.job){TOWN_LIFE.update(n,dt);continue}
    if(n.stationary)continue;
    n.t-=dt;n.sw=Math.max(0,n.sw-dt);
    if(n.t<=0){
      n.tx=n.bx+rnd(-90,90);n.ty=n.by+rnd(-70,70);n.t=rnd(2,6);
      if(Math.random()<.3){n.sw=.28;spark(n.x+8,n.y-12,5,'#9fe9ff',50)}
    }
    const dx=n.tx-n.x,dy=n.ty-n.y,d=Math.hypot(dx,dy);
    if(d>4){mv(n,dx/d*30*dt,dy/d*30*dt,4);n.f=dirOf(dx,dy);n.w+=dt*8}
  }
}

const CM=[
  "Ejder İni'ne party arıyorum!","Göl'de Kraliyet Koi yakaladım!","Satıyorum: Efsanevi Kılıç [+3] 600g",
  "Selam herkese 👋","Demirci Boran yine kılıcımı yaktı haha","Slime farmı çok iyi","Kızıl Ejder'i kim kesecek?",
  "+1 party LF healer","Çöl'de kum golemi kestim nefisti","Yeni başlayanlar tapınaktan kutsama alsın!"
];
const TOWN_CHAT={
  Melis:['Fırından taze ekmek çıktı; buğdayın varsa gel!','Gözcünün kervanı için un hazırlıyorum.'],
  'Amca Osman':['Pazardaki taze sebzelere bak!','Kasaba yolunu geçen kervanlar daha çok ürün getirir.'],
  Aylin:['Yağmur adaçayını güçlendirir; Yayla haritasına bak.','Çiçeklerin büyümesi mevsime göre değişir.'],
  'Çiftçi Dede':['Önce evini tanı, sonra pazardan erzak al.','Sulama kabı boşsa kuyunun yanına git.'],
  'Ozan Can':['Doğu kapısından ormana giden eski bir yol var.','Pazardaki herkesin anlatacak bir hikâyesi var.'],
  'Muhtar Hamdi':['Önce evi, sonra yol. Ejder bekleyebilir.','Kül her sabah biraz daha yakın. Acele etme, hazırlan.','Dönüşünü belediye önünde dinlemek istiyorum.']
};
let chL=[],chT=6;
function chat(n,tg,m,sys){
  chL.push(`<span style="color:${sys?'#ffd23f':'#9fe9ff'}">${escapeHTML(tg)} ${escapeHTML(n)}</span>: ${escapeHTML(m)}`);
  if(chL.length>2)chL.shift();
  const chEl=$('ch');chEl.innerHTML=chL.join('<br>');chEl.style.opacity=1;
  clearTimeout(chat.t);chat.t=setTimeout(()=>{chEl.style.opacity=0},sys?7000:6000);
}
const NOTIFICATIONS=window.NOTIFICATIONS={
  init(){if(!P.adventure)return[];P.adventure.notifications=Array.isArray(P.adventure.notifications)?P.adventure.notifications.slice(-40):[];P.adventure.notificationMode=P.adventure.notificationMode==='quiet'?'quiet':'normal';this.updateBadge();return P.adventure.notifications},
  mode(){return P.adventure?.notificationMode==='quiet'?'quiet':'normal'},
  push(type,icon,title,text){if(!P.adventure)return;const list=this.init(),entry={id:Date.now()+Math.floor(Math.random()*1000),day:P.day||1,type:String(type||'info'),icon:String(icon||'🔔'),title:String(title||'Bildirim').slice(0,100),text:String(text||'').slice(0,500),read:false};list.push(entry);if(list.length>40)list.splice(0,list.length-40);this.updateBadge();sv();return entry},
  unread(){return(P.adventure?.notifications||[]).filter(n=>!n.read).length},
  updateBadge(){const el=$('notice-count');if(!el)return;const n=this.unread();el.textContent=String(Math.min(99,n));el.classList.toggle('h',n===0);$('bnotices')?.setAttribute('aria-label',`Bildirim merkezini aç · ${n} okunmamış`)},
  ui(){const list=(P.adventure?.notifications||[]).slice().reverse(),unread=this.unread();$('notifications-summary').textContent=unread?`${unread} okunmamış · son ${list.length} kayıt`:`Okunmamış bildirim yok · son ${list.length} kayıt`;$('notifications-list').innerHTML=list.length?list.map(n=>`<div class="notice-item ${n.read?'':'unread'}"><div class="notice-head"><b>${escapeHTML(n.icon)} ${escapeHTML(n.title)}</b><small>Gün ${n.day}</small></div><p>${escapeHTML(n.text)}</p></div>`).join(''):'<div class="journey-box">Henüz kayıtlı bildirim yok.</div>';this.updateBadge()},
  open(){$('notifications-modal').classList.remove('h');this.ui()},
  readAll(){for(const n of P.adventure?.notifications||[])n.read=true;sv();this.ui()},
  clear(){P.adventure.notifications=[];sv();this.ui()}
};
const MODAL_QUEUE=window.MODAL_QUEUE={
  items:[],keys:new Set(),active:null,nextAt:0,
  enqueue(key,priority,modalId,show){if(NOTIFICATIONS.mode()==='quiet'||this.keys.has(key)||this.active?.key===key)return false;this.keys.add(key);this.items.push({key,priority,modalId,show});return true},
  pump(){if(this.active){const el=$(this.active.modalId);if(!el||el.classList.contains('h'))this.done();else return}if(!this.items.length||!gameStarted||performance.now()<this.nextAt||document.querySelector('.ov:not(.h)')||$('bt').classList.contains('expanded')||!GAME_CORE.canTravel())return;this.items.sort((a,b)=>b.priority-a.priority);const item=this.items.shift();this.keys.delete(item.key);this.active=item;item.show()},
  done(){this.active=null;this.nextAt=performance.now()+1100}
};
function ban(t,c){
  const b=$('bn');b.textContent=t;b.style.color=c||'#fff';b.style.opacity=1;
  clearTimeout(ban.t);ban.t=setTimeout(()=>b.style.opacity=0,2400);
}
function advanceGuide(next){
  if(P.guideStep>=next||next>4||QUEST_FLOW.optional()||ONBOARD.active())return;
  P.guideStep=next;
  const msg=next===4?'İlk rota tamam! Şimdi Zümrüt Orman’da 6 Slime avla.':GUIDE_ROUTE[next].hint;
  chat('REHBER','',msg,1);
  ban(next===4?'📜 İlk görev: 6 Slime avla':`🧭 ${GUIDE_ROUTE[next].short}`,'#a7f3d0');
  sv();
}

