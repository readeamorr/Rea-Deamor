/* ===== KASABA SİPARİŞ PANOSU VE İTİBAR SİSTEMİ ===== */
const ORDER_POOL=[
  {id:'o_wheat',from:'Fırıncı Melis',icon:'🥖',reqK:'wheat',reqN:3,reqName:'3 Buğday',g:90,m:3,rep:25,desc:'Fırında taze ekmekler için 3 Buğday lazım!'},
  {id:'o_carrot',from:'Amca Osman',icon:'🥕',reqK:'carrot',reqN:3,reqName:'3 Havuç',g:110,m:4,rep:30,desc:'Kasabalılar taze havuç bekliyor: 3 Havuç getir!'},
  {id:'o_berry',from:'Fırıncı Melis',icon:'🍓',reqK:'berry',reqN:2,reqName:'2 Çilek',g:100,m:3,rep:25,desc:'Yeni meyveli pastalar için taze Çilek lazım!'},
  {id:'o_copper',from:'Demirci Boran',icon:'⛏️',reqK:'copper_ore',reqN:2,reqName:'2 Bakır Cevheri',g:130,m:5,rep:35,desc:'Kılıç dövmek için 2 Bakır Cevheri gerekiyor!'},
  {id:'o_fish',from:'Balıkçı Dede',icon:'🐟',reqK:'fish',reqN:2,reqName:'2 Balık',g:120,m:4,rep:30,desc:'Akşam köy ziyafeti için taze 2 Balık yakala!'},
  {id:'o_egg',from:'Fırıncı Melis',icon:'🥚',reqK:'egg',reqN:2,reqName:'2 Yumurta',g:120,m:4,rep:30,desc:'Kek ve börekler için 2 Köy Yumurtası lazım!'},
  {id:'o_milk',from:'Barista Melis',icon:'🥛',reqK:'milk',reqN:2,reqName:'2 Süt',g:140,m:4,rep:35,desc:'Sütlü kahveler için 2 Çiftlik Sütü lazım!'}
];

function getRepTier(rep){
  rep=rep||0;
  if(rep>=500)return{name:'Kasaba Kahramanı',tier:4,color:'#ffd23f',perk:'Katkı yaptığın günde belediye payı: 600 altın + 10 elmas.'};
  if(rep>=250)return{name:'Onurlu Çiftçi',tier:3,color:'#6ee7b7',perk:'Katkı yaptığın günde belediye payı: 280 altın + 5 elmas.'};
  if(rep>=100)return{name:'Kasabalı Dost',tier:2,color:'#38bdf8',perk:'Katkı yaptığın günde belediye payı: 140 altın + 2 elmas.'};
  return{name:'Yabancı',tier:1,color:'#94a3b8',perk:'İlk gün veya katkı yaptığın günde belediye payı: 50 altın.'};
}

function initOrders(){
  if(!P.orders||P.orders.length<4){
    P.orders=[];
    const shuffled=[...ORDER_POOL].sort(()=>Math.random()-.5);
    for(let i=0;i<4;i++)P.orders.push({...shuffled[i%shuffled.length],done:false});
  }
}

function boardUI(){
  initOrders();
  const tInfo=getRepTier(P.rep);
  $('rep-badge').innerHTML=`İtibar Puanı: <b>${P.rep||0}</b> · Rütbe: <b style="color:${tInfo.color}">${tInfo.name}</b><br><small style="color:#a7f3d0">Ayrıcalık: ${tInfo.perk}</small>`;
  let h='';
  P.orders.forEach((ord,idx)=>{
    const hasCount=countInv(ord.reqK);
    const canDeliver=hasCount>=ord.reqN&&!ord.done;
    h+=`<div class="ach-item">
      <div class="ach-info">
        <div class="ach-title">${ord.icon} ${ord.from}: "${ord.desc}"</div>
        <div class="ach-desc">İstenen: <b>${ord.reqName}</b> (${hasCount}/${ord.reqN})</div>
        <div class="ach-reward">Ödül: 🪙 +${ord.g} · 💎 +${ord.m} · ⭐ +${ord.rep} İtibar</div>
      </div>
      <div>
        ${ord.done?'<span style="color:#6ee7b7">✔ Teslim Edildi</span>':
          `<button class="m" data-ord="${idx}" style="padding:6px 12px;font-size:11px;margin:0;background:${canDeliver?'#16a34a':'#475569'}">${canDeliver?'Teslim Et (✔)':'Eksik'}</button>`}
      </div>
    </div>`;
  });
  $('board-orders').innerHTML=h;
}

$('board-orders').onclick=e=>{
  const idx=e.target.dataset.ord;
  if(idx===undefined)return;
  const ord=P.orders[+idx];
  if(!ord||ord.done)return;
  if(inventoryRecipe({[ord.reqK]:ord.reqN}).ok){
    ord.done=true;
    P.gold+=ord.g;P.gems+=ord.m;P.rep=(P.rep||0)+ord.rep;P.townWorkDay=P.day;
    fl(P.x,P.y-26,`+${ord.g}🪙 +${ord.m}💎 +${ord.rep} ⭐ İtibar!`, '#ffd23f', true);
    playChord([523,659,784,1046],.35,'triangle',.07);
    sv();boardUI();
  }else{
    fl(P.x,P.y-26,'Malzemeler eksik!','#ff5d5d');
    sfx(150,.15,'sawtooth',.05);
  }
};

