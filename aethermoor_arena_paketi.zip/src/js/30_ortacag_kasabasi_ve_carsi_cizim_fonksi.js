/* ===== ORTAÇAĞ KASABASI VE ÇARŞI ÇİZİM FONKSİYONLARI (REFERANS GÖRSELLER BİREBİR) ===== */
function marketStallD(x, y, c1, c2, label, icon){
  x = Math.round(x); y = Math.round(y);
  R(x-14, y-2, 28, 3, '#0002'); // gölge
  R(x-12, y-8, 24, 7, '#78350f'); // ahşap tezgah
  R(x-11, y-7, 22, 2, '#92400e');
  R(x-12, y-20, 2, 13, '#451a03'); // sol direk
  R(x+10, y-20, 2, 13, '#451a03'); // sağ direk
  // Çizgili Kumaş Tente
  for(let s=0; s<7; s++){
    const col = s % 2 === 0 ? c1 : c2;
    R(x-14 + s*4, y-22, 4, 9, col);
    R(x-14 + s*4, y-13, 3, 2, col);
  }
  // Ahşap meyve/sebze kasaları
  R(x-10, y-5, 6, 5, '#a16207'); R(x+4, y-5, 6, 5, '#ca8a04');
  if(label&&labelNear(x,y,42))T(icon+' '+label,x,y-28,'#ffd23f');
}

function chapelD(x, y){
  x = Math.round(x); y = Math.round(y);
  R(x-20, y, 40, 4, '#0003');
  R(x-18, y-22, 36, 22, '#64748b'); // taş duvarlar
  for(let i=0; i<6; i++) R(x-16+i*6, y-20+((i&1)*4), 5, 2, '#475569');
  R(x-6, y-14, 12, 14, '#3b200c'); // ahşap kapı
  R(x-5, y-13, 10, 12, '#52341b');
  R(x-1, y-10, 2, 4, '#facc15');
  R(x-4, y-20, 8, 5, '#38bdf8'); // vitray pencere
  R(x-3, y-19, 6, 3, '#f43f5e');
  R(x-2, y-18, 4, 1, '#fde047');
  for(let r=0; r<10; r++) R(x-20+r*2, y-22-r*2, 40-r*4, 2, '#334155'); // taş çatı
  // Çan kulesi & Altın Haç
  R(x-6, y-44, 12, 14, '#475569');
  R(x-4, y-40, 8, 8, '#1e293b');
  R(x-1, y-38, 2, 3, '#facc15'); // pirinç çan!
  for(let r=0; r<7; r++) R(x-7+r, y-44-r*2, 14-r*2, 2, '#1e293b');
  R(x-1, y-60, 2, 7, '#facc15'); // altın haç
  R(x-3, y-57, 6, 2, '#facc15');
  if(labelNear(x,y,76))T('Kasaba Şapeli ⛪',x,y-64,'#fde047');
}

function campfireD(x, y){
  x = Math.round(x); y = Math.round(y);
  R(x-8, y-4, 16, 6, '#475569');
  R(x-6, y-3, 12, 4, '#1e293b');
  R(x-6, y-3, 12, 2, '#78350f');
  R(x-3, y-5, 6, 5, '#92400e');
  const fl = Math.sin(P.t*20)*2;
  R(x-3, y-9+fl, 6, 6, '#ea580c');
  R(x-2, y-7+fl, 4, 4, '#fde047');
  // Kamp ateşi parçacıkları güncelleme saatine bağlıdır; menü açıkken birikmez.
  // Kütük oturaklar
  R(x-16, y-3, 4, 8, '#78350f');
  R(x+12, y-3, 4, 8, '#78350f');
  R(x-8, y+6, 16, 4, '#78350f');
}

function cartD(x, y){
  x = Math.round(x); y = Math.round(y);
  R(x-10, y-8, 20, 8, '#854d0e');
  R(x-9, y-7, 18, 6, '#a16207');
  R(x-6, y-9, 4, 3, '#4ade80'); R(x-1, y-10, 4, 4, '#ea580c'); R(x+4, y-9, 4, 3, '#facc15');
  R(x-8, y-3, 5, 5, '#451a03'); R(x+4, y-3, 5, 5, '#451a03');
}

function wellD(x,y){
  x=Math.round(x);y=Math.round(y);
  R(x-6,y-8,12,8,'#64748b');R(x-5,y-7,10,3,'#1e293b');R(x-4,y-6,8,2,'#38bdf8');
  R(x-6,y-14,2,7,'#78350f');R(x+4,y-14,2,7,'#78350f');
  R(x-8,y-17,16,4,'#854d0e');R(x-6,y-19,12,3,'#a16207');
  if(labelNear(x,y,44))T('Su Kuyusu 💧',x,y-22,'#38bdf8');
}

function watermillD(x,y){
  x=Math.round(x);y=Math.round(y);
  // Değirmen binası
  R(x-14,y-16,28,16,'#854d0e');R(x-16,y-22,32,6,'#78350f');R(x-12,y-26,24,5,'#a16207');
  R(x-4,y-10,8,10,'#451a03');
  // Dönen ahşap su çarkı
  const wheelA = P.t*3;
  const wx = x+16, wy = y-6;
  R(wx-1,wy-8,2,16,'#451a03');R(wx-8,wy-1,16,2,'#451a03');
  for(let a=0;a<6.28;a+=1.57){
    const wa = a + wheelA;
    R(wx+Math.cos(wa)*7-1,wy+Math.sin(wa)*7-1,3,3,'#ca8a04');
  }
  // Su köpükleri
  // Su köpüğü FX yayıcısından gelir.
  if(labelNear(x,y,64))T('Su Değirmeni 🌊',x,y-28,'#38bdf8');
}

function fruitTreeD(x,y,isPeach,fruitReady,treeType){
  x=Math.round(x);y=Math.round(y);
  const tDef=ORCHARD_TREES[treeType||(isPeach?'peach':'apple')]||ORCHARD_TREES.apple;
  const pal=tDef.foliage||['#2a6428','#3a8133','#4fa044'];
  R(x-6,y-2,12,3,'#0003');
  R(x-2,y-8,4,8,'#6b4a2a');R(x-1,y-8,1,8,'#8a6238');
  R(x-10,y-18,20,10,pal[0]);
  R(x-8,y-24,16,8,pal[1]);
  R(x-5,y-29,10,6,pal[2]);
  if(fruitReady){
    const fCol = tDef.fruitCol||(isPeach?'#fb7185':'#ef4444');
    R(x-6,y-16,3,3,fCol);R(x+4,y-15,3,3,fCol);
    R(x-4,y-22,3,3,fCol);R(x+2,y-23,3,3,fCol);
    R(x-1,y-26,3,3,fCol);
  }
}

function lampD(x,y){
  x=Math.round(x);y=Math.round(y);
  R(x-1,y-12,2,12,'#334155');R(x-3,y-15,6,3,'#475569');R(x-2,y-18,4,4,'#fde047');
  // Dinamik aydınlatma sprite önbelleğine gömülmez; FX kaynak listesinde her kare güncellenir.
}

function duckD(d){
  const x=Math.round(d.x),y=Math.round(d.y),f=d.f||1;
  const bob=Math.sin(P.t*5+d.id)*1.5;
  R(x-4,y-3+bob,8,3,'#15803d'); // yeşil gövde
  R(x+f*3,y-5+bob,3,3,'#166534'); // baş
  R(x+f*5,y-4+bob,2,1,'#f59e0b'); // gaga
  R(x-f*3,y-4+bob,2,2,'#b45309'); // kanat
}

function beehiveD(x,y){
  x=Math.round(x);y=Math.round(y);
  R(x-6,y-8,12,8,'#ca8a04');
  R(x-7,y-11,14,3,'#a16207');
  R(x-2,y-3,4,2,'#451a03');
  if(P.honeyReady){
    R(x-2,y-15,4,4,'#ffd23f');
    R(x-1,y-14,2,2,'#fff');
  }
  for(let b=0;b<3;b++){
    const ba=P.t*5+b*2.1;
    R(x+Math.cos(ba)*9,y-8+Math.sin(ba)*5,2,1,'#fde047');
  }
  if(labelNear(x,y,48))T('Arı Kovanı 🐝',x,y-20,'#ffd23f');
}

function caskD(x,y){
  x=Math.round(x);y=Math.round(y);
  R(x-7,y-10,14,10,'#854d0e');
  R(x-8,y-8,16,2,'#64748b');
  R(x-8,y-4,16,2,'#64748b');
  if(P.caskReady){
    R(x-2,y-14,4,4,'#facc15');
    if(labelNear(x,y,50))T('★ HAZIR!',x,y-16,'#ffd23f');
  }else if(P.caskItem){
    // Mayalanma buharı FX yayıcısından gelir.
    if(labelNear(x,y,50))T('🛢️ Mayalanıyor',x,y-16,'#38bdf8');
  }else{
    if(labelNear(x,y,50))T('Fıçı 🛢️',x,y-14,'#cbd5e1');
  }
}

const CASK_RECIPES={
  berry:{needs:{berry:1},seconds:40,nights:1,item:{s:'food',k:'jam',n:'Çilek Reçeli',icon:'🫙',hp:70,mp:50,buff:'crit',duration:360,desc:'+70 Can · +50 Mana · 6 dk kritik desteği',val:65}},
  carrot:{needs:{carrot:1},seconds:40,nights:1,item:{s:'food',k:'pickles',n:'Havuç Turşusu',icon:'🥒',hp:90,mp:0,buff:'def',duration:360,desc:'+90 Can · 6 dk savunma desteği',val:85}},
  wheat:{needs:{wheat:1},seconds:40,nights:1,item:{s:'food',k:'malt',n:'Köy Maltı',icon:'🍺',hp:60,mp:0,buff:'atk',duration:360,desc:'+60 Can · 6 dk saldırı desteği',val:60}},
  grape:{needs:{grape:2},seconds:120,nights:2,item:{s:'food',k:'wine',n:'Yayla Üzüm Şarabı',icon:'🍷',hp:20,mp:60,buff:'crit',duration:360,desc:'+20 Can · +60 Mana · 6 dk kritik desteği. Değerli zanaat ürünü.',val:190}},
  ancient_fruit:{needs:{ancient_fruit:1},seconds:120,nights:2,item:{s:'food',k:'nectar',n:'Kraliyet Aether Nektarı',icon:'👑',hp:160,mp:100,buff:'atk',duration:600,desc:'+160 Can · +100 Mana · 10 dk Saldırı desteği. Efsanevi zanaat ürünü.',val:420}}
};
const CASK=window.CASK={
  start(type){
    const recipe=CASK_RECIPES[type];if(!recipe||P.caskItem||!P.hasCask)return false;
    if(!tryInventoryRecipe(recipe.needs))return false;
    P.caskItem=type;P.caskTimer=recipe.seconds;P.caskReadyDay=P.day+recipe.nights;P.caskReady=false;
    sfx(600,.12,'triangle',.04);sv();return true;
  },
  collect(){
    const recipe=CASK_RECIPES[P.caskItem];if(!P.caskReady||!recipe)return false;
    const output={...recipe.item};if(!ITEMS.add(P.inv,output)){inventoryWarning('Çanta dolu; hazır ürün fıçıda kalacak.');return false}
    P.caskItem=null;P.caskReady=false;P.caskTimer=0;P.caskReadyDay=0;
    $('cask-modal').querySelector('[data-inventory-feedback]')?.remove();addMasteryXp('cook',18);
    fl(P.x,P.y-26,`+${output.icon} ${output.n}!`,'#f0d58a',true);playChord([523,659,784],.25,'triangle',.05);sv();return true;
  }
};
function caskUI(){
  const current=CASK_RECIPES[P.caskItem];let h='';
  if(current&&P.caskReady)h=`<div class="journey-lead"><h2>${current.item.icon} ${current.item.n} Hazır!</h2><p>Anlık satış: ${unitSaleValue(current.item)}🪙. Çanta doluyken ürün fıçıda korunur.</p><button id="btn-collect-cask">✓ Ürünü Topla</button></div>`;
  else if(current)h=`<div class="journey-lead"><h2>🛢️ ${current.item.n}</h2><p>Kalan ${Math.ceil(P.caskTimer)} saniye aktif oyun süresi<br>veya ${Math.max(1,(P.caskReadyDay||P.day+1)-P.day)} gece uyku.</p><p>Kasaba dışında keşifteyken de ilerler; menülerde durur.</p></div>`;
  else h=`<p>Tarif seç; gerekli mahsuller bir defada tüketilir.</p>${Object.entries(CASK_RECIPES).map(([key,r])=>`<div class="journey-box"><b>${r.item.icon} ${r.item.n}</b><p>${Object.entries(r.needs).map(([k,n])=>`${countInv(k)}/${n} ${CROPS[k].n}`).join(' · ')}<br>${r.seconds} saniye veya ${r.nights} gece · Anlık değer: ${unitSaleValue(r.item)}🪙</p><button data-cask="${key}">İşlemeye Başla</button></div>`).join('')}`;
  $('cask-content').innerHTML=h;
  if($('btn-collect-cask'))$('btn-collect-cask').onclick=()=>{CASK.collect();caskUI()};
}
$('cask-content').onclick=e=>{const type=e.target.closest('[data-cask]')?.dataset.cask;if(type){CASK.start(type);caskUI()}};


