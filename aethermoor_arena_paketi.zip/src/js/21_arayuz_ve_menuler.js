/* ===== ARAYÜZ VE MENÜLER ===== */
const MM=$('mm').getContext('2d'),MB=$('mb').getContext('2d');
let ut=0;

function updateCombatTarget(){
  const panel=$('combat-target');if(!panel)return;
  const targets=(mobs||[]).filter(e=>!e.dead&&!e.d.boss&&Math.hypot(e.x-P.x,e.y-P.y)<190);
  if(P.dead||curMap==='home'||curMap==='inside'||!targets.length){panel.classList.add('h');document.body.classList.remove('combat-on');return}
  const priority=e=>(e.st==='wind'?500:e.staggeredT>0?450:e.st==='rec'?350:e.st==='chase'?250:0)-Math.hypot(e.x-P.x,e.y-P.y);
  targets.sort((a,b)=>priority(b)-priority(a));const e=targets[0];
  let text='Yakında',cls='';
  if(e.staggeredT>0){text='💫 SERSEM · SALDIR';cls='open'}
  else if(e.st==='wind'){text='⚠ SALDIRI GELİYOR';cls='danger'}
  else if(e.st==='rec'&&e.lu>0){text='❗ ATILIYOR · SIYRIL';cls='danger'}
  else if(e.st==='rec'){text='✓ AÇIK · SALDIR';cls='open'}
  else if((e.lv||e.d.lv)>=P.lvl+4){text='☠ ÇOK GÜÇLÜ';cls='danger'}
  else if(e.st==='chase')text='Seni takip ediyor';
  const variant=ENCOUNTER_VARIANTS.label(e);$('combat-target-name').textContent=`${variant?variant+' ':''}${e.d.n} · Sv.${e.lv||e.d.lv}`;
  $('combat-target-state').textContent=text;$('combat-target-state').className='combat-target-state '+cls;
  $('combat-target-hp').style.width=cl(e.hp/e.mhp,0,1)*100+'%';
  $('combat-target-stagger').style.width=cl((e.stagger||0)/(e.maxStagger||(e.el?90:50)),0,1)*100+'%';
  document.body.classList.add('combat-on');
  const lesson=$('combat-training'),training=COMBAT.training();
  if(training&&!training.done){lesson.innerHTML=`<b>İlk dövüş</b> · ${training.hits||0}/3 vuruş · ${training.dodge?'✓':'○'} sıyrıl · ${training.skill?'✓':'○'} yetenek · bitince +1 iksir`;lesson.classList.remove('h')}else lesson.classList.add('h');
  panel.classList.remove('h');
}

function ui(dt){
  ut-=dt;if(ut>0)return;ut=.1;
  S=st();P.hp=Math.min(P.hp,S.h);
  FARM.tick(dt);updHotbarUI();
  
  const curCls=CLASSES[P.cls]||CLASSES.warrior;
  const hero=window.STORY&&STORY.hero&&STORY.hero();$('nm').textContent=(hero?hero+' · ':curCls.name+' ')+'Sv.'+P.lvl;$('nm').title=(hero?hero+' · ':'')+curCls.name+' · '+JOURNAL.label();
  $('btalent').classList.toggle('h',!P.talentQueue.length);$('btalent').title='Bekleyen yetenek seçimleri: '+P.talentQueue.length;
  $('bride').classList.toggle('h',!P.adventure.roster.some(r=>BOND.species[r.type].mount));
  $('bride').textContent=P.adventure.mounted?'🚶':'🐐';
  $('mount-status').classList.toggle('h',!P.adventure.mounted||$('bt').classList.contains('expanded'));
  $('mount-status').textContent=`🐐 ${Math.floor(P.adventure.energy)}%`;
  FX.setBar('hp',P.hp/S.h);FX.setBar('rg',Math.min(100,P.rage||0)/100);
  const peaceful=curMap==='home'||curMap==='inside';
  if($('bUlt')) $('bUlt').classList.toggle('h', peaceful || (P.rage||0) < 100);
  if($('bS')) $('bS').classList.toggle('h', peaceful);
  if($('bI')) $('bI').classList.toggle('h', peaceful);
  FX.setBar('mp',P.mp/S.m);FX.setBar('xp',P.xp/xpn(),P.lvl);
  $('gm').textContent=P.gems;$('gd').textContent=P.gold;$('pc').textContent=P.pots;
  updateCombatTarget();
  const lowHealth=!P.dead&&P.hp>0&&P.hp<=S.h*.3;
  document.body.classList.toggle('low-health',lowHealth&&P.pots>0);
  if(!lowHealth)P.lowHpWarned=false;
  const training=P.adventure?.combatTraining,hasCombatTarget=(mobs||[]).some(e=>!e.dead&&Math.hypot(e.x-P.x,e.y-P.y)<190),trainingActive=!!training&&!training.done&&!P.dead&&P.combatTimer>0&&hasCombatTarget;
  const trainHit=trainingActive&&(training.hits||0)<3,trainDodge=trainingActive&&!trainHit&&!training.dodge,trainSkill=trainingActive&&!trainHit&&!trainDodge&&!training.skill;
  document.body.classList.toggle('train-hit',trainHit);document.body.classList.toggle('train-dodge',trainDodge);document.body.classList.toggle('train-skill',trainSkill);
  
  const q=QS[P.q];
  const quest=q?.k==='any'&&P.bounties>0&&P.lastBountyDay===P.day?
    '✓ Günlük av bitti · serbest yaşam':q?`${QUEST_FLOW.optional()?'◇ Serbest':'📜'} ${q.t} ${P.qn}/${q.n}`:'◇ Serbest yaşam · hedefini seç';
  const introStep=ONBOARD.current();
  const introCount=introStep&&introStep.id==='forest'&&QS[P.q]?.k==='slime'?` ${Math.min(P.qn||0,6)}/6`:introStep&&introStep.id==='chest'?` · odun ${Math.min(countInv('wood'),10)}/10`:'' ;
  const guide=introStep?{short:(ONBOARD.steps.indexOf(introStep)+1)+'/'+ONBOARD.steps.length+' · '+introStep.label+introCount,hint:introStep.hint}:P.guideStep<4&&!QUEST_FLOW.optional()&&['home','inside','world'].includes(curMap)?GUIDE_ROUTE[P.guideStep]:null;
  const storyHome=window.STORY&&STORY.cueHome&&STORY.cueHome();
  const nav=navigationCue(),objective=storyHome?'Hamdi’nin kapısına dön':guide?guide.short:quest,pinned=!ONBOARD.active()?GOALS.pinnedCue():null,expedition=EXPEDITIONS.state();
  const expProgress=expedition?EXPEDITIONS.defs[expedition.id].objectives.reduce((n,o)=>n+Math.min(o.need,expedition.progress[o.id]||0),0):0,expTotal=expedition?EXPEDITIONS.defs[expedition.id].objectives.reduce((n,o)=>n+o.need,0):0;
  const night=window.STORY&&STORY.resting&&STORY.resting(),morning=window.STORY&&STORY.morningDue&&STORY.morningDue(),job=window.STORY&&STORY.mastery&&STORY.mastery();
  const action=storyHome?'Hamdi’nin kapısına dön':night?'Bu gece kasabadasın':morning?'Sabah: bir iş seç':job==='mine'?'Kristal madeni':job==='frontier'?'Sisli yayla':job==='elite'?quest:window.STORY&&STORY.needsRest&&STORY.needsRest()?'Eve dön, sabahı aç':window.STORY&&STORY.needsOasis&&STORY.needsOasis()?'Vahada nefes al':objective||quest||'Hedefin';
  const sub=[nav?`${nav.icon} ${nav.text}`:'',expedition?`Sefer ${expProgress}/${expTotal}`:'',pinned?`${pinned.icon} %${pinned.pct}`:''].filter(Boolean).join(' · ');
  const chInfo=window.chapterAt?chapterAt(P.q):null;
  const hero1=introStep?`▶ ${introStep.label}`:action;
  const subParts=[];
  if(introStep)subParts.push('İlk yolculuk '+(ONBOARD.steps.indexOf(introStep)+1)+'/'+ONBOARD.steps.length);
  else if(chInfo)subParts.push(chInfo.short);
  if(sub)subParts.push(sub);
  const bar=`<b>${escapeHTML(hero1)}</b>${subParts.length?`<span>${escapeHTML(subParts.join(' · '))}</span>`:''}`;
  if($('qs').dataset.bar!==bar){$('qs').dataset.bar=bar;$('qs').innerHTML=bar}
  $('qs').title=(storyHome?'Hamdi kapıda. Rapor yok, bir nefes yeter. ':'')+(night?'Bu gece hiçbir iş yok. ':'')+(morning?'Tarlaya bak, Melis’e uğra, bir iş seç. ':'')+(job==='mine'?'Bugünün uzun işi maden. ':'')+(job==='frontier'?'Bugünün uzun işi yayla. ':'')+(job==='elite'?'Bugünün uzun işi seçkin sırt. ':'')+(guide?`${guide.hint} · ${quest}`:quest)+(nav?` · Yön: ${nav.text}`:'')+(expedition?` · Sefer: ${EXPEDITIONS.defs[expedition.id].name} ${expProgress}/${expTotal}`:'')+(pinned?` · Takipte: ${pinned.name} %${pinned.pct}`:'');
  $('qs').setAttribute('aria-label',objective+' ayrıntısını ve yol tarifini aç');
  
  const cData=CLASSES[P.cls]||CLASSES.warrior;
  $('cS').style.height=cl(P.cs/5.5,0,1)*100+'%';
  $('cI').style.height=cl(P.ci/6.5,0,1)*100+'%';
  $('cP').style.height=cl(P.cp/1.2,0,1)*100+'%';
  $('cD').style.height=cl(P.cd2/2.4,0,1)*100+'%';
  
  $('bS').style.opacity=P.mp>=cData.s1Mp?1:.5;
  $('bI').style.opacity=P.mp>=cData.s2Mp?1:.5;
  $('bD').style.opacity=P.cd2>0?.5:1;
  
    // Doğrudan Canlı Etkileşim Butonu (Proximity Action Engine)
  let pText = null, pFn = null;

  if(curMap==='mine'){
    $('bsh').classList.add('h');$('bfg').classList.add('h');$('bpr').classList.add('h');$('bbd').classList.add('h');$('bst').classList.add('h');
    const md = WORLD_DATA.mine;
    if(md?.floor%5===0&&Math.hypot(P.x-6*TS,P.y-4*TS)<29){
      pText=`🛗 Asansör (Kat 1 - ${P.mineElevator||1})`;
      pFn=openElevatorModal;
    }else if(Math.hypot(P.x-4*TS,P.y-4*TS)<36){
      const worldExit=P.mineEntrance==='world';
      pText=worldExit?'🪜 Yüzeye Çık (Kül Geçidi)':'🪜 Yüzeye Çık (Kasaba Madeni)';
      pFn=()=>{
        if(worldExit){if(switchMap('world','center')){P.x=(WORLD_MINE.x+.5)*TS;P.y=(WORLD_MINE.y+2.5)*TS}}
        else if(switchMap('home')){P.x=6*TS;P.y=9*TS}
        P.f=0;
      };
    }else if(md?.ladder?.uncovered&&md.floor<50&&Math.hypot(P.x-md.ladder.x,P.y-md.ladder.y)<30){
      pText=`🪜 ${md.floor+1}. Kata İn`;
      pFn=descendMineFloor;
    }
  }else if(curMap==='inside'){
    $('bsh').classList.add('h');$('bfg').classList.add('h');$('bpr').classList.add('h');$('bbd').classList.add('h');
    const dStove = Math.hypot(P.x - 7*TS, P.y - 14*TS);
    $('bck').classList.toggle('h', dStove > 40);
    const dStor = Math.hypot(P.x - 7*TS, P.y - 20*TS);
    $('bst').classList.toggle('h', dStor > 40);
    const dTv = Math.hypot(P.x - 8*TS, P.y - 8*TS);
    $('btv').classList.toggle('h', dTv > 40);
    const dGram = Math.hypot(P.x - 23*TS, P.y - 14*TS);
    $('bgm').classList.toggle('h', dGram > 40);
    const dWorkbench = Math.hypot(P.x - 18*TS, P.y - 22*TS);
    $('bhs').classList.toggle('h', dWorkbench > 45);
    $('bcf').classList.add('h');$('bmk').classList.add('h');

    if(Math.hypot(P.x-15*TS, P.y-24*TS) < 26){
      pText = '🚪 Dışarı Çık (Çiftliğe Dön)';
      pFn = () => { if(switchMap('home')){P.x=14*TS; P.y=25*TS; P.f=0;} };
    }else if(Math.hypot(P.x-22*TS, P.y-8*TS) < 24){
      pText = DAY_CLOCK.late()?'🛏️ Uyu & Sabah Yap':'🛏️ Gece yarısından sonra uyu';
      pFn = sleepInBed;
    }else if(Math.hypot(P.x-18*TS, P.y-22*TS) < 28){
      pText = '🔨 Evi Geliştir (Tadilat)';
      pFn = () => { $('house-modal').classList.remove('h'); houseUI(); };
    }else if(Math.hypot(P.x-8*TS, P.y-8*TS) < 25){
      pText = '📺 Retro TV Bülteni';
      pFn = () => { $('tv-modal').classList.remove('h'); tvUI('weather'); };
    }else if(Math.hypot(P.x-23*TS, P.y-14*TS) < 25){
      pText = '📻 Gramofon & Plaklar';
      pFn = () => { $('gramophone-modal').classList.remove('h'); gramophoneUI(); };
    }else if(Math.hypot(P.x-7*TS, P.y-14*TS) < 25){
      pText = '🍳 Mutfak Ocağı (Yemek Pişir)';
      pFn = () => { $('cook-modal').classList.remove('h'); cookUI(); };
    }else if(Math.hypot(P.x-7*TS, P.y-20*TS) < 25){
      pText = '📦 Kiler Sandığı';
      pFn = () => { $('storage-modal').classList.remove('h'); storageUI(); };
    }else{
      const step=ONBOARD.current();
      if(step&&step.id==='cook'){pText='🍳 Ocağa yaklaş · soldaki tezgah';pFn=()=>ban('Ocak batı duvarında.','#fde68a')}
      else if(step&&step.id!=='home'){pText='🚪 Dışarı Çık · sıradaki adım dışarıda';pFn=()=>{if(switchMap('home')){P.x=14*TS;P.y=25*TS;P.f=0}}}
      else if(window.STORY&&STORY.needsRest&&STORY.needsRest()){pText='🛏️ Yatağa git · sabahı aç';pFn=()=>ban('Yatak sağ üst köşede.','#93c5fd')}
    }
  }else if(curMap==='home'){
    $('bsh').classList.add('h');$('bpr').classList.add('h');
    $('btv').classList.add('h');$('bgm').classList.add('h');
    const dHome=Math.hypot(P.x-14*TS,P.y-24*TS);
    $('bck').classList.toggle('h',dHome>50);
    $('bhs').classList.toggle('h',dHome>50);
    const dCafe=Math.hypot(P.x-27*TS,P.y-25*TS);
    $('bcf').classList.toggle('h',dCafe>50);
    const dCask=Math.hypot(P.x-19*TS,P.y-35*TS);
    $('bcs').classList.toggle('h',dCask>50||!P.hasCask);
    const dMill=Math.hypot(P.x-48*TS,P.y-22*TS);
    $('bml').classList.toggle('h',dMill>50);
    const dForgeHome=Math.hypot(P.x-50*TS,P.y-39*TS);
    $('bfg').classList.toggle('h',dForgeHome>56);
    const dBot=Math.hypot(P.x-27*TS,P.y-33*TS);
    $('bbt').classList.toggle('h',dBot>50);
    const dMkt=Math.hypot(P.x-35*TS,P.y-25*TS);
    const dChapel=Math.hypot(P.x-31*TS,P.y-14*TS);
    $('bchp').classList.toggle('h', dChapel > 55);
    const dTavern=Math.hypot(P.x-20*TS,P.y-40*TS);
    $('btav').classList.toggle('h', dTavern > 55);
    const dTownHall=Math.hypot(P.x-18*TS,P.y-14*TS);
    $('bth').classList.toggle('h', dTownHall > 55);
    $('bmk').classList.toggle('h',dMkt>50);
    const dLib = Math.hypot(P.x - 50*TS, P.y - 26*TS);
    $('blb').classList.toggle('h', dLib > 60);
    const dBoard=Math.hypot(P.x-31*TS,P.y-24*TS);
    $('bbd').classList.toggle('h',dBoard>50);
    const dStorage=Math.hypot(P.x-14*TS,P.y-24*TS);
    $('bst').classList.toggle('h',dStorage>45);

    if(ONBOARD.current()?.id==='chest'&&Math.hypot(P.x-27*TS,P.y-37*TS)<84){
      pText='📦 Depo Sandığını Kur';
      pFn=()=>BUILD.start('chest');
    }else if(Math.hypot(P.x-6*TS, P.y-8*TS) < 28){
      pText = `⛏️ Kristal Madeni (Giriş · Kat ${P.maxMineFloor||1})`;
      pFn = openElevatorModal;
    }else if(Math.hypot(P.x-12*TS, P.y-24*TS) < 28 || Math.hypot(P.x-14*TS, P.y-24*TS) < 28){
      pText = '🏡 Çiftlik Evi (İçeri Gir)';
      pFn = () => { switchMap('inside'); };
    }else if(Math.hypot(P.x-10*TS, P.y-24*TS) < 24){
      pText = `📦 Sevkiyat Sandığı (${ITEMS.count(P.shippingBin||[])} adet)`;
      pFn = () => { $('shipping-modal').classList.remove('h'); shippingUI(); };
    }else if(Math.hypot(P.x-16*TS, P.y-24*TS) < 28 || Math.hypot(P.x-31*TS, P.y-30*TS) < 28){
      pText = '💧 Su Kuyusu (Kova Doldur)';
      pFn = () => { P.waterCan=20; fl(P.x, P.y-16, '💧 Kova Dolduruldu! (20/20)', '#38bdf8', true); sfx(540,.14,'sine',.05); };
    }else if(AUTO.near()){pText='⚙️ Otomasyon Merkezi';pFn=()=>AUTO.ui();
    }else if(TOWN_PARK.spot()){const sp=TOWN_PARK.spot();pText=sp.text;pFn=sp.fn;
    }else if(Math.hypot(P.x-27*TS, P.y-25*TS) < 28){
      pText = '🥐 Fırın & Kafe (Melis)';
      pFn = () => { if(!TOWN_LIFE.isOpen('cafe'))return TOWN_LIFE.closedNotice('cafe','Melis'); $('cafe-modal').classList.remove('h'); cafeUI(); };
    }else if(Math.hypot(P.x-35*TS, P.y-25*TS) < 28){
      pText = '🛒 Kasaba Manavı (Osman)';
      pFn = () => { if(!TOWN_LIFE.isOpen('market'))return TOWN_LIFE.closedNotice('market','Osman'); $('market-modal').classList.remove('h'); marketUI(); };
    }else if(Math.hypot(P.x-27*TS, P.y-33*TS) < 28){
      pText = '🌸 Botanikçi Serası (Aylin)';
      pFn = () => { if(!TOWN_LIFE.isOpen('botany'))return TOWN_LIFE.closedNotice('botany','Aylin'); $('botany-modal').classList.remove('h'); botanyUI(); };
    }else if(Math.hypot(P.x-31*TS, P.y-14*TS) < 32){
      pText = '⛪ Kasaba Şapeli (Kutsan)';
      pFn = () => { $('chapel-modal').classList.remove('h'); chapelUI(); };
    }else if(Math.hypot(P.x-20*TS, P.y-40*TS) < 32){
      pText = '🍺 Köy Tavernası (Savaşçı Kirala)';
      pFn = () => { $('tavern-modal').classList.remove('h'); tavernUI(); };
    }else if(Math.hypot(P.x-18*TS, P.y-14*TS) < (window.STORY&&STORY.cueHome&&STORY.cueHome()?56:32)){
      if(window.STORY&&STORY.wantsTalk&&STORY.wantsTalk()){pText=STORY.cueHome()?'🏛️ Hamdi · Kapıda bir nefes':'🏛️ Muhtar Hamdi · Konuş';pFn=()=>STORY.talk()}
      else{pText = '🏛️ Belediye Binası (Kasaba Geliri)';pFn = () => { $('townhall-modal').classList.remove('h'); townhallUI(); }}
    }else if(Math.hypot(P.x-48*TS, P.y-22*TS) < 30){
      pText = '🌊 Su Değirmeni (Un Öğüt)';
      pFn = () => { $('mill-modal').classList.remove('h'); millUI(); };
    }else if(dForgeHome < 42){
      pText = '🔨 Kasaba Demircisi (Geliştir)';
      pFn = () => { $('forge').classList.remove('h'); forgeUI(); };
    }else if(Math.hypot(P.x-31*TS, P.y-24*TS) < 26){
      pText = '📋 Kasaba Sipariş Panosu';
      pFn = () => { $('board-modal').classList.remove('h'); boardUI(); };
    }
    const nAn=HERD.nearest();
    const gPrompt=FARM.smartPrompt();
    if(nAn){
      const pr=HERD.promptFor(nAn); pText=pr.text; pFn=pr.fn;
    }else if(Math.hypot(P.x-8*TS, P.y-16*TS) < 28){
      pText = P.hasCoop ? '🐔 Kümes (Hayvanlar & Yem)' : '🐔 Kümes İnşa Et (120 Altın, 10 Odun, 6 Taş)';
      pFn = () => HERD.openBuilding('coop');
    }else if(Math.hypot(P.x-8*TS, P.y-30*TS) < 32){
      pText = P.hasBarn ? '🐄 Ahır (Hayvanlar & Yem)' : '🐄 Ahır İnşa Et (400 Altın, 25 Odun, 15 Taş)';
      pFn = () => HERD.openBuilding('barn');
    }else if(!pText && gPrompt){
      pText = gPrompt.text;
      pFn = gPrompt.fn;
    }
  }else if(curMap==='world'){
    if(!pText&&QS[P.q]?.k==='fish'&&FEATURES.is('fishing')&&waterDir()>=0){
      pText='🎣 Olta At';
      pFn=fish;
    }
  }else if(curMap==='frontier'){
    ['bsh','bfg','bpr','bck','bhs','bcf','bmk','bbd','bst','bcs','bml','bbt','bchp','btav','bth','blb','btv','bgm'].forEach(id=>$(id).classList.add('h'));
    const gate=FRONTIER.gate,ruin=FRONTIER.ruin;
    if(Math.hypot(P.x-(gate.x*TS+8),P.y-((gate.y-1)*TS+8))<46){
      pText='⛩️ Aethermoor Ana Dünyasına Dön';
      pFn=()=>{if(switchMap('world','center')){P.x=(WORLD_GATE.x+.5)*TS;P.y=(WORLD_GATE.y+2.5)*TS;P.f=0}};
    }else if(nearFrontierCamp()){
      pText=P.hasFieldCamp?`🏕️ Yayla Kampı Sv.${P.fieldCampLevel||1} (Yapılar)`:'🏕️ Kamp Kur (90🪙 · 8 Odun · 6 Taş)';
      pFn=P.hasFieldCamp?openFieldCamp:buildFrontierCamp;
    }else if(!P.frontierRuinFound&&Math.hypot(P.x-(ruin.x*TS+8),P.y-(ruin.y*TS+8))<46){
      pText='🗿 Kadim Harabeyi İncele';pFn=inspectFrontierRuin;
    }else if(nearFrontierStation()){
      pText=P.frontierMission>=3?'🧭 Gözcü Lale · Günlük Erzak':'🧭 Gözcü Lale · Yayla Görevleri';
      pFn=openFrontierStation;
    }
  }else{
    $('bck').classList.add('h');$('bhs').classList.add('h');$('bcf').classList.add('h');$('bmk').classList.add('h');$('bbd').classList.add('h');$('bst').classList.add('h');
    const townDist=Math.hypot(P.x-C*TS,P.y-C*TS);
    $('bsh').classList.toggle('h',townDist>75);
    $('bfg').classList.toggle('h',townDist>85);
    $('bpr').classList.toggle('h',townDist>85);
    const marsh=WORLD_OUTPOSTS.marsh,frost=WORLD_OUTPOSTS.frost,oasis=WORLD_OUTPOSTS.oasis;
    if(Math.hypot(P.x-(WORLD_GATE.x*TS+8),P.y-((WORLD_GATE.y+1)*TS+8))<46){
      pText='🌫️ Sisli Yayla Geçidi (Yeni Bölge)';pFn=()=>switchMap('frontier');
    }else if(Math.hypot(P.x-(WORLD_MINE.x*TS+8),P.y-((WORLD_MINE.y+1)*TS+8))<44){
      pText='⛏️ Kül Kristal Ocağı (Madene Gir)';
      pFn=openElevatorModal;
    }else if(Math.hypot(P.x-(SEA_PORT.x*TS+8),P.y-((SEA_PORT.y+1)*TS+8))<46){
      const count=P.inv.filter(it=>it.s==='fish'&&it.origin==='sea').length;
      pText=`⚓ Batı Limanı · Deniz Balığı Sat (${count}, +%25)`;
      pFn=tradeSeaFish;
    }else if(Math.hypot(P.x-(oasis.x*TS+8),P.y-((oasis.y+1)*TS+8))<42){
      pText='🌴 Vaha Kervansarayı (Günde bir kez dinlen)';
      pFn=()=>restAtWorldOutpost('oasis');
    }else if(Math.hypot(P.x-(LAKE_DOCK.x*TS+8),P.y-((LAKE_DOCK.y+1)*TS+8))<42){
      pText=P.lakeBaitDay===P.day?'🎣 Balıkçı: Yarın yeni yem':'🎣 Balıkçı: 3 Göl Yemi Al';
      pFn=claimLakeBait;
    }else if(Math.hypot(P.x-(marsh.x*TS+8),P.y-((marsh.y+1)*TS+8))<42){
      pText='🍄 Sazlık Şifacısı (Günde bir kez dinlen)';
      pFn=()=>restAtWorldOutpost('marsh');
    }else if(Math.hypot(P.x-(frost.x*TS+8),P.y-((frost.y+1)*TS+8))<42){
      pText='❄️ Kar Sığınağı (Günde bir kez dinlen)';
      pFn=()=>restAtWorldOutpost('frost');
    }else if(Math.hypot(P.x-(C*TS-36),P.y-(C*TS-28))<40){
      pText = '🔨 Demirci Boran';
      pFn = () => { $('forge').classList.remove('h'); forgeUI(); };
    }else if(Math.hypot(P.x-(C*TS-32),P.y-(C*TS+28))<40){
      pText = '🕊️ Rahibe Elara (Kutsama)';
      pFn = () => { $('priest').classList.remove('h'); priestUI(); };
    }else if(Math.hypot(P.x-(C*TS+34),P.y-(C*TS+28))<40){
      pText = '🛒 Tüccar (Alışveriş)';
      pFn = () => { $('shop').classList.remove('h'); shopUI(); };
    }else if(Math.hypot(P.x-(C*TS+24),P.y-(C*TS-28))<40){
      pText = '🧙 Sınıf Ustası (Sınıf Değiştir)';
      pFn = () => { $('class-modal').classList.remove('h'); classUI(); };
    }
  }

  if(!pText){
    const trace=BOSS_SYSTEM.nearestTrace(),door=BUILD.nearestDoor(),built=BUILD.nearest(),cave=CAVE.prompt(),animal=BOND.nearest();
    if(trace){pText=`${trace.icon} Boss izini incele`;pFn=()=>BOSS_SYSTEM.inspectTrace(trace)}
    else if(door){pText=door.open?'🚪 Kapıyı Kapat':'🚪 Kapıyı Aç';pFn=()=>BUILD.toggleDoor(door.id)}
    else if(built){pText=built.kind==='chest'?'📦 Kendi Depo Sandığın':'🔨 Kendi Atölyen';pFn=()=>BUILD.interact(built)}
    else if(cave){pText=cave.text;pFn=cave.fn}
    else if(animal){pText=`${BOND.species[animal.type].icon} ${animal.bondName||BOND.species[animal.type].name} · Güven Kazan`;pFn=()=>BOND.open(animal)}
    else if(curMap==='home'&&P.hasCask&&Math.hypot(P.x-19*TS,P.y-35*TS)<32){pText='🛢️ İşleme Fıçısı';pFn=()=>{$('cask-modal').classList.remove('h');caskUI()}}
    else if(curMap==='home'&&Math.hypot(P.x-27*TS,P.y-37*TS)<30){pText='🔨 İnşa Arazisi · Yapı Seç';pFn=()=>ADVENTURE.open('build')}
  }
  if($('bgarden'))$('bgarden').classList.toggle('h',curMap!=='home');
  const fHud=$('farm-hud');
  if(fHud){
    const showFarmHud=curMap==='home'&&!BUILD.active&&(FARM.nearCampus()||FARM.nearOrchard()||Math.hypot(P.x-18*TS,P.y-24*TS)<36);
    fHud.classList.toggle('h',!showFarmHud);
    if(showFarmHud){
      const plan=FARM.carePlan(),growing=(WORLD_DATA.home?.farmPlots||[]).filter(p=>p.crop&&!p.dead&&!FARM.ripe(p)).length;
      const hudKey=[plan.tasks,plan.ripe,plan.dry,plan.dead,plan.plant,plan.fruit,plan.sk||'',P.seeds[plan.sk]||0,growing].join('|');
      if(fHud.dataset.hudKey!==hudKey){
        fHud.dataset.hudKey=hudKey;
        const btn=(k,txt,bg,bd)=>`<button type="button" data-fh="${k}" style="background:${bg};border-color:${bd}">${txt}</button>`;
        const panelText=plan.empty&&!plan.sk?'🌱 Tohum Seç':growing&&!plan.tasks?'🌙 Bugünlük Tamam':'🌱 Bahçeyi Aç';
        fHud.innerHTML=(plan.tasks?btn('care',`🌿 Günlük Bakım (${plan.tasks})`,'#166534','#86efac'):'')+btn('panel',panelText,'#1e3a4a','#7aa2b3');
      }
    }
  }
  const trackedFriend=P.adventure?.trackedFriend;if(trackedFriend&&nearFriend(trackedFriend)){const npc=TOWNSFOLK[trackedFriend];pText=`❤️ ${npc.icon} ${npc.name} ile Konuş`;pFn=()=>openDialogue(trackedFriend)}
  if(BUILD.active){pText=null;pFn=null}
  const actEl = $('act-prompt');
  if(actEl){
    if(pText && pFn){
      actEl.textContent = pText;
      window.activePromptFn = pFn;
      actEl.classList.remove('h');
    }else{
      window.activePromptFn = null;
      actEl.classList.add('h');
    }
  }
  $('bF').classList.toggle('h',!(waterDir()>=0||P.fs)||P.dead);
  
  // Buff göstergesi
  let bHtml='';
  if(P.shld>0)bHtml+=`<span class="bf">🛡️ ${P.shld}</span>`;
  if(P.buffs.atk>0)bHtml+=`<span class="bf" style="border-color:#ffd23f">⚔️ ${Math.ceil(P.buffs.atk)}s</span>`;
  if(P.buffs.spd>0)bHtml+=`<span class="bf" style="border-color:#a7f3d0">👟 ${Math.ceil(P.buffs.spd)}s</span>`;
  if(P.buffs.def>0)bHtml+=`<span class="bf">🛡 ${Math.ceil(P.buffs.def)}s</span>`;
  if(P.buffs.crit>0)bHtml+=`<span class="bf">🎯 ${Math.ceil(P.buffs.crit)}s</span>`;
  $('buffs').innerHTML=bHtml;
  
  // Boss Health Bar
  const b=mobs.find(e=>e.d.boss&&e.act&&!e.dead);
  $('bb').classList.toggle('h',!b);
  if(b){
    const icon=b.k==='dragon'?'🐉':b.k==='colossus'?'👑':'⚔️';
    $('bb-title').textContent=icon+' '+b.d.n+(b.p2?' [ÖFKELİ]':'');
    const areaDanger=tel.some(t=>t.t>0&&t.t<.8&&Math.hypot(t.x-P.x,t.y-P.y)<t.r+38);
    $('bb-state').textContent=b.staggeredT>0?'💫 SERSEMLEDİ · ŞİMDİ SALDIR':areaDanger?'⚠ ALAN SALDIRISI · HAREKET ET':b.cast>0?'⚠ SALDIRI HAZIRLIYOR':b.p2?'🔥 İKİNCİ FAZ · DAHA HIZLI':'Saldırı aralığını bekle';
    $('bh').style.width=b.hp/b.mhp*100+'%';
  }
  
  // Mini Harita Çizimi (66x66)
  {const ms=Math.min(4,Math.max(2,Math.ceil(window.devicePixelRatio||1)));const mmEl=$('mm');if(mmEl.width!==66*ms){mmEl.width=mmEl.height=66*ms}MM.setTransform(ms,0,0,ms,0,0);}
  MM.imageSmoothingEnabled=true;MM.imageSmoothingQuality='high';
  MM.clearRect(0,0,66,66);
  MM.drawImage(mmc,P.x/TS-20,P.y/TS-20,40,40,0,0,66,66);
  const dot=(x,y,c,s)=>{
    MM.fillStyle=c;
    MM.fillRect((x/TS-P.x/TS+20)*1.65-s/2,(y/TS-P.y/TS+20)*1.65-s/2,s,s);
  };
  for(const e of mobs)if(!e.dead&&e.d.boss)dot(e.x,e.y,'#f33',4);
  for(const ch of chests)if(!ch.opened&&!ch.hidden)dot(ch.x,ch.y,'#ffd23f',2.5);
  if(curMap==='home')for(const b of P.adventure.buildings){const p=BUILD.pos(b),mat=BUILD_CONFIG.materials[b.material||BUILD.defaultMaterial(b.kind)];dot(p.x,p.y,b.kind==='chest'?'#bfe5e3':mat?.trim||'#f0ce86',2.5)}
  if(curMap==='frontier'&&P.fieldCampLevel>=3)
    for(const r of resources)if(!r.mined)dot(r.x,r.y,r.isOre?'#facc15':'#86efac',2);
  for(const n of npcs)if(!n.hidden)dot(n.x,n.y,'#6ff',2.5);
  dot(P.x,P.y,'#fff',3.5);

  const wEl=$('wth-badge');
  if(wEl){
    if(curMap==='mine'||curMap==='inside'){
      wEl.textContent=curMap==='mine'?`⛏️ Yeraltı · Kat ${P.mineFloor}`:'🏠 İç Mekân';
      wEl.style.borderColor='#9b8a65';wEl.style.color='#d6e4ec';
    }else if(curMap==='world'&&P.biome==='frost'||curMap==='frontier'&&FARM.seasonIdx()===3){
      const blood=weather.type==='blood_moon';
      wEl.textContent=blood?'❄️ Kanlı Ay · 3x Ganimet':'❄️ Karlı Bölge';wEl.style.borderColor=blood?'#ef4444':'#83b6c7';wEl.style.color=blood?'#fca5a5':'#e0f5ff';
    }else if(weather.type==='blood_moon'){
      wEl.innerHTML='🌑 Kanlı Ay (3x Ganimet!)';
      wEl.style.borderColor='#ef4444';wEl.style.color='#f87171';
    }else if(weather.type==='storm'){
      wEl.textContent='⛈️ Fırtına · Islak Hedefler';wEl.style.borderColor='#94b9e1';wEl.style.color='#d0e7ff';
    }else if(weather.type==='rain'){
      wEl.innerHTML=curMap==='frontier'?'🌧️ Adaçayı Bereketi':curMap==='home'?'🌧️ Yağmur (Oto-Sulama)':'🌧️ Yağmurlu';
      wEl.style.borderColor='#38bdf8';wEl.style.color='#7dd3fc';
    }else if(weather.type==='fog'){
      wEl.innerHTML=curMap==='frontier'?'🌫️ Sis · Domuz görüşü ↓':'🌫️ Mistik Sis';
      wEl.style.borderColor='#c084fc';wEl.style.color='#e2e8f0';
    }else{
      wEl.textContent=DAY_CLOCK.night()?'🌙 Açık Gece':'☀️ Açık Hava';
      wEl.style.borderColor='#4a5d94';wEl.style.color=DAY_CLOCK.night()?'#cbdcf0':'#ffd23f';
    }
    const event=WORLD_EVENTS.current();wEl.textContent+=` · ${event.icon}`;wEl.title=(curMap==='frontier'?frontierClimateLabel():wEl.textContent)+` · ${event.name}: ${event.desc}`;
  }
  WAYPOINTS.tick();updateFriendTracker();FEATURES.update();QUEST_FLOW.maybeShowChapter();if(window.CHAPSCENES)CHAPSCENES.tick();DECISIONS.tick();DAY_RECAP.maybeShow();MODAL_QUEUE.pump();
}

/* Envanter Arayüzü */
const ic=$('iv');let sel=null,inventoryPage=0,inventoryFilter='all';
function inventoryMatches(it,filter=inventoryFilter){if(!it)return false;if(filter==='all')return true;if(filter==='equipment')return !!SL[it.s];if(filter==='food')return it.s==='food';if(filter==='farm')return ['crop','food_ing','fish'].includes(it.s)||['egg','milk','wool','honey'].includes(it.k);if(filter==='materials')return ITEMS.stackable(it)||it.s==='mat';return true}
function equipmentScore(it){if(!it||!SL[it.s])return -1;const up=upgradeMultiplier(it);return (it.atk||0)*up*3+(it.def||0)*up*2+(it.hp||0)*up*.18+(it.crit||0)*120+(it.spd||0)*70+(it.r||0)*3}
function equipmentComparison(it){if(!it||!SL[it.s])return'';const old=P.eq[it.s],mult=upgradeMultiplier(it),oldMult=old?upgradeMultiplier(old):1,stats=[['⚔','Saldırı',(it.atk||0)*mult,(old?.atk||0)*oldMult],['🛡','Zırh',(it.def||0)*mult,(old?.def||0)*oldMult],['❤','Can',(it.hp||0)*mult,(old?.hp||0)*oldMult],['🎯','Kritik',(it.crit||0)*100,(old?.crit||0)*100],['👟','Hız',(it.spd||0)*100,(old?.spd||0)*100]];return `<div class="item-comparison">${stats.filter(([, ,a,b])=>a||b).map(([icon,name,a,b])=>{const d=Math.round((a-b)*10)/10,cls=d>0?'up':d<0?'down':'';return `<div><span>${icon} ${name}</span><b class="${cls}">${d>0?'+':''}${d}</b></div>`}).join('')||'<div>Temel ekipman</div>'}</div>`}
function equipBestItems(){let changed=0;for(const slot of Object.keys(SL)){if(P.eq[slot]?.locked)continue;let bestScore=equipmentScore(P.eq[slot]),bestIndex=-1;for(let i=0;i<P.inv.length;i++)if(P.inv[i]?.s===slot&&equipmentScore(P.inv[i])>bestScore){bestScore=equipmentScore(P.inv[i]);bestIndex=i}if(bestIndex>=0){const old=P.eq[slot];P.eq[slot]=P.inv[bestIndex];if(old)P.inv[bestIndex]=old;else P.inv.splice(bestIndex,1);changed++}}if(changed){S=st();spark(P.x,P.y-10,28,'#86efac',60);playChord([523,659,784],.22,'triangle',.04);fl(P.x,P.y-28,`⚡ ${changed} güçlü ekipman kuşanıldı`,'#86efac',true);sv()}return changed}
const escapeHTML=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const slotH=(it,w,i)=>{
  const rarity=it?(RAR[it.r]||RAR[0]):null,icon=it?(it.icon||(it.s==='fish'?'🐟':(SL[it.s]||'📦'))):'';
  const label=it?`${it.n} · ${ITEMS.qty(it)} adet`:'Boş göz';
  const selected=sel&&sel.w===w&&sel.i===i;
  return `<button type="button" class="sl${selected?' selected':''}${it?.locked?' item-locked':''}" data-w="${w}" data-i="${i}" title="${escapeHTML(label)}" aria-label="${escapeHTML(label)}" style="${it?'border-color:'+rarity[1]+';box-shadow:inset 0 0 8px '+rarity[1]+'66':''}">
    ${icon}${ITEMS.stackable(it)?`<small class="stack-count">×${ITEMS.qty(it)}</small>`:it&&it.up?`<small>+${it.up}</small>`:''}
  </button>`;
};

function invUI(){
  const s=st(),keys=Object.keys(SL);
  let h=`<p style="margin:2px 0 4px;font-size:10px;color:#cbd5e1">Sv ${P.lvl} · ⚔ ${s.a} · 🛡 ${s.d} · ❤ ${s.h} · 🎯 ${Math.round(s.c*100)}% · 👟 ${Math.round(s.s*100)}%</p>
  <div class="eq">${keys.map(k=>slotH(P.eq[k]||null,'e',k)).join('')}</div>
  <div class="inventory-summary"><strong>🎒 ${P.inv.length}/${BAG_CAPACITY} göz</strong><span>${ITEMS.count(P.inv)} adet eşya</span></div>
  <div class="inventory-capacity"><i style="width:${Math.min(100,P.inv.length/BAG_CAPACITY*100)}%"></i></div>
  <div class="inventory-filters">${[['all','Tümü'],['equipment','Ekipman'],['food','Yemek'],['farm','Çiftlik'],['materials','Malzeme']].map(([k,n])=>`<button type="button" data-inv-filter="${k}" class="${inventoryFilter===k?'act':''}">${n}</button>`).join('')}</div>
  <div class="inventory-toolbar"><span>Gösterilen: <b id="inventory-filter-count"></b></span><button type="button" data-a="equip-best">⚡ En Güçlüleri Kuşan</button></div>
  ${P.pendingRewards?.length?`<div class="inventory-toolbar"><span>🎁 ${ITEMS.count(P.pendingRewards)} adet ödül bekliyor.</span><button data-a="claim-rewards">Yer Açıp Teslim Al</button></div>`:''}
  <p id="inventory-status" class="inventory-status h" role="status"></p>
  <p class="inventory-help">🔒 Kilitlenen eşyalar satılmaz, sevkiyata girmez, hediye edilmez; kuşanılmışsa otomatik değiştirilmez. Odun, taş ve cevherler ×99 yığınlanır.${P.inv.length>BAG_CAPACITY?' <b style="color:#facc15">Fazla eşyalar korunuyor; yeni eşya için yer aç.</b>':''}</p>
  <div class="gr">`;
  const entries=P.inv.map((it,index)=>({it,index})).filter(row=>inventoryMatches(row.it)),pages=Math.max(1,Math.ceil(entries.length/BAG_CAPACITY));
  inventoryPage=cl(inventoryPage,0,pages-1);const first=inventoryPage*BAG_CAPACITY,visible=entries.slice(first,first+BAG_CAPACITY);
  if(visible.length)for(const row of visible)h+=slotH(row.it,'i',row.index);else h+='<div class="inventory-empty-filter">Bu kategoride eşya yok.</div>';
  if(inventoryFilter==='all'&&pages===1)for(let i=P.inv.length;i<BAG_CAPACITY;i++)h+=slotH(null,'i',i);
  h+='</div>';
  if(pages>1)h+=`<div class="inventory-toolbar" aria-label="Çanta sayfaları"><button data-inv-page="${inventoryPage-1}" ${inventoryPage===0?'disabled':''}>‹ Önceki</button><span>${inventoryPage+1}/${pages} · ${first+1}–${Math.min(first+BAG_CAPACITY,entries.length)} / ${entries.length}</span><button data-inv-page="${inventoryPage+1}" ${inventoryPage===pages-1?'disabled':''}>Sonraki ›</button></div>`;
  h+='<div id="dt">';
  if(sel){
    const it=sel.w==='e'?P.eq[sel.i]:P.inv[sel.i];
    if(it){
      const rData = RAR[it.r] || RAR[0];
      const isEquippable = it.s in SL;
      const value=unitSaleValue(it,Math.round(8*rData[2]*(P.lvl+1))),amount=ITEMS.qty(it);
      h+=`<b style="color:${rData[1]}">${it.locked?'🔒 ':''}${escapeHTML(it.n)} ${it.up?`[+${it.up}]`:''}</b> <small>(${rData[0]})</small><br>
      ${itx(it)}${ITEMS.stackable(it)?`<br><strong style="color:#a5f3fc">${amount}/${ITEMS.MAX_STACK} adet · ${value}🪙/adet · Toplam ${value*amount}🪙</strong>`:''}
      ${sel.w==='i'&&isEquippable?equipmentComparison(it):''}
      <div class="inventory-actions">
      ${sel.w==='i'&&isEquippable?'<button data-a="eq">Kuşan</button>':''}
      ${sel.w==='e'?'<button data-a="un">Çıkar</button>':it.s==='food'?`<button data-a="eat" ${it.locked?'disabled':''}>${it.locked?'Kilitli':'Tüket'}</button>`:`<button data-a="sell" ${it.locked?'disabled':''}>${it.locked?'Kilitli':(ITEMS.stackable(it)?'1 Adet Sat':'Sat')}${it.locked?'':` (+${value}🪙)`}</button>${ITEMS.stackable(it)&&amount>1?`<button class="sell-all" data-a="sell-all" ${it.locked?'disabled':''}>${it.locked?'Kilitli Yığın':`Yığını Sat (${amount} · +${value*amount}🪙)`}</button>`:''}`}
      <button class="lock-item" data-a="toggle-lock">${it.locked?'🔓 Kilidi Aç':'🔒 Koru'}</button>
      </div>`;
    }else sel=null;
  }
  if(!sel)h+='Bir eşyaya dokun. 🧪 İksir: '+P.pots+' · 🐟 Balık tutmak için suya yaklaş.';
  $('iv').innerHTML=h+'</div>';const filterCount=$('inventory-filter-count');if(filterCount)filterCount.textContent=`${entries.length} göz`;
}

function sellBagItem(index,amount){
  const it=P.inv[index];if(!it||it.locked)return false;
  const price=unitSaleValue(it,Math.round(8*(RAR[it.r]||RAR[0])[2]*(P.lvl+1)));
  if(!ITEMS.removeAt(P.inv,index,amount))return false;
  P.gold+=price*amount;ECONOMY.record(it,amount);return true;
}
ic.addEventListener('click',e=>{
  const filter=e.target.closest('[data-inv-filter]');if(filter){inventoryFilter=filter.dataset.invFilter;inventoryPage=0;sel=null;invUI();return}
  const page=e.target.closest('[data-inv-page]');if(page){inventoryPage=Math.max(0,Number(page.dataset.invPage)||0);sel=null;invUI();return}
  const slot=e.target.closest('[data-w]'),action=e.target.closest('[data-a]')?.dataset.a;
  if(slot){sel={w:slot.dataset.w,i:slot.dataset.w==='e'?slot.dataset.i:+slot.dataset.i};invUI();return}
  if(action==='equip-best'){const changed=equipBestItems();sel=null;invUI();const status=$('inventory-status');status.classList.remove('h');status.textContent=changed?`${changed} ekipman yuvası güçlendirildi.`:'Daha güçlü bir ekipman bulunamadı.';return}
  if(action==='claim-rewards'){
    let claimed=0;
    P.pendingRewards=P.pendingRewards.filter(it=>{if(ITEMS.add(P.inv,it)){claimed+=ITEMS.qty(it);return false}return true});
    sel=null;sv();invUI();
    const status=$('inventory-status');status.classList.remove('h');
    status.textContent=claimed?`${claimed} adet ödül teslim alındı.`:'Ödül için önce çantanda boş göz aç. Ödülün kayıtlı olarak bekliyor.';return;
  }
  if(!sel||!action)return;
  const it=sel.w==='e'?P.eq[sel.i]:P.inv[sel.i];
  if(!it){sel=null;invUI();return}
  if(action==='toggle-lock'){it.locked=!it.locked;sv();invUI();return}
  if(action==='eq'&&sel.w==='i'&&SL[it.s]){
    const old=P.eq[it.s];P.eq[it.s]=it;P.inv.splice(sel.i,1);
    if(old)P.inv.push(old);
    sel=null;S=st();spark(P.x,P.y-10,24,(RAR[it.r]||RAR[0])[1],60);sfx(500,.15);
  }else if(action==='un'&&sel.w==='e'){
    if(!ITEMS.add(P.inv,it)){$('dt').insertAdjacentHTML('beforeend','<p class="inventory-status" role="status">Ekipmanı çıkarmak için bir boş göz gerekiyor.</p>');return}
    delete P.eq[sel.i];sel=null;S=st();
  }else if(action==='eat'&&sel.w==='i'&&it.s==='food'&&!it.locked){
    if(it.hp)P.hp=Math.min(S.h,P.hp+it.hp);
    if(it.mp)P.mp=Math.min(S.m,P.mp+it.mp);
    if(it.buff)P.buffs[it.buff]=Math.max(P.buffs[it.buff]||0,it.duration||180);
    ITEMS.removeAt(P.inv,sel.i,1);sel=null;S=st();playChord([523,659,784],.25,'triangle',.05);
  }else if((action==='sell'||action==='sell-all')&&sel.w==='i'){
    const amount=action==='sell-all'?ITEMS.qty(it):1,remains=ITEMS.qty(it)>amount;
    if(sellBagItem(sel.i,amount)){if(!remains)sel=null;sfx(900,.1)}
  }
  sv();invUI();
});

function openInv(){$('inv').classList.remove('h');invUI()}
let mapView='world';
function openMap(view){
  if(!view){
    const intro=ONBOARD.current(),q=QS[P.q];
    if(['frontier','mine'].includes(curMap))view=curMap;
    else if(intro)view=intro.target==='forest'?'world':'home';
    else if(q&&!QUEST_FLOW.optional())view=q.k==='forge'?'home':'world';
    else view=curMap;
  }
  if(view==='frontier'&&!P.frontierDiscovered&&curMap!=='frontier')view='world';
  if(!WORLD_DATA[view])view=curMap;
  mapView=view;
  const viewMap=mapView,viewData=WORLD_DATA[viewMap],viewN=viewData?.N||N;
  const modal=$('map');modal.classList.remove('h');
  $('tab-world').classList.toggle('act',viewMap==='world');
  $('tab-frontier').classList.toggle('h',!P.frontierDiscovered&&curMap!=='frontier');
  $('tab-frontier').classList.toggle('act',viewMap==='frontier');
  $('tab-home').classList.toggle('act',viewMap==='home');
  MB.imageSmoothingEnabled=false;
  MB.clearRect(0,0,400,400);
  MB.drawImage(viewData?.atlas||mmc,0,0,400,400);
  if(viewMap==='frontier'&&P.fieldCampLevel>=3){
    const md=WORLD_DATA.frontier;
    const mark=(x,y,color,size=4)=>{
      const ax=Math.round(x/TS/viewN*400),ay=Math.round(y/TS/viewN*400);
      MB.fillStyle='#0b1020';MB.fillRect(ax-3,ay-3,size+2,size+2);
      MB.fillStyle=color;MB.fillRect(ax-2,ay-2,size,size);
    };
    for(const r of md.resources)if(!r.mined)mark(r.x,r.y,r.isOre?'#facc15':'#86efac');
    for(const c of md.chests)if(!c.opened)mark(c.x,c.y,'#fb923c',5);
  }
  if(viewMap==='home')for(const b of P.adventure.buildings){const d=BUILD.defs[b.kind],mat=BUILD_CONFIG.materials[b.material||BUILD.defaultMaterial(b.kind)];MB.fillStyle=b.kind==='chest'?'#96d8d4':mat?.color||'#e2b876';MB.globalAlpha=BUILD.layer(b)==='roof'?.72:BUILD.layer(b)==='floor'?.45:1;MB.fillRect(b.gx/viewN*400,b.gy/viewN*400,d.w/viewN*400,d.h/viewN*400);MB.globalAlpha=1}
  const px=P.x/TS/viewN*400,py=P.y/TS/viewN*400;
  if(viewMap===curMap){
    MB.fillStyle='#162a3c';MB.fillRect(px-5,py-5,10,10);
    MB.fillStyle='#ffe096';MB.fillRect(px-4,py-4,8,8);
    MB.fillStyle='#fff';MB.fillRect(px-2,py-2,4,4);
  }
  const frame=$('mw'),legend=$('map-legend');
  frame.querySelectorAll('.zn').forEach(b=>b.remove());legend.replaceChildren();
  const curQ=QS[P.q];
  const places=viewMap==='world' ? [
    {x:50,y:50,sx:50,sy:54,icon:'🏘️',name:'Gölgeköy',desc:'Güvenli merkez · pazar ve geçitler',zone:0},
    {x:50,y:18,sx:50,sy:26,icon:'🌲',name:'Zümrüt Orman',desc:'Slime, kurt ve Orman Muhafızı',zone:1,guide:guideIs(3)},
    {x:WORLD_GATE.x,y:WORLD_GATE.y,sx:WORLD_GATE.x,sy:WORLD_GATE.y+2,icon:'🌫️',name:'Yayla Geçidi',desc:"Sisli Yayla'ya geçiş · ilk keşif",zone:1},
    {x:WORLD_OUTPOSTS.marsh.x,y:WORLD_OUTPOSTS.marsh.y,sx:WORLD_OUTPOSTS.marsh.x,sy:WORLD_OUTPOSTS.marsh.y+3,icon:'🍄',name:'Mantar Bataklığı',desc:'Sazlık şifası, lotus, kurbağa · şifacı',zone:1},
    {x:WORLD_OUTPOSTS.frost.x,y:WORLD_OUTPOSTS.frost.y,sx:WORLD_OUTPOSTS.frost.x,sy:WORLD_OUTPOSTS.frost.y+3,icon:'❄️',name:'Akçam Karları',desc:'Kardelen, demir, kırağı kurdu · sığınak',zone:1},
    {x:27,y:50,sx:25,sy:50,icon:'🌊',name:'Sığ Göl',desc:'Tatlı su balıkları · kuzey kıyıda Kral Yengeç',zone:2},
    {x:LAKE_DOCK.x,y:LAKE_DOCK.y,sx:33,sy:56,icon:'🎣',name:LAKE_DOCK.name,desc:'İskelede balık tut · günlük 3 göl yemi',zone:2},
    {x:SEA_PORT.x,y:SEA_PORT.y,sx:3,sy:63,icon:'⚓',name:SEA_PORT.name,desc:'Açık deniz balıkları · limanda +%25 satış',zone:2},
    {x:82,y:50,sx:64,sy:50,icon:'🏜️',name:'Kızıl Çöl',desc:'Çöl ağzından gir · yolda akrep, vahada nefes, güneyde golem',zone:3},
    {x:WORLD_OUTPOSTS.oasis.x,y:WORLD_OUTPOSTS.oasis.y,sx:WORLD_OUTPOSTS.oasis.x,sy:WORLD_OUTPOSTS.oasis.y+3,icon:'🌴',name:'Kızıl Vaha',desc:'Dinlen, kovanı doldur · kaktüs meyvesi',zone:3},
    {x:DRAGON_LAIR.x,y:DRAGON_LAIR.y,sx:DRAGON_LAIR.x,sy:DRAGON_LAIR.approachY,icon:'🐉',name:'Ejder İni',desc:'Kül geçidi · lavın ardında Kızıl Ejder',zone:4},
    {x:WORLD_MINE.x,y:WORLD_MINE.y,sx:WORLD_MINE.x,sy:WORLD_MINE.y+2,icon:'⛏️',name:WORLD_MINE.name,desc:'Aynı 50 katlı madene ikinci giriş',zone:4}
  ]:viewMap==='frontier' ? [
    {x:FRONTIER.gate.x,y:FRONTIER.gate.y,sx:FRONTIER.gate.x,sy:FRONTIER.gate.y-2,icon:'⛩️',name:'Ana Dünya Geçidi',desc:"Aethermoor'a geri dön"},
    {x:FRONTIER.camp.x,y:FRONTIER.camp.y,sx:FRONTIER.camp.x,sy:FRONTIER.camp.y+2,icon:'🏕️',name:'Yayla Kampı',desc:P.hasFieldCamp?`Seviye ${P.fieldCampLevel} · ${P.fieldCampLevel>=3?'kule & depo':P.fieldCampLevel>=2?'saha deposu':'günlük dinlenme'}`:'90🪙, 8 odun, 6 taş ile kur'},
    {x:FRONTIER.ruin.x,y:FRONTIER.ruin.y,sx:FRONTIER.ruin.x+2,sy:FRONTIER.ruin.y+1,icon:'🗿',name:'Kadim Harabe',desc:P.frontierRuinFound?P.frontierMission>=3?'Gözcü Lale · günlük erzak':`Gözcü Lale · ${3-P.frontierMission} görev kaldı`:'Harabeyi incele · Gözcü Lale yakında'},
    {x:FRONTIER.lake.x,y:FRONTIER.lake.y,sx:FRONTIER.lake.x-6,sy:FRONTIER.lake.y+2,icon:'💧',name:'Yayla Gölü',desc:'Soğuk su kıyısı · olta ve kaynaklar'}
  ]:viewMap==='home' ? [
    {x:12,y:24,sx:14,sy:25,icon:'🏡',name:'Çiftlik Evi',desc:'Eve gir, pişir ve dinlen',guide:guideIs(0)},
    {x:17,y:27,sx:18,sy:25,icon:'🌱',name:'Kolay Bahçe',desc:'Tohum seç, günlük bakımı yap, evde uyu ve hasat et'},
    {x:31,y:30,sx:31,sy:32,icon:'⛲',name:'Pazar Meydanı',desc:'Esnaf ve sipariş panosu',guide:guideIs(1)},
    {x:55,y:30,sx:55,sy:30,icon:'🚪',name:'Doğu Kapısı',desc:'Vahşi Dünya’ya giden açık geçit',guide:guideIs(2)},
    {x:31,y:12,sx:31,sy:13,icon:'⛪',name:'Kasaba Şapeli',desc:'Şifa ve kutsama'},
    {x:48,y:22,sx:50,sy:24,icon:'🌊',name:'Su Değirmeni',desc:'Buğdaydan un yap'},
    {x:50,y:38,sx:50,sy:40,icon:'🔨',name:'Kasaba Demircisi',desc:'Köprüden geç · güneydeki kapıdan hizmet al'},
    {x:27,y:40,sx:29,sy:38,icon:'🛠️',name:'İnşa Arazisi',desc:'Çit, atölye ve ayrı depo sandıkları kur'}
  ]:[];
  const intro=ONBOARD.current();if(intro)for(const site of places)site.guide=(intro.target==='home'&&site.name==='Çiftlik Evi')||(intro.target==='farm'&&site.name==='Kolay Bahçe')||(intro.target==='forest'&&site.name==='Zümrüt Orman')||(intro.target==='build'&&site.name==='İnşa Arazisi');
  for(const site of places)site.unlocked=WAYPOINTS.isUnlocked(viewMap,site.name);
  function guideToSite(site){const wp=WAYPOINTS.defs.find(w=>w.map===viewMap&&w.name===site.name)||site;WAYPOINTS.guide(viewMap,{name:site.name,x:wp.x,y:wp.y});if(viewMap!==curMap){const side=viewMap==='world'?'center':viewMap==='home'?'east':undefined;if(!switchMap(viewMap,side))return false}modal.classList.add('h');ban(`🧭 YÜRÜYEREK KEŞFET: ${site.name}`,'#fde68a');chat('REHBER','',`Yön oku seni ${site.name} bölgesine götürecek. Yaklaşınca hızlı yolculuk açılır.`,1);return true}
  function travel(site){
    if(!GAME_CORE.canTravel()){inventoryWarning('Savaş sürüyor. Haritayı kapatıp güvenli bir yerde birkaç saniye bekle.');return}
    GAME_CORE.resetInput();
    if(viewMap!==curMap){
      const side=viewMap==='home'?'east':viewMap==='world'?'center':undefined;
      if(!switchMap(viewMap,side))return;
    }
    // Bina, su veya bossun içine ışınlanmak yerine yakındaki yürünebilir yolu seç.
    for(let radius=0;radius<=9;radius++)for(let dy=-radius;dy<=radius;dy++)for(let dx=-radius;dx<=radius;dx++){
      if(Math.max(Math.abs(dx),Math.abs(dy))!==radius)continue;
      const x=(site.sx+dx+.5)*TS,y=(site.sy+dy+.5)*TS;
      if(bl(x,y,4)||mobs.some(e=>e.d.boss&&!e.dead&&Math.hypot(e.x-x,e.y-y)<55))continue;
      P.x=x;P.y=y;P.fs=null;
      if(curMap==='world'){P.z=zoneOf(site.sx+dx,site.sy+dy);P.biome=worldBiome(site.sx+dx,site.sy+dy)}
      modal.classList.add('h');ban('🧭 '+site.name+' rotasına ulaştın','#a7f3d0');sfx(300,.4,'sine',.05);svNow();
      return;
    }
    fl(P.x,P.y-24,'Bu hedefte güvenli bir yaklaşma noktası bulunamadı.','#ff5d5d');
  }
  const difficulty=site=>{
    if(viewMap==='home'||site.zone===0)return {text:'Güvenli',cls:'easy',req:1};
    if(viewMap==='frontier')return site.name==='Ana Dünya Geçidi'?{text:'Güvenli',cls:'easy',req:1}:{text:'Orta',cls:'medium',req:4};
    if(site.zone===1)return {text:'Başlangıç',cls:'easy',req:1};
    if(site.zone===2)return {text:'Orta',cls:'medium',req:3};
    return site.zone===3?{text:'Zor',cls:'hard',req:6}:{text:'Çok Zor',cls:'hard',req:10};
  };
  const questTargets={slime:'Zümrüt Orman',treant:'Zümrüt Orman',fish:LAKE_DOCK.name,lizard:'Sığ Göl',crab:'Sığ Göl',scorpion:'Kızıl Çöl',golem:'Kızıl Çöl',forge:'Kasaba Demircisi',skeleton:'Ejder İni',dragon:'Ejder İni'};
  const questTarget=curQ&&!QUEST_FLOW.optional()?questTargets[curQ.k]:null;
  function requestTravel(site){
    if(!site.unlocked){guideToSite(site);return}
    const level=difficulty(site);
    if(P.lvl<level.req){
      $('travel-confirm-content').innerHTML=`<h3>${site.icon} ${site.name}</h3><p>Bu bölge <b>${level.text}</b> olarak işaretli. Önerilen seviye <b>${level.req}</b>, senin seviyen <b>${P.lvl}</b>.</p><p>Gidebilirsin; ancak düşmanlar daha fazla hasar verebilir. Önce ekipmanını, yemeğini ve iksirlerini kontrol etmen önerilir.</p>`;
      $('travel-confirm-modal').classList.remove('h');
      $('travel-confirm-go').onclick=()=>{$('travel-confirm-modal').classList.add('h');travel(site)};
      return;
    }
    travel(site);
  }
  $('travel-confirm-close').onclick=$('travel-confirm-cancel').onclick=()=>$('travel-confirm-modal').classList.add('h');
  for(const site of places)site.quest=!!(questTarget&&site.name===questTarget);
  if(viewMap===curMap&&places.length){const here=[...places].sort((a,b)=>Math.hypot(a.x-P.x/TS,a.y-P.y/TS)-Math.hypot(b.x-P.x/TS,b.y-P.y/TS))[0];if(here&&Math.hypot(here.x-P.x/TS,here.y-P.y/TS)<18)here.current=true}
  const recommended=places.find(site=>site.guide)||places.find(site=>site.quest)||null;
  const viewLabels={world:'Vahşi Dünya',frontier:'Sisli Yayla',home:'Huzurlu Çiftlik',mine:'Kristal Madeni'};
  const route=$('map-route');route.replaceChildren();
  const routeCopy=document.createElement('div');routeCopy.className='map-route-copy';
  const routeTitle=document.createElement('b'),routeDesc=document.createElement('small');routeCopy.append(routeTitle,routeDesc);route.appendChild(routeCopy);
  if(recommended){
    const routeLevel=difficulty(recommended);
    routeTitle.textContent=`🧭 Önerilen rota: ${recommended.name}`;
    routeDesc.textContent=(recommended.unlocked?(recommended.guide?'Rehber adımın burada. Yeşil işaretli hedefe git.':'Mevcut görevin bu bölgede. Sarı görev işaretini takip et.'):`Bu konuma henüz ulaşmadın. İlk kez yürüyerek keşfet.`)+` · ${routeLevel.text}, önerilen Sv.${routeLevel.req}`;
    const go=document.createElement('button');go.type='button';go.className='map-route-go';go.textContent=recommended.unlocked?'HEDEFE GİT':'ROTAYI İŞARETLE';go.onclick=()=>requestTravel(recommended);route.appendChild(go);
    if(viewMap===curMap){
      MB.save();MB.strokeStyle='rgba(134,239,172,.85)';MB.lineWidth=3;MB.setLineDash([8,6]);MB.beginPath();MB.moveTo(px,py);MB.lineTo(recommended.x/viewN*400,recommended.y/viewN*400);MB.stroke();MB.restore();
      MB.fillStyle='#162a3c';MB.fillRect(px-5,py-5,10,10);MB.fillStyle='#ffe096';MB.fillRect(px-4,py-4,8,8);MB.fillStyle='#fff';MB.fillRect(px-2,py-2,4,4);
    }
  }else{
    routeTitle.textContent=viewMap===curMap?'📍 Bulunduğun bölgeyi inceliyorsun':`🗺️ ${viewLabels[viewMap]||'Bölge'} haritasını inceliyorsun`;
    routeDesc.textContent=viewMap===curMap?'Beyaz merkezli sarı işaret senin konumundur.':'Sekmeler yalnızca haritayı değiştirir; bir konuma gitmek için karttaki GİT düğmesini kullan.';
  }
  const ordered=[...places].sort((a,b)=>(b===recommended?1:0)-(a===recommended?1:0));
  for(const site of ordered){
    const b=document.createElement('button');b.type='button';
    b.className='zn'+(site.quest?' has-q':'')+(site.guide?' has-guide':'')+(site.unlocked?'':' undiscovered');
    b.textContent=site.unlocked?site.icon:'?';b.title=site.name+' — '+(site.unlocked?site.desc:'İlk kez yürüyerek keşfet');
    const level=difficulty(site);
    b.setAttribute('aria-label',site.name+' · '+(site.unlocked?'hızlı yolculuk':'yürüyerek keşfet')+' · '+level.text);
    b.style.left=site.x/viewN*100+'%';b.style.top=site.y/viewN*100+'%';
    b.onclick=()=>requestTravel(site);frame.appendChild(b);
    const card=document.createElement('button');card.type='button';card.className='map-place'+(site.guide?' guided':'')+(site.quest?' quest':'')+(site.current?' current':'')+(site.unlocked?'':' undiscovered');
    const icon=document.createElement('span');icon.textContent=site.unlocked?site.icon:'❔';
    const text=document.createElement('span'),title=document.createElement('strong'),desc=document.createElement('small'),badge=document.createElement('span'),go=document.createElement('span');
    const distance=viewMap===curMap?Math.round(Math.hypot(site.x-P.x/TS,site.y-P.y/TS)):null;
    text.style.minWidth='0';title.textContent=site.name;desc.textContent=(site.unlocked?site.desc:'İlk ziyaret yürüyerek yapılmalı')+(distance!==null?` · ${distance<=3?'yakındasın':distance+' kare'}`:'');badge.className='map-badge '+(site.unlocked?level.cls:'locked');badge.textContent=!site.unlocked?'🔒 KEŞFEDİLMEDİ':site.guide?`REHBER · ${level.text}`:site.quest?`GÖREV · ${level.text} · Sv.${level.req}`:site.current?'ŞU AN BURADASIN':`${level.text} · Sv.${level.req}`;go.className='map-go';go.textContent=site.unlocked?'GİT':'KEŞFET';text.append(title,desc,badge);card.append(icon,text,go);
    card.setAttribute('aria-label',`${site.name}: ${site.unlocked?site.desc:'İlk kez yürüyerek keşfet'}. ${level.text}, önerilen seviye ${level.req}. ${site.unlocked?'Git':'Rotayı işaretle'}`);card.onclick=()=>requestTravel(site);legend.appendChild(card);
  }
  if(viewMap==='mine'&&WORLD_DATA.mine){
    const md=WORLD_DATA.mine;
    const mark=(x,y,color)=>{
      MB.fillStyle='#0b1020';MB.fillRect(x/TS/viewN*400-4,y/TS/viewN*400-4,10,10);
      MB.fillStyle=color;MB.fillRect(x/TS/viewN*400-2,y/TS/viewN*400-2,6,6);
    };
    mark(4*TS,4*TS,'#86efac');
    if(md.floor%5===0)mark(6*TS,4*TS,'#facc15');
    if(md.ladder?.uncovered)mark(md.ladder.x,md.ladder.y,'#c084fc');
    const note=document.createElement('div');note.className='map-place map-note';
    note.textContent=`⛏️ Kat ${md.floor} · ${ {earth:'Toprak',ice:'Buzul',magma:'Magma',iridium:'İridyum'}[md.biome] } · Yeşil: yüzey · Sarı: asansör · Mor: açılmış geçit`;
    legend.appendChild(note);
    $('map-hint').textContent=md.floor===50?'👑 Son kat: Kristal Muhafızı. Daha aşağı geçit yok.':md.ladder?.uncovered?'🪜 Mor geçide yürü; E / dokun ile alt kata in.':'🪨 Merdiven bir kayanın altında; kazmayı kullan veya düşmanları temizle.';
  }else if(viewMap==='frontier'&&P.fieldCampLevel>=3){
    const note=document.createElement('div');note.className='map-place map-note';
    note.textContent='🔭 Gözetleme Kulesi · Yeşil: ot · Sarı: maden · Turuncu: açılmamış sandık';legend.appendChild(note);
    $('map-hint').textContent=`🔭 Gözetleme: hazır kaynaklar · ${frontierClimateLabel()}`;
  }else if(viewMap==='frontier'){
    $('map-hint').textContent=`${frontierClimateLabel()} · Sekmeler yalnızca haritayı gösterir; GİT düğmesi güvenli yaklaşma noktasına götürür.`;
  }else if(recommended){
    $('map-hint').textContent=recommended.unlocked?`🧭 ${recommended.guide?'Yeşil rehber':'Sarı görev'} işaretini takip et. GİT düğmesi güvenli yaklaşma noktasına götürür.`:`🔒 Bu hedef henüz keşfedilmedi. ROTAYI İŞARETLE düğmesine bas ve yön okunu takip ederek ilk kez yürüyerek ulaş.`;
  }else{
    $('map-hint').textContent=places.length?'📍 Beyaz merkezli sarı işaret sensin. Sekmeler haritayı inceler; yalnızca GİT düğmesi yolculuk başlatır.':'Bu diyardan çıkmak için yakınındaki geçidi kullan.';
  }
}

/* ===== SINIF SEÇİM ARAYÜZÜ ===== */
function classUI(){
  const cur=P.cls||'warrior';
  let h='';
  Object.values(CLASSES).forEach(c=>{
    const isAct=c.id===cur;
    h+=`<div class="class-card${isAct?' act':''}" data-cid="${c.id}">
      <div class="class-icon">${c.icon}</div>
      <div class="class-details">
        <div class="class-name"><span>${c.name}</span> <span style="font-size:10px;color:${isAct?'#4ade80':'#94a3b8'}">${isAct?'(Aktif)':'[Seçmek için Dokun]'}</span></div>
        <div class="class-desc">${c.desc}</div>
        <div class="class-skills"><b>Yetenekler:</b> ${c.s1Icon} ${c.s1Name} [K] · ${c.s2Icon} ${c.s2Name} [U]</div>
      </div>
    </div>`;
  });
  $('class-cards').innerHTML=h;
}

$('class-cards').onclick=e=>{
  const card=e.target.closest('[data-cid]');
  if(!card)return;
  selectClass(card.dataset.cid);
  $('class-modal').classList.add('h');
};

function selectClass(cid){
  if(!CLASSES[cid])return;
  P.cls=cid;
  const cData=CLASSES[cid];
  S=st();
  P.hp=Math.min(S.h,P.hp);
  P.mp=Math.min(S.m,P.mp);
  updateClassButtons();
  ban(cData.icon+' '+cData.name+' sınıfına geçtin!','#7dff9c');
  playChord([523,659,784,1046],.25,'triangle',.05);
  sv();
}

function updateClassButtons(){
  const cData=CLASSES[P.cls]||CLASSES.warrior;
  $('bA').innerHTML=cData.wpn==='staff'?'☄️':cData.wpn==='bow'?'🏹':'⚔️';
  $('bS').innerHTML=`${cData.s1Icon}<span class="key-hint">K</span><small>${cData.s1Mp}</small><div class="cdv" id="cS"></div>`;
  $('bI').innerHTML=`${cData.s2Icon}<span class="key-hint">U</span><small>${cData.s2Mp}</small><div class="cdv" id="cI"></div>`;
  $('av').textContent=cData.icon;
  $('bcl').textContent=cData.icon;
}

function openClass(){
  $('class-modal').classList.remove('h');
  classUI();
}


