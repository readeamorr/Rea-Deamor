/* ===== KAYIT SİSTEMİ · SÜRÜMLÜ / DOĞRULANMIŞ / GERİ ALINABİLİR ===== */
// Anahtar aynı kalır: aynı tarayıcı/adresteki ilerleme sıfırlanmaz.
const LK='aethermoor_px_v2',LK_OLD='aethermoor_px_v1',LK_STACK_BACKUP='aethermoor_px_v2_before_stacks',LK_CORE_BACKUP='aethermoor_px_v2_before_core_rules';
const LK_CORRUPT='aethermoor_px_v2_corrupt',LK_IMPORT_BACKUP='aethermoor_px_v2_before_import';
const LK_FOUNDATION_BACKUP='aethermoor_px_v2_before_foundation',LK_PREVIOUS='aethermoor_px_v2_previous_good',LK_BUILD_BACKUP='aethermoor_px_v2_before_build_core',LK_NPC_BACKUP='aethermoor_px_v2_before_npc_life';
const SAVE_VERSION=5; // NPC ihtiyaçları/yaşam durumu eklendi; eski kayıtlar güvenle varsayılan alır.
// Kayıttan yalnız bilinen alanlar okunur; bilinmeyen veya tehlikeli anahtarlar (__proto__ vb.) oyuncu nesnesine girmez.
const SAVE_KEYS=new Set(['saveVersion','coreRulesVersion','clockState','inventoryVersion','adventure','visualSettings','wildMaps','weatherState','lvl','xp','gold','gems','pots','inv','pendingRewards','eq','q','qn','kills','tl','guideStep','ach','bounties','lastBountyDay','townWorkDay','cls','rep','storage','orders','rage','merc','dailyIncomeCollected','arenaRewardDay','arenaPendingReward','arenaPts','arenaStreak','arenaWinsToday','arenaReward','pet','hasSprinkler','auto','hasCoop','eggsAvailable','cowMilkedToday','hasBeehive','honeyReady','hasCask','caskItem','caskTimer','caskReady','caskReadyDay','restDays','lakeBait','lakeBaitDay','frontierDiscovered','hasFieldCamp','fieldCampLevel','fieldCampStorage','fieldCampRestDay','frontierRuinFound','frontierMission','frontierBoarsKilled','frontierBoarStart','frontierTradeDay','skills','friendship','houseLevel','musicTrack','volMusic','volSfx','shakeSetting','activeTool','waterCan','shippingBin','coopLove','mineFloor','maxMineFloor','mineElevator','mineEntrance','herd','hay','hasBarn','coopLv','barnLv','autoFeed','day','seeds','fert','seedSel','farmPlots','life','talentQueue','session']);
const UNSAFE_KEYS=new Set(['__proto__','constructor','prototype']);
// Sıralı geçiş listesi: yeni bir şema değişikliği = bu listeye bir satır + SAVE_VERSION artışı.
const SAVE_MIGRATIONS=[
  {v:1,name:'sağlamlaştırma',needed:d=>d.coreRulesVersion!==1,backupKey:LK_CORE_BACKUP},
  {v:2,name:'miktarlı envanter',needed:d=>d.inventoryVersion!==1,backupKey:LK_STACK_BACKUP},
  {v:3,name:'temel altyapı',needed:d=>Number(d.saveVersion||0)<3,backupKey:LK_FOUNDATION_BACKUP},
  {v:4,name:'inşa sistemi çekirdeği',needed:d=>Number(d.saveVersion||0)<4,backupKey:LK_BUILD_BACKUP},
  {v:5,name:'NPC günlük ihtiyaçları',needed:d=>Number(d.saveVersion||0)<5,backupKey:LK_NPC_BACKUP}
];
let svFailed=false,svWarnAt=0,svPending=false,svTimer=0,saveLocked=false,gameStarted=false;
let saveLockReason='',lastSavedJSON='',storageUnavailable=false,loadRepairs=[],lastSaveError='';
function readStore(key){try{return localStorage.getItem(key)}catch(error){storageUnavailable=true;svFailed=true;return null}}
function saveNotice(message){
  const el=$('save-warning');if(!el)return;el.classList.toggle('h',!message||!$('save-modal').classList.contains('h'));$('save-warning-text').textContent=message||'';
  $('save-health').textContent=message||'Kayıt sistemi hazır. Site verilerini silmeden önce güncel kayıt kodunu yedekle.';
}
function saveNoticeCurrent(){
  if(saveLocked)saveNotice(saveLockReason==='runtime'?'Oturum hatası: son kayıt üzerine yazılmıyor. Kayıt kodunu güvene al.':saveLockReason==='external'?'Başka bir sekme yeni kayıt yazdı. Bu sekmenin eski ilerlemeyi üzerine yazması durduruldu; son kaydı yeniden aç veya oturum kodunu dışa aktar.':'Kayıt koruma kilidi açık. Eski veri üzerine yazılmıyor; kayıt menüsünden yedeğini dışa aktar.');
  else if(svFailed||storageUnavailable)saveNotice('Kayıt yazılamıyor. Site verilerini silmeden önce oturum kodunu dışa aktar.'+(lastSaveError?' '+lastSaveError:''));
  else saveNotice('');
}
const pendingLoadNotices=[]; // Yükleme sırasındaki uyarılar oyun başlayınca sohbette gösterilir.

// NaN/Infinity koruması: bozulan sayılar sessizce eski değerle karıştırılmaz.
// Geçersiz durumun kaydı reddedilir; son sağlam kayıt ve ham oturum korunur.
const CORE_NUMS=['lvl','xp','gold','gems','pots'],lastGoodNums={};
function guardCoreNumbers(){
  SAVE_CODEC.assertRuntime();for(const k of CORE_NUMS)lastGoodNums[k]=P[k];
}
// Kayıt metnini üretir; hata verirse fırlatır. Hem kayıt hem dışa aktarım bunu kullanır.
function buildSaveJSON(){
  guardCoreNumbers();
  ADVENTURE.capture();
  const wildMaps={world:snapshotWildMap(WORLD_DATA.world,'world')||wildStateCache.world,
    frontier:snapshotWildMap(WORLD_DATA.frontier,'frontier')||wildStateCache.frontier};
  wildStateCache=wildMaps;
  return JSON.stringify({saveVersion:SAVE_VERSION,session:GAME_CORE.snapshot(),life:P.life,talentQueue:P.talentQueue,coreRulesVersion:1,clockState:DAY_CLOCK.snapshot(),inventoryVersion:1,adventure:P.adventure,visualSettings:{...FX.options},wildMaps,weatherState:{type:weather.type,timer:weather.timer,tod},
      lvl:P.lvl,xp:P.xp,gold:P.gold,gems:P.gems,pots:P.pots,
      inv:P.inv,pendingRewards:P.pendingRewards,eq:P.eq,q:P.q,qn:P.qn,kills:P.kills,tl:P.tl,guideStep:P.guideStep,
      ach:P.ach,bounties:P.bounties,lastBountyDay:P.lastBountyDay,townWorkDay:P.townWorkDay,cls:P.cls,rep:P.rep,storage:P.storage,orders:P.orders,rage:P.rage,merc:P.merc,dailyIncomeCollected:P.dailyIncomeCollected,arenaRewardDay:P.arenaRewardDay,arenaPendingReward:P.arenaPendingReward,arenaPts:P.arenaPts,arenaStreak:P.arenaStreak,arenaWinsToday:P.arenaWinsToday,arenaReward:P.arenaReward,pet:P.pet,hasSprinkler:P.hasSprinkler,auto:P.auto,hasCoop:P.hasCoop,eggsAvailable:P.eggsAvailable,cowMilkedToday:P.cowMilkedToday,hasBeehive:P.hasBeehive,honeyReady:P.honeyReady,hasCask:P.hasCask,caskItem:P.caskItem,caskTimer:P.caskTimer,caskReady:P.caskReady,caskReadyDay:P.caskReadyDay,restDays:P.restDays,lakeBait:P.lakeBait,lakeBaitDay:P.lakeBaitDay,frontierDiscovered:P.frontierDiscovered,hasFieldCamp:P.hasFieldCamp,fieldCampLevel:P.fieldCampLevel,fieldCampStorage:P.fieldCampStorage,fieldCampRestDay:P.fieldCampRestDay,frontierRuinFound:P.frontierRuinFound,frontierMission:P.frontierMission,frontierBoarsKilled:P.frontierBoarsKilled,frontierBoarStart:P.frontierBoarStart,frontierTradeDay:P.frontierTradeDay,skills:P.skills,friendship:P.friendship,houseLevel,musicTrack,volMusic,volSfx,shakeSetting,activeTool:P.activeTool,waterCan:P.waterCan,shippingBin:P.shippingBin,coopLove:P.coopLove,mineFloor:P.mineFloor,maxMineFloor:P.maxMineFloor,mineElevator:P.mineElevator,mineEntrance:P.mineEntrance,herd:P.herd,hay:P.hay,hasBarn:P.hasBarn,coopLv:P.coopLv,barnLv:P.barnLv,autoFeed:P.autoFeed,day:P.day,seeds:P.seeds,fert:P.fert,seedSel:P.seedSel,farmPlots:(WORLD_DATA.home&&WORLD_DATA.home.farmPlots)||[]
    });
}

// Anında kaydet. Başarıyı true/false döndürür.
function svNow(){
  if(saveLocked||GAME_CORE.loading)return false;
  if(svTimer){clearTimeout(svTimer);svTimer=0}
  try{
    const raw=buildSaveJSON(),checked=SAVE_CODEC.parse(raw),previous=readStore(LK);
    if(checked.badType.length)throw new Error('Oturum doğrulaması: '+checked.badType.slice(0,4).join(', '));
    if(previous&&previous!==raw){try{SAVE_CODEC.parse(previous);localStorage.setItem(LK_PREVIOUS,previous)}catch(backupError){/* Ana yazma atomiktir; yedek başarısızsa eski ana kayıt hâlâ durur. */}}
    localStorage.setItem(LK,raw);lastSavedJSON=raw;svPending=false;storageUnavailable=false;
    if(svFailed)chat('SİSTEM','','Kayıt yeniden çalışıyor, ilerleme kaydedildi.',1);
    svFailed=false;lastSaveError='';saveNoticeCurrent();return true;
  }catch(e){
    const now=Date.now();if(!svFailed||now-svWarnAt>60000){svWarnAt=now;console.warn('Kayıt yazılamadı:',e);chat('SİSTEM','','⚠ Kayıt yazılamadı. İlerlemeni kayıt koduyla dışa aktar; site verilerini silme.',1)}
    lastSaveError=String(e.message||e).slice(0,160);svFailed=true;svPending=true;saveNoticeCurrent();return false;
  }
}
// Kayıt isteği: 112 yerden çağrılır; aynı anda gelen istekler tek bir yazmada birleşir (en geç 350 ms).
function sv(){
  if(saveLocked||GAME_CORE.loading)return;
  svPending=true;
  if(svTimer)return;
  svTimer=setTimeout(()=>{svTimer=0;svNow()},350);
}
// Sekme gizlenirken / sayfa kapanırken bekleyen kaydı hemen yaz.
function flushSave(){
  if(saveLocked)return;
  if(!svPending&&!gameStarted)return; // Açılış kartındayken (oyun başlamadan) yüklenen kaydın üzerine yazma.
  if(svTimer){clearTimeout(svTimer);svTimer=0}
  svNow();
}

// Kayıttan gelen veriyi süzer: bilinmeyen/tehlikeli anahtarlar ve tür uyuşmazlıkları elenir.
function sanitizeSave(d){return SAVE_CODEC.normalize(d)}

/* ---- Kayıt okuma ---- */
let loadedRaw=null,loadedSave=null;
loadedRaw=readStore(LK)||readStore(LK_OLD);
if(loadedRaw?.trim()==='null')loadedRaw=null;
if(loadedRaw){
  try{
    const parsed=SAVE_CODEC.parse(loadedRaw);loadedSave=parsed.clean;loadRepairs=parsed.badType;lastSavedJSON=loadedRaw;
    if(loadRepairs.length){try{localStorage.setItem(LK_CORRUPT,loadedRaw)}catch(error){saveLocked=true;saveLockReason='repair-backup'}}
  }catch(error){
    saveLocked=true;saveLockReason=error.code==='FUTURE_SAVE'?'future':'corrupt';
    let protectedRaw=false;try{localStorage.setItem(LK_CORRUPT,loadedRaw);protectedRaw=true}catch(backupError){console.warn('Ham kayıt disk yedeği yazılamadı; bellekte korunuyor.',backupError)}
    if(saveLockReason!=='future'){
      const fallback=readStore(LK_PREVIOUS);
      if(fallback)try{const recovered=SAVE_CODEC.parse(fallback);loadedSave=recovered.clean;loadRepairs=recovered.badType;lastSavedJSON=fallback;if(protectedRaw){saveLocked=false;saveLockReason=''}pendingLoadNotices.push('⚠ Ana kayıt okunamadı. Önceki sağlam kayıt belleğe alındı; bozuk ham kod Kayıt menüsünde korunuyor.')}catch(fallbackError){/* Kullanıcıya açık, korumalı geçici oturum. */}
    }
    if(!loadedSave)pendingLoadNotices.push('⚠ '+error.message+' Korumalı geçici oturum açıldı; eski kayıt otomatik olarak ezilmez.');
  }
}
if(storageUnavailable)pendingLoadNotices.push('⚠ Tarayıcı depolamasına erişilemiyor. Güncel kayıt kodunu dışa aktararak ilerlemeni koru.');
const saveData=loadedSave;
const loadFailures=[];
// Her bölüm kendi try'ında çalışır: biri bozuksa diğerleri etkilenmez.
function loadStep(name,fn){try{fn()}catch(e){console.warn('Kayıt bölümü düzeltilemedi: '+name,e);loadFailures.push(name)}}

loadStep('sürüm yedekleri',()=>{
  if(!saveData)return;
  SAVE_MIGRATIONS.forEach(m=>{
    if(!m.needed(saveData))return;
    try{if(!localStorage.getItem(m.backupKey))localStorage.setItem(m.backupKey,loadedRaw)}
    catch(error){saveLocked=true;saveLockReason='migration-backup';console.warn('Geçiş yedeği yazılamadı; eski kayıt üzerine yazılmayacak: '+m.name,error)}
  });
});
let loadBadTypes=[];
loadStep('oyuncu verisi',()=>{
  if(!saveData)return;
  const olderGuide=!Object.prototype.hasOwnProperty.call(saveData,'guideStep');
  const result=sanitizeSave(saveData);
  loadBadTypes=[...new Set([...loadRepairs,...result.badType])];
  Object.assign(P,result.clean);
  if(olderGuide)P.guideStep=4; // Eski kayıtları yeni başlangıç rotasına zorlamayalım.
});
loadStep('haritalar',()=>{if(saveData)loadWildMaps(saveData.wildMaps)});
delete P.wildMaps;
loadStep('çiftlik parselleri',()=>{
  if(!saveData||!Array.isArray(saveData.farmPlots)||!WORLD_DATA.home||!WORLD_DATA.home.farmPlots)return;
  const fp=WORLD_DATA.home.farmPlots;fp.length=0;
  saveData.farmPlots.forEach(p=>{
    if(!p||typeof p!=='object')return;
    if(p.crop&&!CROPS[p.crop]){p.crop=null}
    if(p.age===undefined)p.age=p.crop?Math.round((CROPS[p.crop].d)*(p.stage||0)/3):0;
    fp.push(p);
  });
});
delete P.farmPlots;
loadStep('ayarlar',()=>{
  if(!saveData)return;
  if(saveData.houseLevel)houseLevel=saveData.houseLevel;
  if(saveData.musicTrack!==undefined)musicTrack=saveData.musicTrack;
  if(Number.isFinite(saveData.volMusic))volMusic=cl(saveData.volMusic,0,1);
  if(Number.isFinite(saveData.volSfx))volSfx=cl(saveData.volSfx,0,1);
  if(['normal','reduced','off'].includes(saveData.shakeSetting))shakeSetting=saveData.shakeSetting;
});
loadStep('görsel ayarlar',()=>{if(saveData){FX.load(saveData.visualSettings)}});
delete P.visualSettings;
loadStep('hava durumu',()=>{
  if(!saveData||!saveData.weatherState||typeof saveData.weatherState!=='object')return;
  const w=saveData.weatherState;
  if(['clear','rain','storm','fog','blood_moon'].includes(w.type))weather.type=w.type;
  if(Number.isFinite(w.timer))weather.timer=cl(w.timer,.1,600);
});
loadStep('gün saati',()=>{if(saveData)DAY_CLOCK.restore(saveData.clockState,saveData.weatherState)});
delete P.weatherState;delete P.clockState;delete P.coreRulesVersion;delete P.saveVersion;

loadStep('envanter',()=>{
  normalizeInventories();
  if(!P.herd)HERD.init();
  if(P.hay===undefined)P.hay=6;
  if(P.hasCoop&&!P.coopLv)P.coopLv=1;
});
loadStep('gün ve görevler',()=>{
  if(!P.day)P.day=1;
  P.bounties=Math.max(0,Math.floor(Number(P.bounties)||0));
  P.lastBountyDay=Math.max(0,Math.floor(Number(P.lastBountyDay)||0));
  P.townWorkDay=Math.max(0,Math.floor(Number(P.townWorkDay)||0));
  if(saveData&&!Object.prototype.hasOwnProperty.call(saveData,'lastBountyDay')&&P.bounties>0)P.lastBountyDay=P.day;
  if(saveData&&!Object.prototype.hasOwnProperty.call(saveData,'townWorkDay')&&!P.dailyIncomeCollected)P.townWorkDay=P.day;
  P.arenaRewardDay=Number(P.arenaRewardDay)||0;
  P.arenaPendingReward=!!P.arenaPendingReward;
  P.arenaPts=Math.max(0,Number(P.arenaPts)||0);P.arenaStreak=Math.max(0,Number(P.arenaStreak)||0);P.arenaWinsToday=Math.max(0,Number(P.arenaWinsToday)||0);
  if(!P.arenaReward||typeof P.arenaReward!=='object')P.arenaReward=null;
  if(!P.restDays)P.restDays={};
});
loadStep('sınır bölgesi ve kamp',()=>{
  P.frontierDiscovered=!!P.frontierDiscovered;
  P.hasFieldCamp=!!P.hasFieldCamp;
  P.fieldCampLevel=cl(Math.floor(Number(P.fieldCampLevel)||0),0,3);
  if(P.hasFieldCamp&&P.fieldCampLevel<1)P.fieldCampLevel=1; // Eski kamp kayıtları Lv.1 olarak açılır.
  if(P.fieldCampLevel>=1)P.hasFieldCamp=true;
  if(!Array.isArray(P.fieldCampStorage))P.fieldCampStorage=[];
  P.fieldCampRestDay=Number(P.fieldCampRestDay)||0;
  P.frontierRuinFound=!!P.frontierRuinFound;
  P.frontierMission=cl(Math.floor(Number(P.frontierMission)||0),0,3);
  P.frontierBoarsKilled=Math.max(0,Math.floor(Number(P.frontierBoarsKilled)||0));
  P.frontierBoarStart=cl(Math.floor(Number(P.frontierBoarStart)||0),0,P.frontierBoarsKilled);
  P.frontierTradeDay=Math.max(0,Math.floor(Number(P.frontierTradeDay)||0));
});
loadStep('rehber ve göl',()=>{
  P.guideStep=cl(Math.floor(Number(P.guideStep)||0),0,4);
  P.lakeBait=cl(Number(P.lakeBait)||0,0,3);
  if(!P.lakeBaitDay)P.lakeBaitDay=0;
});
loadStep('çiftlik malzemeleri',()=>{
  if(!P.fert)P.fert=0;
  if(!P.seeds||typeof P.seeds!=='object'){P.seeds={wheat:5,carrot:4,potato:3};P.seedSel='wheat'}
  P.inv=(Array.isArray(P.inv)?P.inv:[]).filter(i=>i&&typeof i==='object');
  // Geçerli ve eski botanik tohumları tüm depolarla birlikte GAME_CORE.init içinde taşınır.
});
loadStep('sınıf ve araçlar',()=>{
  if(!P.cls)P.cls='warrior';
  if(P.dailyIncomeCollected===undefined)P.dailyIncomeCollected=false;
  if(!P.activeTool)P.activeTool='sword';
  if(P.waterCan===undefined)P.waterCan=20;
  if(!P.shippingBin)P.shippingBin=[];
  if(!P.coopLove)P.coopLove=0;
});
loadStep('maden',()=>{
  if(!P.mineFloor)P.mineFloor=1;
  if(!P.maxMineFloor)P.maxMineFloor=1;
  if(!P.mineElevator)P.mineElevator=1;
  // Eski sürümde Kat 5 yanlışlıkla herkese açıktı; gerçekten ulaşılmadıysa kilitle.
  if(P.mineElevator===5&&P.maxMineFloor<5&&P.mineFloor<5)P.mineElevator=1;
  P.mineEntrance=P.mineEntrance==='world'?'world':'home';
});
loadStep('macera',()=>{ADVENTURE.init()});
loadStep('yaşam ve oturum',()=>GAME_CORE.init(saveData));
if(loadFailures.length){saveLocked=true;saveLockReason='load-step'}
guardCoreNumbers(); // Yüklenen sağlam değerleri 'son sağlam' olarak işaretle.
if(loadBadTypes.length)pendingLoadNotices.push('⚠ Kayıttaki '+loadBadTypes.length+' alan geçersizdi ve varsayılana döndürüldü.');
if(loadFailures.length)pendingLoadNotices.push('⚠ Kaydın '+loadFailures.length+' bölümü düzeltilemedi ('+loadFailures.join(', ')+'). Varsayılanlarla devam ediliyor.');

FX.load();updateClassButtons();
S=st();P.hp=S.h;P.mp=S.m;

let VG;
let autoLowRes=false;
function pickRS(K,w,h,dp){
  const mode=FX.options.resolution,mobile=w<700;let r=K;
  if(mode==='classic')r=1;
  else if(mode==='balanced')r=Math.max(1,Math.ceil(K/2));
  else if(mode==='auto')r=FX.tier===0?1:Math.max(1,Math.ceil(K*(FX.tier===2?.66:.5)));
  const budget=mode==='native'?6e6:mode==='auto'?(mobile?(FX.tier===2?700000:450000):(FX.tier===2?1400000:900000)):1800000;
  while(r>1&&(w*dp)*(h*dp)*(r/K)*(r/K)>budget)r--;
  return r;
}
function rs(){
  const dp=Math.min(4,Math.max(1,window.devicePixelRatio||1)),oldW=LW,oldH=LH;
  const w=Math.max(320,window.innerWidth||document.documentElement.clientWidth||800);
  const h=Math.max(240,window.innerHeight||document.documentElement.clientHeight||600);
  const view=CONTROLS.state().view,portraitScale={normal:2.3,wide:1.9,ultra:1.65}[view],landscapeMin={normal:1.8,wide:1.55,ultra:1.35}[view],landscapeDiv={normal:200,wide:230,ultra:260}[view];
  const K=Math.max(2,Math.round((h>w?portraitScale:Math.max(landscapeMin,h/landscapeDiv))*dp));
  LW=Math.max(120,Math.floor(w*dp/K));
  LH=Math.max(96,Math.floor(h*dp/K));
  RS=pickRS(K,w,h,dp);
  sc=K/dp;cv.width=LW*RS;cv.height=LH*RS;
  cv.style.width='100%';cv.style.height='100%';
  cv.style.imageRendering=(K%RS===0)?'pixelated':'auto';
  VG=document.createElement('canvas');VG.width=LW*RS;VG.height=LH*RS;
  const v=VG.getContext('2d');v.setTransform(RS,0,0,RS,0,0);
  const r0=Math.max(10,Math.min(LW,LH)*.3),r1=Math.max(30,Math.max(LW,LH)*.78);
  const rg=v.createRadialGradient(LW/2,LH/2,r0,LW/2,LH/2,r1);
  rg.addColorStop(0,'#02081700');rg.addColorStop(.45,'#02081708');rg.addColorStop(.75,'#02081730');rg.addColorStop(1,'#0208177a');
  v.fillStyle=rg;v.fillRect(0,0,LW,LH);FX.resize(oldW!==LW||oldH!==LH);
  if(window.__gfxReady&&(oldW!==LW||oldH!==LH))GAME_CORE.resetInput();window.__gfxReady=true;
}
addEventListener('resize',rs);rs();
In.init();GAME_CORE.restoreSession();GAME_CORE.install();skillPerksText();saveNoticeCurrent();
STORY.renderTitle();

window.cookUI = cookUI;
window.cafeUI = cafeUI;
window.marketUI = marketUI;
window.tavernUI = tavernUI;
window.chapelUI = chapelUI;
window.townhallUI = townhallUI;
window.botanyUI = botanyUI;
window.bestiaryUI = bestiaryUI;
window.boardUI = boardUI;
window.openSaveModal = openSaveModal;
window.quickDepositStorage = quickDepositStorage;
window.addFriendship = addFriendship;
window.openDialogue = openDialogue;
window.friendsUI = friendsUI;
window.hasInv = hasInv;
window.countInv = countInv;
window.consumeInv = consumeInv;
window.addFood = addFood;
window.useActiveTool = useActiveTool;
window.openElevatorModal = openElevatorModal;
window.descendMineFloor = descendMineFloor;
window.initMineFloor = initMineFloor;
window.getCurMap = () => curMap;
window.getActiveNpcNames = () => npcs.map(n=>n.n);

function startGame(){
  // Bu giriş yalnız açılış kartına aittir; ölüm/yetenek penceresi arka plana dokunarak kapatılamaz.
  if(!$('go')||$('ov').classList.contains('h'))return;
  try{
    if(!AC)AC=new(window.AudioContext||window.webkitAudioContext)();
    if(AC.state==='suspended')AC.resume().catch(error=>console.warn('Ses izni bekleniyor.',error));
  }catch(e){console.warn('Ses sistemi başlatılamadı.',e)}
  STORY.commit();
  $('ov').classList.add('h');
  gameStarted=true;
  if(!STORY.openingDue())chat('SİSTEM','',STORY.welcomeLine(),1);
  while(pendingLoadNotices.length)chat('SİSTEM','',pendingLoadNotices.shift(),1);
  if(!STORY.openingDue()){const g=guideNow();if(g)chat('REHBER','',g.hint,1);}
  QUEST_FLOW.resolveRecorded();GAME_CORE.started();saveNoticeCurrent();
  STORY.begin();
  svNow();
}

$('act-prompt').onclick = () => {
  if(window.activePromptFn) window.activePromptFn();
};
if($('go'))$('go').onclick=startGame;
$('ov').addEventListener('click',e=>{if(e.target===$('ov')&&!$('story-turn'))startGame()});
window.addEventListener('keydown',e=>{
  const tag=(e.target&&e.target.tagName)||'';
  const typing=tag==='INPUT'||tag==='TEXTAREA'||tag==='SELECT';
  const storyOpen=$('story-modal')&&!$('story-modal').classList.contains('h');
  if(storyOpen&&!typing&&(e.key==='Enter'||e.key===' '||e.key==='Escape')){
    e.preventDefault();
    if(e.key==='Escape')$('story-skip').click();else $('story-next').click();
    return;
  }
  if(typing)return;
  const ov=$('ov');
  if(ov&&!ov.classList.contains('h')&&(e.key==='Enter'||e.key===' '||e.key==='j'||e.key==='J')){
    const turn=$('story-turn');
    if(turn){if(e.key==='j'||e.key==='J')return;e.preventDefault();turn.click();return}
    startGame();
  }
});

let last=0,svT=0,loopFailStreak=0,loopErrLogged=0,crashShown=false;
function showCrashOverlay(phase,err){
  crashShown=true;
  saveLocked=true; // Hatalı durumun son sağlam kaydın üzerine yazılmasını engelle.
  const el=document.createElement('div');
  el.id='crash-overlay';
  el.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(11,16,32,.94);color:#f4f1e6;display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;touch-action:manipulation;user-select:text;-webkit-user-select:text';
  const box=document.createElement('div');
  box.style.cssText='max-width:320px;text-align:center;background:#16203c;border:1px solid #ef4444;border-radius:10px;padding:14px;font:700 11px system-ui,sans-serif';
  const h=document.createElement('b');h.textContent='⚠ Beklenmedik oyun hatası';h.style.cssText='font-size:14px;color:#ffd23f';
  const m=document.createElement('p');m.style.cssText='margin:8px 0;line-height:1.35;font-weight:600';
  m.textContent='Oyun durduruldu ('+phase+'). Hatalı durum kaydedilmiyor. Varsa son başarılı kayıt yeniden açılabilir; kurtarma kodunu da dışa alabilirsin.';
  const small=document.createElement('p');small.style.cssText='margin:4px 0 10px;font-size:9px;color:#94a3b8;font-weight:500;word-break:break-word';
  small.textContent=String(err&&err.message||err).slice(0,140);
  const mk=(txt,bg)=>{const b=document.createElement('button');b.textContent=txt;b.style.cssText='margin:3px;padding:8px 12px;font-size:12px;font-weight:800;color:#fff;border:0;border-radius:7px;background:'+bg;return b};
  const reload=mk('Son Kaydı Yeniden Aç','#16a34a'),exportCode=mk('Kurtarma Kodunu Göster','#475569');
  reload.onclick=()=>window.location.reload();
  exportCode.onclick=()=>{let area=box.querySelector('textarea');if(!area){area=document.createElement('textarea');area.readOnly=true;area.style.cssText='width:100%;height:100px;box-sizing:border-box;margin-top:8px';box.appendChild(area)}const raw=lastSavedJSON||readStore(LK_PREVIOUS)||loadedRaw||'';area.value=raw?btoa(encodeURIComponent(raw)):'Bu oturumdan önce kayıt bulunamadı.';area.select()};
  box.append(h,m,small,reload,exportCode);el.appendChild(box);document.body.appendChild(el);
}
function handleLoopError(phase,err){
  if(crashShown)return;loopFailStreak++;console.error('Oyun güvenli biçimde durduruldu ('+phase+'):',err);
  GAME_CORE.fatal=true;GAME_CORE.resetInput();saveLocked=true;saveLockReason='runtime';
  if(svTimer){clearTimeout(svTimer);svTimer=0}svPending=false;showCrashOverlay(phase,err);
}
function loop(t){
  if(crashShown){last=t;return}
  requestAnimationFrame(loop);
  const started=performance.now(),frameMs=t-last,raw=Math.max(0,Math.min(.05,frameMs/1000));last=t;
  if(document.hidden)return;
  let phase='başlangıç';
  try{
    // Oyun zamanı ile görsel zaman ayrı: 3–5 ms hit-stop tarayıcıyı/arayüzü bloklamaz.
    const paused=$('bt').classList.contains('expanded')||!!document.querySelector('.ov:not(.h)')||GAME_CORE.unfocused||saveLockReason==='external';
    phase='durum denetimi';guardCoreNumbers();GAME_CORE.paused=paused;
    if(gameStarted&&P.hp<=0&&!P.dead)GAME_CORE.defeat();
    phase='güncelleme';
    if(!paused){
      const dt=FX.consumeHitStop(raw);if(dt>0)update(dt);
      svT+=raw;if(svT>12){svT=0;sv()}
    }
    phase='arayüz';ui(raw);
    phase='efektler';FX.step(raw,paused);
    phase='çizim';WLAB.begin();draw();WLAB.flush(paused);
    FX.sample(performance.now()-started,frameMs,paused);
    loopFailStreak=0;
  }catch(err){handleLoopError(phase,err)}
}
document.addEventListener('visibilitychange',()=>{last=performance.now();if(document.hidden)flushSave()});
window.addEventListener('pagehide',flushSave);
window.addEventListener('storage',e=>{
  if(e.key!==LK||e.newValue===lastSavedJSON||e.newValue===loadedRaw)return;
  saveLocked=true;saveLockReason='external';GAME_CORE.external=true;GAME_CORE.resetInput();if(svTimer){clearTimeout(svTimer);svTimer=0}svPending=false;saveNoticeCurrent();
});
// Olay işleyicilerinde (buton tıklaması vb.) oluşan yakalanmamış hatalar oyunu durdurmaz; en fazla 30 sn'de bir bildirilir.
let errNoticeAt=0;
function reportUncaught(kind,err){
  console.error(kind,err);
  const now=Date.now();
  if(now-errNoticeAt<30000)return;
  errNoticeAt=now;
  handleLoopError('olay işleyicisi',err);
}
// Barındırma/önizleme ortamının eklediği betiklerden (çapraz çerçeve, SecurityError, 'Script error.') gelen hatalar oyunu durdurmaz.
const foreignError=(err)=>/SecurityError|cross-origin|Script error|ResizeObserver loop/i.test(String((err&&err.message)||err||''));
window.addEventListener('error',e=>{const err=e.error||e.message;if(foreignError(err)){console.warn('Harici betik hatası yoksayıldı:',err);return}reportUncaught('Yakalanmamış hata:',err)});
window.addEventListener('unhandledrejection',e=>{if(foreignError(e.reason)){console.warn('Harici söz hatası yoksayıldı:',e.reason);e.preventDefault();return}reportUncaught('Yakalanmamış söz hatası:',e.reason)});
requestAnimationFrame(t=>{last=t;loop(t)});
