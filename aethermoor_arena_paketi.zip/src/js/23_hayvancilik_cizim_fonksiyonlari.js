/* ===== HAYVANCILIK ÇİZİM FONKSİYONLARI (KÜMES, TAVUKLAR, İNEK) ===== */
function chickenD(c){
  const x=Math.round(c.x),y=Math.round(c.y),f=c.f||1;
  const bob=Math.abs(Math.sin(P.t*12+c.id))*2;
  R(x-3,y-4-bob,6,4,'#fff');
  R(x+f*3,y-5-bob,2,2,'#fff');
  R(x+f*4,y-4-bob,2,1,'#f59e0b');
  R(x+f*2,y-3-bob,1,2,'#ef4444');
  R(x-f*4,y-5-bob,2,3,'#e2e8f0');
  R(x-1,y-bob,1,2,'#f59e0b');R(x+1,y-bob,1,2,'#f59e0b');
}

function cowD(x,y){
  x=Math.round(x);y=Math.round(y);
  R(x-10,y-12,20,11,'#f8fafc');
  R(x-5,y-10,6,5,'#1e293b');
  R(x+3,y-8,5,4,'#1e293b');
  R(x+8,y-16,8,8,'#f8fafc');
  R(x+12,y-12,4,3,'#f472b6');
  R(x+9,y-18,2,3,'#cbd5e1');R(x+13,y-18,2,3,'#cbd5e1');
  R(x+7,y-8,3,3,'#facc15');
  R(x-8,y-1,3,5,'#1e293b');R(x-3,y-1,3,5,'#f8fafc');R(x+2,y-1,3,5,'#1e293b');R(x+6,y-1,3,5,'#f8fafc');
  const tailS=Math.sin(P.t*6)*3;
  R(x-12,y-8+tailS,2,6,'#1e293b');
  if(labelNear(x,y,55))T('Sarıkız 🐄',x,y-22,'#fde047');
}

function sheepD(x,y,sh){
  x=Math.round(x);y=Math.round(y);
  const wool=(sh&&sh.woolReady)?1:0;
  R(x-7,y-1,14,3,'#0002');
  R(x-8,y-10-wool*2,16,9+wool*2,wool?'#f8fafc':'#cbd5e1');
  if(wool){
    R(x-9,y-9,2,6,'#f1f5f9');
    R(x+7,y-9,2,6,'#f1f5f9');
    R(x-6,y-12,12,3,'#ffffff');
  }
  R(x+6,y-12,5,5,'#475569');
  R(x+7,y-13,2,2,'#334155');
  R(x+8,y-11,1,1,'#fff');
  R(x-6,y-1,2,4,'#334155');R(x-2,y-1,2,4,'#334155');
  R(x+2,y-1,2,4,'#334155');R(x+6,y-1,2,4,'#334155');
  if(labelNear(x,y,55))T('Kıvırcık 🐑',x,y-20-wool*2,'#fde047');
}

function eggD(e){
  const x=Math.round(e.x),y=Math.round(e.y);
  R(x-2,y,4,1,'#0003');
  R(x-2,y-4,4,4,e.star===3?'#facc15':e.star===2?'#fef08a':'#fef9c3');
  R(x-1,y-5,2,5,e.star===3?'#ffd23f':'#ffffff');
  if(e.star===3)R(x,y-4,1,1,'#fff');
}

function ladderD(x, y, isUp){
  x = Math.round(x); y = Math.round(y);
  R(x-7, y-7, 14, 14, '#090d16');
  R(x-6, y-6, 12, 12, '#0f172a');
  R(x-5, y-6, 2, 12, '#78350f');
  R(x+3, y-6, 2, 12, '#78350f');
  for(let i=0; i<4; i++){
    R(x-4, y-5+i*3, 8, 1.5, '#ca8a04');
  }
  T(isUp ? 'Cikis 🪜' : 'Merdiven 🪜', x, y-12, isUp ? '#6ee7b7' : '#ffd23f');
}

function elevatorD(x, y){
  x = Math.round(x); y = Math.round(y);
  R(x-8, y-10, 16, 12, '#334155');
  R(x-7, y-9, 14, 10, '#1e293b');
  R(x-1, y-14, 2, 5, '#eab308');
  R(x-4, y-8, 8, 8, '#ca8a04');
  R(x-2, y-6, 4, 4, '#fef08a');
  if(labelNear(x,y,48))T('Asansör 🛗',x,y-14,'#ffd23f');
}

function coopD(x,y){
  x=Math.round(x);y=Math.round(y);
  if(P.hasCoop){
    R(x-14,y-12,28,12,'#854d0e');
    R(x-16,y-18,32,6,'#b91c1c');
    R(x-12,y-22,24,4,'#dc2626');
    R(x-4,y-8,8,8,'#451a03');
    R(x+8,y-4,8,4,'#ca8a04');
    if(HERD.readyCount('coop')>0){
      R(x+9,y-6,3,3,'#fef08a');
      R(x+12,y-6,3,3,'#fef08a');
    }
    if(labelNear(x,y,65))T('Tavuk Kümesi 🐔',x,y-26,'#ffd23f');
  }else{
    R(x-10,y-10,20,10,'#78350f');
    R(x-1,y,2,6,'#451a03');
    if(labelNear(x,y,65))T('🐔 Kümes Yap',x,y-14,'#ffd23f');
  }
}

function drawWaypointGuide(){
  if(P.dead)return;
  const step=ONBOARD.current();
  let tx=null,ty=null,label='';
  if(step){
    if(curMap==='home'){
      if(step.id==='home'||step.id==='cook'){tx=12*TS;ty=24*TS-24;label=step.id==='cook'?'▼ EVE GİR & EKMEK PİŞİR':'▼ ÇİFTLİK EVİ'}
      else if(step.id==='farm'){tx=18*TS;ty=24*TS-22;label='▼ KOLAY BAHÇE · GÜNLÜK BAKIM'}
      else if(step.id==='forest'){tx=56*TS;ty=30*TS-16;label='Doğu Kapısı'}
      else if(step.id==='chest'){tx=27*TS;ty=37*TS-22;label='▼ İNŞA ARAZİSİ'}
    }else if(curMap==='world'&&step.id==='forest'){
      tx=50*TS;ty=22*TS-12;label='Slime Açıklığı';
    }else if(curMap==='inside'){
      if(step.id==='cook'){tx=7*TS;ty=14*TS-18;label='OCAK · EKMEK'}
      else{tx=15*TS;ty=22*TS;label='Dışarı'}
    }
  }
  if(tx===null&&window.STORY&&STORY.needsRest&&STORY.needsRest()){
    if(curMap==='home'){tx=12*TS;ty=24*TS-20;label='Eve Gir'}
    else if(curMap==='inside'){tx=22*TS;ty=8*TS-16;label='Yatak'}
  }
  if(tx===null&&QS[P.q]?.k==='treant'&&curMap==='world'){tx=56*TS;ty=12*TS-18;label='Muhafız Korusu'}
  if(tx===null&&QS[P.q]?.k==='lizard'&&curMap==='world'){tx=40*TS;ty=54*TS-18;label='İskele Koyu'}
  if(tx===null&&QS[P.q]?.k==='crab'&&curMap==='world'){tx=36*TS;ty=44*TS-18;label='Yengeç Kayalığı'}
  if(tx===null&&window.STORY&&STORY.needsOasis&&STORY.needsOasis()&&curMap==='world'){tx=84*TS;ty=38*TS-18;label='Vaha'}
  if(tx===null&&QS[P.q]?.k==='scorpion'&&curMap==='world'){tx=73*TS;ty=47*TS-18;label='Kervan Yolu'}
  if(tx===null&&QS[P.q]?.k==='golem'&&curMap==='world'){tx=82*TS;ty=56*TS-18;label='Golem Çukuru'}
  if(tx===null&&QS[P.q]?.k==='forge'&&curMap==='home'){tx=50*TS;ty=38*TS-18;label='Demirci'}
  if(tx===null&&QS[P.q]?.k==='skeleton'&&curMap==='world'){tx=50*TS;ty=67*TS-18;label='Kül Geçidi'}
  if(tx===null&&QS[P.q]?.k==='dragon'&&curMap==='world'){tx=50*TS;ty=84*TS-18;label='Ejder Arenası'}
  if(tx===null&&window.STORY&&STORY.cueHome&&STORY.cueHome()){if(curMap==='home'){tx=18*TS;ty=14*TS-18;label='Hamdi'}else if(curMap==='world'){tx=8*TS;ty=50*TS-18;label='Kasaba'}}
  if(tx===null&&window.STORY&&STORY.resting&&STORY.resting()&&curMap==='home'){tx=12*TS;ty=24*TS-20;label='Evin'}
  if(tx===null&&window.STORY&&STORY.mastery){const job=STORY.mastery();if(job==='mine'&&curMap==='home'){tx=6*TS;ty=8*TS-18;label='Maden'}else if(job==='frontier'&&curMap==='world'){tx=55*TS;ty=30*TS-18;label='Yayla'}else if(job==='elite'&&curMap==='world'){tx=27*TS;ty=81*TS-18;label='Seçkinler'}}
  if(tx===null||ty===null)return;
  const bob=Math.sin(P.t*6)*3;
  R(tx-2,ty+bob-4,4,4,'#fde047');R(tx-1,ty+bob,2,2,'#fff');
  T(label,tx,ty+bob-7,'#fde047',true);
}

function gardenCampusGroundD(){
  const h=FARM.cfg();
  // 0) Çiftlik Kampüsü Ahşap Giriş Kemeri (14*TS, 24*TS)
  const ax=14*TS,ay=24*TS;
  R(ax-12,ay-22,3,22,'#5c3a1e');R(ax+9,ay-22,3,22,'#5c3a1e');
  R(ax-14,ay-25,28,4,'#78350f');R(ax-12,ay-27,24,2,'#b45309');
  R(ax-9,ay-24,18,2,'#fde047');
  if(Math.hypot(P.x-ax,P.y-ay)<70&&Math.hypot(P.x-18*TS,P.y-24*TS)>55&&ONBOARD.current()?.id!=='farm')T('Tarla Bahçe',ax+22,ay-44,'#fde047');

  // 1) Bahçe Yönetim Tabelası (18*TS, 24*TS)
  const sx=18*TS,sy=24*TS;
  R(sx-5,sy-1,10,2,'#0004');
  R(sx-1,sy-12,3,12,'#5c3a1e');
  R(sx-8,sy-18,17,8,'#854d0e');R(sx-7,sy-17,15,6,'#b45309');
  R(sx-5,sy-15,11,1,'#fde047');R(sx-5,sy-13,8,1,'#fef08a');
  if(Math.hypot(P.x-sx,P.y-sy)<55&&ONBOARD.current()?.id!=='farm')T('Bahçe',sx,sy-21,'#86efac');

  // 2) Kuzey Meyve Bahçesi Alçak Taş Bordür & Ağaç Toprak Çemberleri
  const ox0=14*TS+6,oy0=15*TS-6,ow=8*TS+4,oh=4*TS+14;
  R(ox0,oy0,ow,2,'#64748b');R(ox0,oy0+oh-2,ow,2,'#64748b');
  R(ox0,oy0,2,oh,'#64748b');R(ox0+ow-2,oy0,2,oh,'#64748b');
  for(const slot of ORCHARD_SLOTS){
    const ox=slot.gx*TS,oy=slot.gy*TS;
    R(ox-7,oy-3,14,6,'#5c3a1e');R(ox-6,oy-2,12,4,'#3f2712');
    if(!h.orchard.includes(slot.slot)&&Math.hypot(P.x-ox,P.y-oy)<68){
      const tDef=ORCHARD_TREES[slot.type];
      T(`+Fidan: ${tDef.icon}`,ox,oy-8,'#a7f3d0');
    }
  }

  // 3) 3 Bahçe Yatağı Ahşap Çerçeve & Kilitli Genişleme Parselleri
  const bedRects=[
    {id:1,x:15*TS-3,y:26*TS-3,w:4*TS+6,h:3*TS+6,label:'1. Yatak'},
    {id:2,x:15*TS-3,y:30*TS-3,w:4*TS+6,h:3*TS+6,label:'2. Yatak (+12)'},
    {id:3,x:20*TS-3,y:26*TS-3,w:3*TS+6,h:7*TS+6,label:'3. Yatak (+18)'}
  ];
  for(const br of bedRects){
    const open=h.beds>=br.id;
    if(open){
      const frameCol=h.soilLv>=3?'#ca8a04':h.soilLv>=2?'#92400e':'#78350f';
      const trimCol=h.soilLv>=3?'#fde047':h.soilLv>=1?'#d97706':'#b45309';
      R(br.x,br.y,br.w,2,frameCol);R(br.x,br.y+br.h-2,br.w,2,frameCol);
      R(br.x,br.y,2,br.h,frameCol);R(br.x+br.w-2,br.y,2,br.h,frameCol);
      R(br.x,br.y,3,3,trimCol);R(br.x+br.w-3,br.y,3,3,trimCol);
      R(br.x,br.y+br.h-3,3,3,trimCol);R(br.x+br.w-3,br.y+br.h-3,3,3,trimCol);
    }else{
      g.globalAlpha=0.55;
      R(br.x+2,br.y+2,br.w-4,br.h-4,'#14532d66');
      R(br.x+2,br.y+2,br.w-4,1,'#86efac');R(br.x+2,br.y+br.h-3,br.w-4,1,'#86efac');
      R(br.x+2,br.y+2,1,br.h-4,'#86efac');R(br.x+br.w-3,br.y+2,1,br.h-4,'#86efac');
      g.globalAlpha=1;
      if(Math.hypot(P.x-(br.x+br.w/2),P.y-(br.y+br.h/2))<90){
        T('🔒 '+br.label+' [Dokun]',br.x+br.w/2,br.y+br.h/2,'#fde047');
      }
    }
  }

  // 4) Cam Sera (Greenhouse) Kubbe & Kristal Çerçevesi
  if(h.greenhouse){
    const gx=15*TS-5,gy=26*TS-5,gw=8*TS+10,gh=7*TS+10;
    R(gx,gy,gw,2,'#38bdf8');R(gx,gy+gh-2,gw,2,'#38bdf8');
    R(gx,gy,2,gh,'#38bdf8');R(gx+gw-2,gy,2,gh,'#38bdf8');
    R(gx-1,gy-1,4,4,'#fde047');R(gx+gw-3,gy-1,4,4,'#fde047');
    R(gx-1,gy+gh-3,4,4,'#fde047');R(gx+gw-3,gy+gh-3,4,4,'#fde047');
    g.globalAlpha=0.1;R(gx+2,gy+2,gw-4,gh-4,'#bae6fd');g.globalAlpha=1;
  }

  // 5) Güney Zanaat Terası Taş Kaideleri (Arı Kovanı: 16*TS,35*TS · Fıçı: 19*TS,35*TS · Kompost & Islah: 21*TS,35*TS)
  R(16*TS-9,35*TS-5,18,7,'#475569');R(16*TS-8,35*TS-4,16,5,'#64748b');
  if(!P.hasBeehive&&Math.hypot(P.x-16*TS,P.y-35*TS)<60)T('🐝 Kovan Yeri',16*TS,35*TS-10,'#fde047');
  R(19*TS-9,35*TS-5,18,7,'#475569');R(19*TS-8,35*TS-4,16,5,'#64748b');
  if(!P.hasCask&&Math.hypot(P.x-19*TS,P.y-35*TS)<60)T('🛢️ Fıçı Yeri',19*TS,35*TS-10,'#cbd5e1');
  const cx=21*TS,cy=35*TS;
  R(cx-7,cy-9,14,9,'#3f6212');R(cx-6,cy-8,12,7,'#4d7c0f');R(cx-5,cy-10,10,2,'#84cc16');
  if(Math.hypot(P.x-cx,P.y-cy)<60)T('🧬 Islah & Kompost',cx,cy-13,'#a3e635');

  // 6) Bahçe Korkuluğu (Scarecrow: 14*TS+4, 27.5*TS)
  const scx=14*TS+4,scy=27*TS+8;
  R(scx-1,scy-12,2,12,'#78350f');R(scx-6,scy-8,12,2,'#92400e');
  R(scx-4,scy-9,8,5,'#ca8a04');R(scx-3,scy-14,6,5,'#ea580c');R(scx-5,scy-15,10,2,'#fde047');

  // 7) Batı Hayvancılık Meraları Yemlik ve Su Olukları (Engelsiz Dekor)
  R(11*TS-8,16*TS-3,14,5,'#78350f');R(11*TS-7,16*TS-2,12,3,'#fde047');
  R(11*TS-8,31*TS-3,16,6,'#78350f');R(11*TS-7,31*TS-2,14,4,'#38bdf8');
}

function farmPlotD(p){
  const x=Math.round(p.x)-8,y=Math.round(p.y)-8,w=p.watered,soilLv=FARM.cfg().soilLv||0;
  const baseDry=soilLv>=3?'#713f12':soilLv>=1?'#784721':'#8a5a2e';
  const baseWet=soilLv>=3?'#32190b':soilLv>=1?'#3b2313':'#452b18';
  R(x,y,16,16,w?baseWet:baseDry);
  R(x,y,16,1,w?'#2b1a0d':'#6b4423');R(x,y+15,16,1,w?'#2b1a0d':'#6b4423');
  R(x,y,1,16,w?'#32200f':'#74491f');R(x+15,y,1,16,w?'#32200f':'#74491f');
  for(let i=4;i<15;i+=4)R(x+2,y+i,12,1,w?'#321d10':'#7a4c22');
  if(w){R(x+3,y+3,3,1,'#6b8da055');R(x+10,y+8,2,1,'#8cb4c455')}
  else{R(x+4,y+4,1,3,'#4b2b17');R(x+3,y+6,2,1,'#4b2b17');R(x+11,y+10,1,3,'#5a3219');R(x+10,y+12,2,1,'#5a3219')}
  if(p.fert||soilLv>=2){R(x+2,y+2,1,1,'#fde68a');R(x+12,y+9,1,1,'#fde68a');R(x+6,y+13,1,1,'#fde68a')}
  if(!p.crop){if(FARM.focusedPlot===p)T('Boş toprak · Ekim için hazır',x+8,y-5,'#e7c58a',true);return}
  const c=CROPS[p.crop];if(!c)return;
  const cx=x+8,by=y+14;
  // Küçük ürün rozeti, filiz aşamasından itibaren hangi ürünün ekili olduğunu açıkça gösterir.
  R(x+1,y+1,7,7,'#07111dcc');T2(c.icon,x+4.5,y+7);
  if(p.dead){
    R(cx-1,by-5,2,5,'#78350f');R(cx-4,by-4,3,1,'#92400e');R(cx+1,by-3,3,1,'#92400e');R(cx-2,by-7,1,2,'#a16207');
    if(FARM.focusedPlot===p)T(`${c.icon} ${c.n} · Solmuş`,cx,y-6,'#fca5a5',true);return;
  }
  const st=FARM.stageOf(p),left=Math.max(0,c.d-(p.age||0));
  const t=performance.now()/500,sw=st>=2?Math.round(Math.sin(t+p.x*.3)*.7):0;
  FARM.sprite(c,st,cx,by,sw,p.crop);
  if(st===3){
    const bob=Math.sin(P.t*4+p.id)*1.5;
    R(x,y,3,1,'#86efac');R(x+13,y,3,1,'#86efac');R(x,y+15,3,1,'#86efac');R(x+13,y+15,3,1,'#86efac');
    R(cx-5,y-10+bob,10,8,'#ffffffdd');R(cx-4,y-9+bob,8,6,'#fef9c3');T2(c.icon,cx,y-3+bob);
  }else if(!w){R(x+12,y+2,2,2,'#f59e0b');R(x+13,y+4,1,2,'#f59e0b')}
  if(FARM.focusedPlot===p){
    const stageName=st===0?'Yeni ekildi':st===1?'Filizlendi':st===2?'Büyüyor':'Hasada hazır';
    T(`${c.icon} ${c.n} · ${stageName}${st<3?` · ${left} gün · ${w?'💧 Sulu':'Kuru'}`:''}`,cx,y-6,st===3?'#86efac':w?'#bae6fd':'#fde68a',true);
    const prog=cl((p.age||0)/c.d,0,1);R(x+2,y+13,12,2,'#0f172a');R(x+2,y+13,Math.max(2,Math.round(12*prog)),2,st===3?'#4ade80':w?'#38bdf8':'#facc15');
  }
}

const COOK_RECIPES=[
  {id:'c_soup',name:'Havuç Çorbası',icon:'🍲',req:'2 Havuç',needs:{carrot:2},hp:80,mp:0,buff:'def',dur:3},
  {id:'c_bread',name:'Taze Köy Ekmeği',icon:'🍞',req:'2 Buğday',needs:{wheat:2},hp:60,mp:0,buff:'atk',dur:3},
  {id:'c_fish',name:'Izgara Balık',icon:'🐟',req:'1 Balık',needs:{fish:1},hp:70,mp:0,buff:'crit',dur:3},
  {id:'c_pie',name:'Çilekli Turta',icon:'🥧',req:'2 Çilek',needs:{berry:2},hp:50,mp:40,buff:'spd',dur:3},
  {id:'c_omelet',name:'Köy Omleti',icon:'🍳',req:'2 Yumurta',needs:{egg:2},hp:100,mp:0,buff:'atk',dur:6},
  {id:'c_cheese',name:'Çiftlik Peyniri',icon:'🧀',req:'1 Süt',needs:{milk:1},hp:80,mp:0,buff:'def',dur:6},
  {id:'c_pancake',name:'Ballı Sütlü Pankek',icon:'🥞',req:'1 Süt + 1 Yumurta + 1 Buğday',needs:{milk:1,egg:1,wheat:1},hp:120,mp:60,buff:'spd',dur:6},
  {id:'c_corn',name:'Közde Mısır',icon:'🌽',req:'1 Mısır',needs:{corn:1},hp:70,mp:50,buff:'def',dur:6},
  {id:'c_pumpkin',name:'Fırında Balkabağı Tatlısı',icon:'🎃',req:'1 Balkabağı + 1 Süt',needs:{pumpkin:1,milk:1},hp:140,mp:0,buff:'atk',dur:10},
  {id:'c_royal',name:'Kraliyet Ziyafeti',icon:'👑',req:'1 Balık + 1 Bal + 1 Un + 1 Peynir',needs:{fish:1,honey:1,flour:1,c_cheese:1},hp:200,mp:100,buff:'atk',dur:12}
];
function cookUI(){
  const baking=ONBOARD.current()?.id==='cook',wheat=countInv('wheat');
  let h=baking?`<p style="font-size:11px;color:#fde68a"><b>Taze Köy Ekmeği</b> bu adımın yemeği. Buğday ${Math.min(wheat,2)}/2.${wheat<2?' Bahçede Günlük Bakım hazır buğdayı toplar.':''}</p>`:'<p style="font-size:10px;color:#a7f3d0">Girdiler tüketilince açılan gözler de hesaba katılır. Çift porsiyonun tamamı sığmıyorsa malzemelerin harcanmaz.</p>';
  COOK_RECIPES.forEach(r=>{
    const canCook=Object.entries(r.needs).every(([k,n])=>hasInv(k,n));
    const focus=baking&&r.id==='c_bread';
    h+=`<div class="ach-item" style="${focus?'outline:1px solid #fde68a;background:#3a2e12':''}"><div class="ach-info">
      <div class="ach-title">${r.icon} ${r.name}</div><div class="ach-desc">Gereken: ${r.req}</div>
      </div><button class="m" data-cook="${r.id}" style="padding:5px 12px;font-size:11px;margin:0;background:${canCook?'#16a34a':'#475569'}">${focus&&canCook?'Ekmeği Pişir':canCook?'Pişir':'Eksik'}</button></div>`;
  });
  $('cook-list').innerHTML=h;
}
$('cook-list').onclick=e=>{
  const recipe=COOK_RECIPES.find(r=>r.id===e.target.closest('[data-cook]')?.dataset.cook);
  if(!recipe)return;
  addFood(recipe.id,recipe.name,recipe.icon,recipe.hp,recipe.mp,recipe.buff,recipe.dur,recipe.needs);
};
function hasInv(k,n=1){return Number.isSafeInteger(n)&&n>=0&&countInv(k)>=n}
function consumeInv(k,n){return ITEMS.take(P.inv,k,n)}
function hasFish(){return hasInv('fish',1)}
function consumeFish(){return consumeInv('fish',1)}
function addFood(k,name,icon,hp,mp,buff,durationM,needs={}){
  const cLvl=P.skills?.cook?.lvl||1,dur=Math.max(durationM,cLvl>=10?10:cLvl>=2?6:0);
  const portions=cLvl>=4&&Math.random()<.25?2:1;
  const output=Array.from({length:portions},()=>({s:'food',k,id:k,n:name,icon,hp,mp,buff,duration:dur*60,
    desc:`+${hp} Can${mp?' · +'+mp+' Mana':''} ${buff?`· ${buff==='crit'?'+8 puan Kritik':'+%22 '+(buff==='atk'?'Saldırı':buff==='def'?'Zırh':'Hız')} (${dur}dk)`:''}`}));
  if(!tryInventoryRecipe(needs,output))return false;
  if(k==='c_bread')ONBOARD.event('cook');
  if(portions>1)fl(P.x,P.y-32,'🍳 2 KAT PORSİYON!','#ffd23f',true);
  addMasteryXp('cook',20);SESSION_COACH.event('farm',1);
  fl(P.x,P.y-26,'+'+icon+' '+name,'#a7f3d0',true);playChord([523,659,784],.2,'triangle',.05);
  sv();cookUI();return true;
}

function houseUI(){
  const levels=[
    {lv:1,name:'Ahşap Çiftlik Kulübesi',desc:'Temel çiftlik evi, yatak ve ocak.',cost:0,gems:0,wood:0,stone:0},
    {lv:2,name:'Taş Çiftlik Evi',desc:'Taş cephe, yenilenen çatı ve 40 gözlü ev kileri. Kapladığı arazi değişmez.',cost:300,gems:5,wood:8,stone:8},
    {lv:3,name:'Görkemli Malikane',desc:'Altın işlemeli çatı, taş cephe ve 50 gözlü ev kileri. Kapladığı arazi değişmez.',cost:1800,gems:15,wood:16,stone:16}
  ];
  let h=`<p>Mevcut Ev Seviyesi: <b>Lv.${houseLevel} - ${levels[houseLevel-1].name}</b></p>`;
  if(houseLevel<3){
    const next=levels[houseLevel];
    h+=`<div class="ach-item">
      <div class="ach-info">
        <div class="ach-title">Sonraki: ${next.name}</div>
        <div class="ach-desc">${next.desc}</div>
        <div class="ach-reward">Maliyet: 🪙 ${next.cost} · 💎 ${next.gems} · 🪵 ${next.wood||0} Odun · 🪨 ${next.stone||0} Taş</div>
      </div>
      <div>
        <button id="btn-upgrade-house" class="m" style="padding:6px 14px;font-size:12px;margin:0">Evi Geliştir (🔨)</button>
      </div>
    </div>`;
  }else{
    h+='<p style="color:#ffd23f">Evin maksimum görkemli seviyeye ulaştı!</p>';
  }
  $('house-content').innerHTML=h;
  if($('btn-upgrade-house')){
    $('btn-upgrade-house').onclick=()=>{
      const next=levels[houseLevel];
      if(!next)return;
      if(tryInventoryRecipe({wood:next.wood||0,stone:next.stone||0},[],{gold:next.cost,gems:next.gems})){
        houseLevel++;
        fl(P.x,P.y-26,'🏡 EV GELİŞTİRİLDİ: '+next.name,'#ffd23f',true);
        playChord([523,659,784,1046],.4,'triangle',.07);
        sv();houseUI();
      }
    };
  }
}

function cafeUI(){
  $('cafe-content').innerHTML=`
    <p>🪙 Altın: <b>${P.gold}</b></p>
    <p style="font-size:11px;color:#fde047">"Hoş geldin! Taze pişmiş sıcacık kahve ve fırın lezzetleri!"</p>
    <button data-cf="coffee" style="display:block;width:100%;margin:5px 0">☕ Kahve (+%22 Hız, ${friendHearts('melis')>=5?6:3} dk) · ${friendPrice('melis',15)} Altın</button>
    <button data-cf="croissant" style="display:block;width:100%;margin:5px 0">🥐 Kruvasan (+60 Can, +40 Kalkan; sınır 150) · ${friendPrice('melis',20)} Altın</button>
    <button data-cf="stew" style="display:block;width:100%;margin:5px 0">🍲 Güveç (+100 Kalkan; sınır 200, +%22 Saldırı ${friendHearts('melis')>=5?6:3} dk) · ${friendPrice('melis',35)} Altın</button>
  `;
}

$('cafe-content').onclick=e=>{
  const act=e.target.dataset.cf;
  if(!act)return;
  const duration=friendHearts('melis')>=5?360:180;
  if(act==='coffee'&&P.gold>=friendPrice('melis',15)){
    P.gold-=friendPrice('melis',15);P.buffs.spd=Math.max(P.buffs.spd||0,duration);S=st();
    fl(P.x,P.y-26,'☕ KAHVE İÇİLDİ (+%22 Hız)' ,'#fde047',true);
    sfx(650,.15,'sine',.04);
  }else if(act==='croissant'&&P.gold>=friendPrice('melis',20)){
    P.gold-=friendPrice('melis',20);P.hp=Math.min(S.h,P.hp+60);grantShield(40,150);
    fl(P.x,P.y-26,'🥐 KRUVASAN YENDİ!','#6ee7b7',true);
    sfx(650,.15,'sine',.04);
  }else if(act==='stew'&&P.gold>=friendPrice('melis',35)){
    P.gold-=friendPrice('melis',35);grantShield(100,200);P.buffs.atk=Math.max(P.buffs.atk||0,duration);S=st();
    fl(P.x,P.y-26,'🍲 GÜVEÇ YENDİ (+100 Kalkan & Hasar)','#ffd23f',true);
    sfx(650,.15,'sine',.04);
  }
  sv();cafeUI();
};

function shippingBinD(x, y){
  x = Math.round(x); y = Math.round(y);
  const count=ITEMS.count(P.shippingBin||[]);
  R(x-9, y-1, 18, 3, '#0003');
  R(x-8, y-10, 16, 9, '#78350f');
  R(x-8, y-10, 2, 9, '#451a03'); R(x+6, y-10, 2, 9, '#451a03');
  R(x-6, y-6, 12, 2, '#92400e');
  if(count > 0){
    R(x-10, y-13, 20, 3, '#ca8a04');
    R(x-4, y-11, 8, 2, '#fde047');
    if(labelNear(x,y,48))T('📦 '+count,x,y-16,'#ffd23f');
  }else{
    R(x-9, y-12, 18, 3, '#92400e');
    if(labelNear(x,y,48))T('Sevkiyat',x,y-15,'#94a3b8');
  }
}

function shippingUI(message=''){
  P.shippingBin=P.shippingBin||[];
  $('shipping-status').textContent=message;
  const countEl = $('shipping-count');
  if(countEl) countEl.textContent = P.shippingBin.length;
  let totalVal = 0;
  P.shippingBin.forEach(i=>{totalVal+=unitSaleValue(i)*ITEMS.qty(i)});
  if(!message&&P.shippingBin.length){const trends=P.shippingBin.map(i=>ECONOMY.trend(i));if(trends.every(t=>t.cls==='low'))$('shipping-status').textContent='⚠ Pazar fiyatları düşük. İstersen ürünleri geri alıp başka günü bekleyebilirsin.';else if(trends.some(t=>t.cls==='high'))$('shipping-status').textContent='📈 Sandıkta yüksek fiyatlı ürün var; bu gece satılması avantajlı.'}
  const estEl = $('shipping-est-gold');
  if(estEl) estEl.textContent = totalVal;

  let sh = '';
  for(let i=0;i<containerSlots(P.shippingBin,30);i++){
    const it = P.shippingBin[i] || null;
    sh += slotH(it, 'ship', i);
  }
  const sGrid = $('shipping-grid');
  if(sGrid) sGrid.innerHTML = sh;

  let bh = '';
  for(let i=0;i<containerSlots(P.inv,BAG_CAPACITY);i++){
    const it = P.inv[i] || null;
    bh += slotH(it, 'ship_bag', i);
  }
  const bGrid = $('ship-bag-grid');
  if(bGrid) bGrid.innerHTML = bh;
}

$('shipping-modal').onclick=e=>{
  const slot=e.target.closest('[data-w]');if(!slot)return;
  const deposit=slot.dataset.w==='ship_bag',idx=+slot.dataset.i;
  if(!deposit&&slot.dataset.w!=='ship')return;
  const from=deposit?P.inv:P.shippingBin,to=deposit?P.shippingBin:P.inv,it=from[idx];
  if(!it)return;if(deposit&&it.locked){shippingUI('🔒 Bu eşya korumalı. Sevkiyat için önce kilidini aç.');return}
  const amount=transferAmount(it,'shipping-amount');
  if(!ITEMS.transfer(from,to,idx,amount,deposit?30:BAG_CAPACITY)){
    shippingUI('Seçilen miktara yer yok; eşyaların olduğu yerde kaldı.');return;
  }
  sel=null;sfx(650,.08,'triangle',.04);sv();shippingUI(`${amount} adet ${it.n} ${deposit?'gece satışına ayrıldı':'çantana geri alındı'}.`);
};

$('btn-ship-all').onclick = () => {
  P.shippingBin = P.shippingBin || [];
  let moved=0,protectedCount=0;
  for(let i=0;i<P.inv.length;){
    const it=P.inv[i];if(it.locked&&isFarmSaleItem(it)){protectedCount+=ITEMS.qty(it);i++;continue}const isSellable=!it.locked&&isFarmSaleItem(it);
    if(isSellable&&ITEMS.transfer(P.inv,P.shippingBin,i,ITEMS.qty(it),30)){moved+=ITEMS.qty(it);continue}
    i++;
  }
  if(moved){sel=null;playChord([523,659,784],.2,'triangle',.04);sv()}
  shippingUI(moved?`📦 ${moved} adet ürün sevkiyata eklendi.${protectedCount?` 🔒 ${protectedCount} korumalı ürün çantada kaldı.`:''} Sığmayan ürünler çantanda; odun ve cevherlerin satılmadı.`:protectedCount?`🔒 ${protectedCount} korumalı ürün sevkiyata alınmadı.`:'Sevkiyata konulacak ürün yok veya sandık dolu.');
};

$('shpc').onclick = () => $('shipping-modal').classList.add('h');
$('earnc').onclick = () => $('earnings-modal').classList.add('h');
$('btn-claim-earnings').onclick = () => {
  $('earnings-modal').classList.add('h');
  sfx(900, .15, 'sine', .05);
};

function marketUI(){
  const wheatC=countInv('wheat'),carrotC=countInv('carrot'),berryC=countInv('berry'),cornC=countInv('corn');
  const pumpkinC=countInv('pumpkin'),eggC=countInv('egg'),milkC=countInv('milk'),woolC=countInv('wool');

  let totalFarmVal = 0;
  const saleGroups=new Map();
  P.inv.forEach(i=>{
    if(!i.locked&&isFarmSaleItem(i)){
      const qty=ITEMS.qty(i),value=unitSaleValue(i)*qty,key=ITEMS.key(i.k||i.s);
      totalFarmVal+=value;
      const row=saleGroups.get(key)||{item:i,qty:0,total:0};row.qty+=qty;row.total+=value;saleGroups.set(key,row);
    }
  });
  const opportunities=[...saleGroups.values()].map(row=>({...row,key:ITEMS.key(row.item.k||row.item.s),trend:ECONOMY.trend(row.item),unit:Math.round(row.total/Math.max(1,row.qty))})).sort((a,b)=>b.trend.factor-a.trend.factor||b.total-a.total).slice(0,3);
  const highItems=P.inv.filter(i=>!i.locked&&isFarmSaleItem(i)&&ECONOMY.trend(i).cls==='high'),highTotal=highItems.reduce((sum,i)=>sum+unitSaleValue(i)*ITEMS.qty(i),0),lowFarmCount=ITEMS.count(P.inv.filter(i=>!i.locked&&isFarmSaleItem(i)&&ECONOMY.trend(i).cls==='low'));
  const opportunityHTML=`<div class="market-opportunities"><h3>📈 Bugünün Satış Fırsatları</h3>${opportunities.length?opportunities.map(row=>`<div class="market-opportunity"><span>${row.item.icon||'📦'} <b>${row.item.n}</b> · ${row.qty} adet</span><i class="trend ${row.trend.cls}">${row.trend.label}</i><span>${row.unit}🪙/adet · toplam ${row.total}🪙</span><button type="button" data-op-sell="${row.key}">SAT</button></div>`).join(''):'<p class="inventory-help">Çantanda fiyatı karşılaştırılacak çiftlik ürünü yok.</p>'}<p class="inventory-help">Yüksek fiyatlı ürünü şimdi satabilirsin. Düşük fiyatlı ürünleri bekletmek, işlemek veya başka gün satmak daha iyi olabilir.</p></div>`;

  const materialRows=Object.entries(MATERIALS).map(([k,definition])=>{
    const items=P.inv.filter(it=>!it.locked&&ITEMS.stackable(it)&&ITEMS.key(it.k)===k),amount=ITEMS.count(items);
    if(!amount)return '';
    const total=items.reduce((sum,it)=>sum+unitSaleValue(it)*ITEMS.qty(it),0);
    return `<div class="material-sale"><span>${definition.icon} <b>${definition.n}</b> · ${amount} adet</span><button data-mat-sell="${k}" data-sell-qty="1">1 Sat (+${unitSaleValue(items[0])}🪙)</button><button data-mat-sell="${k}" data-sell-qty="all">Tümünü Sat (+${total}🪙)</button></div>`;
  }).join('');
  $('market-content').innerHTML=`
    <p>🪙 Altın: <b>${P.gold}</b></p>
    ${opportunityHTML}
    ${FARM.shopHTML()}

    <div style="margin-top:8px;border-top:1px solid #334155;padding-top:6px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <b style="color:var(--gd)">🌾 Çiftlik Satışı:</b>
        <div style="display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end"><button id="btn-sell-high" ${highItems.length?'':'disabled'} style="padding:4px 9px;font-size:9px;background:#14532d;border-color:#86efac;white-space:nowrap">📈 Yüksekleri Sat (+${highTotal})</button><button id="btn-sell-all-farm" style="padding:4px 9px;font-size:9px;background:#16a34a;border-color:#86efac;white-space:nowrap">⚡ Tümünü Sat (+${totalFarmVal})</button></div>
      </div>
      ${lowFarmCount?`<p class="inventory-help" style="color:#fca5a5">⚠ ${lowFarmCount} ürün düşük fiyatlı. “Tümünü Sat” bu ürünleri de satar.</p>`:''}
      <div style="display:flex;flex-direction:column;gap:4px">
        ${[['wheat','🌾 Buğday'],['carrot','🥕 Havuç'],['berry','🍓 Çilek'],['corn','🌽 Mısır'],['pumpkin','🎃 Balkabağı'],['egg','🥚 Yumurta'],['milk','🥛 Süt'],['wool','🧶 Yün']].map(([k,n])=>{const items=P.inv.filter(i=>!i.locked&&i.k===k),value=items.reduce((v,it)=>v+unitSaleValue(it)*ITEMS.qty(it),0);return `<button data-sell="${k}" style="text-align:left;padding:5px 8px">${n} · ${ITEMS.count(items)} adet · Tümünü Sat (+${value}🪙)</button>`}).join('')}
      </div>
    </div>
    <div style="margin-top:12px;text-align:left;border-top:1px solid #334155;padding-top:8px">
      <b style="color:#a5f3fc">⛏️ Ham Malzeme Satışı</b>
      <p class="inventory-help">İnşaat malzemeleri çiftlik toplu satışına dahil değildir. Aşağıdan ayrı satabilirsin.</p>
      ${materialRows||'<p class="inventory-help">Çantanda satılacak odun, taş veya cevher yok.</p>'}
      <p id="market-status" class="inventory-status" role="status"></p>
    </div>
    ${ECONOMY.html()}
  `;

  if($('btn-sell-high'))$('btn-sell-high').onclick=()=>{
    const predicate=i=>!i.locked&&isFarmSaleItem(i)&&ECONOMY.trend(i).cls==='high',count=ITEMS.count(P.inv.filter(predicate)),earned=ECONOMY.sellWhere(predicate);
    if(earned){fl(P.x,P.y-26,`📈 ${count} yüksek fiyatlı ürün: +${earned}🪙`,'#86efac',true);playChord([523,659,784],.25,'triangle',.045);sv();marketUI();$('market-status').textContent=`Yalnız yüksek fiyatlı ${count} ürün satıldı · +${earned} altın.`}
  };
  if($('btn-sell-all-farm')){
    $('btn-sell-all-farm').onclick = () => {
      const button=$('btn-sell-all-farm');
      if(lowFarmCount&&button.dataset.confirm!=='1'){
        button.dataset.confirm='1';button.textContent=`⚠ ${lowFarmCount} düşük fiyatlı ürün var · Onayla`;
        $('market-status').textContent='Tüm satış düşük fiyatlı ürünleri de içeriyor. Satmak için düğmeye tekrar bas.';
        setTimeout(()=>{const b=$('btn-sell-all-farm');if(b&&b.dataset.confirm==='1'){b.dataset.confirm='';b.textContent=`⚡ Tümünü Sat (+${totalFarmVal})`}},3000);return;
      }
      const count=ITEMS.count(P.inv.filter(i=>!i.locked&&isFarmSaleItem(i))),earned=ECONOMY.sellWhere(isFarmSaleItem);
      if(earned > 0){
        fl(P.x, P.y-26, `+${earned} Altın Kazandın! (${count} ürün)`, '#ffd23f', true);
        playChord([523,659,784,1046],.35,'triangle',.06);
        sv(); marketUI();
      }else fl(P.x, P.y-22, 'Satılacak çiftlik ürünü yok!', '#cbd5e1');
    };
  }
}

$('market-content').onclick=e=>{
  if(ECONOMY.click(e))return;
  const sdBtn = e.target.closest('[data-sd]');
  const sellBtn = e.target.closest('[data-sell]');
  const opportunityBtn=e.target.closest('[data-op-sell]'),goalBtn=e.target.closest('[data-goal-open]');
  if(goalBtn){ECONOMY.openGoal(goalBtn.dataset.goalOpen);return}
  if(sdBtn){ FARM.buy(sdBtn.dataset.sd, +(sdBtn.dataset.qty||1)); return; }
  if(opportunityBtn){
    const k=opportunityBtn.dataset.opSell,predicate=i=>!i.locked&&isFarmSaleItem(i)&&ITEMS.key(i.k||i.s)===k,count=ITEMS.count(P.inv.filter(predicate)),earned=ECONOMY.sellWhere(predicate);
    if(earned){sfx(900,.12,'sine',.05);sv();marketUI();$('market-status').textContent=`${count} adet ürün fırsat fiyatından satıldı · +${earned} altın.`}return;
  }
  const materialBtn=e.target.closest('[data-mat-sell]');
  if(materialBtn){
    const k=materialBtn.dataset.matSell,all=materialBtn.dataset.sellQty==='all';
    const before=P.gold;let sold=0;
    const matches=it=>!it.locked&&ITEMS.stackable(it)&&ITEMS.key(it.k)===k;
    if(all){sold=ITEMS.count(P.inv.filter(matches));ECONOMY.sellWhere(matches)}
    else{const index=P.inv.findIndex(matches);if(index>=0&&sellBagItem(index,1))sold=1}
    if(sold){sel=null;sfx(900,.12,'sine',.05);sv()}
    marketUI();$('market-status').textContent=sold?`${sold} adet satıldı · +${P.gold-before} altın.`:'Satılacak malzeme yok.';return;
  }
  if(sellBtn){
    const k = sellBtn.dataset.sell;
    const earned=ECONOMY.sellWhere(i=>i.k===k);
    if(earned > 0){
      fl(P.x, P.y-26, `+${earned} Altın Satıldı!`, '#ffd23f', true);
      sfx(900, .12, 'sine', .05);
      sv(); marketUI();
    }else{
      fl(P.x, P.y-22, 'Satılacak eşya yok!', '#cbd5e1');
    }
  }
};


/* ===== KARANLIK KRİSTAL MADENİ ASANSÖR & İLERLEME ===== */
function descendMineFloor(){
  const md=WORLD_DATA.mine;
  if(curMap!=='mine'||!md?.ladder?.uncovered||md.floor>=50||Math.hypot(P.x-md.ladder.x,P.y-md.ladder.y)>=30)return false;
  if(!GAME_CORE.canTravel()){inventoryWarning('Savaş sürüyor; merdivene dönmeden önce güvenli alan aç.');return false}
  const previous={floor:P.mineFloor,max:P.maxMineFloor,elevator:P.mineElevator},nextFloor=md.floor+1;
  P.mineFloor=nextFloor;P.maxMineFloor=Math.max(P.maxMineFloor||1,nextFloor);
  if(nextFloor%5===0)P.mineElevator=Math.max(P.mineElevator||1,nextFloor);
  if(!switchMap('mine')){P.mineFloor=previous.floor;P.maxMineFloor=previous.max;P.mineElevator=previous.elevator;return false}
  if(nextFloor%5===0){fl(P.x,P.y-28,`🛗 ASANSÖR: KAT ${nextFloor}`,'#ffd23f',true);playChord([523,659,784,1046],.4,'triangle',.08)}
  sv();return true;
}

function openElevatorModal(){
  P.maxMineFloor = Math.max(P.maxMineFloor || 1, P.mineFloor || 1);
  P.mineElevator = Math.min(50,Math.max(1,Math.min(P.mineElevator||1,P.maxMineFloor)));
  const maxF = Math.min(50, Math.max(1, P.maxMineFloor));
  $('mine-max-floor-lbl').textContent = `Kat ${maxF}`;
  
  let h = '';
  h += `<button class="m" data-mine-fl="1" style="padding:7px;font-size:11px;background:#334155;border-color:#64748b">Kat 1 (Giriş Taş Mağara)</button>`;
  if(P.mineFloor>1&&P.mineFloor<=maxF&&P.mineFloor%5!==0){
    h+=`<button class="m" data-mine-fl="${P.mineFloor}" style="padding:7px;font-size:11px;background:#166365;border-color:#67e8f9">⛏️ Devam Et · Kat ${P.mineFloor}</button>`;
  }
  for(let fl=5; fl<=50; fl+=5){
    const isUnlocked = fl <= (P.mineElevator || 1) && fl <= (P.maxMineFloor || 1);
    const biome = fl<=10?'Toprak':fl<=25?'Buzul':fl<=40?'Magma':'İridyum';
    h += `<button class="m" data-mine-fl="${fl}" style="padding:7px;font-size:11px;background:${isUnlocked?'#1e3a8a':'#1e293b'};color:${isUnlocked?'#ffd23f':'#64748b'};border-color:${isUnlocked?'#38bdf8':'#334155'}" ${isUnlocked?'':'disabled'}>
      ${isUnlocked ? `🛗 Kat ${fl} (${biome})` : `🔒 Kat ${fl} (Kilitli)`}
    </button>`;
  }
  $('mine-floors-list').innerHTML = h;
  $('mine-modal').classList.remove('h');
}

$('mine-modal').onclick = e => {
  const btn=e.target.closest('[data-mine-fl]');if(!btn||btn.disabled)return;
  if(!GAME_CORE.canTravel()){inventoryWarning('Savaş sürüyor; madene geçmek için önce güvenli alana çık.');return}
  const targetFloor=+btn.dataset.mineFl,previous={floor:P.mineFloor,entrance:P.mineEntrance};
  if(curMap==='world'||curMap==='home')P.mineEntrance=curMap;
  P.mineFloor=targetFloor;
  if(!switchMap('mine')){P.mineFloor=previous.floor;P.mineEntrance=previous.entrance;return}
  $('mine-modal').classList.add('h');sv();
};
$('mnc').onclick = () => $('mine-modal').classList.add('h');



