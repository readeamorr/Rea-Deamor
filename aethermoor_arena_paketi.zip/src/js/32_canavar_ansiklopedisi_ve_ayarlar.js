/* ===== CANAVAR ANSİKLOPEDİSİ (BESTIARY) VE AYARLAR ===== */
const BESTIARY = [
  { k: 'slime', name: 'Slime (Sv.1)', icon: '🟢', weak: 'Alev Büyüsü', drop: 'Altın, Çayır Otu', desc: 'Sakin ve zıplayan jölemsi orman canavarı.' },
  { k: 'wolf', name: 'Kurt (Sv.3)', icon: '🐺', weak: 'Refleks Parry & Kılıç', drop: 'Yaban Postu, Altın', desc: 'Sürü halinde çok hızlı koşan orman avcısı.' },
  { k: 'boar', name: 'Yayla Domuzu (Sv.4)', icon: '🐗', weak: 'Atılma uyarısından sıyrılma', drop: 'Altın, nadiren ekipman', desc: 'Sisli Yayla otlağında gezinir; kışın daha uzağı fark eder, siste görüşü daralır.' },
  { k: 'mire_wisp', name: 'Bataklık Ateşi (Sv.4)', icon: '🍄', weak: 'Kılıç ve ateş', drop: 'Altın, nadiren ekipman', desc: 'Sazlıkların loş sularında dolaşır. Lotus ve sazlık şifasını korur.' },
  { k: 'frost_wolf', name: 'Kırağı Kurdu (Sv.6)', icon: '❄️', weak: 'Ateş ve iyi zamanlanmış sıyrılma', drop: 'Altın, nadiren ekipman', desc: 'Karlı orman ve demir damarları çevresinde gezen soğuğa dayanıklı avcı.' },
  { k: 'treant', name: 'Orman Muhafızı [Boss Sv.4]', icon: '🌲', weak: 'Alev Çemberi & Darbe', drop: 'Orman Dalı, Nadir/Epik Eşya, Elmas', desc: 'Zümrüt Orman derinliklerinde kök patlamaları yapan dev kadim boss.' },
  { k: 'lizard', name: 'Murloc (Sv.5)', icon: '🦎', weak: 'Buz Dalgası & Şimşek', drop: 'Su Pulu, Mızrak', desc: 'Göl kıyısında yaşayan ve mızrak fırlatan su yaratığı.' },
  { k: 'crab', name: 'Kral Yengeç [Boss Sv.7]', icon: '🦀', weak: 'Ağır Darbe & Arkadan Vuruş', drop: 'Kral Kıskacı, Epik Ekipman, Elmas', desc: 'Sığ Göl kıyısında yaşayan, su baloncukları atan zırhlı dev boss.' },
  { k: 'scorpion', name: 'Akrep (Sv.8)', icon: '🦂', weak: 'Dondurma & Delici Ok', drop: 'Akrep Kıskacı, Altın', desc: 'Kızıl Çöl kumlarında zehirli kıskaçlarıyla gezen çöl canavarı.' },
  { k: 'golem', name: 'Kum Golemi [Boss Sv.10]', icon: '🗿', weak: 'Buz Kristali & Kaya Kırıcı', drop: 'Golem Çekirdeği, Epik/Efsanevi Eşya', desc: 'Çöl harabelerinde deprem şok dalgaları saçan devasa taş canavar.' },
  { k: 'skeleton', name: 'İskelet (Sv.11)', icon: '💀', weak: '3lü Kılıç Kombosu & Kasırga', drop: 'Kemik, Demir Kılıç', desc: 'Kılıç ve kalkanla organize saldıran mezar bekçisi.' },
  { k: 'phalanx', name: 'Kalkanlı Muhafız (Sv.12)', icon: '🛡️', weak: 'Arkadan Saldırı (Flank) & Buz', drop: 'Savaş Nişanı, Demir Cevheri', desc: 'Önden gelen TÜM saldırıları dev kule kalkanıyla bloke eder!' },
  { k: 'assassin', name: 'Gölge Suikastçisi (Sv.12)', icon: '🗡️', weak: 'Doğru Anda Sıyrılma (Dash)', drop: 'Gölge Pelerini, Çelik Bıçak', desc: 'Yönünü kısa süre takip edip kilitler, sonra hızla atılır. Uyarı çizgisinin dışına çık.' },
  { k: 'summoner', name: 'Kemik Çağırıcısı (Sv.12)', icon: '🔮', weak: 'Hızlı Suikast & Alev', drop: 'Büyü Asası, Elmas', desc: 'Arka saflardan menzilli büyü atışları yapar. Atış hazırlığını izleyip mesafeyi kapat.' },
  { k: 'dragon', name: 'Kızıl Ejder [Büyük Boss Sv.15]', icon: '🐉', weak: 'Buz Dalgası & Titan Yakarışı', drop: 'Efsanevi Ejderha Seti, Ejder Boynuzu', desc: 'Aethermoorun kadim hükümdarı! 2. fazında öfkelenir ve meteor yağmuru başlatır!' }
];

function bestiaryUI(){
  const book=P.adventure.bestiary,keys=Object.keys(MT),known=keys.filter(k=>book[k]?.seen).length,collected=keys.filter(k=>book[k]?.kills>0).length;
  let h=`<div class="journey-lead"><small>CANAVAR KARTI KOLEKSİYONU</small><h2>📚 ${collected}/${keys.length} Kart</h2><p>${known} tür görüldü. 1 / 5 / 15 galibiyet kartına yıldız kazandırır.</p></div>`;
  for(const k of keys){
    const entry=book[k],b=BESTIARY.find(b=>b.k===k),kills=entry?.kills||0,stars=kills>=15?3:kills>=5?2:kills>0?1:0;
    h+=`<div class="journey-box bestiary-card${entry?.seen?'':' locked'}" data-card="${k}"><div class="title-row"><b>${entry?.seen?`${b?.icon||'◆'} ${b?.name||MT[k].n}`:'🔒 Keşfedilmemiş Canavar'}</b><span class="bestiary-stars">${'★'.repeat(stars)}${'☆'.repeat(3-stars)}</span></div><p>${entry?.seen?(b?.desc||'Bu canavarı yenerek kartını koleksiyonuna ekle.'):'Açık dünyada veya madende bu türe yaklaş.'}</p>${entry?.seen?`<div class="card-tag">${entry.legacyCredit&&kills===0?'Eski kazanım korundu; tür bazlı geçmiş doğrulanamıyor.':kills+' galibiyet'} · ${b?'Öneri: '+b.weak:'Seviye '+MT[k].lv}</div>`:''}</div>`;
  }
  $('bestiary-list').innerHTML=h;
}

const WORLD_EVENTS=window.WORLD_EVENTS={
  defs:[
    {id:'market',icon:'🛒',name:'Pazar Günü',desc:'Bütün uygun satış fiyatları bugün %12 daha yüksek.',tag:'SATIŞ +%12',action:'market',actionLabel:'Pazarı Aç',objective:'sell',need:5,goal:'5 ürün sat',gold:40,gems:1},
    {id:'harvest',icon:'🌾',name:'Bereket Günü',desc:'Ekin ve çiftlik ürünü satışları bugün %20 daha yüksek.',tag:'ÜRÜN +%20',action:'market',actionLabel:'Ürünleri Gör',objective:'harvest',need:5,goal:'5 ürün hasat et',gold:35,gems:1},
    {id:'fishing',icon:'🎣',name:'Göl Şenliği',desc:'Balıklar daha hızlı ısırır ve satış değeri %25 artar.',tag:'BALIK +%25',action:'fishing',actionLabel:'Göle Git',objective:'fish',need:3,goal:'3 balık tut',gold:40,gems:1},
    {id:'hunt',icon:'⚔️',name:'Muhafız Çağrısı',desc:'Canavarlardan kazanılan XP %20, düşen altın %10 artar.',tag:'AV BONUSU',action:'hunt',actionLabel:'Av Rotasını Aç',objective:'hunt',need:5,goal:'5 düşman yen',gold:50,gems:1},
    {id:'mining',icon:'⛏️',name:'Cevher Talebi',desc:'Taş, cevher ve maden malzemesi satışları %25 daha yüksek.',tag:'MADEN +%25',action:'mining',actionLabel:'Madeni Göster',objective:'mine',need:3,goal:'3 maden kaynağı kır',gold:45,gems:1},
    {id:'social',icon:'🎉',name:'Kasaba Buluşması',desc:'Sohbet, hediye ve kişisel isteklerden gelen dostluk %25 artar.',tag:'DOSTLUK +%25',action:'social',actionLabel:'Dostları Gör',objective:'social',need:2,goal:'2 sosyal etkileşim yap',gold:30,gems:1}
  ],
  current(day=P.day){return this.defs[(Math.max(1,day)-1)%this.defs.length]},
  state(){const e=this.current();let s=P.adventure.worldEventProgress;if(!s||typeof s!=='object'||s.day!==P.day||s.id!==e.id)s={day:P.day,id:e.id,progress:0,done:false};s.progress=cl(Math.floor(Number(s.progress)||0),0,e.need);s.done=s.done===true;P.adventure.worldEventProgress=s;return s},
  progress(kind,amount=1){const e=this.current(),s=this.state();if(s.done||e.objective!==kind||!Number.isFinite(amount)||amount<=0)return false;s.progress=Math.min(e.need,s.progress+Math.floor(amount));if(s.progress>=e.need){s.done=true;P.gold+=e.gold;P.gems+=e.gems;P.townWorkDay=P.day;P.adventure.stats.worldEventsDone=(P.adventure.stats.worldEventsDone||0)+1;NOTIFICATIONS.push('event',e.icon,`${e.name} tamamlandı`,`İsteğe bağlı etkinlik ödülü: +${e.gold} altın · +${e.gems} elmas.`);ban(`${e.icon} ${e.name} ETKİNLİĞİ TAMAMLANDI!`,'#fde68a');chat('KASABA BÜLTENİ','',`İsteğe bağlı etkinlik ödülü: +${e.gold}🪙 +${e.gems}💎`,1);playChord([523,659,784,1046],.28,'triangle',.05)}sv();return true},
  saleMultiplier(it){const e=this.current();if(e.id==='market'&&ECONOMY.eligible(it))return 1.12;if(e.id==='harvest'&&isFarmSaleItem(it))return 1.2;if(e.id==='fishing'&&it?.s==='fish')return 1.25;if(e.id==='mining'&&it&&['stone','copper_ore','iron_ore','coal','gold_ore','ruby','diamond','iridium_ore'].includes(ITEMS.key(it.k)))return 1.25;return 1},
  xpMultiplier(){return this.current().id==='hunt'?1.2:1},
  lootMultiplier(){return this.current().id==='hunt'?1.1:1},
  friendshipMultiplier(){return this.current().id==='social'?1.25:1},
  fishingWaitMultiplier(){return this.current().id==='fishing'?.65:1},
  html(interactive=false){const e=this.current(),next=this.current(P.day+1),s=this.state(),pct=Math.round(s.progress/e.need*100);return `<div class="world-event"><span>${e.icon}</span><span class="world-event-main"><b>Bugünün Dünya Olayı: ${e.name}</b><small>${e.desc}</small><span class="event-objective ${s.done?'event-complete':''}"><span>${s.done?'✓ Etkinlik tamamlandı':`İsteğe bağlı: ${e.goal}`}</span><span>${s.progress}/${e.need} · +${e.gold}🪙 +${e.gems}💎</span></span><span class="event-progress"><i style="width:${pct}%"></i></span></span><span class="world-event-actions"><em>${e.tag}</em>${interactive?`<button type="button" data-world-event-action="${e.action}">${e.actionLabel}</button>`:''}<small class="world-event-next">Yarın: ${next.icon} ${next.name}</small></span></div>`},
  openAction(action){$('tv-modal').classList.add('h');if(action==='market'){if(FEATURES.use('market'))ADVENTURE.open('market')}else if(['fishing','hunt','mining'].includes(action)){$('journey-modal').classList.add('h');openMap('world')}else if(action==='social'&&FEATURES.use('social')){$('journey-modal').classList.add('h');$('friends-modal').classList.remove('h');friendsUI()}}, 
  newDay(){const e=this.current();P.adventure.worldEventProgress={day:P.day,id:e.id,progress:0,done:false};if(e.id==='social')for(const id of Object.keys(TOWNSFOLK))npcLifeState(id).mood=Math.min(100,npcLifeState(id).mood+8);setTimeout(()=>{ban(`${e.icon} ${e.name}`,'#fde68a');chat('KASABA BÜLTENİ','',`${e.desc} Yarın: ${this.current(P.day+1).name}.`,1)},1200)}
};
document.addEventListener('click',e=>{const b=e.target.closest?.('[data-world-event-action]');if(b)WORLD_EVENTS.openAction(b.dataset.worldEventAction)});
const DAY_RECAP=window.DAY_RECAP={
  init(){let s=P.adventure.dayStats;if(!s||typeof s!=='object'||Number(s.day)!==P.day)s={day:P.day,startGold:P.gold,startLevel:P.lvl,farm:0,explore:0,combat:0,fish:0,social:0};s.day=P.day;s.startGold=Math.max(0,Math.floor(Number(s.startGold)||P.gold));s.startLevel=Math.max(1,Math.floor(Number(s.startLevel)||P.lvl));for(const k of ['farm','explore','combat','fish','social'])s[k]=cl(Math.floor(Number(s[k])||0),0,9999);P.adventure.dayStats=s;P.adventure.dayRecapPending=P.adventure.dayRecapPending===true;return s},
  event(type,amount=1){const s=this.init();if(Object.hasOwn(s,type)&&Number.isFinite(amount)&&amount>0)s[type]+=Math.floor(amount)},
  closeDay(){const s=this.init(),focus=P.adventure.dailyFocus;P.adventure.lastDaySummary={day:s.day,farm:s.farm||0,explore:s.explore||0,combat:s.combat||0,fish:s.fish||0,social:s.social||0,netGold:P.gold-(s.startGold||0),levels:Math.max(0,P.lvl-(s.startLevel||P.lvl)),focus:focus?.type||null,focusDone:focus?.done===true,event:WORLD_EVENTS.current(s.day).id};const r=P.adventure.lastDaySummary;P.adventure.dayRecapPending=!!(r.farm+r.explore+r.combat+r.fish+r.social+Math.abs(r.netGold)+r.levels||r.focus);sv()},
  startDay(){P.adventure.dayStats={day:P.day,startGold:P.gold,startLevel:P.lvl,farm:0,explore:0,combat:0,fish:0,social:0}},
  maybeShow(){
    const r=P.adventure?.lastDaySummary;if(!P.adventure?.dayRecapPending||!r)return;P.adventure.dayRecapPending=false;NOTIFICATIONS.push('day','🌅',`Gün ${r.day} özeti`,`Çiftlik ${r.farm} · Keşif ${r.explore} · Savaş ${r.combat} · Balık ${r.fish} · Sosyal ${r.social} · Net altın ${r.netGold>=0?'+':''}${r.netGold}.`);sv();
    MODAL_QUEUE.enqueue(`day:${r.day}`,1,'day-recap-modal',()=>{const rec=GOALS.recommendation(),dayEvent=WORLD_EVENTS.defs.find(e=>e.id===r.event)||WORLD_EVENTS.current(r.day),focusName=r.focus?`${DAILY_FOCUS.defs[r.focus]?.name}${r.focusDone?' · tamamlandı':' · devam edebilir'}`:'Seçilmedi · isteğe bağlı',netSign=r.netGold>=0?'+':'';$('day-recap-content').innerHTML=`<div class="day-recap-hero"><span class="guide-kicker">GÜN ${r.day} TAMAMLANDI</span><h2>${r.focusDone?'✓ Odak tamamlandı':'Yeni güne hazırsın'}</h2><p>${dayEvent.icon} ${dayEvent.name} etkindi. Bu özet yalnızca ne yaptığını gösterir; eksik kalan etkinlikler için ceza yoktur.</p></div><div class="day-recap-grid"><div><b>🌿 ${r.farm}</b><span>Çiftlik / üretim</span></div><div><b>🧭 ${r.explore}</b><span>Kaynak noktası</span></div><div><b>⚔️ ${r.combat}</b><span>Düşman</span></div><div><b>🎣 ${r.fish}</b><span>Balık</span></div><div><b>❤️ ${r.social}</b><span>Sosyal etkileşim</span></div><div><b>⭐ ${r.levels}</b><span>Kazanılan seviye</span></div></div><div class="day-recap-net"><span><b>Günlük odak:</b> ${focusName}</span><strong style="color:${r.netGold>=0?'#86efac':'#fca5a5'}">Net altın ${netSign}${r.netGold}</strong></div><div class="goal-recommend"><small>YENİ GÜN ÖNERİSİ</small><h3>${rec.icon} ${rec.title}</h3><p>${rec.desc}</p></div>`;const next=$('day-recap-next'),nextAction=rec.action||'goals';if(nextAction){next.dataset.action=nextAction;next.textContent=rec.label||'Hedefler Merkezini Aç';next.classList.remove('h')}else{next.dataset.action='';next.classList.add('h')}$('day-recap-modal').classList.remove('h');GAME_CORE.resetInput()});
  }
};
function closeDayRecap(){$('day-recap-modal').classList.add('h');GAME_CORE.resetInput();MODAL_QUEUE.done()}
$('day-recap-close').onclick=closeDayRecap;$('day-recap-ok').onclick=closeDayRecap;$('day-recap-next').onclick=()=>{const action=$('day-recap-next').dataset.action;closeDayRecap();if(action)GOALS.open(action)};
const SESSION_COACH=window.SESSION_COACH={
  time:0,counts:{farm:0,explore:0,combat:0,fish:0,social:0},shown:{},breakShown:false,
  event(type,amount=1){
    DAY_RECAP.event(type,amount);const eventType={combat:'hunt',fish:'fish',social:'social'}[type];if(eventType)WORLD_EVENTS.progress(eventType,amount);if(!Object.hasOwn(this.counts,type)||!Number.isFinite(amount)||amount<=0)return;this.counts[type]+=amount;
    const limits={combat:12,explore:10,fish:5,social:4},tips={combat:'Uzun bir av yaptın. Ganimeti depolamak, yemek hazırlamak veya kasabaya dönmek iyi bir tempo değişimi olabilir.',explore:'Çantan kaynakla doluyor olabilir. Depoya dönüp bir yatırım hedefini tamamlamayı düşünebilirsin.',fish:'Yeterince balık tuttun. Bir kısmını pişirmek, satmak veya dostluk hediyesi yapmak yeni bir rota açabilir.',social:'Kasabada güzel vakit geçirdin. İstersen şimdi kısa bir keşif ya da çiftlik turuna çıkabilirsin.'};
    if(limits[type]&&this.counts[type]>=limits[type]&&!this.shown[type]){this.shown[type]=true;chat('TEMPO REHBERİ','',tips[type],1)}
  },
  tick(dt){this.time+=dt;if(this.time>=1200&&!this.breakShown){this.breakShown=true;chat('SİSTEM','','20 dakikadır oynuyorsun. İstersen mola verebilirsin; ilerlemen otomatik kaydedildi.',1);flushSave()}},
  label(){const minutes=Math.floor(this.time/60);return `${minutes} dk · ⚔️ ${this.counts.combat} · 🧭 ${this.counts.explore} · 🎣 ${this.counts.fish} · ❤️ ${this.counts.social}`}
};
const GAME_BALANCE=window.GAME_BALANCE={
  profiles:{
    story:{name:'Rahat',damage:.75,windup:1.2,xp:1,loot:1,death:.05,lastStand:true,desc:'Düşman hasarı %25 azalır, saldırı uyarıları %20 uzar ve yenilgide yalnız %5 altın kaybedilir. Hikâye ve keşif için. Ani ölümde 60 saniyede bir Son Şans koruması vardır.'},
    standard:{name:'Standart',damage:1,windup:1,xp:1,loot:1,death:.1,lastStand:true,desc:'Önerilen savaş hızı, hasar ve ödül dengesi. Ani ölümde 60 saniyede bir Son Şans koruması vardır.'},
    veteran:{name:'Usta',damage:1.15,windup:.9,xp:1.15,loot:1.15,death:.12,lastStand:false,desc:'Düşmanlar %15 daha sert, uyarılar %10 daha kısa. Canavar XP’si ve düşen altın %15 artar.'}
  },
  state(){if(!P.adventure)return'standard';const v=this.profiles[P.adventure.difficulty]?P.adventure.difficulty:'standard';P.adventure.difficulty=v;return v},
  profile(){return this.profiles[this.state()]},
  init(){this.state()},
  set(v){if(!this.profiles[v])return false;P.adventure.difficulty=v;sv();return true}
};
const CONTROLS=window.CONTROLS={
  defaults:{handedness:'right',size:'normal',view:'wide',haptics:true,labels:false,contrast:false},
  state(){
    if(!P.adventure)return {...this.defaults};const raw=P.adventure.controls&&typeof P.adventure.controls==='object'?P.adventure.controls:{};
    const s=P.adventure.controls={handedness:['right','left'].includes(raw.handedness)?raw.handedness:'right',size:['compact','normal','large'].includes(raw.size)?raw.size:'normal',view:['normal','wide','ultra'].includes(raw.view)?raw.view:'wide',haptics:raw.haptics!==false,labels:raw.labels===true,contrast:raw.contrast===true};return s;
  },
  init(){this.apply()},
  apply(){const s=this.state();document.body.classList.toggle('left-handed',s.handedness==='left');document.body.classList.toggle('show-action-labels',s.labels);document.body.classList.toggle('high-contrast',s.contrast);document.body.dataset.controlSize=s.size},
  set(key,value){const s=this.state();if(key==='handedness'&&['right','left'].includes(value))s.handedness=value;else if(key==='size'&&['compact','normal','large'].includes(value))s.size=value;else if(key==='view'&&['normal','wide','ultra'].includes(value)){s.view=value;if(window.__gfxReady)rs()}else if(['haptics','labels','contrast'].includes(key))s[key]=!!value;else return false;this.apply();sv();return true},
  vibrate(pattern){const s=this.state();if(!s.haptics||!navigator.vibrate)return false;try{return navigator.vibrate(pattern)}catch(e){return false}},
  test(){this.vibrate([25,30,45]);document.body.classList.add('control-test');setTimeout(()=>document.body.classList.remove('control-test'),700);sfx(720,.1,'sine',.05)}
};
function haptic(pattern=8){return CONTROLS.vibrate(pattern)}

function settingsUI(){
  $('settings-modal').classList.remove('h');
  $('vol-music').value = Math.round(volMusic * 100);
  $('vol-sfx').value = Math.round(volSfx * 100);
  $('lbl-vol-music').textContent = Math.round(volMusic * 100) + '%';
  $('lbl-vol-sfx').textContent = Math.round(volSfx * 100) + '%';
  $('opt-shake').value = shakeSetting;
  const difficulty=GAME_BALANCE.state(),profile=GAME_BALANCE.profile();$('opt-difficulty').value=difficulty;$('opt-notification-mode').value=NOTIFICATIONS.mode();$('difficulty-desc').textContent=profile.desc;$('balance-readout').innerHTML=`<b>Etkin denge:</b> Alınan hasar %${Math.round(profile.damage*100)} · Uyarı süresi %${Math.round(profile.windup*100)} · Yenilgi kaybı %${Math.round(profile.death*100)}${profile.lastStand?' · Son Şans açık':''}${profile.xp>1?` · Canavar XP +%${Math.round((profile.xp-1)*100)}`:''}${profile.loot>1?` · Düşen altın +%${Math.round((profile.loot-1)*100)}`:''}<br><b>Ganimet güvencesi:</b> ${P.adventure.lootPity||0}/8 · <b>Oturum:</b> ${SESSION_COACH.label()}`;
  const controls=CONTROLS.state();$('opt-handedness').value=controls.handedness;$('opt-control-size').value=controls.size;$('opt-view-distance').value=controls.view;$('opt-haptics').checked=controls.haptics;$('opt-action-labels').checked=controls.labels;$('opt-high-contrast').checked=controls.contrast;
  $('opt-vfx-quality').value=FX.options.quality;
  $('opt-vfx-res').value=FX.options.resolution;
  document.querySelectorAll('[data-vfx]').forEach(el=>{el.checked=FX.options[el.dataset.vfx]});
  const stats=FX.stats();
  $('vfx-readout').textContent=`Etkin: ${stats.tier} · ${cv.width}×${cv.height} piksel (x${RS}) · ${Math.round(stats.fps)} FPS · JS kare p95: ${stats.cpuP95.toFixed(1)} ms · ${stats.particleCount}/${stats.particleLimit} parçacık`;
}

$('vol-music').oninput = e => {
  volMusic = +e.target.value / 100;
  $('lbl-vol-music').textContent = e.target.value + '%';
  sv();
};

$('vol-sfx').oninput = e => {
  volSfx = +e.target.value / 100;
  $('lbl-vol-sfx').textContent = e.target.value + '%';
  sfx(700, .1, 'sine', .05);
  sv();
};

$('opt-shake').onchange=e=>{shakeSetting=e.target.value;sv()};
$('opt-difficulty').onchange=e=>{GAME_BALANCE.set(e.target.value);settingsUI()};$('opt-notification-mode').onchange=e=>{P.adventure.notificationMode=e.target.value==='quiet'?'quiet':'normal';if(P.adventure.notificationMode==='quiet'){MODAL_QUEUE.items.length=0;MODAL_QUEUE.keys.clear()}sv();settingsUI()};
$('opt-handedness').onchange=e=>{CONTROLS.set('handedness',e.target.value);settingsUI()};
$('opt-control-size').onchange=e=>{CONTROLS.set('size',e.target.value);settingsUI()};$('opt-view-distance').onchange=e=>{CONTROLS.set('view',e.target.value);settingsUI()};
$('opt-haptics').onchange=e=>CONTROLS.set('haptics',e.target.checked);
$('opt-action-labels').onchange=e=>CONTROLS.set('labels',e.target.checked);
$('opt-high-contrast').onchange=e=>CONTROLS.set('contrast',e.target.checked);
$('btn-control-test').onclick=()=>CONTROLS.test();
$('opt-vfx-quality').onchange=e=>{FX.setOption('quality',e.target.value);sv();settingsUI()};
$('opt-vfx-res').onchange=e=>{FX.setOption('resolution',e.target.value);sv();settingsUI()};
$('settings-modal').addEventListener('change',e=>{
  if(e.target.dataset.vfx){FX.setOption(e.target.dataset.vfx,e.target.checked);sv();settingsUI()}
});
$('btn-vfx-demo').onclick=()=>{
  $('settings-modal').classList.add('h');
  FX.slash(P.x,P.y-9,Math.atan2(P.ay,P.ax),36,1,true,3.1);
  FX.flash(P.x+18,P.y-7,58,2,.35);FX.sparks(P.x+18,P.y-7,28,'#f4cb83',115,true);
  FX.text(P.x,P.y-35,'✧ VFX ÖNİZLEMESİ','#ffe1a1',true);FX.text(P.x,P.y-49,'Hasar verilmedi','#bfddd9',false);
  shk=Math.max(shk,3);FX.hitStop(5);
};


