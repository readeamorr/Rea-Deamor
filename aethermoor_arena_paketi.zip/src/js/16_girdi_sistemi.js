/* ===== GİRDİ SİSTEMİ ===== */
const In={
  jx:0,jy:0,atk:false,keys:{},generation:0,held:[],
  cancelAttack(){this.atk=false;P.chargeT=0;this.generation++},
  reset(){this.keys={};this.jx=this.jy=0;this.cancelAttack();if(this.clearJoystick)this.clearJoystick();for(const state of this.held){const id=state.id;state.id=null;try{if(id!==null&&state.el.hasPointerCapture(id))state.el.releasePointerCapture(id)}catch(error){}}},
  init(){
    const zl=$('zl'),jb=$('jb'),jk=$('jk');let id=null,o=null;
    zl.addEventListener('pointerdown',e=>{
      if(id!==null||GAME_CORE.busy()||e.button>0)return;
      e.preventDefault();id=e.pointerId;try{zl.setPointerCapture(id)}catch(error){}
      o={x:e.clientX,y:e.clientY};
      jb.style.display='block';jb.style.left=(o.x-54)+'px';jb.style.top=(o.y-54)+'px';
      jk.style.transform='none';
    });
    window.addEventListener('pointermove',e=>{
      if(e.pointerId!==id)return;
      let dx=e.clientX-o.x,dy=e.clientY-o.y;
      const m=Math.hypot(dx,dy),k=m<8?0:Math.min(1,m/46);
      if(m>0){dx/=m;dy/=m}
      this.jx=dx*k;this.jy=dy*k;
      jk.style.transform=`translate(${dx*k*36}px,${dy*k*36}px)`;
    });
    const end=e=>{
      if(e.pointerId!==id)return;
      id=null;this.jx=this.jy=0;jb.style.display='none';
    };
    window.addEventListener('pointerup',end);window.addEventListener('pointercancel',end);zl.addEventListener('lostpointercapture',end);
    this.clearJoystick=()=>{const previous=id;id=null;o=null;this.jx=this.jy=0;jb.style.display='none';jk.style.transform='none';try{if(previous!==null&&zl.hasPointerCapture(previous))zl.releasePointerCapture(previous)}catch(error){}};
    
    const hold=(el,f,u)=>{
      const state={el,id:null,generation:0};this.held.push(state);
      el.addEventListener('pointerdown',e=>{
        if(state.id!==null||GAME_CORE.busy()||e.button>0)return;
        e.preventDefault();state.id=e.pointerId;state.generation=this.generation;
        try{el.setPointerCapture(e.pointerId);if(AC)AC.resume().catch(()=>{})}catch(error){}haptic(8);f();
      });
      window.addEventListener('pointerup',e=>{
        if(state.id!==e.pointerId)return;const valid=state.generation===this.generation&&!GAME_CORE.busy();state.id=null;
        try{if(el.hasPointerCapture(e.pointerId))el.releasePointerCapture(e.pointerId)}catch(error){}
        if(u){if(valid)u();else this.cancelAttack()}
      });
      const cancel=e=>{if(state.id!==e.pointerId)return;state.id=null;if(u)this.cancelAttack()};
      window.addEventListener('pointercancel',cancel);el.addEventListener('lostpointercapture',cancel);
    };
    
    hold($('bA'),()=>{ this.atk=true; P.chargeT=0; },()=>{
      this.atk=false;
      const isCharged = (P.chargeT||0) >= 0.35;
      useActiveTool(isCharged);
      P.chargeT = 0;
    });
    hold($('bS'),skill1);
    hold($('bI'),skill2);
    hold($('bUlt'),useUltimate);
    hold($('bP'),potion);
    hold($('bF'),fish);
    hold($('bD'),dash);
    
    addEventListener('keydown',e=>{
      const k=e.key.toLowerCase();
      if($('bt').classList.contains('expanded')){
        if(k==='escape'){closeQuickMenu();e.preventDefault()}
        return;
      }
      if(k==='escape'){if(BUILD.active)BUILD.cancel();else GAME_CORE.closeMenu();e.preventDefault();return}
      if(e.target?.closest?.('input,textarea,select')||GAME_CORE.busy())return;
      if(e.repeat&&!['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright'].includes(k))return;
      if(BUILD.active){
        if(k==='escape'){BUILD.cancel();e.preventDefault();return}
        if(k==='enter'){BUILD.confirm();e.preventDefault();return}
        const direction={arrowup:[0,-1],arrowdown:[0,1],arrowleft:[-1,0],arrowright:[1,0]}[k];
        if(direction){BUILD.move(...direction);e.preventDefault();return}
      }
      if(k==='g'){ADVENTURE.open();e.preventDefault();return}
      if(k==='n'){FARM.openUI('beds');e.preventDefault();return}
      if(k==='z'){if(FEATURES.use('social'))BOND.ride();e.preventDefault();return}
      this.keys[k]=1;
      if(['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright'].includes(k))e.preventDefault();
      if(k==='tab'||k==='x'){
        cycleTool(e.shiftKey ? -1 : 1);
        e.preventDefault();
      }
      if(k==='1') selectTool('sword');
      if(k==='2') selectTool('hoe');
      if(k==='3') selectTool('can');
      if(k==='4') selectTool('pickaxe');
      if(k==='5') selectTool('rod');
      if(k==='6') selectTool('food');
      if(k==='7') selectTool('seed');
      if(k==='j'||k===' ') {
        if(!this.atk){
          this.atk=true;
          P.chargeT=0;
        }
      }
      if(k==='k') skill1();
      if(k==='u'||k==='q') skill2();
      if(k==='r') useUltimate();
      if(k==='l') potion();
      if(k==='f') fish();
      if(k==='e' && window.activePromptFn){
        window.activePromptFn();
      }else if(k==='e'||k==='shift'){
        dash();
      }
      if(k==='i')openInv();
      if(k==='m')openMap();
      if(k==='t'&&FEATURES.use('character'))openAch();
      if(k==='v'&&FEATURES.use('character')){ $('mastery-modal').classList.remove('h'); masteryUI(); }
      if(k==='h'&&FEATURES.use('social')){ $('friends-modal').classList.remove('h'); friendsUI(); }
      if(k==='o'){ settingsUI(); }
      if(k==='b'&&FEATURES.use('bestiary')){ $('bestiary-modal').classList.remove('h'); bestiaryUI(); }
      if(k==='c'&&FEATURES.use('character'))openClass();
      if(k==='p'&&FEATURES.use('social')){ $('pet-modal').classList.remove('h'); petUI(); }
      if(k===' ')e.preventDefault();
    });
    addEventListener('keyup',e=>{
      const k=e.key.toLowerCase();
      const pressed=this.keys[k]===1;this.keys[k]=0;
      if(k==='j'||k===' '){
        if(!pressed||!this.atk||GAME_CORE.busy()){this.cancelAttack();return}
        this.atk=false;
        const isCharged = (P.chargeT||0) >= 0.35;
        useActiveTool(isCharged);
        P.chargeT=0;
      }
    });

    // Fare tekerleğiyle hızlı araç değiştirme
    addEventListener('wheel', e => {
      if($('bt').classList.contains('expanded'))return;
      const isModalOpen=!!document.querySelector('.ov:not(.h)');
      if(isModalOpen) return;
      const tools = ['sword','hoe','can','pickaxe',...(FEATURES.is('fishing')?['rod']:[]),'food','seed'];
      let idx = tools.indexOf(P.activeTool||'sword');
      if(e.deltaY>0) idx=(idx+1)%tools.length;
      else if(e.deltaY<0) idx=(idx-1+tools.length)%tools.length;
      selectTool(tools[idx]);
    }, { passive: true });

    if($('hotbar')){
      $('hotbar').onclick = e => {
        const slot = e.target.closest('[data-tool]');
        if(slot && slot.dataset.tool) selectTool(slot.dataset.tool);
      };
    }
  },
  vec(){
    const k=this.keys;
    let x=this.jx+((k.d||k.arrowright?1:0)-(k.a||k.arrowleft?1:0));
    let y=this.jy+((k.s||k.arrowdown?1:0)-(k.w||k.arrowup?1:0));
    const m=Math.hypot(x,y);
    if(m>1){x/=m;y/=m}
    return{x,y};
  }
};

