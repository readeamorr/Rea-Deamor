/* ===== CANLI KONUŞMA BALONLARI VE KAYIT PAYLAŞIM SİSTEMİ ===== */
const bubbles = [];
let botChatterT = 8;
const BOT_CHATTER = [
  'SLIME FARMI!',
  'KIZIL EJDER!',
  'SICAK KAHVE! ☕',
  'ALTIN EKIN!',
  'SAVAS ZAMANI!',
  'DEMIRCI BORAN!'
];

function say(entity, text, duration, col, bg){
    if(!entity||!text)return;
  // Eski baloncuğu temizle
  const idx = bubbles.findIndex(b=>b.entity===entity);
  if(idx!==-1) bubbles.splice(idx,1);
  const dur = duration||3.2;
  bubbles.push({
    entity, text, t: dur, maxT: dur,
    col: col||'#f8fafc',
    bg: bg||'rgba(15,23,42,0.92)'
  });
}
window.say = say;

function updBubbles(dt){
  for(let i=bubbles.length-1;i>=0;i--){
    const b=bubbles[i];
    b.t-=dt;
    if(b.t<=0) bubbles.splice(i,1);
  }

  // Rastgele Köy Botlarının Canlı Konuşması
  botChatterT-=dt;
  if(botChatterT<=0){
    botChatterT=rnd(8,16);
    if(npcs&&npcs.length){
      const nearBots = npcs.filter(n=>Math.hypot(n.x-P.x, n.y-P.y)<180);
      if(nearBots.length){
        const bot = pick(nearBots);
        say(bot, pick(BOT_CHATTER), 3.2);
      }
    }
  }
}

function drawPixelTextDirect(str, cx, cy, col) {
  const u = String(str).toUpperCase()
    .replace(/İ/g, "I").replace(/Ş/g, "S").replace(/Ğ/g, "G")
    .replace(/Ü/g, "U").replace(/Ö/g, "O").replace(/Ç/g, "C").replace(/★/g, "*");
  const totalW = u.length * 4 - 1;
  const startX = Math.round(cx - totalW / 2);
  g.fillStyle = col || "#0f172a";
  for (let i = 0; i < u.length; i++) {
    const gl = FN[u[i]];
    if (!gl) continue;
    const px = startX + i * 4;
    for (let r = 0; r < 5; r++) {
      const b = +gl[r];
      for (let j = 0; j < 3; j++) {
        if ((b >> (2 - j)) & 1) g.fillRect(px + j, cy + r, 1, 1);
      }
    }
  }
}

function bubbleD(b){
  const e = b.entity;
  if(!e)return;
  const cx=Math.round(e.x-FX.viewX);
  const cy=Math.round(e.y-FX.viewY-(e.r?e.r*2:22)-8);
  if(cx < -100 || cx > LW + 100 || cy < -40 || cy > LH + 40) return;

  const rawText = String(b.text || '').trim();
  const words = rawText.split(' ');
  const lines = [];
  let cur = '';
  for(const w of words){
    if((cur + ' ' + w).trim().length <= 13){
      cur = (cur + ' ' + w).trim();
    }else{
      if(cur) lines.push(cur);
      cur = w;
    }
  }
  if(cur) lines.push(cur);
  if(!lines.length) return;

  WLAB.bubble(rawText, cx, cy);
  return;
  const maxChars = Math.max(...lines.map(l => l.length));
  const boxW = Math.max(26, maxChars * 4 + 7);
  const boxH = lines.length * 7 + 4;
  const bx = Math.round(cx - boxW / 2);
  const by = Math.round(cy - boxH - 4);

  // 1-pixel siyah kenarlık (notched corners)
  R(bx + 1, by, boxW - 2, 1, '#000'); // üst
  R(bx + 1, by + boxH - 1, boxW - 2, 1, '#000'); // alt
  R(bx, by + 1, 1, boxH - 2, '#000'); // sol
  R(bx + boxW - 1, by + 1, 1, boxH - 2, '#000'); // sağ

  // Beyaz / krem arka plan (Kahraman beyaz #fff, diğerleri krem #fefce8)
  const isHero = e === P;
  const bgCol = isHero ? '#ffffff' : '#fefce8';
  R(bx + 1, by + 1, boxW - 2, boxH - 2, bgCol);

  // Karakteri işaret eden ok
  R(cx - 2, by + boxH - 1, 4, 1, bgCol);
  R(cx - 3, by + boxH, 1, 1, '#000');
  R(cx - 2, by + boxH, 3, 1, bgCol);
  R(cx + 1, by + boxH, 1, 1, '#000');

  R(cx - 2, by + boxH + 1, 1, 1, '#000');
  R(cx - 1, by + boxH + 1, 2, 1, bgCol);
  R(cx + 1, by + boxH + 1, 1, 1, '#000');

  R(cx - 1, by + boxH + 2, 1, 1, '#000');
  R(cx, by + boxH + 2, 1, 1, bgCol);
  R(cx + 1, by + boxH + 2, 1, 1, '#000');

  R(cx, by + boxH + 3, 1, 1, '#000');

  // Baloncuğun içindeki küçük keskin piksel yazısı
  lines.forEach((l, idx) => {
    drawPixelTextDirect(l, cx, by + 3 + idx * 7, '#0f172a');
  });
}

/* Envanter Akıllı Düzenleme (Auto-Sort) */
function sortInventory(){
  const rank = { weapon:1, armor:2, helm:3, boots:4, ring:5, artisan:6, food:7, food_ing:8, crop:9, seed:10, mat:11, fish:12 };
  P.inv=ITEMS.normalize(P.inv);sel=null;inventoryPage=0;
  P.inv.sort((a,b)=>{
    if(!!a.locked!==!!b.locked)return a.locked?-1:1;
    const rA = rank[a.s]||99, rB = rank[b.s]||99;
    if(rA!==rB) return rA - rB;
    return (b.r||0)-(a.r||0)||String(a.k||a.n).localeCompare(String(b.k||b.n),'tr')||ITEMS.qty(b)-ITEMS.qty(a);
  });
  fl(P.x, P.y-26, '⚡ Çanta Düzenlendi!', '#38bdf8', true);
  playChord([523,659,784], .2, 'sine', .05);
  sv(); invUI();
}

/* Kayıt Dışa/İçe Aktarma (Save Export/Import) */
function openSaveModal(){
  GAME_CORE.resetInput();svNow();$('save-modal').classList.remove('h');
  let rawData='',live=true;
  try{rawData=buildSaveJSON()}catch(error){live=false;rawData=lastSavedJSON||readStore(LK_PREVIOUS)||''}
  $('save-code-label').textContent=live?'Güncel Oturum Kodu (Dışa Aktar):':'Son Sağlam Kayıt Kodu · Canlı oturum geçersiz:';
  $('btn-legacy-save').classList.toggle('h',!readStore(LK_STACK_BACKUP));$('btn-core-save').classList.toggle('h',!readStore(LK_CORE_BACKUP));
  $('btn-corrupt-save').classList.toggle('h',!readStore(LK_CORRUPT)&&!(saveLocked&&loadedRaw));$('btn-import-save').classList.toggle('h',!readStore(LK_IMPORT_BACKUP));
  $('btn-previous-save').classList.toggle('h',!readStore(LK_PREVIOUS));$('btn-foundation-save').classList.toggle('h',!readStore(LK_FOUNDATION_BACKUP));
  $('btn-use-session').classList.toggle('h',!saveLocked||['future','runtime','import','external'].includes(saveLockReason));
  try{$('save-export-text').value=btoa(encodeURIComponent(rawData))}catch(error){$('save-export-text').value=rawData}
  $('btn-reload-save').dataset.confirm='';$('btn-reload-save').textContent=svFailed||saveLocked?'Kaydedilmemiş oturumu bırakıp son kaydı aç':'Son Kaydı Yeniden Aç';
  saveNoticeCurrent();
}

$('btn-core-save').onclick=()=>{
  const raw=readStore(LK_CORE_BACKUP);if(!raw)return;
  $('save-export-text').value=btoa(encodeURIComponent(raw));
  $('save-code-label').textContent='Sağlamlaştırma Öncesi İlk Yedek · Güncel ilerleme değildir:';
};
$('btn-legacy-save').onclick=()=>{
  const raw=readStore(LK_STACK_BACKUP);if(!raw)return;
  $('save-export-text').value=btoa(encodeURIComponent(raw));
  $('save-code-label').textContent='Yığın Öncesi İlk Yedek · Güncel ilerleme değildir:';
};
$('btn-corrupt-save').onclick=()=>{
  const raw=readStore(LK_CORRUPT)||(saveLocked?loadedRaw:null);if(!raw)return;
  $('save-export-text').value=btoa(encodeURIComponent(raw));
  $('save-code-label').textContent='Bozuk Okunan Kayıt (ham veri) · Güncel ilerleme değildir:';
};
$('btn-import-save').onclick=()=>{
  const raw=readStore(LK_IMPORT_BACKUP);if(!raw)return;
  $('save-export-text').value=btoa(encodeURIComponent(raw));
  $('save-code-label').textContent='İçe Aktarma Öncesi Kayıt · Güncel ilerleme değildir:';
};
$('btn-copy-save').onclick=async()=>{
  const txt=$('save-export-text');txt.select();let copied=false;
  try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(txt.value);copied=true}}catch(error){/* İzin yoksa kullanıcı hareketindeki klasik kopyalamayı dene. */}
  if(!copied)try{copied=document.execCommand('copy')===true}catch(error){}
  $('save-health').textContent=copied?'✓ Kayıt kodu kopyalandı.':'Kopyalama izni yok. Kutudaki metni seçip elle kopyala.';
};
function showSavedCode(key,label){const raw=readStore(key);if(raw){$('save-export-text').value=btoa(encodeURIComponent(raw));$('save-code-label').textContent=label}}
$('btn-previous-save').onclick=()=>showSavedCode(LK_PREVIOUS,'Önceki Sağlam Kayıt · Güncel oturum olmayabilir:');
$('btn-foundation-save').onclick=()=>showSavedCode(LK_FOUNDATION_BACKUP,'Altyapı Güncellemesi Öncesi İlk Yedek:');
$('save-warning-open').onclick=openSaveModal;
$('btn-reload-save').onclick=()=>{
  const b=$('btn-reload-save');if((svFailed||saveLocked)&&b.dataset.confirm!=='yes'){b.dataset.confirm='yes';b.textContent='Bu oturumu bırakmak için tekrar dokun';return}
  saveLocked=true;saveLockReason='reload';window.location.reload();
};
$('btn-save-now').onclick=()=>{if(svNow())$('save-health').textContent='✓ İlerleme kaydedildi.';else saveNoticeCurrent()};
$('btn-use-session').onclick=()=>{
  if(!saveLocked||['future','runtime','import','external'].includes(saveLockReason))return;
  try{if(loadedRaw)localStorage.setItem(LK_CORRUPT,loadedRaw);saveLocked=false;saveLockReason='';if(!svNow())return;openSaveModal()}catch(error){saveLocked=true;saveNotice('Ham kayıt yedeklenemedi. Önce kayıt kodlarını dışa aktar; eski veri korunuyor.')}
};

$('btn-load-save').onclick=()=>{
  const val=$('save-import-text').value.trim();
  if(!val)return;
  if(val.length>SAVE_CODEC.MAX_BYTES*4){$('save-health').textContent='Kayıt kodu çok büyük; mevcut ilerleme değişmedi.';return;}
  let parsed=null;
  try{
    let raw=val;
    try{ raw=decodeURIComponent(atob(val)); }catch(x){ raw=val; } // Kod base64 değilse düz JSON dene.
    if(new TextEncoder().encode(raw).length>SAVE_CODEC.MAX_BYTES)throw new Error('Kayıt boyutu sınırı');
    parsed=JSON.parse(raw);
  }catch(e){
    $('save-health').textContent='Kayıt kodu okunamadı. Mevcut ilerleme değiştirilmedi.';
    return;
  }
  let checked;
  try{checked=SAVE_CODEC.normalize(parsed)}catch(error){$('save-health').textContent='İçe aktarılmadı: '+error.message;return}
  if(checked.badType.length){$('save-health').textContent='İçe aktarılmadı: geçersiz alanlar var ('+checked.badType.slice(0,5).join(', ')+'). Mevcut ilerlemen değişmedi.';return}
  try{
    // Dosyadaki son 350 ms değil, mevcut canlı ilerleme yedeklenir.
    const current=buildSaveJSON();localStorage.setItem(LK_IMPORT_BACKUP,current);
    localStorage.setItem(LK,JSON.stringify(checked.clean));
  }catch(storeError){$('save-health').textContent='İçe aktarılmadı: depolama yazılamadı. Mevcut ilerleme korunuyor.';return}
  if(svTimer){clearTimeout(svTimer);svTimer=0}svPending=false;
  saveLocked=true;saveLockReason='import'; // pagehide eski oturumu içe aktarılan kayda yazamaz.
  $('save-modal').classList.add('h');
  window.location.reload();
};


/* ===== SU DEĞİRMENİ VE BOTANİKÇİ ARAYÜZLERİ ===== */
function millUI(){
  const wheatCount=countInv('wheat');
  const canMill = wheatCount >= 2;
  $('mill-content').innerHTML = `
    <div style="background:#020617;border:2px solid #334155;border-radius:8px;padding:12px;margin:8px 0;text-align:center">
      <div style="font-size:32px">🌊 ➜ 🥡</div>
      <b style="color:#38bdf8;font-size:13px">Taş Değirmende Un Öğütme</b>
      <p style="font-size:10.5px;color:#cbd5e1;margin:6px 0">Tarif: <b>2 Buğday</b> (Çantanda: ${wheatCount}/2) ➜ <b>1 Çuval Çiftlik Unu</b></p>
      <p style="font-size:9.5px;color:#a7f3d0">Un değeri: 40🪙 · Mutfakta ekmek ve ziyafet pankeki yapımında kullanılır!</p>
      <button id="btn-mill-wheat" class="m" style="padding:6px 18px;font-size:12px;background:${canMill?'#16a34a':'#475569'}">
        ${canMill ? 'Buğdayı Una Öğüt (🌾 ➜ 🥡)' : 'Yetersiz Buğday (2 Gerekir)'}
      </button>
    </div>
  `;

  if($('btn-mill-wheat')){
    $('btn-mill-wheat').onclick = () => {
      const flour={s:'food_ing',k:'flour',n:'Çiftlik Unu',icon:'🥡',val:40,desc:'Değirmende öğütülmüş un. Ekmek ve hamurişinde kullanılır'};
      if(tryInventoryRecipe({wheat:2},[flour])){
        fl(P.x, P.y-26, '+🥡 1 Çuval Çiftlik Unu!', '#ffd23f', true);
        playChord([523, 659, 784], .25, 'triangle', .05);
        addMasteryXp('farm', 12);
        sv(); millUI();
      }
    };
  }
}

function botanyUI(){
  const season=FARM.seasonIdx(),flowers=['tulip','sunflower','snowdrop'].filter(k=>CROPS[k].se.includes(season));
  $('botany-content').innerHTML=`<p>🪙 <b>${P.gold}</b> · ${SEASONS[season].n}</p><p style="color:#f3b8d6">Aylin yalnız bu mevsimde gerçekten yetiştirebileceğin çiçekleri sunuyor.</p>${flowers.map(k=>{const c=CROPS[k];return `<button data-bt="${k}" style="display:block;width:100%;padding:10px;margin:6px 0">${c.icon} ${c.n} Tohumu · ${friendPrice('osman',c.cost)}🪙 · ${c.d} gün</button>`}).join('')}<p class="inventory-help">Tohumlar doğrudan kesene gider; çantada yer istemez. Seçimi değiştirmek için tohum aracına tekrar dokun. Eski, ekilemeyen fidanların bedeli kayıt yüklenirken bir kez iade edilir.</p>`;
}
$('botany-content').onclick=e=>{
  const k=e.target.closest('[data-bt]')?.dataset.bt;if(!['tulip','sunflower','snowdrop'].includes(k))return;
  FARM.buy(k,1);botanyUI();
};


/* ===== NİHAİ YETENEK (ULTIMATE / RAGE ABILITY) ===== */
function useUltimate(){
  if(BUILD.active)return;BOND.dismount();
  if(P.dead || (P.rage||0) < 100) return;
  P.rage = 0;
  shk = 12;
  FX.hitStop(5);FX.flash(P.x,P.y-8,105,P.cls==='mage'?2:0,.4);
  playChord([392, 523, 659, 784, 1046], .5, 'sawtooth', .1);
  try{if(!FX.options.reducedMotion&&navigator.vibrate)navigator.vibrate([80,50,150])}catch(x){}

  const cls = P.cls || 'warrior';
  if(cls === 'mage'){
    // ☄️ Kıyamet Meteoru
    fl(P.x, P.y-28, '☄️ KIYAMET METEORU!', '#ef4444', true);
    for(let a=0; a<6.28; a+=0.15){
      FX.emit(P.x,P.y-8,Math.cos(a)*140,Math.sin(a)*140,.6,Math.sin(a*5)>0?'#ffad5c':'#ffd23f',2.8,55,1);
    }
    for(const m of mobs){
      if(!m.dead && Math.hypot(m.x-P.x, m.y-P.y) < 160){
        hitMob(m, Math.round(S.a * 5.8), true, (m.x-P.x)*0.8, (m.y-P.y)*0.8, false, true);
      }
    }
  }else if(cls === 'ranger'){
    // 🏹 Ok Fırtınası
    fl(P.x, P.y-28, '🏹 OK FIRTINASI!', '#38bdf8', true);
    P.buffs.spd = 6; P.buffs.atk = 6; S = st();
    for(let i=0; i<35; i++){
      const a = (i/35)*6.283;
      prj.push({
        x: P.x, y: P.y-10, vx: Math.cos(a)*300, vy: Math.sin(a)*300, t: 0.7,
        dmg: Math.round(S.a * 2.2), col: '#fde047', isHero: true, critBonus: 0.3
      });
    }
  }else{
    // ⚔️ Titan Yakarışı
    fl(P.x, P.y-28, '💥 TİTAN YAKARIŞI!', '#ffd23f', true);
    for(let a=0; a<6.28; a+=0.1){
      FX.emit(P.x,P.y-8,Math.cos(a)*180,Math.sin(a)*180,.55,'#ffd23f',2.8,45,1);
    }
    for(const m of mobs){
      if(!m.dead && Math.hypot(m.x-P.x, m.y-P.y) < 140){
        m.staggeredT = 3.5; m.st = 'rec'; m.t = 3.5;
        hitMob(m, Math.round(S.a * 5.2), true, (m.x-P.x)*0.9, (m.y-P.y)*0.9);
      }
    }
  }
}


