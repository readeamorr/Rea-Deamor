/* ===== NESNE DETAYI: gölgelendirilmiş yaprak kümeleri ve çam katmanları ===== */
function lobe(cx,cy,rx,ry,pal,seed){
  for(let dy=-ry;dy<=ry;dy++)for(let dx=-rx;dx<=rx;dx++){
    const nx=dx/rx,ny=dy/ry,d=nx*nx+ny*ny;if(d>1)continue;
    const tone=-(nx*.45+ny*.85)+(H(cx+dx*7+seed,cy+dy*13+seed*3)-.5)*.55-d*.25;
    const i=tone>.5?3:tone>.05?2:tone>-.4?1:0;
    R(cx+dx,cy+dy,1,1,pal[i]);
  }
}
function pineTier(cx,top,h,hw,pal,seed,snow){
  for(let r=0;r<h;r++){
    let half=Math.ceil((r+1)/h*hw);if(r>1&&H(cx+r*5+seed,top*3+r)>.7)half=Math.max(1,half-1);
    for(let dx=-half;dx<=half;dx++){
      const u=dx/hw,tone=-u*.9+(H(cx+dx*11+seed,top+r*7)-.5)*.5-r/h*.25;
      let i=tone>.45?3:tone>.0?2:tone>-.4?1:0;
      if(r===h-1)i=0;
      if(snow&&(r<=1||(dx<0&&r<h*.5&&H(cx+dx+seed,top+r)>.35)))R(cx+dx,top+r,1,1,i>=2?'#ffffff':'#dcecf3');
      else R(cx+dx,top+r,1,1,pal[i]);
    }
  }
}
function objRaw(o){
  const x=Math.round(o.x),y=Math.round(o.y),k=o.k;
  if(k==='barn_col')return;
  if(k!=='torch')R(x-(k==='tree'?10:6),y-2,k==='tree'?22:12,3,'#0003');
  if(k==='tree'){
    const f=o.f6,w=o.w,sd=Math.floor((o.v||0)*997)%97;
    const pal=f?['#1d4a22','#2a6428','#3a8133','#5fb04a']:['#2a6a2c','#378a31','#4aa23c','#8fdc6c'];
    // kök, gövde (üç tonlu kabuk)
    R(x-4,y-2,8,2,'#4e3520');R(x-3,y-3,6,1,'#6b4a2a');
    R(x-2,y-15,4,13,'#6b4a2a');R(x-2,y-15,1,13,'#9a6e3d');R(x+1,y-15,1,13,'#46301c');
    R(x-1,y-11,1,2,'#46301c');R(x,y-7,1,2,'#9a6e3d');
    // taç: arkadan öne gölgeli kümeler
    lobe(x-6+w,y-17,8,6,pal,sd);lobe(x+6+w,y-17,8,6,pal,sd+3);lobe(x+w,y-20,10,7,pal,sd+5);
    lobe(x-4+w,y-25,7,6,pal,sd+7);lobe(x+5+w,y-24,6,5,pal,sd+9);lobe(x+w,y-28,7,6,pal,sd+11);
    R(x-10+w,y-12,20,1,'#00000028');
  }else if(k==='fence'){
    R(x-6,y-8,12,2,'#8f5528');R(x-6,y-8,12,1,'#b87a42');R(x-6,y-4,12,2,'#8f5528');R(x-6,y-4,12,1,'#b87a42');R(x-6,y-6,12,1,'#5e3517');R(x-6,y-2,12,1,'#5e3517');
    R(x-2,y-10,4,10,'#6e3f1c');R(x-2,y-10,1,10,'#a1632f');R(x+1,y-10,1,10,'#4a2810');R(x-2,y-11,4,1,'#c98a4d');R(x-1,y-7,1,1,'#d9c7a0');R(x-1,y-3,1,1,'#d9c7a0');
  }else if(k==='gate'){
    R(x-8,y-10,3,10,'#78350f');R(x+5,y-10,3,10,'#78350f');
    R(x-5,y-7,10,2,'#92400e');R(x-5,y-4,10,2,'#92400e');
    R(x-1,y-9,2,6,'#ca8a04');
  }else if(k==='frontier_gate'){
    R(x-13,y-4,26,5,'#546d75');R(x-12,y-27,6,23,'#879a98');R(x+6,y-27,6,23,'#879a98');
    R(x-13,y-31,26,6,'#b2c5ab');R(x-8,y-26,16,21,'#2a5670');
    R(x-3,y-23,6,16,'#6bdae0');R(x-1,y-25,2,19,'#e0f9f2');
  }else if(k==='frontier_ruin'){
    R(x-14,y-4,28,5,'#5a6870');R(x-11,y-22,6,18,'#95a5a3');R(x+5,y-27,6,23,'#829697');
    R(x-12,y-29,24,4,'#b8bbae');R(x-3,y-16,6,12,'#283947');
  }else if(k==='frontier_station'){
    const stage=o.stage||0;
    R(x-12,y-4,24,5,'#594d43');R(x-10,y-18,20,14,'#927555');
    R(x-13,y-22,26,5,stage>=1?'#4f846f':'#665a54');
    R(x-8,y-25,16,4,stage>=1?'#6ba28a':'#8a7765');
    R(x-3,y-13,6,9,'#324437');R(x+5,y-13,3,3,'#fce7a4');
    if(stage>=2){R(x+9,y-37,3,16,'#99aa9b');R(x+12,y-37,10,4,'#dfc17b');R(x-10,y-27,4,5,'#aed4bb')}
    if(stage>=3){R(x-6,y-27,12,3,'#f8d577');R(x-1,y-29,3,4,'#ffeec0')}
  }else if(k==='camp_marker'){ 
    R(x-10,y-4,20,4,'#9a8456');R(x-8,y-7,3,9,'#6f553d');R(x+6,y-7,3,9,'#6f553d');
    R(x-9,y-14,18,7,'#b9a067');R(x-4,y-17,8,4,'#d9c089');R(x-1,y-13,3,3,'#fff2ac');
  }else if(k==='mine_entrance'){
    R(x-14,y-18,28,18,'#1e293b');
    R(x-12,y-16,24,16,'#0f172a');
    R(x-10,y-14,20,14,'#020617');
    R(x-11,y-16,3,16,'#78350f');R(x+8,y-16,3,16,'#78350f');
    R(x-11,y-18,22,3,'#92400e');
    R(x-6,y-2,12,1,'#64748b');R(x-6,y,12,1,'#64748b');
    R(x-13,y-12,2,4,'#38bdf8');R(x+11,y-12,2,4,'#a855f7');
    T('Kristal Madeni ⛏️',x,y-22,'#ffd23f');
  }else if(k==='ladder_up'){
    ladderD(x,y,true);
  }else if(k==='elevator'){
    elevatorD(x,y);
  }else if(k==='pine'||k==='snow_pine'){
    const cold=k==='snow_pine',sd=Math.floor((o.v||0)*997)%89;
    const pal=cold?['#1b3f4a','#245562','#33808c','#6fc0c8']:['#1c4630','#265a3d','#34774f','#62a874'];
    R(x-3,y-2,6,2,'#3b2314');R(x-2,y-9,4,8,'#4a2c1a');R(x-2,y-9,1,8,'#6f4527');
    pineTier(x,y-12,11,10,pal,sd,cold);pineTier(x,y-20,10,8,pal,sd+4,cold);
    pineTier(x,y-27,9,6,pal,sd+8,cold);pineTier(x,y-33,8,4,pal,sd+12,cold);
    R(x,y-35,1,2,cold?'#ffffff':pal[3]);
  }else if(k==='dead_tree'){
    R(x-2,y-20,5,20,'#413b35');R(x,y-24,2,14,'#625647');
    R(x-9,y-19,10,2,'#54483a');R(x+1,y-17,9,2,'#54483a');
    R(x-10,y-24,2,7,'#54483a');R(x+8,y-22,2,7,'#54483a');
  }else if(k==='reed'){
    R(x-4,y-7,2,7,'#a5b984');R(x,y-11,2,11,'#c0cc87');R(x+4,y-8,2,8,'#829f68');
    R(x-4,y-9,2,3,'#5e4e33');R(x,y-14,2,4,'#665536');
  }else if(k==='lake_reed'){
    R(x-4,y-7,2,7,'#62946a');R(x,y-13,2,13,'#a2b96e');R(x+4,y-9,2,9,'#628b64');
    R(x,y-15,2,4,'#816447');R(x+2,y-4,4,2,'#95c77f');
  }else if(k==='ice_crystal'){
    R(x-6,y-2,12,3,'#7baebb');R(x-3,y-11,5,10,'#e0fbff');
    R(x-1,y-16,3,8,'#88d9ee');R(x+4,y-8,3,7,'#6fbcd4');
    R(x,y-12,1,7,'#fff');
  }else if(k==='snow_peak'){
    R(x-12,y-4,24,5,'#667b86');R(x-9,y-10,18,7,'#849da6');
    R(x-6,y-17,13,9,'#a4b9be');R(x-3,y-24,7,10,'#eefcff');
    R(x-2,y-25,3,5,'#fff');R(x+4,y-11,3,7,'#d8eaed');
  }else if(k==='shroom'){ 
    R(x-3,y-12,6,12,'#e2e8f0');R(x-2,y-10,4,8,'#cbd5e1');
    R(x-11,y-22,22,11,'#7e22ce');R(x-9,y-24,18,3,'#9333ea');
    R(x-6,y-20,3,3,'#c084fc');R(x+3,y-18,3,3,'#f472b6');R(x-1,y-15,3,3,'#a855f7');
  }else if(k==='lamp'){
    lampD(o.x,o.y);
  }else if(o.k==='apple_tree'||o.k==='peach_tree'){
    fruitTreeD(o.x,o.y,o.isPeach,o.fruitReady,o.treeType);
  }else if(k==='pillar'){
    R(x-5,y-22,10,22,'#d97706');R(x-6,y-24,12,3,'#f59e0b');R(x-6,y-2,12,3,'#b45309');
    R(x-3,y-16,6,2,'#92400e');R(x-3,y-10,6,2,'#92400e');
  }else if(k==='palm'){
    R(x-1,y-14,3,14,'#9c7a4a');R(x-9,y-17,18,3,'#2d9a3f');R(x-4,y-20,8,3,'#38b04b');
    R(x-10,y-14,4,3,'#2d9a3f');R(x+6,y-14,4,3,'#2d9a3f');
  }else if(k==='cactus'){
    R(x-2,y-16,5,16,'#3f9a4a');R(x-7,y-12,5,3,'#3f9a4a');R(x-7,y-16,3,5,'#3f9a4a');
    R(x+3,y-9,5,3,'#3f9a4a');R(x+6,y-13,3,5,'#3f9a4a');
  }else if(k==='dry_bush'){
    R(x-6,y-4,12,4,'#8c7646');R(x-4,y-7,8,3,'#ad985d');
    R(x-2,y-11,2,6,'#b69d61');R(x+3,y-10,2,7,'#9b824c');
  }else if(k==='sandstone'){
    R(x-8,y-5,16,6,'#a78159');R(x-6,y-10,12,6,'#d5aa72');
    R(x-4,y-12,8,3,'#e5c48e');R(x+4,y-7,3,2,'#896441');
  }else if(k==='obsidian_spire'){
    R(x-9,y-3,18,4,'#242c35');R(x-6,y-18,12,16,'#39404a');
    R(x-3,y-27,6,12,'#5d4344');R(x-1,y-31,3,10,'#232b33');
    R(x,y-18,2,10,'#e56b38');R(x+2,y-10,2,5,'#f5ac53');
  }else if(k==='desert_ruin'){
    R(x-15,y-3,30,4,'#6c5748');
    R(x-14,y-28,7,25,'#b49a75');R(x+7,y-23,7,20,'#ab8b63');
    R(x-16,y-29,11,3,'#e5d1a1');R(x+5,y-25,11,3,'#e5d1a1');
    R(x-10,y-30,22,5,'#be9e73');R(x-10,y-32,14,3,'#ebd19d');
    R(x-4,y-16,8,13,'#352e30');R(x-2,y-15,4,8,'#d48b49');
  }else if(k==='stump'){
    R(x-5,y-6,10,6,'#6b3410');R(x-5,y-6,2,6,'#8f4d1c');R(x+3,y-6,2,6,'#4a2308');R(x-1,y-5,1,4,'#4a2308');R(x+1,y-3,1,2,'#8f4d1c');
    lobe(x,y-7,5,2,['#a8733a','#c08a4a','#d9a35e','#f2d3a0'],1);R(x-2,y-7,4,1,'#a8733a');R(x-1,y-8,2,1,'#8f5a28');
  }else if(k==='boulder'){
    const sd=Math.floor((o.v||0)*997)%83;
    lobe(x,y-6,8,6,['#455062','#64748b','#8697ad','#b9c6d6'],sd);R(x-7,y-1,14,1,'#2f3846');
    lobe(x-1,y-10,4,2,['#2f6b3a','#3f8f4c','#4ade80','#9af0b0'],sd+3);
  }else if(k==='rock'){
    const sd=Math.floor((o.v||0)*997)%83,pr=['#4f5966','#6b7683','#8f9ba8','#c4cdd6'];
    lobe(x,y-5,7,5,pr,sd);lobe(x+2,y-8,4,3,pr,sd+2);R(x-6,y-1,13,1,'#3a424c');
  }else{
    R(x-1,y-12,3,12,'#554');R(x-3,y-14,7,2,'#889');
    const fl=o.fl;
    R(x-3,y-21+fl,7,7,'#5ad1ff');R(x-1,y-24+fl,3,4,'#cfeeff');
  }
}


function critterD(c){
  const x=Math.round(c.x),y=Math.round(c.y),t=c.type,f=c.f;
  const bob=c.st==='hop'||c.st==='flee'?Math.abs(Math.sin(c.hopT*8))*3.5:0;
  if(t==='rabbit'||t==='snow_hare'){
    const fur=t==='snow_hare'?'#ddfaff':'#f1f5f9';
    R(x-4,y-2,8,2,'#0002');
    R(x-4,y-5-bob,8,5,fur);
    R(x-2,y-6-bob,4,2,t==='snow_hare'?'#b2dce8':'#e2e8f0');
    const ex=f>0?1:-4;
    R(x+ex,y-10-bob,2,5,fur);
    R(x+ex+2,y-10-bob,2,5,fur);
    R(x+(f>0?3:-3),y-4-bob,1,1,t==='snow_hare'?'#459abb':'#f43f5e');
  }else if(t==='bird'){
    const flyZ=c.z||0;
    if(flyZ>0)R(x-3,y-2,6,2,'#0002');
    R(x-3,y-4-flyZ,6,4,'#38bdf8');
    R(x+(f>0?2:-4),y-5-flyZ,3,3,'#7dd3fc');
    R(x+(f>0?4:-5),y-4-flyZ,2,1,'#f59e0b');
    if(flyZ>0){
      const flap=Math.sin(P.t*25)>0?2:-2;
      R(x-2,y-6-flyZ+flap,4,1,'#bae6fd');
    }
  }else if(t==='heron'){
    R(x-5,y-2,10,2,'#0003');R(x-3,y-14-bob,6,10,'#e5f4ed');
    R(x-2,y-19-bob,5,7,'#f4fbf4');R(x+(f>0?3:-8),y-16-bob,5,2,'#e4ac60');
    R(x-2,y-4,1,4,'#ae7d57');R(x+2,y-4,1,4,'#ae7d57');R(x+(f>0?2:-2),y-17-bob,1,1,'#284850');
  }else if(t==='frog'){
    R(x-4,y-2,8,2,'#0002');
    R(x-4,y-4-bob,8,4,'#22c55e');
    R(x-3,y-6-bob,2,2,'#facc15');R(x+1,y-6-bob,2,2,'#facc15');
    R(x-2,y-5-bob,1,1,'#000');R(x+2,y-5-bob,1,1,'#000');
  }else if(t==='lizard'){
    R(x-5,y-3,10,3,'#ca8a04');
    R(x+(f>0?4:-6),y-3,2,1,'#eab308');
    R(x-(f>0?6:-4),y-3,3,1,'#b45309');
  }else if(t==='desert_fox'){
    R(x-7,y-2,14,3,'#0003');R(x-6,y-9-bob,12,7,'#c98248');
    R(x+(f>0?3:-8),y-14-bob,7,6,'#e7ae69');
    R(x+(f>0?3:-8),y-20-bob,2,7,'#b36b42');R(x+(f>0?7:-4),y-20-bob,2,7,'#b36b42');
    R(x+(f>0?5:-6),y-12-bob,2,2,'#3d3e34');R(x-(f>0?10:-6),y-8-bob,5,4,'#e7b17c');
  }else if(t==='mountain_goat'){
    const winter=curMap==='frontier'&&FARM.seasonIdx()===3;
    R(x-7,y-2,14,3,'#0003');R(x-7,y-11-bob,14,8,winter?'#e8eef0':'#d7d2b5');
    R(x-5,y-3,2,4,'#8c8479');R(x+3,y-3,2,4,'#8c8479');
    R(x+(f>0?4:-10),y-15-bob,7,6,winter?'#f8fcf8':'#ede1bd');
    R(x+(f>0?3:-7),y-19-bob,2,7,'#b6a58b');R(x+(f>0?7:-3),y-18-bob,2,6,'#b6a58b');
    R(x+(f>0?7:-8),y-13-bob,1,1,'#352e29');
  }else if(t==='deer'){
    R(x-6,y-2,12,3,'#0003');
    R(x-7,y-11,14,8,'#92400e');
    R(x-5,y-3,2,6,'#78350f');R(x+3,y-3,2,6,'#78350f');
    R(x+5,y-16,4,7,'#b45309');
    R(x+5,y-20,2,5,'#fef08a');R(x+7,y-20,2,5,'#fef08a');
  }
}

function resD(r){
  const x=Math.round(r.x),y=Math.round(r.y);
  if(r.isSecret){
    if(!r.mined){R(x-3,y-6,2,5,'#d4bd8b');R(x-1,y-2,3,2,'#ae9268');R(x+1,y,1,5,'#d4bd8b')}
    return;
  }
  if(r.mined){
    if(r.isOre){
      R(x-4,y-2,8,3,'#475569');
      if(r.readyDay>P.day&&Math.hypot(P.x-x,P.y-y)<26)T(`${r.readyDay-P.day} GUN`,x,y-8,'#a7f3d0');
    }
    return;
  }
  if(['ore_crystal','ore_iridium','ore_diamond','ore_ruby','herb_mana'].includes(r.k))FX.glow(x,y-7,15,r.k==='ore_ruby'?4:r.k==='ore_iridium'||r.k==='ore_crystal'?2:1,.42);
  if(r.k==='fallen_log'){
    R(x-9,y-3,18,4,'#5f4434');R(x-10,y-7,20,5,'#96714e');
    R(x-8,y-8,16,2,'#ba9169');R(x+6,y-6,2,3,'#5e4634');
    R(x-4,y-9,3,2,'#729556');
  }else if(r.k==='herb_sun'){
    R(x-1,y-3,2,4,'#15803d');
    R(x-3,y-8,6,5,'#facc15');R(x-1,y-7,2,3,'#ea580c');
  }else if(r.k==='herb_mana'){
    R(x-1,y-2,2,3,'#0d9488');
    R(x-3,y-7,6,5,'#38bdf8');R(x-1,y-6,2,3,'#fff');
  }else if(r.k==='berries'){
    R(x-5,y-7,10,6,'#166534');
    R(x-3,y-6,2,2,'#e11d48');R(x+1,y-5,2,2,'#e11d48');R(x-1,y-3,2,2,'#f43f5e');
  }else if(r.k==='bog_herb'){
    R(x-4,y-8,2,8,'#74a773');R(x,y-12,2,12,'#9ac788');R(x+3,y-6,2,6,'#b9d884');
    R(x-1,y-14,4,3,'#e4c989');
  }else if(r.k==='highland_herb'){
    const frost=curMap==='frontier'&&FARM.seasonIdx()===3;
    R(x-1,y-4,2,5,frost?'#708c92':'#3c7656');
    R(x-6,y-10,5,5,frost?'#a4c5c9':'#8bd6a4');R(x+1,y-11,5,6,frost?'#bfd8da':'#9ee8bf');
    R(x-2,y-13,4,4,frost?'#dce8ee':'#c8b5df');R(x-1,y-12,2,2,'#e9d9f2');
  }else if(r.k==='snowdrop'){
    R(x,y-6,2,6,'#438579');R(x-4,y-10,10,3,'#d6f5f4');
    R(x-1,y-12,3,7,'#fff');R(x,y-10,1,2,'#f5df85');
  }else if(r.k==='cactus_fruit'){
    R(x-3,y-3,7,4,'#4b8c51');R(x-2,y-12,5,10,'#53a966');
    R(x-6,y-9,4,2,'#53a966');R(x+2,y-7,4,2,'#53a966');
    R(x-1,y-15,4,4,'#f49054');R(x,y-13,2,2,'#f9c177');
  }else if(r.k==='ore_copper'){ 
    R(x-6,y-7,12,7,'#78350f');R(x-4,y-6,4,3,'#ea580c');R(x+1,y-5,4,2,'#fb923c');
  }else if(r.k==='ore_iron'){
    R(x-6,y-7,12,7,'#334155');R(x-3,y-6,5,3,'#94a3b8');R(x+2,y-4,3,2,'#e2e8f0');
  }else if(r.k==='ore_stone'){
    R(x-6,y-7,12,7,'#475569');R(x-4,y-6,5,3,'#94a3b8');R(x+1,y-4,4,2,'#cbd5e1');
  }else if(r.k==='ore_crystal'){
    const ash=r.name==='Kül Kristali';
    R(x-6,y-7,12,7,'#475569');
    R(x-4,y-9,3,6,ash?'#f59e56':'#c084fc');
    R(x,y-11,4,8,ash?'#ffcb73':'#38bdf8');R(x+3,y-7,3,4,ash?'#de693d':'#a855f7');
  }else if(r.k==='ore_coal'){
    R(x-6,y-7,12,7,'#1e293b');R(x-3,y-6,6,4,'#0f172a');R(x+1,y-4,3,2,'#334155');
  }else if(r.k==='ore_gold'){
    R(x-6,y-7,12,7,'#713f12');R(x-3,y-8,6,6,'#eab308');R(x-1,y-6,3,3,'#fef08a');
  }else if(r.k==='ore_ruby'){
    R(x-6,y-7,12,7,'#450a0a');R(x-3,y-8,6,6,'#dc2626');R(x-1,y-6,3,3,'#f87171');
  }else if(r.k==='ore_diamond'){
    R(x-6,y-7,12,7,'#0e7490');R(x-3,y-9,6,7,'#06b6d4');R(x-1,y-7,3,4,'#cffafe');
  }else if(r.k==='ore_iridium'){
    R(x-6,y-7,12,7,'#3b0764');R(x-4,y-9,8,8,'#7e22ce');R(x-1,y-7,4,4,'#d8b4fe');
  }
}

function houseD(h){
  const level=h.isPlayerHome?houseLevel:(h.level||0),color=h.isPlayerHome&&level>1?(level===2?'#566f7c':'#77556f'):h.c;
  const s=spr(['H',color,h.type||'',h.isForge?'forge':'',h.isPlayerHome?'home':'',level].join(),64,64,32,58,(X,Y)=>houseRaw({x:X,y:Y,c:color,type:h.type,isForge:h.isForge,isPlayerHome:h.isPlayerHome,level}));
  g.drawImage(s.c,Math.round(h.x)-s.ox,Math.round(h.y)-s.oy);
}

function houseRaw(h){
  const x=h.x,y=h.y;
  R(x-26,y,60,5,'#0003');
  const wc=h.type==='frost'?['#7c8a8c','#9ca9aa','#b6c3c4']:['#6e5236','#8b6b47','#a58760'];
  // duvar: gölgeli tahtalar
  R(x-24,y-14,48,14,wc[1]);
  for(let i=0;i<8;i++){R(x-24+i*6,y-14,1,14,wc[2]);R(x-19+i*6,y-14,1,14,wc[0]);if(i%2)R(x-23+i*6,y-14,4,14,'#00000010')}
  for(let i=0;i<8;i++)R(x-22+i*6+(i%3),y-9+(i*5)%7,1,1,wc[0]);
  if(h.isPlayerHome&&h.level>=2){
    R(x-24,y-14,48,14,'#80949b');for(let row=0;row<5;row++)for(let col=0;col<8;col++){const xx=x-24+col*6+(row%2?3:0);if(xx+5<=x+24){R(xx,y-14+row*3,5,2,'#b6c5c4');R(xx,y-14+row*3,5,1,'#d5d9cb')}}
  }
  // taş temel
  R(x-24,y-4,48,4,'#6b6258');for(let i=0;i<8;i++){R(x-24+i*6,y-4,5,2,'#8a8074');R(x-21+i*6,y-2,5,2,'#7a7064')}R(x-24,y-4,48,1,'#a39a8c');
  // çatı: sıra sıra kiremit, solda aydınlık, sağda gölge
  for(let r=0;r<12;r++){
    const rx=x-27+r*2,rw=54-r*4,ry=y-16-r*2;
    R(rx,ry,rw,2,h.c);R(rx,ry,rw,1,'#ffffff1c');R(rx,ry+1,rw,1,'#00000040');
    for(let i=(r%2)*3;i<rw;i+=6)R(rx+i,ry,1,2,'#00000030');
    R(rx,ry,Math.max(1,rw>>2),2,'#ffffff14');R(rx+rw-Math.max(1,rw>>2),ry,Math.max(1,rw>>2),2,'#00000026');
  }
  R(x-24,y-14,48,2,'#00000045');R(x-1,y-40,2,2,'#ffffff30');
  if(h.isPlayerHome&&h.level>=3){R(x-26,y-16,52,1,'#dfbf79');R(x-7,y-23,14,2,'#e2c98c');R(x-1,y-32,2,12,'#c7a05c');R(x-3,y-28,6,2,'#f1dda4')}
  // kapı: çerçeve, tahtalar, tokmak, basamak
  R(x-5,y-10,10,10,'#2f1e12');R(x-4,y-9,8,9,'#5b3b22');R(x-4,y-9,1,9,'#7a5232');R(x,y-9,1,9,'#3f2815');R(x+2,y-4,1,1,'#f5c842');R(x-6,y-1,12,1,'#8a8378');
  // pencereler: çerçeve, çapraz, ışık, denizlik
  for(const wx of [x+9,x-17]){
    R(wx,y-12,8,7,'#3a2818');R(wx+1,y-11,6,5,'#ffe08a');R(wx+1,y-11,6,1,'#fff3c2');R(wx+4,y-11,1,5,'#3a2818');R(wx+1,y-9,6,1,'#3a2818');R(wx-1,y-5,10,1,'#c9b38a');
  }
  // baca: tuğla
  R(x+12,y-42,5,8,'#6b5a50');for(let j=0;j<4;j++){R(x+12,y-41+j*2,5,1,'#4a3d36');R(x+13+(j%2)*2,y-42+j*2,1,2,'#4a3d36')}R(x+11,y-43,7,2,'#3d3530');
  if(h.isForge){
    R(x+11,y-49,8,11,'#4b5563');R(x+11,y-50,8,2,'#9ca3af');
    R(x-10,y-28,20,8,'#202d3c');R(x-7,y-26,14,4,'#d59045');
    R(x-2,y-27,4,2,'#ffe3a5'); // ocak tabelası
    R(x+21,y-8,9,5,'#475569');R(x+24,y-11,4,3,'#94a3b8'); // örs
    R(x-4,y-3,8,2,'#ecc487');
  }else if(h.type==='frost'){
    R(x-24,y-19,48,3,'#f8feff');R(x-17,y-26,34,2,'#e4f5f7');
    R(x+12,y-43,5,2,'#fff');R(x-4,y-3,8,2,'#8fd4e8');
  }else if(h.type==='marsh'){
    R(x-19,y-24,12,3,'#7caa68');R(x+8,y-24,10,3,'#81a465');
    R(x+17,y-22,2,8,'#94bb84');R(x+13,y-19,8,3,'#a267b6');
    R(x-4,y-3,8,2,'#a6dc9d');
  }else if(h.type==='fisher'){
    R(x-19,y-26,38,3,'#d9ae67');R(x-7,y-29,14,5,'#314f68');
    R(x-3,y-28,6,2,'#7dd2d9');R(x+15,y-19,2,7,'#755a42');
    R(x+13,y-21,6,2,'#9dd8e1');R(x-4,y-3,8,2,'#d8bd7f');
  }else if(h.type==='oasis'){
    R(x-25,y-25,50,3,'#f3d294');R(x-16,y-29,32,4,'#b45e40');
    R(x-10,y-33,20,5,'#d28b58');R(x-3,y-27,6,3,'#f9d76f');
    R(x-5,y-3,10,3,'#e1bb77');R(x+17,y-25,2,9,'#6d634a');
    R(x+18,y-26,7,4,'#74b988');
  }else if(h.type==='harbor'){
    R(x-24,y-18,48,3,'#d1e0db');R(x-18,y-29,36,4,'#274f69');
    R(x-12,y-35,24,6,'#437f9c');R(x+16,y-42,2,18,'#e8d39a');
    R(x+18,y-41,7,4,'#58bed8');R(x-4,y-3,8,2,'#84d6dc');
  }else if(h.type==='field_camp'){
    R(x-24,y-21,48,5,'#31574c');R(x-17,y-27,34,7,'#527e64');
    R(x-6,y-29,12,4,'#d9c089');R(x+11,y-43,3,15,'#73563a');
    R(x+12,y-44,9,5,'#acd9a2');R(x-4,y-3,8,3,'#f7cf83');
    if(h.level>=2){
      R(x+23,y-9,9,9,'#8b613c');R(x+23,y-12,9,3,'#cca06a');R(x+26,y-6,3,2,'#facc15');
      R(x-31,y-7,7,7,'#6b5339');R(x-30,y-9,5,2,'#d6ad75');
    }
    if(h.level>=3){
      R(x-8,y-43,16,19,'#617a6f');R(x-10,y-46,20,4,'#a8c7a7');
      R(x-5,y-52,10,6,'#4d7067');R(x-2,y-38,4,6,'#f7da89');
      R(x+8,y-55,2,13,'#d8ead1');R(x+10,y-54,10,5,'#e6c66a');
    }
  }
}

function fountain(){
  const x=C*TS,y=C*TS;
  R(x-12,y-4,24,8,'#8d97a8');R(x-9,y-6,18,4,'#4aa3df');
  R(x-3,y-16,6,12,'#b5bfce');R(x-5,y-20,10,5,'#8d97a8');
  R(x-1,y-24,2,5,'#9fe0ff');
}

function paintCottage(tile,px,py,tx,ty){
  if(curMap!=='inside')return;
  if(tile===3){
    R(px,py,TS,TS,((tx+ty)&1)?'#9a6238':'#b07848');
    R(px,py+5,TS,1,'#7a4e2c');
    R(px,py+11,TS,1,'#6d4426');
    if((tx&3)===0)R(px,py,1,TS,'#5c3a22');
  }else if(tile===4){
    R(px,py,TS,TS,'#6e5646');
    R(px,py,TS,3,'#8d6b52');
    R(px,py+TS-3,TS,3,'#4e3b32');
    if(((tx+ty)&1)===0)R(px+4,py+6,2,7,'#3f2e26');
  }
}
function draw(){
  labelCount=0;
  FX.beginRender();
  const x0=Math.max(0,(camX/TS|0)-1),x1=Math.min(N-1,((camX+LW)/TS|0)+1);
  const y0=Math.max(0,(camY/TS|0)-1),y1=Math.min(N-1,((camY+LH)/TS|0)+1);
  const tw=Math.floor(P.t*2);
  
  for(let ty=y0;ty<=y1;ty++)for(let tx=x0;tx<=x1;tx++){
    const t=tl[ty*N+tx],px=tx*TS,py=ty*TS,h=H(tx,ty);
    g.drawImage(TA[t][Math.min(3,h*4|0)],px,py);paintCottage(t,px,py,tx,ty);
    const isLake=curMap==='world'&&t===1&&lakeWater(tx,ty);
    const isOasis=curMap==='world'&&t===1&&oasisWater(tx,ty);
    if(t===1&&tl[ty*N+tx-1]===1&&tl[ty*N+tx+1]===1&&tl[(ty-1)*N+tx]===1&&tl[(ty+1)*N+tx]===1&&!isLake)
      R(px,py,TS,TS,'#0a2a5a40');
    if(t!==1)for(let q=0;q<4;q++){
      const dx=q<2?(q?1:-1):0,dy=q>1?(q&1?1:-1):0,nx=tx+dx,ny=ty+dy;
      if(nx<0||ny<0||nx>=N||ny>=N)continue;
      const u=tl[ny*N+nx];
      if(u===t||u===1)continue;
      for(let k=0;k<TS;k++){
        const e0=k&1?0:1;
        if(dx)R(dx<0?px+e0:px+TS-1-e0,py+k,1,1,PAL3[u][0]);
        else R(px+k,dy<0?py+e0:py+TS-1-e0,1,1,PAL3[u][0]);
      }
    }
    if(t===1){
      const isBog=curMap==='world'&&marshWater(tl,N,tx,ty);
      if(isBog)R(px,py,TS,TS,'#274b4270');
      else if(isLake)R(px,py,TS,TS,'#28aaab44');
      else if(isOasis)R(px,py,TS,TS,'#44bba440');
      const glint=isBog?'#92baa7':isLake?'#b4e8d2':isOasis?'#e6f5c8':'#9fd4f5';
      if((tx+ty+tw)%4===0)R(px+3,py+6,7,1,glint);
      if((tx*3+ty+tw*2)%7===0)R(px+8,py+11,4,1,isBog?'#b0d1ac':isLake?'#d8f5df':'#cfeaff');
      if(tx>0&&tl[ty*N+tx-1]!==1)R(px,py,2,TS,isBog?'#a3c6ab':isOasis?'#e6f5c8':isLake?'#b4e8d2':'#d8f1ff');
      if(ty>0&&tl[(ty-1)*N+tx]!==1)R(px,py,TS,2,isBog?'#a3c6ab':isOasis?'#e6f5c8':isLake?'#b4e8d2':'#d8f1ff');
      if(isLake&&H(tx+47,ty+32)<.12){
        R(px+4,py+9,8,3,'#327957');R(px+6,py+8,5,2,'#63ba73');
        R(px+10,py+7,2,2,'#f9b7d4');
      }
    }else if(t===13){
      if((tx*3+ty+tw)%4===0)R(px+3,py+7,5,2,'#ffd36f');
      if((tx+ty+tw*2)%5===0)R(px+11,py+12,3,2,'#ffed9f');
    }
  }

  if(curMap==='home'){
    TOWN_PARK.ground();
    gardenCampusGroundD();
  }

  // HEDEFLEME PİKSEL KILAVUZU (AKILLI KARO REHBERİ)
  if(!P.dead && (curMap==='home'||curMap==='world')){
    const dirOffsets = [[0,1],[0,-1],[-1,0],[1,0]];
    const off = dirOffsets[P.f] || [0,1];
    const tgtGx=Math.floor(P.x/TS)+off[0];
    const tgtGy=Math.floor(P.y/TS)+off[1];
    const cpx = tgtGx * TS;
    const cpy = tgtGy * TS;
    
    let cCol = '';
    let cBadge = '';
    const aimPlot=FARM.plotAt(cpx+8,cpy+8);
    const isWater=tAt(cpx+8,cpy+8)===1||(!aimPlot&&curMap==='home'&&(Math.hypot(cpx+8-16*TS,cpy+8-24*TS)<24||Math.hypot(cpx+8-31*TS,cpy+8-30*TS)<24));
    const plot = farmPlots && farmPlots.find(p => Math.abs(p.x - (cpx+8)) < 12 && Math.abs(p.y - (cpy+8)) < 12);
    const oreRes = resources && resources.find(r => !r.mined && r.isOre && Math.hypot(r.x - (cpx+8), r.y - (cpy+8)) < 18);
    const tool = P.activeTool || 'sword';

    if(curMap === 'home'){
      if(plot){
        if(plot.dead){ cCol='#ef4444'; cBadge='TEMIZLE'; }
        else if(FARM.ripe(plot)){ cCol='#4ade80'; cBadge='HASAT ★'; }
        else if(!plot.crop){ cCol='#a3e635'; cBadge='TOHUM EK'; }
        else if(!plot.watered){ cCol='#38bdf8'; cBadge='SULA 💧'; }
        else { const cd=CROPS[plot.crop]; cCol='#fde047'; cBadge=`${Math.max(1,cd.d-(plot.age||0))}G KALDI`; }
      }else if(oreRes){
        cCol='#fb923c'; cBadge='KIR ⛏️';
      }else if(isWater && (tool==='can'||tool==='rod')){
        cCol='#38bdf8'; cBadge=tool==='rod'?'OLTA 🎣':'DOLDUR 💧';
      }
    }else{
      if(tool === 'pickaxe' && oreRes){ cCol = '#fb923c'; cBadge = 'KIR'; }
      else if(tool === 'rod' && isWater){ cCol = '#38bdf8'; cBadge = 'OLTA'; }
      else if(tool === 'sword'){ cCol = '#f43f5e88'; }
    }

    if(cCol){
      const pPulse = 0.65 + Math.sin(P.t * 8) * 0.25;
      g.globalAlpha = pPulse;
      R(cpx, cpy, 4, 1, cCol); R(cpx, cpy, 1, 4, cCol);
      R(cpx + TS - 4, cpy, 4, 1, cCol); R(cpx + TS - 1, cpy, 1, 4, cCol);
      R(cpx, cpy + TS - 1, 4, 1, cCol); R(cpx, cpy + TS - 4, 1, 4, cCol);
      R(cpx + TS - 4, cpy + TS - 1, 4, 1, cCol); R(cpx + TS - 1, cpy + TS - 4, 1, 4, cCol);
      g.globalAlpha = 1;
      if(cBadge) T(cBadge, cpx + 8, cpy - 3, cCol);
    }
  }
  
  CAVE.draw();
  for(const l of loot){
    if(!FX.visible(l.x,l.y,100))continue;
    const c=l.t==='g'?'#ffd23f':l.t==='gem'?'#38bdf8':l.t==='p'?'#6dff9c':(RAR[l.v.r]||RAR[0])[1];
    const z=l.z+Math.sin(l.a*5)*1.5;
    FX.shadow(l.x,l.y,5,2,.5);
    if(l.t==='p'||l.t==='gem'||l.t==='i'&&l.v.r>=2)FX.glow(l.x,l.y-2+z,l.t==='p'?13:17,l.t==='p'?3:l.t==='gem'?1:l.v.r===3?0:2,.62);
    if(l.t==='i'){
      const isLeg=l.v.r===3;
      const isEpic=l.v.r===2;
      if(isLeg||isEpic){
        const beamH=isLeg?90:55;
        const beamW=isLeg?5:3;
        g.globalCompositeOperation='lighter';
        g.globalAlpha=0.45+Math.sin(P.t*7)*0.2;
        R(l.x-Math.floor(beamW/2),l.y-beamH,beamW,beamH,c);
        for(let s=0;s<2;s++){
          const sy=l.y-((Math.floor(P.t*45+s*30))%beamH);
          R(l.x+Math.sin(P.t*5+s)*3,sy,2,2,'#fff');
        }
        g.globalAlpha=0.3+Math.sin(P.t*5)*0.15;
        g.fillStyle=c;
        g.beginPath();
        g.ellipse(l.x,l.y,isLeg?10:7,isLeg?5:3.5,0,0,6.283);
        g.fill();
        g.globalAlpha=1;
        g.globalCompositeOperation='source-over';
      }else{
        g.globalAlpha=.35;R(l.x-1,l.y-35,3,35,c);g.globalAlpha=1;
      }
    }
    R(l.x-3,l.y-4+z,l.t==='g'?4:7,l.t==='g'?4:7,c);
    R(l.x-2,l.y-3+z,2,2,'#fff');
  }
  
  DRAW.begin();
  for(const o of objs){
    if(curMap==='home'&&['well','campfire','cart','watermill','barn_col'].includes(o.k))continue;
    if(curMap==='mine'&&['ladder_up','elevator'].includes(o.k))continue;
    DRAW.add(curMap==='inside'?'inside':'obj',o);
  }
  for(const h of hs)DRAW.add('house',h);
  for(const ch of chests)if(!ch.hidden)DRAW.add('chest',ch);
  if(curMap==='home'){
    DRAW.add('buildsite',null,27*TS,37*TS);
    for(const b of P.adventure.buildings){const d=BUILD.defs[b.kind];DRAW.add('placed',b,(b.gx+d.w/2)*TS,(b.gy+d.h)*TS,BUILD.drawOrder(b))}
    DRAW.add('chapel',null,31*TS,12*TS);DRAW.add('well',null,31*TS,30*TS);
    DRAW.add('stall',null,27*TS,25*TS,0);DRAW.add('stall',null,35*TS,25*TS,1);
    DRAW.add('stall',null,27*TS,33*TS,2);DRAW.add('stall',null,35*TS,33*TS,3);
    DRAW.add('mill',null,48*TS,22*TS);DRAW.add('well',null,16*TS,24*TS);
    DRAW.add('shipping',null,10*TS,24*TS);DRAW.add('coop',null,8*TS,16*TS);DRAW.add('barn',null,8*TS,30*TS);
    for(const a of HERD.list())DRAW.add('herd',a);
    if(P.hasBeehive)DRAW.add('beehive',null,16*TS,35*TS);
    if(P.hasCask)DRAW.add('cask',null,19*TS,35*TS);
    for(const d of WORLD_DATA.home.ducks||[])DRAW.add('duck',d);
    FARM.focusedPlot=(farmPlots||[]).reduce((best,p)=>{const d=Math.hypot(P.x-p.x,P.y-p.y);return d<58&&(!best||d<best.d)?{p,d}:best},null)?.p||null;
    for(const p of farmPlots||[])DRAW.add('plot',p);
    if(P.hasSprinkler||FARM.cfg().sprinklerLv>=1)DRAW.add('sprinkler',null,17*TS,27.5*TS);
    DRAW.add('autost',null,AUTO.RX,AUTO.RY);if(AUTO.A().golem&&AUTO.g)DRAW.add('golem',null,AUTO.g.x,AUTO.g.y);
  }
  for(const r of resources)DRAW.add('resource',r);
  for(const c of critters)if(!c.dead&&!c.tamed)DRAW.add('critter',c);
  if(P.pet)DRAW.add('pet',P.pet);if(P.merc)DRAW.add('merc',P.merc);
  if(curMap==='world'){
    for(const track of BOSS_SYSTEM.traces)DRAW.add('bosstrack',track,track.x,track.y);
    DRAW.add('fountain',null,C*TS,C*TS+4);
    DRAW.add('town',null,C*TS+34,C*TS+28,0);DRAW.add('town',null,C*TS-36,C*TS-28,1);
    DRAW.add('town',null,C*TS-32,C*TS+28,2);DRAW.add('town',null,C*TS+24,C*TS-28,3);
  }
  if(curMap==='mine'){
    const md=WORLD_DATA.mine;
    DRAW.add('ladder',null,4*TS,4*TS,1);
    if(md?.floor%5===0)DRAW.add('elevator',null,6*TS,4*TS);
    if(md?.ladder?.uncovered)DRAW.add('ladder',null,md.ladder.x,md.ladder.y,0);
  }
  for(const e of mobs)if(!e.dead)DRAW.add('mob',e);
  if(curMap!=='inside')for(const n of npcs)if(!n.hidden)DRAW.add('npc',n);
  if(!P.dead)DRAW.add('player',P);
  DRAW.draw();
  
  if(P.fs){
    const f=P.fs,by=f.by+(f.st==='bite'?Math.sin(P.t*40)*2:Math.sin(P.t*3)*.8);
    for(let i=0;i<=10;i++){
      const k=i/10;
      R(P.x+(f.bx-P.x)*k,P.y-14+(by-P.y+14)*k-Math.sin(k*3.14)*8,1,1,'#fff');
    }
    R(f.bx-1,by-1,3,3,'#e33');R(f.bx-1,by+1,3,1,'#fff');
  }
  
  COMBAT.drawTg();
  for(const t of tel){
    const k=1-t.t/t.max;
    g.fillStyle=`rgba(${t.c},${.14+.2*k})`;
    g.beginPath();g.ellipse(t.x,t.y,t.r,t.r*.8,0,0,6.283);g.fill();
    g.strokeStyle=`rgba(${t.c},.9)`;g.lineWidth=1;g.stroke();
    g.fillStyle=`rgba(${t.c},${.25+.3*k})`;
    g.beginPath();g.ellipse(t.x,t.y,t.r*k,t.r*k*.8,0,0,6.283);g.fill();
  }
  
  BUILD.preview();FX.paintTrails();
  for(const p of prj)if(FX.visible(p.x,p.y,28))COMBAT.drawP(p);
  FX.paintParticles();
  drawWaypointGuide();
  FX.paintLighting();FX.paintRays();FX.paintBloom();FX.paintGrade();
  
  g.setTransform(RS,0,0,RS,0,0);
  
  FX.paintAtmosphere();FX.paintHurt();
  // Canlı Konuşma Baloncukları
  for(const b of bubbles) bubbleD(b);
  g.imageSmoothingEnabled=true;g.drawImage(VG,0,0,LW,LH);
}

