/* ===== YAŞAM BECERİLERİ USTALIĞI (LIFE SKILLS MASTERY) ===== */
const MASTERY_INFO = {
  farm: {
    id: 'farm', name: 'Çiftçilik Ustalığı', icon: '🌾',
    desc: 'Tarlada ekin ekip hasat ettikçe gelişir.',
    perks: [
      'Lv.2: Ekinler %15 daha hızlı olgunlaşır.',
      'Lv.4: Hasatta %25 şansla 2 Kat Ürün elde edersin!',
      'Lv.7: ★★★ Altın Ekin çıkma şansı iki katına çıkar!',
      'Lv.10: [Toprak Efendisi] Tohumlar %50 indirimli!'
    ]
  },
  mine: {
    id: 'mine', name: 'Madencilik Ustalığı', icon: '⛏️',
    desc: 'Kayaları ve cevher damarlarını kırdıkça gelişir.',
    perks: [
      'Lv.2: Kazma/maden hasarın 2 katına çıkar (hızlı kırma).',
      'Lv.4: Kırılan madenlerden %35 şansla fazladan +1 Elmas (💎)!',
      'Lv.7: Madenlerden düşen altın miktarı 2 katına çıkar!',
      'Lv.10: [Cevher Ustası] Kristal damarlar 2 kat hızlı yeniden doğar.'
    ]
  },
  cook: {
    id: 'cook', name: 'Aşçılık Ustalığı', icon: '🍳',
    desc: 'Mutfakta yemek pişirdikçe ve yeni tarifler denedikçe gelişir.',
    perks: [
      'Lv.2: Yemek buff süreleri 3 dakikadan 6 dakikaya uzar!',
      'Lv.4: Pişirirken %25 şansla fazladan Çift Porsiyon elde edersin!',
      'Lv.7: Pişirilen yemeklerin can ve kalkan gücü +%50 artar!',
      'Lv.10: [Kraliyet Aşçısı] Tüm ziyafet buffları 10 dakika sürer!'
    ]
  },
  fish: {
    id: 'fish', name: 'Balıkçılık Ustalığı', icon: '🎣',
    desc: 'Gölde ve nehirlerde balık tuttukça gelişir.',
    perks: [
      'Lv.2: Balıkların oltaya vurma süresi %30 hızlanır.',
      'Lv.4: Nadir ve Altın Balık çıkma şansı iki katına çıkar!',
      'Lv.7: Oltaya %20 şansla Gizli Hazine Sandığı takılır!',
      'Lv.10: [Denizler Hakimi] Balıklar tüccarda 3 kat fiyata satılır.'
    ]
  }
};

function addMasteryXp(skillId,xp){
  if(!MASTERY_INFO[skillId]||!Number.isFinite(xp)||xp<=0)return false;
  if(skillId==='farm'&&friendHearts('dede')>=2)xp*=1.25;
  if(!P.skills)P.skills={farm:{lvl:1,xp:0},mine:{lvl:1,xp:0},cook:{lvl:1,xp:0},fish:{lvl:1,xp:0}};
  const sk=P.skills[skillId]||(P.skills[skillId]={lvl:1,xp:0});
  const before=sk.lvl;sk.xp+=xp;
  while(sk.lvl<10&&sk.xp>=sk.lvl*35){sk.xp-=sk.lvl*35;sk.lvl++}
  if(sk.lvl>=10)sk.xp=0;
  if(sk.lvl>before){
    const mInfo=MASTERY_INFO[skillId];
    fl(P.x,P.y-26,`★ ${mInfo.icon} ${mInfo.name} SEVİYE ${sk.lvl}!`, '#ffd23f', true);
    playChord([523,659,784,1046],.35,'triangle',.07);
    spark(P.x,P.y-10,24,'#ffd23f',80);
    sv();
  }
}

function masteryUI(){
  if(!P.skills)P.skills={farm:{lvl:1,xp:0},mine:{lvl:1,xp:0},cook:{lvl:1,xp:0},fish:{lvl:1,xp:0}};
  let h='';
  Object.values(MASTERY_INFO).forEach(m=>{
    const sk=P.skills[m.id]||{lvl:1,xp:0};
    const req=sk.lvl*35;
    const pct=sk.lvl>=10?100:Math.min(100,Math.round((sk.xp/req)*100));
    h+=`<div class="ach-item" style="flex-direction:column;align-items:stretch">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <div style="font-weight:900;color:var(--gd);font-size:13px">${m.icon} ${m.name} <span style="color:#a7f3d0;font-size:11px">(Sv.${sk.lvl})</span></div>
        <div style="font-size:10px;color:#94a3b8">${sk.lvl>=10?'MAKSİMUM':`İlerleme: ${sk.xp}/${req}`}</div>
      </div>
      <div style="width:100%;height:5px;background:#000a;border-radius:3px;overflow:hidden;margin-bottom:6px">
        <div style="width:${pct}%;height:100%;background:linear-gradient(90deg,#38bdf8,#ffd23f)"></div>
      </div>
      <div style="font-size:10px;color:#cbd5e1;line-height:1.4">
        ${m.perks.map((p,idx)=>{
          const unlocked=sk.lvl>=(m.thresholds||[2,4,7,10])[idx];
          return `<div style="color:${unlocked?'#6ee7b7':'#64748b'}">${unlocked?'✔':'🔒'} ${p}</div>`;
        }).join('')}
      </div>
    </div>`;
  });
  $('mastery-list').innerHTML=h;
}


/* ===== DİNAMİK HAVA DURUMU VE GECE ETKİNLİKLERİ ===== */
const weather = window.weather = {
  type: 'clear', // 'clear', 'rain', 'fog', 'blood_moon'
  timer: 160
};

function updWeather(dt){
  weather.timer -= dt;
  if(weather.timer <= 0){
    const n = cl(.4-Math.sin(tod*6.283)*.9,0,.6);
    const isNight = n > 0.22;
    if(isNight){
      const r = Math.random();
      if(r < 0.35){
        weather.type = 'blood_moon';
        ban('🌑 KANLI AY DOĞDU! Canavarlar öfkelendi!', '#ef4444');
        playChord([220, 311, 440], .5, 'sawtooth', .08);
        chat('SİSTEM', '', 'Kanlı Ay yükseldi! Canavarlar vahşileşti ama ganimetler 3 KATINA ÇIKTI!', 1);
      }else if(r < 0.65){
        weather.type = 'fog';
        ban('🌫️ Mistik Sis Çöktü...', '#c084fc');
      }else if(r<.8){
        weather.type='storm';ban('⛈️ Fırtına · Açık arazide hedefler ıslanır!','#a8d4ef');
      }else{
        weather.type = 'clear';
      }
    }else{
      const r = Math.random();
      if(r<.12){
        weather.type='storm';ban('⛈️ Fırtına Başladı · Pazarda fiyatlar değişiyor!','#a8d4ef');
      }else if(r < 0.38){
        weather.type = 'rain';
        ban('🌧️ Bereketli Yağmur Başladı! Tarlalar sulanıyor.', '#38bdf8');
        playChord([523, 659, 784], .3, 'sine', .04);
        chat('SİSTEM', '', 'Yağmur başladı! Çiftlikteki tüm ekinler otomatik sulanıyor.', 1);
      }else if(r < 0.55){
        weather.type = 'fog';
        ban('🌫️ Mistik Sis Çöktü...', '#c084fc');
      }else{
        weather.type = 'clear';
        ban('☀️ Gökyüzü Açıldı!', '#ffd23f');
      }
    }
    weather.timer = rnd(120, 220);
  }

  // Yağmur yağarken tarlalar otomatik sulanır
  if(isWetWeather()&&WORLD_DATA.home?.farmPlots){
    WORLD_DATA.home.farmPlots.forEach(p=>{p.watered=true;p.moisture=friendHearts('dede')>=5?2:1;if(p.introPlant)ONBOARD.event('water')});
  }
}


