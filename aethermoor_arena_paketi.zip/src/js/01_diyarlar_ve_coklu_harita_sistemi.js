/* ===== DİYARLAR VE ÇOKLU HARİTA SİSTEMİ (WORLD, HOME) ===== */
let curMap = 'world';
const WORLD_DATA = {};
let wildStateCache={world:null,frontier:null}; // Henüz açılmamış il de kayıt sırasında korunur.
let N = 100, TS = 16, C = 50;
let tl, objs = [], hs = [], chests = [], critters = [], resources = [], mobs = [], npcs = [], mmc;
let farmPlots = [], houseLevel = 1;

const ZN=['Gölgeköy','Zümrüt Orman','Sığ Göl','Kızıl Çöl','Ejder İni'];
const ZC=[[50,50],[50,18],[18,50],[82,50],[50,82]];
const GUIDE_ROUTE=[
  {short:'Evine gir [E]',hint:'Gölgeköy senin yuvan. Evinde yemek hazırlayabilir ve uyuyarak yeni güne başlayabilirsin; yaklaş ve E / etkileşim kullan.'},
  {short:'Pazarı tanı [M]',hint:'Pazar, ürettiklerini kasabalılara ulaştırdığın yer. M ile Pazar Meydanı yönünü bul; acele etmeden çevreni tanı.'},
  {short:'Yola hazırlan [M]',hint:'Hazır olduğunda doğu kapısından çık. Çiftliğin hazırlık alanın; keşif dönüşünde kaynaklarını burada değerlendir.'},
  {short:'Zümrüt Orman [M]',hint:'Orman yolundaki ilk hedefin 6 Slime. Hazırlığını tamamladıysan yola çık; kasabaya her zaman dönebilirsin.'}
];
// Rehber: başlangıç görevi (ONBOARD) etkinse harita durağı ve mesajlar onun adımını izler; çelişen ikinci rota gösterilmez.
function guideIs(i){const st=window.ONBOARD&&ONBOARD.current&&ONBOARD.current();if(st)return (i===0&&(st.target==='home'))||(i===3&&st.target==='forest');return P.guideStep===i&&!QUEST_FLOW.optional()}
function guideNow(){const st=window.ONBOARD&&ONBOARD.current&&ONBOARD.current();if(st)return st;return(P.guideStep<4&&!QUEST_FLOW.optional())?GUIDE_ROUTE[P.guideStep]:null}
function navigationTarget(){
  if(window.STORY&&STORY.cueHome&&STORY.cueHome())return {map:'home',x:18,y:14,name:'Hamdi’nin kapısı'};
  if(window.STORY&&STORY.resting&&STORY.resting())return {map:'home',x:12,y:24,name:'Bu gece evindesin'};
  if(window.STORY&&STORY.morningDue&&STORY.morningDue())return null;
  if(window.STORY&&STORY.mastery){const job=STORY.mastery();if(job==='mine')return {map:'home',x:6,y:8,name:'Kristal Madeni'};if(job==='frontier')return {map:'world',x:55,y:30,name:'Yayla Geçidi'};if(job==='elite')return {map:'world',x:27,y:81,name:'Seçkin Sırt'}}
  if(window.STORY&&STORY.needsRest&&STORY.needsRest())return {map:'home',x:12,y:24,name:'Eve dön · sabahı aç'};
  if(window.STORY&&STORY.needsOasis&&STORY.needsOasis())return {map:'world',x:84,y:38,name:'Vahada nefes al'};
  const marked=P.adventure?.navWaypoint;if(marked&&['world','frontier','home'].includes(marked.map))return marked;
  const step=window.ONBOARD&&ONBOARD.current&&ONBOARD.current();
  if(step){
    const targets={home:{map:'home',x:12,y:24,name:'Çiftlik Evi'},farm:{map:'home',x:17,y:27,name:'Kolay Bahçe'},cook:curMap==='inside'?{map:'inside',x:7,y:14,name:'Ev Ocağı'}:{map:'home',x:12,y:24,name:'Çiftlik Evi'},forest:{map:'world',x:50,y:22,name:'Slime açıklığı'},chest:{map:'home',x:27,y:40,name:'İnşa Arazisi'}};
    return targets[step.id]||null;
  }
  const q=typeof QS!=='undefined'&&window.P?QS[P.q]:null;if(!q||QUEST_FLOW.optional())return null;
  const targets={slime:{map:'world',x:50,y:22,name:'Slime açıklığı'},treant:{map:'world',x:56,y:12,name:'Muhafız Korusu'},fish:{map:'world',x:LAKE_DOCK.x,y:LAKE_DOCK.y,name:LAKE_DOCK.name},lizard:{map:'world',x:40,y:54,name:'İskele Koyu'},crab:{map:'world',x:36,y:44,name:'Yengeç Kayalığı'},scorpion:{map:'world',x:73,y:48,name:'Kervan Yolu'},golem:{map:'world',x:82,y:56,name:'Golem Çukuru'},forge:{map:'home',x:50,y:39,name:'Demirci Boran'},skeleton:{map:'world',x:50,y:67,name:'Kül Geçidi'},dragon:{map:'world',x:50,y:84,name:'Ejder Arenası'}};
  return targets[q.k]||null;
}
function navigationCue(){
  const t=navigationTarget();if(!t)return null;
  if(t.map!==curMap)return {icon:'🗺️',text:`${t.name} · haritayı aç`,target:t};
  const dx=t.x*TS+8-P.x,dy=t.y*TS+8-P.y,tiles=Math.round(Math.hypot(dx,dy)/TS),a=Math.atan2(dy,dx),arrows=['→','↘','↓','↙','←','↖','↑','↗'];
  const icon=arrows[(Math.round(a/(Math.PI/4))+8)%8];return {icon,text:tiles<=4?`${t.name} · yakındasın`:`${t.name} · ${tiles} kare`,target:t};
}
// Görevlerin 0–4 bölge kimlikleri sabit kalır; kar ve bataklık kuzey bölgesinin alt biyomlarıdır.
const MAP_COLORS=['#69a844','#277cb3','#ead6a4','#b7ad96','#3f4b5c','#dbb574','#397b41','#e0f1f0','#526e50','#cda971','#9dcdda','#6b21a8','#a57149','#ba4828','#172131','#756858','#789765','#4e6070'];
const LAKE_DOCK={x:37,y:55,name:'Balıkçı İskelesi'};
const SEA_PORT={x:9,y:62,name:'Batı Limanı'};
const WORLD_MINE={x:57,y:70,name:'Kül Kristal Ocağı'};
const WORLD_GATE={x:55,y:30,name:'Yayla Geçidi'};
const FRONTIER={N:72,C:36,gate:{x:36,y:66},camp:{x:43,y:42},ruin:{x:22,y:24},lake:{x:50,y:38}};
const FRONTIER_STATION={x:25,y:24,name:'Yayla Gözcü Karakolu'};
const DESERT_OASIS={x:78,y:36};
const DRAGON_LAIR={x:50,y:84,approachY:67};
// Sığ Göl açık denizden ayrı, kuzey-güney uzanan tek bir tatlı su havzasıdır.
const lakeShape=(x,y)=>((x-27)/8)**2+((y-50)/10)**2+(vn(x*.17+88,y*.16+35)-.5)*.18;
const nearLake=(x,y)=>zoneOf(x,y)===2&&lakeShape(x,y)<1.6;
const lakeWater=(x,y)=>zoneOf(x,y)===2&&lakeShape(x,y)<1;
const oasisShape=(x,y)=>((x-DESERT_OASIS.x)/4.6)**2+((y-DESERT_OASIS.y)/3.6)**2+(vn(x*.24+66,y*.24+13)-.5)*.12;
const oasisWater=(x,y)=>zoneOf(x,y)===3&&oasisShape(x,y)<1;
const nearOasis=(x,y)=>zoneOf(x,y)===3&&oasisShape(x,y)<4.5;
const WORLD_OUTPOSTS={
  marsh:{x:31,y:24,name:'Sazlık Şifacısı',icon:'🍄',tile:8},
  frost:{x:66,y:21,name:'Kar Sığınağı',icon:'❄️',tile:7},
  oasis:{x:84,y:38,name:'Vaha Kervansarayı',icon:'🌴',tile:5}
};
const WAYPOINTS=window.WAYPOINTS={
  defs:[
    {map:'world',name:'Zümrüt Orman',x:50,y:18},{map:'world',name:'Yayla Geçidi',x:55,y:30},{map:'world',name:'Mantar Bataklığı',x:31,y:24},{map:'world',name:'Akçam Karları',x:66,y:21},{map:'world',name:'Sığ Göl',x:27,y:50},{map:'world',name:'Balıkçı İskelesi',x:37,y:55},{map:'world',name:'Batı Limanı',x:9,y:62},{map:'world',name:'Kızıl Çöl',x:82,y:50},{map:'world',name:'Kızıl Vaha',x:84,y:38},{map:'world',name:'Ejder İni',x:50,y:67},{map:'world',name:'Kül Kristal Ocağı',x:57,y:70},
    {map:'frontier',name:'Yayla Kampı',x:43,y:42},{map:'frontier',name:'Kadim Harabe',x:22,y:24},{map:'frontier',name:'Yayla Gölü',x:50,y:38}
  ],
  key(map,name){return `${map}:${name}`},
  init(existing){
    const a=P.adventure,had=a.waypoints&&typeof a.waypoints==='object';a.waypoints=had?a.waypoints:{};a.waypoints[this.key('world','Gölgeköy')]=true;
    if(existing&&!had){if(P.q>=1)a.waypoints[this.key('world','Zümrüt Orman')]=true;if(P.q>=3||P.ach.fish_caught)a.waypoints[this.key('world','Sığ Göl')]=true;if(P.q>=5)a.waypoints[this.key('world','Kızıl Çöl')]=true;if(P.q>=8)a.waypoints[this.key('world','Ejder İni')]=true;if((P.maxMineFloor||1)>1)a.waypoints[this.key('world','Kül Kristal Ocağı')]=true;if(P.frontierDiscovered)for(const d of this.defs.filter(d=>d.map==='frontier'))a.waypoints[this.key(d.map,d.name)]=true}
    return a.waypoints;
  },
  isUnlocked(map,name){return map==='home'||map==='inside'||map==='mine'||name==='Gölgeköy'||name==='Ana Dünya Geçidi'||!!P.adventure?.waypoints?.[this.key(map,name)]},
  unlock(def){const key=this.key(def.map,def.name);if(P.adventure.waypoints[key])return false;P.adventure.waypoints[key]=true;if(P.adventure.navWaypoint?.map===def.map&&P.adventure.navWaypoint?.name===def.name)P.adventure.navWaypoint=null;ban(`🗺️ HIZLI YOLCULUK AÇILDI: ${def.name}`,'#86efac');NOTIFICATIONS.push('waypoint','🗺️',`${def.name} keşfedildi`,'Bu konuma artık haritadaki GİT düğmesiyle hızlı yolculuk yapabilirsin.');playChord([523,659,784],.25,'triangle',.045);sv();return true},
  tick(){if(!['world','frontier'].includes(curMap))return;for(const d of this.defs)if(d.map===curMap&&!this.isUnlocked(d.map,d.name)&&Math.hypot(P.x-(d.x+.5)*TS,P.y-(d.y+.5)*TS)<7*TS)this.unlock(d);this.grove();this.oasis();this.pass();this.arena()},
  grove(){
    if(curMap!=='world'||QS[P.q]?.k!=='treant'||!window.STORY||STORY.needsRest())return;
    const s=STORY.state();if(s.beats.grove)return;
    if(Math.hypot(P.x-56.5*TS,P.y-12.5*TS)>7*TS)return;
    s.beats.grove=true;ban('🌳 Muhafız Korusu','#86efac');
    chat('ÇİFTÇİ DEDE','','Burada yalnız o var. Ekmeğini ye, işaretli alandan çık, sersemleyince vur.',1);sv();
  },
  oasis(){
    if(curMap!=='world'||!window.STORY||!STORY.needsOasis())return;
    const site=WORLD_OUTPOSTS.oasis;
    if(Math.hypot(P.x-(site.x+.5)*TS,P.y-(site.y+.5)*TS)>7*TS)return;
    STORY.state().beats.oasis=false;ban('🌴 Vaha','#86efac');
    chat('KERVANCI LEYLA','','Nefes aldın. İstersen kervansarayda dinlen. Kum Golemi yolun güneyindeki çukurda.',1);sv();
  },
  pass(){
    if(curMap!=='world'||QS[P.q]?.k!=='skeleton'||!window.STORY)return;
    const s=STORY.state();if(s.beats.pass)return;
    if(Math.hypot(P.x-50.5*TS,P.y-67*TS)>6*TS)return;
    s.beats.pass=true;ban('💀 Kül Geçidi','#fca5a5');
    chat('DEMİRCİ BORAN','','Beş iskelet yolu tutuyor. Ejder daha güneyde. Onu buraya çekme.',1);sv();
  },
  arena(){
    if(curMap!=='world'||QS[P.q]?.k!=='dragon'||!window.STORY)return;
    const s=STORY.state();if(s.beats.arena)return;
    if(Math.hypot(P.x-50.5*TS,P.y-84*TS)>8*TS)return;
    s.beats.arena=true;ban('🐉 Ejder Arenası','#fca5a5');
    chat('MUHTAR HAMDİ','','Burası yalnız onun. İşaretli alandan çık, sersemleyince vur. Geçitteki ölüleri buraya sürme.',1);sv();
  },
  guide(map,site){P.adventure.navWaypoint={map,x:site.x,y:site.y,name:site.name};sv()}
};
const zoneOf=(x,y)=>{
  const dx=x-C,dy=y-C;
  if(Math.hypot(dx,dy)<12)return 0;
  const a=Math.atan2(dy,dx),A=Math.abs(a);
  return A<.785?3:A>2.356?2:a<0?1:4;
};
const worldBiome=(x,y)=>{
  if(zoneOf(x,y)!==1)return null;
  const edge=(vn(x*.08+23,y*.09+7)-.5)*5;
  return y<44&&x<40+edge?'marsh':y<44&&x>60+edge?'frost':'forest';
};
// Ejder arenası ve kuzey giriş koridoru lavın dışında kalır.
const dragonLava=(x,y)=>{
  if(zoneOf(x,y)!==4||y<66||y>94)return false;
  const dx=x-DRAGON_LAIR.x,dy=y-DRAGON_LAIR.y,r=Math.hypot(dx,dy);
  return r>8&&r<19&&Math.abs(dx)>5&&vn(x*.23+31,y*.21+64)>.47;
};
const marshWater=(tiles,n,x,y)=>{
  if(tiles[y*n+x]!==1)return false;
  for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){
    const xx=x+dx,yy=y+dy;
    if(xx>=0&&xx<n&&yy>=0&&yy<n&&tiles[yy*n+xx]===8)return true;
  }
  return false;
};

// Denge notu: boss olmayan canavarların saldırısı eşyasız oyuncuya karşı çok zayıf kaldığı için +%30 artırıldı.
const MT={
  slime:{n:'Slime',hp:32,a:8,sp:24,ag:64,rg:13,xp:10,g:[1,4],z:1,lv:1,r:7},
  wolf:{n:'Kurt',hp:54,a:14,sp:46,ag:84,rg:14,xp:20,g:[3,7],z:1,lv:3,r:7},
  boar:{n:'Yayla Domuzu',hp:84,a:18,sp:37,ag:78,rg:15,xp:36,g:[5,11],z:1,lv:4,r:8},
  mire_wisp:{n:'Bataklık Ateşi',hp:72,a:17,sp:29,ag:75,rg:14,xp:30,g:[4,9],z:1,lv:4,r:7},
  frost_wolf:{n:'Kırağı Kurdu',hp:106,a:23,sp:44,ag:90,rg:15,xp:44,g:[7,14],z:1,lv:6,r:8},
  treant:{n:'Orman Muhafızı',hp:620,a:20,sp:20,ag:95,rg:22,xp:260,g:[50,90],z:1,lv:4,r:14,boss:2},
  lizard:{n:'Murloc',hp:95,a:21,sp:34,ag:80,rg:16,xp:32,g:[5,10],z:2,lv:5,r:8},
  crab:{n:'Kral Yengeç',hp:1050,a:25,sp:24,ag:95,rg:20,xp:420,g:[80,140],z:2,lv:7,r:15,boss:2},
  scorpion:{n:'Akrep',hp:145,a:29,sp:38,ag:84,rg:15,xp:50,g:[8,15],z:3,lv:8,r:8},
  golem:{n:'Kum Golemi',hp:1650,a:34,sp:24,ag:100,rg:24,xp:620,g:[120,200],z:3,lv:10,r:16,boss:2},
  skeleton:{n:'İskelet',hp:210,a:39,sp:34,ag:90,rg:16,xp:75,g:[12,22],z:4,lv:11,r:8},
  phalanx:{n:'Kalkanlı Muhafız',hp:360,a:32,sp:20,ag:90,rg:16,xp:100,g:[20,40],z:4,lv:12,r:9},
  assassin:{n:'Gölge Suikastçisi',hp:230,a:52,sp:50,ag:110,rg:15,xp:120,g:[30,50],z:4,lv:12,r:8},
  summoner:{n:'Kemik Çağırıcısı',hp:290,a:29,sp:20,ag:100,rg:24,xp:130,g:[35,60],z:4,lv:12,r:9},
  gladiator:{n:'Arena Şampiyonu',hp:2000,a:44,sp:26,ag:120,rg:28,xp:900,g:[200,350],z:4,lv:14,r:16,boss:2},
  dragon:{n:'Kızıl Ejder',hp:3200,a:48,sp:0,ag:150,rg:65,xp:2200,g:[350,600],z:4,lv:15,r:22,boss:1},
  bat:{n:'Mağara Yarasası',hp:45,a:18,sp:52,ag:80,rg:12,xp:25,g:[3,8],z:1,lv:3,r:6},
  ice_skeleton:{n:'Buzul İskelet',hp:260,a:34,sp:32,ag:95,rg:18,xp:95,g:[18,30],z:2,lv:8,r:8},
  magma_golem:{n:'Magma Golemi',hp:1400,a:38,sp:22,ag:105,rg:24,xp:550,g:[100,180],z:3,lv:12,r:15,boss:2},
  colossus:{n:'Kristal Muhafızı',hp:3600,a:52,sp:24,ag:140,rg:36,xp:3000,g:[500,900],z:4,lv:20,r:24,boss:1}
};
// Tek denge noktası: yalnızca açık dünya bossları bu dolaşım profillerini kullanır.
const BOSS_CONFIG={
  rules:{sleepMin:18,sleepMax:30,patrolMin:6,patrolMax:12,retreatHp:.26,recoverHp:.72,restRegen:.045,traceInterval:4,traceLife:48,traceDistance:22,traceLimit:32,traceRadius:42},
  profiles:{
    treant:{name:'Orman Muhafızı',icon:'🌿',clue:'kırık kök ve ağır ayak izleri',trace:'#a6b76d',zone:1,patrolTiles:7,sense:120,leashTiles:13,patrolSpeed:15,huntSpeed:18,returnSpeed:22},
    crab:{name:'Kral Yengeç',icon:'🦀',clue:'ıslak kabuk izleri ve su damlaları',trace:'#67c8d2',zone:2,patrolTiles:6,sense:125,leashTiles:12,patrolSpeed:18,huntSpeed:22,returnSpeed:24},
    golem:{name:'Kum Golemi',icon:'🗿',clue:'çatlamış taş ve ezilmiş kum',trace:'#d2a75e',zone:3,patrolTiles:8,sense:130,leashTiles:15,patrolSpeed:14,huntSpeed:20,returnSpeed:22},
    dragon:{name:'Kızıl Ejder',icon:'🐉',clue:'kül, yanık izleri ve ağır kanat çırpışları',trace:'#e88455',zone:4,patrolTiles:10,sense:155,leashTiles:18,patrolSpeed:20,huntSpeed:28,returnSpeed:30}
  }
};

/* --- 1. AETHERMOOR VAHŞİ DÜNYASI (100x100) --- */
function initWorldMap(){
  const wN=100, wC=50;
  const wTl=new Uint8Array(wN*wN), wObjs=[], wHs=[], wChests=[], wCritters=[], wRes=[], wMobs=[], wNpcs=[];
  
  for(let y=0;y<wN;y++)for(let x=0;x<wN;x++){
    const d=Math.hypot(x-wC,y-wC),isl=d/44+(vn(x*.08,y*.08)-.5)*.4,z=zoneOf(x,y);let t=0;
    if(isl>1)t=1;
    else if(isl>.92){
      const b=worldBiome(x,y);
      t=b==='marsh'?8:b==='frost'?7:2;
    }else if(z===1){
      const b=worldBiome(x,y);
      const wet=vn(x*.25+43,y*.23+12);
      t=b==='marsh'?(wet>.67?1:8):b==='frost'?(wet>.73?10:7):vn(x*.16+12,y*.15+4)>.72?0:6;
    }else if(z===3)t=oasisWater(x,y)?1:5;
    else if(z===4)t=4;
    else if(z===2&&lakeWater(x,y))t=1;
    wTl[y*wN+x]=t;
  }
  // Islak kıyılar çamurlu, buzlu kıyılar donuk; diğer kıyılar kumsal kalır.
  {
    const c2=wTl.slice();
    for(let y=1;y<wN-1;y++)for(let x=1;x<wN-1;x++){
      const i=y*wN+x;
      if(c2[i]!==1&&c2[i]!==4&&(c2[i-1]===1||c2[i+1]===1||c2[i-wN]===1||c2[i+wN]===1)){
        const b=worldBiome(x,y);
        wTl[i]=b==='marsh'?8:b==='frost'?10:2;
      }
    }
  }
  for(let y=76;y<88;y++)for(let x=44;x<56;x++)wTl[y*wN+x]=4;
  for(let y=66;y<95;y++)for(let x=25;x<76;x++){
    const i=y*wN+x;
    if(wTl[i]===4&&dragonLava(x,y))wTl[i]=13;
  }
  // Kesintisiz ana güzergâhlar ve bataklık/kar sığınaklarına ayrılan patikalar.
  function trail(ax,ay,bx,by){
    const steps=Math.max(Math.abs(bx-ax),Math.abs(by-ay))*3;
    for(let i=0;i<=steps;i++){
      const s=i/steps,x=Math.round(ax+(bx-ax)*s),y=Math.round(ay+(by-ay)*s);
      for(const[dx,dy]of[[0,0],[1,0],[-1,0],[0,1],[0,-1]]){
        const xx=x+dx,yy=y+dy;
        if(xx<1||xx>=wN-1||yy<1||yy>=wN-1)continue;
        const p=yy*wN+xx;
        wTl[p]=(wTl[p]===1||wTl[p]===3||wTl[p]===13)?3:9; // Su/lav üstü taş geçitler tekrar çizilince kaybolmaz.
      }
    }
  }
  ZC.slice(1).forEach(([x,y])=>trail(wC,wC,x,y));
  trail(50,35,WORLD_OUTPOSTS.marsh.x,26);
  trail(50,35,WORLD_OUTPOSTS.frost.x,26);
  trail(50,35,WORLD_GATE.x,WORLD_GATE.y+2);
  trail(82,50,WORLD_OUTPOSTS.oasis.x,WORLD_OUTPOSTS.oasis.y+3);
  for(let x=1;x<wN-1;x++){
    const i=50*wN+x;wTl[i]=(wTl[i]===1||wTl[i]===3)?3:9;
  }
  for(let y=0;y<wN;y++)for(let x=0;x<wN;x++)if(Math.hypot(x-wC,y-wC)<6)wTl[y*wN+x]=3;
  // Balıkçı kulübesi ve açık deniz limanı farklı su ekosistemlerine açılır.
  trail(39,50,LAKE_DOCK.x,LAKE_DOCK.y+1);
  for(let x=33;x<=36;x++)wTl[56*wN+x]=12;
  trail(12,50,SEA_PORT.x,SEA_PORT.y+2);
  for(let x=3;x<=8;x++)wTl[63*wN+x]=12; // Son kalas denize komşu; ucundan olta atılır.
  // Kuzey kül geçidinden maden ağzına yan yol; girişte lav ve su bulunamaz.
  trail(50,68,WORLD_MINE.x,WORLD_MINE.y+2);
  for(let y=WORLD_MINE.y-2;y<=WORLD_MINE.y+2;y++)for(let x=WORLD_MINE.x-2;x<=WORLD_MINE.x+2;x++){
    const i=y*wN+x;if(wTl[i]===1||wTl[i]===13)wTl[i]=4;
  }
  [[-8,-7],[8,-7],[-8,7],[8,7]].forEach(([a,b],i)=>wHs.push({x:(wC+a)*TS+8,y:(wC+b)*TS+16,c:['#5c6fa6','#a65c5c','#5ca672','#a69a5c'][i]}));
  wHs.push({x:LAKE_DOCK.x*TS+8,y:LAKE_DOCK.y*TS+8,c:'#b77d47',type:'fisher',title:LAKE_DOCK.name});
  wHs.push({x:SEA_PORT.x*TS+8,y:SEA_PORT.y*TS+8,c:'#447a9c',type:'harbor',title:SEA_PORT.name});
  for(const [type,site] of Object.entries(WORLD_OUTPOSTS)){
    for(let y=site.y-2;y<=site.y+2;y++)for(let x=site.x-2;x<=site.x+2;x++){
      const i=y*wN+x;
      if(wTl[i]===1)wTl[i]=site.tile;
    }
    trail(site.x,site.y+1,site.x,site.y+3);
    wHs.push({x:site.x*TS+8,y:site.y*TS+8,c:type==='marsh'?'#648061':type==='frost'?'#95aeb6':'#bd8459',type,title:site.name});
  }

  for(let y=4;y<wN-4;y++)for(let x=4;x<wN-4;x++){
    const t=wTl[y*wN+x],r=H(x+99,y+7),d=Math.hypot(x-wC,y-wC);
    if(t===1||t===3||t===9||t===12||t===13||d<8||Object.values(WORLD_OUTPOSTS).some(s=>Math.hypot(x-s.x,y-s.y)<4)||Math.hypot(x-LAKE_DOCK.x,y-LAKE_DOCK.y)<3||Math.hypot(x-SEA_PORT.x,y-SEA_PORT.y)<4||Math.hypot(x-WORLD_MINE.x,y-WORLD_MINE.y)<4||Math.hypot(x-WORLD_GATE.x,y-WORLD_GATE.y)<4||Math.hypot(x-DRAGON_LAIR.x,y-DRAGON_LAIR.y)<7)continue;
    let k=null;
    if(t===6&&r<.22)k='tree';
    else if(t===6&&r<.25)k='pine';
    else if(t===7&&r<.24)k='snow_pine';
    else if(t===7&&r<.29)k='snow_peak';
    else if(t===8&&r<.16)k='shroom';
    else if(t===8&&r<.20)k='dead_tree';
    else if(t===8&&r<.28)k='reed';
    else if(t===10&&r<.06)k='ice_crystal';
    else if(t===0&&r<.06&&d>11)k='tree';
    else if(t===2&&nearLake(x,y)&&r<.15)k='lake_reed';
    else if(t===2&&nearOasis(x,y)&&r<.13)k='palm';
    else if(t===2&&r<.04)k='palm';
    else if(t===5&&nearOasis(x,y)&&r<.14)k='palm';
    else if(t===5&&r<.025)k='cactus';
    else if(t===5&&r<.053)k='rock';
    else if(t===5&&r<.088)k='dry_bush';
    else if(t===5&&r<.112)k='sandstone';
    else if(t===4&&r<.08&&Math.abs(x-wC)>5)k=r<.015?'torch':r<.052?'rock':'obsidian_spire';
    if(k)wObjs.push({k,x:x*TS+8+(H(x+2,y)-.5)*3,y:y*TS+8+(H(x,y+2)-.5)*3,r:k==='snow_peak'||k==='obsidian_spire'?6:k==='rock'||k==='sandstone'?5:k==='reed'||k==='dry_bush'?2:4,v:r});
  }

  // Kül geçidindeki ikinci maden ağzı kasabadaki aynı kata bağlanır.
  wObjs.push({k:'mine_entrance',x:WORLD_MINE.x*TS+8,y:WORLD_MINE.y*TS+8,r:9,v:.12});
  wObjs.push({k:'frontier_gate',x:WORLD_GATE.x*TS+8,y:WORLD_GATE.y*TS+8,r:8,v:.18});
  // Kadim çöl gözetleme kulesi; yakındaki gizli sandıkla ilişkilidir.
  wObjs.push({k:'desert_ruin',x:76*TS+8,y:64*TS+8,r:9,v:.1});
  // Geçit Tabelaları
  wObjs.push({k:'pillar',x:3*TS,y:48*TS,r:4,v:0});
  wObjs.push({k:'pillar',x:(wN-4)*TS,y:48*TS,r:4,v:0});

  // Aynı çarpışma kurallarıyla kasabadan erişilebilen kara hücrelerini bir kez hesapla.
  // Böylece ne sandık ne kaynak, vahanın veya lavın ardındaki kapalı bir cebe yerleşir.
  const walkable=new Uint8Array(wN*wN),reachable=new Uint8Array(wN*wN);
  for(let y=1;y<wN-1;y++)for(let x=1;x<wN-1;x++){
    const i=y*wN+x,t=wTl[i],px=x*TS+8,py=y*TS+8;
    if(t===1||t===13||Math.hypot(px-wC*TS,py-wC*TS)<14)continue;
    if(wObjs.some(o=>Math.abs(o.x-px)<14&&Math.abs(o.y-py)<14&&Math.hypot(o.x-px,o.y-py)<o.r+4))continue;
    if(wHs.some(h=>px>h.x-28&&px<h.x+28&&py>h.y-10&&py<h.y+4))continue;
    walkable[i]=1;
  }
  const start=54*wN+50,queue=walkable[start]?[start]:[];
  if(queue.length)reachable[start]=1;
  for(let q=0;q<queue.length;q++){
    const i=queue[q];
    for(const j of [i-1,i+1,i-wN,i+wN]){
      if(j<0||j>=wTl.length||!walkable[j]||reachable[j])continue;
      reachable[j]=1;queue.push(j);
    }
  }
  const CHEST_LOCS=[[38,18],[62,16],[18,36],[16,66],[82,34],[86,64],[40,84],[60,84],[26,22],[74,18]];
  function safeChest(x,y){
    if(x<5||y<5||x>94||y>94)return false;
    const t=wTl[y*wN+x];
    return reachable[y*wN+x]===1&&t!==3&&t!==9&&t!==12;
  }
  CHEST_LOCS.forEach(([cx,cy],idx)=>{
    let found=null;
    for(let r=0;r<=10&&!found;r++)for(let dy=-r;dy<=r&&!found;dy++)for(let dx=-r;dx<=r;dx++){
      if(Math.max(Math.abs(dx),Math.abs(dy))!==r)continue;
      const x=cx+dx,y=cy+dy;
      if(zoneOf(x,y)===zoneOf(cx,cy)&&safeChest(x,y)&&!wChests.some(c=>Math.hypot(c.x/TS-x,c.y/TS-y)<3)){found={x,y};break}
    }
    if(found)wChests.push({id:idx,x:found.x*TS+8,y:found.y*TS+8,opened:false,t:0,r:6});
  });

  // Tek bir geçerli kara hücresi havuzu: kaynaklar suya, lava veya yolun içine düşemez.
  const blocked=new Set(wObjs.map(o=>((o.y/TS)|0)*wN+((o.x/TS)|0)));
  const reserved=new Set(wChests.map(c=>((c.y/TS)|0)*wN+((c.x/TS)|0)));
  for(const[x,y]of[[56,12],[36,44],[82,56],[50,84]])reserved.add(y*wN+x);
  const cells=[];
  for(let y=5;y<wN-5;y++)for(let x=5;x<wN-5;x++){
    const t=wTl[y*wN+x];
    if(!reachable[y*wN+x]||t===3||t===9||t===12||blocked.has(y*wN+x)||Math.hypot(x-wC,y-wC)<9)continue;
    if(wHs.some(h=>Math.hypot(x-h.x/TS,y-h.y/TS)<4))continue;
    cells.push({x,y,t});
  }
  function placeCell(match){
    const possible=cells.filter(c=>!reserved.has(c.y*wN+c.x)&&match(c));
    if(!possible.length)return null;
    const c=pick(possible);reserved.add(c.y*wN+c.x);return c;
  }
  function habitat(c,place){
    if(place==='forest'||place==='marsh'||place==='frost')return worldBiome(c.x,c.y)===place;
    if(place==='lake')return nearLake(c.x,c.y);
    if(place==='oasis')return nearOasis(c.x,c.y)&&c.t===5;
    if(place==='desert')return zoneOf(c.x,c.y)===3&&c.t===5&&!nearOasis(c.x,c.y);
    if(place==='cave')return zoneOf(c.x,c.y)===4&&c.t===4&&Math.hypot(c.x-DRAGON_LAIR.x,c.y-DRAGON_LAIR.y)>14&&Math.hypot(c.x-50,c.y-67)>8;
    return false;
  }
  function addWCr(type,place){
    const c=placeCell(c=>c.t!==4&&habitat(c,place));
    if(!c)return;
    const x=c.x*TS+8,y=c.y*TS+8;
    wCritters.push({type,x,y,hx:x,hy:y,vx:0,vy:0,f:1,st:'idle',t:rnd(1,3),hopT:0,z:0,dead:false,rt:0,r:4,habitat:place});
  }
  for(let i=0;i<10;i++)addWCr('rabbit','forest');
  for(let i=0;i<8;i++)addWCr('bird','forest');
  for(let i=0;i<10;i++)addWCr('frog','marsh');
  for(let i=0;i<8;i++)addWCr('lizard','desert');
  for(let i=0;i<4;i++)addWCr('desert_fox','oasis');
  for(let i=0;i<6;i++)addWCr('snow_hare','frost');
  for(let i=0;i<5;i++)addWCr('heron','lake');
  for(let i=0;i<4;i++)addWCr('deer','forest');

  function addWRes(k,isOre,name,col,goldRange,gems,maxHp,reqT,count,where){
    for(let i=0;i<count;i++){
      const c=placeCell(c=>c.t===reqT&&(!where||where(c)));
      if(!c)break;
      wRes.push({k,isOre,name,col,gold:goldRange||[5,15],gems:gems||0,x:c.x*TS+8,y:c.y*TS+8,r:isOre?7:5,hp:maxHp||1,maxHp:maxHp||1,mined:false,respawnT:0});
    }
  }
  addWRes('herb_sun',false,'Güneş Çiçeği','#facc15',[6,12],0,1,0,14);
  addWRes('herb_mana',false,'Mavi Lotus','#38bdf8',[8,16],0,1,8,10);
  addWRes('berries',false,'Yaban Böğürtleni','#e11d48',[4,10],0,1,6,8);
  addWRes('fallen_log',false,'Orman Kuru Dalı','#b47d50',[0,0],0,1,6,14);
  addWRes('bog_herb',false,'Sazlık Şifası','#86efac',[6,12],0,1,8,12);
  addWRes('snowdrop',false,'Kardelen','#e0f2fe',[8,16],0,1,7,12);
  addWRes('cactus_fruit',false,'Kaktüs Meyvesi','#ec8f49',[8,14],0,1,5,8,c=>nearOasis(c.x,c.y));
  addWRes('ore_copper',true,'Bakır Damarı','#ea580c',[18,35],1,3,5,10);
  addWRes('ore_iron',true,'Demir Damarı','#94a3b8',[30,55],2,4,4,8);
  addWRes('ore_iron',true,'Karlı Demir Damarı','#94a3b8',[30,55],2,4,7,5);
  addWRes('ore_crystal',true,'Kristal Damarı','#c084fc',[50,90],3,4,4,6);
  addWRes('ore_crystal',true,'Kül Kristali','#f9a35a',[70,110],3,4,4,4,c=>{
    const d=Math.hypot(c.x-DRAGON_LAIR.x,c.y-DRAGON_LAIR.y);
    return zoneOf(c.x,c.y)===4&&d>9&&d<19;
  });

  // Orman, sazlık ve kar canlıları yalnızca kendi habitatlarında doğar.
  function spawnMob(k,place,fx,fy,calm){
    const d=MT[k];let x=fx,y=fy;
    if(x===undefined){
      const c=placeCell(c=>zoneOf(c.x,c.y)===d.z&&(!place||habitat(c,place))&&Math.hypot(c.x-50,c.y-24)>=12&&Math.hypot(c.x-56,c.y-12)>=12&&Math.hypot(c.x-40,c.y-54)>=7&&Math.hypot(c.x-73,c.y-48)>=8&&Math.hypot(c.x-84,c.y-38)>=12&&Math.hypot(c.x-82,c.y-56)>=10&&Math.hypot(c.x-64,c.y-50)>=8&&Math.hypot(c.x-50,c.y-67)>=8&&Math.hypot(c.x-50,c.y-84)>=14&&Math.hypot(c.x-27,c.y-81)>=8);
      if(!c)return;
      x=c.x*TS+8;y=c.y*TS+8;
    }else{
      const gx=x/TS|0,gy=y/TS|0,t=wTl[gy*wN+gx];
      if(t===1||t===3||t===9||t===12||t===13||blocked.has(gy*wN+gx)||!reachable[gy*wN+gx]){
        const near=cells.filter(c=>zoneOf(c.x,c.y)===d.z)
          .sort((a,b)=>Math.hypot(a.x-gx,a.y-gy)-Math.hypot(b.x-gx,b.y-gy))[0];
        if(near){x=near.x*TS+8;y=near.y*TS+8}
      }
    }
    const lv=calm?d.lv:d.lv+(d.boss?0:ri(0,2)),k2=1+.2*(lv-d.lv);
    const el=!calm&&!d.boss&&Math.random()<.09,em=el?3:1;
    wMobs.push({k,d,x,y,hx:x,hy:y,lv,mhp:Math.round(d.hp*k2*em),hp:Math.round(d.hp*k2*em),a:Math.round(d.a*k2*(el?1.4:1)),el,st:'idle',t:rnd(0,2),kx:0,ky:0,fl:0,dead:false,rt:0,f:1,ph:rnd(0,6),tx:x,ty:y,v:Math.random()<.5?0:1,hv:0,cast:0,act:false,r:d.r,chill:0});
  }
  [['slime',12,'forest'],['wolf',10,'forest'],['mire_wisp',10,'marsh'],['frost_wolf',10,'frost'],['lizard',8,'lake'],['scorpion',6,'desert'],['skeleton',4,'cave']].forEach(([k,num,place])=>{
    for(let i=0;i<num;i++)spawnMob(k,place);
  });
  [[46,23],[48,22],[52,22],[54,23],[47,25],[53,25]].forEach(([x,y])=>spawnMob('slime','forest',x*TS+8,y*TS+8,true));
  [[40,54],[39,56],[41,53],[38,57]].forEach(([x,y])=>spawnMob('lizard','lake',x*TS+8,y*TS+8,true));
  [[70,47],[72,47],[74,47],[76,48]].forEach(([x,y])=>spawnMob('scorpion','desert',x*TS+8,y*TS+8,true));
  [[43,63],[46,68],[45,73],[57,63],[54,68]].forEach(([x,y])=>spawnMob('skeleton','cave',x*TS+8,y*TS+8,true));
  wMobs.forEach(m=>{if(m.k==='skeleton'&&Math.hypot(m.x/TS-50,m.y/TS-67)<12){m.d={...m.d,ag:36};m.guard=true}});
  [[25,78],[30,81],[26,84]].forEach(([x,y])=>{spawnMob('skeleton','cave',x*TS+8,y*TS+8,true);const m=wMobs[wMobs.length-1];if(m&&m.k==='skeleton'){m.el=true;m.camp='mastery';m.guard=true;m.d={...m.d,ag:36};m.mhp=Math.round(m.mhp*1.35);m.hp=m.mhp}});
  spawnMob('treant',null,56*TS+8,12*TS+8,true);
  spawnMob('crab',null,36*TS,44*TS);
  spawnMob('golem',null,82*TS+8,56*TS+8,true);
  spawnMob('dragon',null,50*TS,84*TS);

  const wMmc=document.createElement('canvas');wMmc.width=wMmc.height=wN;
  {const m=wMmc.getContext('2d');for(let y=0;y<wN;y++)for(let x=0;x<wN;x++){
    const t=wTl[y*wN+x];m.fillStyle=marshWater(wTl,wN,x,y)?'#385e63':t===1&&lakeWater(x,y)?'#389bb5':t===1&&oasisWater(x,y)?'#4aaab5':MAP_COLORS[t];m.fillRect(x,y,1,1);
  }}
  return {N:wN,TS:16,C:wC,tl:wTl,objs:wObjs,hs:wHs,chests:wChests,critters:wCritters,resources:wRes,mobs:wMobs,npcs:wNpcs,mmc:wMmc,atlas:buildWorldAtlas(wTl,wObjs,wHs),seaMask:buildSeaMask(wTl,wN),farmPlots:[]};
}

// Deniz, harita sınırına bağlı su kütlesidir; iç göl ve vaha buna karışmaz.
function buildSeaMask(tiles,n){
  const mask=new Uint8Array(n*n),queue=[];
  const add=(x,y)=>{const i=y*n+x;if(tiles[i]!==1||mask[i])return;mask[i]=1;queue.push(i)};
  for(let k=0;k<n;k++){add(k,0);add(k,n-1);add(0,k);add(n-1,k)}
  for(let i=0;i<queue.length;i++){
    const p=queue[i],x=p%n,y=(p/n)|0;
    if(x>0)add(x-1,y);if(x<n-1)add(x+1,y);
    if(y>0)add(x,y-1);if(y<n-1)add(x,y+1);
  }
  return mask;
}

// Oyun zemininden üretilen piksel atlası: sabit bir görsel değil, oynanan dünya ile birebir aynı coğrafya.
function buildWorldAtlas(tiles,objects,houses){
  const a=document.createElement('canvas');a.width=a.height=400;
  const m=a.getContext('2d');m.imageSmoothingEnabled=false;
  const B=(x,y,w,h,col)=>{m.fillStyle=col;m.fillRect(x,y,w,h)};
  const at=(x,y)=>x>=0&&x<100&&y>=0&&y<100?tiles[y*100+x]:1;
  for(let y=0;y<100;y++)for(let x=0;x<100;x++){
    const t=at(x,y),px=x*4,py=y*4,h=H(x+17,y+31);
    const bogPool=marshWater(tiles,100,x,y),lakePool=t===1&&lakeWater(x,y),oasisPool=t===1&&oasisWater(x,y);
    B(px,py,4,4,bogPool?'#385e63':lakePool?'#389bb5':oasisPool?'#4aaab5':MAP_COLORS[t]);
    if(t===1){
      const foam=bogPool?'#96c1aa':lakePool?'#b4e8d2':oasisPool?'#d7ecc7':'#abdef0';
      if(at(x,y-1)!==1)B(px,py,4,1,foam);
      if(at(x-1,y)!==1)B(px,py,1,4,foam);
      if(h>.87)B(px+1,py+2,2,1,'#80cce4');
      if(lakePool&&h<.11){B(px+1,py+1,3,2,'#489c6d');B(px+3,py+2,1,1,'#e9b2d3')}
      if(oasisPool&&h<.24)B(px+1,py+2,2,1,'#dcf1bb');
    }else if(t===2){
      if(at(x,y+1)===1)B(px+1,py+3,3,1,'#fff0c2');
      if(h>.55)B(px+1,py+1,1,1,'#bda670');
    }else if(t===7){
      if(h>.6)B(px+1,py+1,2,1,'#fff');
      if(h<.22)B(px+2,py+3,1,1,'#9dbbc6');
    }else if(t===10){
      B(px,py,4,1,'#d3f3f6');
      if(h>.58)B(px+1,py+2,2,1,'#69aec7');
    }else if(t===8){
      if(h>.52)B(px,py+2,3,1,'#769b67');
      if(h<.3)B(px+2,py+1,1,2,'#354d44');
    }else if(t===5){
      if(h>.53)B(px,py+1,4,1,'#efca8d');
      if(h<.23)B(px+2,py+3,2,1,'#ac824f');
    }else if(t===13){
      B(px,py+3,4,1,'#732923');
      if(h>.4)B(px+1,py+1,2,1,'#ffd174');
    }else if(t===9||t===3){
      if(h>.6)B(px+1,py+2,2,1,t===3?'#e4d6ad':'#edd6a2');
      if(h<.22)B(px,py,1,1,'#947951');
    }else if(t===12){
      B(px,py,4,1,'#ddad73');B(px+1,py+2,1,1,'#5f483a');
    }else if(h>.72){
      B(px+1,py+2,2,1,t===5?'#f1d09a':'#88bc4c');
    }
  }
  for(const o of objects){
    const x=Math.round(o.x/TS*4),y=Math.round(o.y/TS*4);
    if(o.k==='tree'||o.k==='pine'||o.k==='snow_pine'){
      B(x-2,y+1,4,1,'#203521');B(x,y-1,1,2,'#644629');
      B(x-3,y-4,6,4,o.k==='snow_pine'?'#295c62':'#286d3b');
      B(x-2,y-5,4,2,o.k==='snow_pine'?'#bde4dc':'#5aaa49');
      if(o.k==='snow_pine')B(x-2,y-3,3,1,'#f5fdff');
    }else if(o.k==='shroom'){
      B(x-1,y-1,2,3,'#ddd4c2');B(x-3,y-3,6,3,'#7e3c8d');B(x-1,y-3,2,1,'#f2a6e9');
    }else if(o.k==='dead_tree'){
      B(x,y-4,1,5,'#45392e');B(x-2,y-4,5,1,'#45392e');
    }else if(o.k==='lake_reed'){
      B(x-2,y-3,1,4,'#567a4c');B(x+1,y-5,1,6,'#a0b768');
    }else if(o.k==='reed'){
      B(x,y-2,1,3,'#c6c480');B(x-2,y-1,1,2,'#a7a567');
    }else if(o.k==='ice_crystal'){
      B(x-1,y-3,3,4,'#f0fbff');B(x,y-5,1,4,'#79cee6');
    }else if(o.k==='snow_peak'){
      B(x-4,y,8,2,'#758e9b');B(x-3,y-3,6,4,'#a5bac0');
      B(x-1,y-5,3,4,'#f6ffff');
    }else if(o.k==='cactus'){
      B(x,y-3,2,5,'#327752');B(x-2,y-2,2,1,'#327752');
    }else if(o.k==='palm'){
      B(x,y-2,1,4,'#8b623a');B(x-4,y-5,9,2,'#348864');B(x-2,y-6,5,2,'#72b96b');
    }else if(o.k==='dry_bush'){
      B(x-2,y-1,4,2,'#9c8754');B(x,y-3,1,3,'#ae9a61');
    }else if(o.k==='sandstone'){
      B(x-3,y-2,6,4,'#ad845b');B(x-2,y-3,4,2,'#f2cc92');
    }else if(o.k==='obsidian_spire'){
      B(x-2,y-4,5,6,'#293036');B(x-1,y-6,2,3,'#7a4740');B(x,y-3,1,3,'#f38b3b');
    }else if(o.k==='desert_ruin'){
      B(x-5,y-5,10,7,'#9c7351');B(x-6,y-7,12,2,'#e4be82');
      B(x-2,y-3,4,5,'#684831');B(x-4,y-5,1,2,'#ffe2a5');
    }else if(o.k==='mine_entrance'){
      B(x-5,y-5,10,7,'#667487');B(x-3,y-3,6,5,'#13293b');
      B(x-1,y-4,2,2,'#73e1e1');
    }else if(o.k==='frontier_gate'){
      B(x-5,y-6,10,8,'#697f81');B(x-3,y-4,6,6,'#294254');B(x-1,y-4,2,5,'#9ce9e0');
    }else if(o.k==='rock'||o.k==='pillar'){
      B(x-2,y-1,4,3,'#53616a');B(x-1,y-2,2,1,'#b3b8ab');
    }
  }
  for(const h of houses){
    const x=Math.round(h.x/TS*4),y=Math.round(h.y/TS*4);
    B(x-8,y-6,16,11,'#334b44');B(x-7,y-5,14,9,'#e1d3b1');
    B(x-9,y-8,18,4,h.type==='frost'?'#617d8b':h.type==='marsh'?'#435849':h.c);
    B(x-7,y-9,14,2,h.type==='frost'?'#eefbff':'#bb9874');
    if(h.type==='fisher')B(x+6,y-9,3,2,'#79d4df');
    if(h.type==='oasis')B(x-6,y-10,12,1,'#ffdc9c');
    if(h.type==='harbor'){B(x+6,y-13,1,9,'#e6e4bd');B(x+7,y-13,4,3,'#6ac7df')}
    B(x-2,y,4,4,'#4b362e');B(x-6,y-1,2,2,'#f8e3a5');B(x+4,y-1,2,2,'#f8e3a5');
    if(h.type==='marsh')B(x+6,y-9,2,3,'#9fe3a3');
    if(h.type==='frost')B(x-7,y-10,14,1,'#fff');
  }
  // Atlantik mavisi yerine kuzeyi gösteren küçük, okunabilir bir pusula.
  B(370,16,1,15,'#f7e7b9');B(363,23,15,1,'#f7e7b9');
  B(369,15,3,3,'#e8bc69');B(369,29,3,3,'#e8bc69');
  return a;
}

/* --- KUZEY KEŞİF BÖLGESİ: Sisli Yayla (72×72), ana dünyayı bozmayan ilk genişleme. --- */
function initFrontierMap(){
  const n=FRONTIER.N,c=FRONTIER.C;
  const ft=new Uint8Array(n*n),fo=[],fh=[],fc=[],fr=[],fm=[],ch=[],fn=[];
  for(let y=0;y<n;y++)for(let x=0;x<n;x++){
    const edge=Math.hypot((x-c)/33,(y-34)/33)+(vn(x*.11+18,y*.11+61)-.5)*.17;
    let t=16;
    if(edge>1)t=1;
    else if(edge>.91)t=2;
    else if(x<29&&y<53)t=6;
    else if(x>42&&y<27)t=y<17?7:vn(x*.19+29,y*.18+44)>.52?17:16;
    if(edge<.91&&Math.pow((x-FRONTIER.lake.x)/5.5,2)+Math.pow((y-FRONTIER.lake.y)/4.2,2)<1)t=1;
    ft[y*n+x]=t;
  }
  const original=ft.slice();
  for(let y=1;y<n-1;y++)for(let x=1;x<n-1;x++){
    const i=y*n+x;
    if(original[i]!==1&&original[i]!==17&&[original[i-1],original[i+1],original[i-n],original[i+n]].includes(1))ft[i]=2;
  }
  const sites=[FRONTIER.gate,FRONTIER.camp,FRONTIER.ruin];
  for(const site of sites)for(let dy=-3;dy<=3;dy++)for(let dx=-3;dx<=3;dx++){
    const x=site.x+dx,y=site.y+dy;
    if(x>1&&y>1&&x<n-2&&y<n-2&&Math.hypot(dx,dy)<2.8&&(ft[y*n+x]===1||ft[y*n+x]===17))ft[y*n+x]=16;
  }
  function path(ax,ay,bx,by){
    const steps=Math.max(Math.abs(bx-ax),Math.abs(by-ay))*3;
    for(let i=0;i<=steps;i++){
      const s=i/steps,x=Math.round(ax+(bx-ax)*s),y=Math.round(ay+(by-ay)*s);
      for(const[dx,dy]of[[0,0],[1,0],[-1,0],[0,1],[0,-1]]){
        const xx=x+dx,yy=y+dy;
        if(xx<2||yy<2||xx>=n-2||yy>=n-2)continue;
        const pos=yy*n+xx;
        ft[pos]=[1,3,17].includes(ft[pos])?3:9;
      }
    }
  }
  path(FRONTIER.gate.x,FRONTIER.gate.y-2,36,50);
  path(36,50,FRONTIER.camp.x,FRONTIER.camp.y+2);
  path(FRONTIER.camp.x,FRONTIER.camp.y,FRONTIER.ruin.x+2,FRONTIER.ruin.y+2);
  path(FRONTIER.camp.x,FRONTIER.camp.y,FRONTIER.lake.x-6,FRONTIER.lake.y+2);
  path(FRONTIER.camp.x,FRONTIER.camp.y,46,20);
  for(let y=3;y<n-3;y++)for(let x=3;x<n-3;x++){
    const t=ft[y*n+x],r=H(x+720,y+380);
    if([1,3,9,17].includes(t)||sites.some(s=>Math.hypot(x-s.x,y-s.y)<4)||Math.hypot(x-FRONTIER.lake.x,y-FRONTIER.lake.y)<6)continue;
    const k=t===6&&r<.19?'tree':t===6&&r<.25?'pine':t===7&&r<.19?'snow_pine':t===16&&r<.052?'rock':null;
    if(k)fo.push({k,x:x*TS+8,y:y*TS+8,r:k==='rock'?5:4,v:r});
  }
  fo.push({k:'frontier_gate',x:FRONTIER.gate.x*TS+8,y:FRONTIER.gate.y*TS+8,r:8,v:.2});
  fo.push({k:'frontier_ruin',x:FRONTIER.ruin.x*TS+8,y:FRONTIER.ruin.y*TS+8,r:8,v:.15});
  // Harabe yolundaki küçük karakol sabit kalır; eski kaynak konumlarının yerine kurulmaz.
  fo.push({k:'frontier_station',x:FRONTIER_STATION.x*TS+8,y:FRONTIER_STATION.y*TS+8,r:6,v:.32});
  const lx=(FRONTIER_STATION.x+.5)*TS,ly=(FRONTIER_STATION.y+1.5)*TS;
  fn.push({n:'Gözcü Lale',tag:'🧭 Yayla Gözcüsü',lv:9,x:lx,y:ly,bx:lx,by:ly,tx:lx,ty:ly,
    t:4,f:0,w:0,sw:0,c:'#387665',h:'#244b50',cape:'#d8b96b',d:{r:4},hp:1,stationary:true});
  if(P.hasFieldCamp)fh.push({x:FRONTIER.camp.x*TS+8,y:FRONTIER.camp.y*TS+8,c:'#a5674b',type:'field_camp',level:P.fieldCampLevel||1,title:`Yayla Kampı Sv.${P.fieldCampLevel||1} 🏕️`});
  else fo.push({k:'camp_marker',x:FRONTIER.camp.x*TS+8,y:FRONTIER.camp.y*TS+8,r:4,v:.1});

  const reach=new Uint8Array(n*n),walk=new Uint8Array(n*n),used=new Set();
  for(let y=1;y<n-1;y++)for(let x=1;x<n-1;x++){
    const pos=y*n+x,t=ft[pos],px=x*TS+8,py=y*TS+8;
    if(t===1||t===17||fo.some(o=>Math.abs(o.x-px)<14&&Math.abs(o.y-py)<14&&Math.hypot(o.x-px,o.y-py)<o.r+4))continue;
    if(fh.some(h=>px>h.x-28&&px<h.x+28&&py>h.y-10&&py<h.y+4))continue;
    walk[pos]=1;
  }
  const start=(FRONTIER.gate.y-2)*n+FRONTIER.gate.x,q=walk[start]?[start]:[];
  if(q.length)reach[start]=1;
  for(let i=0;i<q.length;i++)for(const j of [q[i]-1,q[i]+1,q[i]-n,q[i]+n]){
    if(j>=0&&j<walk.length&&walk[j]&&!reach[j]){reach[j]=1;q.push(j)}
  }
  const spots=[];
  for(let y=4;y<n-4;y++)for(let x=4;x<n-4;x++){
    const t=ft[y*n+x];
    if(!reach[y*n+x]||[1,3,9,17].includes(t)||sites.some(s=>Math.hypot(x-s.x,y-s.y)<4))continue;
    spots.push({x,y,t});
  }
  const choose=filter=>{
    const free=spots.filter(s=>!used.has(s.y*n+s.x)&&filter(s));
    if(!free.length)return null;
    const s=pick(free);used.add(s.y*n+s.x);return s;
  };
  // Sabit kimlikli iki keşif sandığı; yol, su veya inşa parseline yerleşmez.
  for(const [id,filter]of [
    [100,s=>s.t===6&&Math.hypot(s.x-FRONTIER.ruin.x,s.y-FRONTIER.ruin.y)<9],
    [101,s=>s.t===16&&Math.hypot(s.x-FRONTIER.lake.x,s.y-FRONTIER.lake.y)<12]
  ]){
    const s=choose(filter);
    if(s)ch.push({id,x:s.x*TS+8,y:s.y*TS+8,opened:false,t:0,r:6});
  }
  const res=(k,count,filter,ore=false,hp=1,col='#9bdb91')=>{
    for(let i=0;i<count;i++){
      const s=choose(filter);if(!s)break;
      fr.push({k,x:s.x*TS+8,y:s.y*TS+8,r:ore?7:5,isOre:ore,hp,maxHp:hp,col,gold:ore?8:[4,9],gems:0,mined:false,respawnT:0});
    }
  };
  res('fallen_log',7,s=>s.t===6,false,1,'#b47d50');
  res('ore_stone',10,s=>s.t===16,true,3,'#94a3b8');
  res('ore_iron',4,s=>s.t===16,true,4,'#cbd5e1');
  res('highland_herb',11,s=>s.t===16,false,1,'#8de6ad');
  function critter(type,count,filter){
    for(let i=0;i<count;i++){
      const s=choose(filter);if(!s)break;
      const x=s.x*TS+8,y=s.y*TS+8;
      fc.push({type,x,y,hx:x,hy:y,vx:0,vy:0,f:1,st:'idle',t:rnd(1,3),hopT:0,z:0,dead:false,rt:0,r:4});
    }
  }
  critter('mountain_goat',8,s=>s.t===16);
  critter('deer',4,s=>s.t===6);
  critter('bird',6,s=>s.t===16||s.t===6);
  function enemy(k,count,filter){
    const d=MT[k];
    for(let i=0;i<count;i++){
      const s=choose(filter);if(!s)break;
      const x=s.x*TS+8,y=s.y*TS+8,lv=d.lv+ri(0,1),hp=Math.round(d.hp*(1+.2*(lv-d.lv)));
      fm.push({k,d,x,y,hx:x,hy:y,lv,mhp:hp,hp,a:d.a,el:false,st:'idle',t:rnd(1,3),kx:0,ky:0,fl:0,dead:false,rt:0,f:1,ph:rnd(0,6),tx:x,ty:y,v:0,hv:0,cast:0,act:false,r:d.r,chill:0});
    }
  }
  enemy('boar',9,s=>s.t===16&&Math.hypot(s.x-FRONTIER.gate.x,s.y-FRONTIER.gate.y)>8);
  enemy('wolf',5,s=>s.t===6&&Math.hypot(s.x-FRONTIER.gate.x,s.y-FRONTIER.gate.y)>8);
  const mm=document.createElement('canvas');mm.width=mm.height=n;
  const m=mm.getContext('2d');
  for(let y=0;y<n;y++)for(let x=0;x<n;x++){m.fillStyle=MAP_COLORS[ft[y*n+x]];m.fillRect(x,y,1,1)}
  if(P.hasFieldCamp)drawFieldCampMinimap(mm,P.fieldCampLevel||1);
  drawFrontierStationMinimap(mm,P.frontierMission||0);
  return {N:n,TS,C:c,tl:ft,objs:fo,hs:fh,chests:ch,critters:fc,resources:fr,mobs:fm,npcs:fn,mmc:mm,atlas:buildFrontierAtlas(ft,fo,fh),farmPlots:[]};
}

function drawFieldCampMinimap(canvas,level){
  const m=canvas.getContext('2d');
  m.fillStyle=level>=3?'#d4b663':level>=2?'#789aa1':'#a5674b';
  m.fillRect(FRONTIER.camp.x-2,FRONTIER.camp.y-2,5,4);
  if(level>=3){m.fillStyle='#f9e2a0';m.fillRect(FRONTIER.camp.x,FRONTIER.camp.y-4,1,3)}
}
function drawFrontierStationMinimap(canvas,stage){
  const m=canvas.getContext('2d');
  m.fillStyle=stage>=3?'#f5d782':stage>=1?'#a8d5b4':'#8b775e';
  m.fillRect(FRONTIER_STATION.x-2,FRONTIER_STATION.y-2,4,4);
  if(stage>=2){m.fillStyle='#f1d28a';m.fillRect(FRONTIER_STATION.x,FRONTIER_STATION.y-4,1,3)}
}
function buildFrontierAtlas(tiles,objects,houses){
  const canvas=document.createElement('canvas');canvas.width=canvas.height=360;
  const a=canvas.getContext('2d'),B=(x,y,w,h,c)=>{a.fillStyle=c;a.fillRect(Math.round(x),Math.round(y),w,h)};
  for(let y=0;y<72;y++)for(let x=0;x<72;x++){
    const t=tiles[y*72+x],px=x*5,py=y*5,h=H(x+103,y+11);
    B(px,py,5,5,MAP_COLORS[t]);
    if(t===1){if(x>0&&tiles[y*72+x-1]!==1)B(px,py,1,5,'#a6dae0');if(h>.77)B(px+1,py+3,2,1,'#8cd4eb')}
    else if(t===16&&h>.55)B(px+2,py+1,2,1,h>.8?'#d9b4df':'#bfd47d');
    else if(t===17){B(px,py+4,5,1,'#344957');if(h>.5)B(px+2,py,2,2,'#bed0d0')}
    else if(t===9&&h>.6)B(px+1,py+2,3,1,'#e4c891');
    else if(t===7&&h>.6)B(px+1,py+1,2,1,'#fff');
  }
  for(const o of objects){
    const x=Math.round(o.x/TS*5),y=Math.round(o.y/TS*5);
    if(o.k==='tree'||o.k==='pine'||o.k==='snow_pine'){
      B(x,y-1,1,4,'#533f32');B(x-3,y-5,7,5,o.k==='snow_pine'?'#305d65':'#326e42');
      B(x-1,y-6,3,2,o.k==='snow_pine'?'#e9f8fa':'#8fc778');
    }else if(o.k==='frontier_gate'){
      B(x-5,y-6,10,8,'#5b7380');B(x-3,y-4,6,6,'#28364b');B(x-1,y-4,2,4,'#71e6e9');
    }else if(o.k==='frontier_ruin'){
      B(x-6,y-5,12,7,'#798486');B(x-4,y-7,8,3,'#c0ba9d');B(x-2,y-2,4,4,'#313842');
    }else if(o.k==='frontier_station'){
      const stage=P.frontierMission||0;
      B(x-5,y-4,10,6,'#887456');B(x-6,y-7,12,3,stage>=1?'#45846e':'#655b57');
      B(x-1,y-2,2,4,'#32433d');
      if(stage>=2){B(x+4,y-12,2,6,'#8ca794');B(x+5,y-13,5,2,'#ead49a')}
      if(stage>=3)B(x-3,y-8,6,2,'#f6d67a');
    }else if(o.k==='camp_marker'){
      B(x-5,y-4,10,7,'#a78656');B(x-3,y-6,6,3,'#e6cd94');B(x-1,y,2,2,'#fff1b0');
    }
  }
  for(const h of houses){
    const x=Math.round(h.x/TS*5),y=Math.round(h.y/TS*5);
    B(x-9,y-5,18,8,'#987157');B(x-10,y-8,20,4,'#416660');B(x-5,y-10,10,3,'#bcdcb6');B(x-2,y,4,3,'#382c24');
    if(h.level>=2){B(x+10,y-4,6,5,'#a87c49');B(x+11,y-5,4,1,'#efc887')}
    if(h.level>=3){B(x-5,y-17,10,8,'#647e72');B(x-3,y-20,6,3,'#bddab0');B(x,y-26,1,7,'#e9f0ce');B(x+1,y-25,5,3,'#f9d67f')}
  }
  B(332,15,1,14,'#e8e2c3');B(326,21,13,1,'#e8e2c3');
  return canvas;
}

/* --- Açık dünya durumu: yalnız değişen kaynak kimliği/konumu ve sandık ödülü kaydedilir. --- */
function frontierClimate(){
  const season=FARM.seasonIdx(),rain=isWetWeather();
  const night=cl(.4-Math.sin(tod*6.283)*.9,0,.6)>.22;
  return {season,rain,night,storm:rain||weather.type==='fog'||weather.type==='blood_moon'};
}
function frontierClimateLabel(){
  const c=frontierClimate();
  if(c.season===3)return c.rain?'❄️ Kış yağmuru: adaçayı erken döner; keçiler sığınır':'❄️ Kış: adaçayı geç büyür; keçiler sığınır';
  if(c.rain)return '🌧️ Yağmur: adaçayı güçlenir, keçi ve kuşlar sığınır';
  if(weather.type==='fog')return '🌫️ Sis: kuşlar sığınır, domuzların görüşü azalır';
  if(c.night)return '🌙 Gece: keçi ve kuşlar güvenli yere döner';
  return c.season===2?'🍂 Sonbahar: adaçayı daha yavaş büyür':'🌿 Açık hava: keçiler ve kuşlar gezer';
}
function wildRegrowDays(r){
  if(r.k==='highland_herb'){
    const c=frontierClimate(),base=c.season===3?4:c.season===2?3:2;
    return Math.max(1,base-(c.rain?1:0));
  }
  if(r.k==='fallen_log')return 3;
  if(r.isOre)return r.k==='ore_crystal'?4:3;
  if(['bog_herb','snowdrop','cactus_fruit','herb_mana','berries'].includes(r.k))return 2;
  return 1;
}
function markResourceMined(r,seconds){
  r.mined=true;
  if(curMap==='world'||curMap==='frontier'){
    r.readyDay=(P.day||1)+wildRegrowDays(r);r.respawnT=0;
  }else if(curMap==='home'&&r.isOre){r.readyDay=(P.day||1)+1;r.respawnT=0}
  else r.respawnT=seconds;
}
function refreshWildResources(md){
  if(!md)return;
  for(const r of md.resources)if(r.mined&&r.readyDay>0&&r.readyDay<=(P.day||1)){
    r.mined=false;r.hp=r.maxHp;r.readyDay=0;r.respawnT=0;
  }
}
function snapshotWildMap(md,id){
  if(!md)return null;
  return {v:1,n:md.N,
    resources:md.resources.map((r,i)=>({id:`${id}:${i}:${r.k}`,k:r.k,name:r.name||'',x:r.x,y:r.y,
      hp:r.hp,mined:!!r.mined,readyDay:Math.max(0,Math.floor(Number(r.readyDay)||0))})),
    chests:md.chests.filter(c=>!c.isWarChest).map(c=>({id:c.id,x:c.x,y:c.y,opened:!!c.opened}))};
}
function restoreWildMap(md,id,saved){
  if(!md||saved?.v!==1||saved.n!==md.N)return;
  const blocked=new Set([1,3,9,12,13,14,17]);
  const valid=(x,y)=>{
    if(!Number.isInteger(x)||!Number.isInteger(y)||x%TS!==8||y%TS!==8)return false;
    const tx=x/TS|0,ty=y/TS|0;
    if(tx<2||ty<2||tx>=md.N-2||ty>=md.N-2||blocked.has(md.tl[ty*md.N+tx]))return false;
    if(md.objs.some(o=>Math.abs(o.x-x)<14&&Math.abs(o.y-y)<14&&Math.hypot(o.x-x,o.y-y)<o.r+4))return false;
    return !md.hs.some(h=>x>h.x-28&&x<h.x+28&&y>h.y-10&&y<h.y+4);
  };
  const resources=new Map((Array.isArray(saved.resources)?saved.resources:[]).filter(s=>s&&typeof s==='object').map(s=>[s.id,s]));
  const occupied=new Set();
  md.resources.forEach((r,i)=>{
    const s=resources.get(`${id}:${i}:${r.k}`),key=s&&`${s.x}:${s.y}`;
    if(!s||s.k!==r.k||(s.name||'')!==(r.name||'')||!valid(s.x,s.y)||occupied.has(key))return;
    occupied.add(key);r.x=s.x;r.y=s.y;
    r.hp=Number.isFinite(s.hp)?cl(s.hp,0,r.maxHp):r.maxHp;
    r.mined=!!s.mined;
    r.readyDay=r.mined?Math.max(P.day||1,Math.floor(Number(s.readyDay)||P.day||1)):0;
    if(r.mined&&r.readyDay<=(P.day||1)){r.mined=false;r.hp=r.maxHp;r.readyDay=0}
    r.respawnT=0;
  });
  const chests=new Map((Array.isArray(saved.chests)?saved.chests:[]).filter(s=>s&&typeof s==='object').map(s=>[s.id,s]));
  for(const c of md.chests){
    const s=chests.get(c.id);
    if(!s||!valid(s.x,s.y))continue;
    c.x=s.x;c.y=s.y;c.opened=!!s.opened;c.t=c.opened?Infinity:0;
  }
}
function loadWildMaps(saved){
  wildStateCache={world:saved?.world||null,frontier:saved?.frontier||null};
  restoreWildMap(WORLD_DATA.world,'world',wildStateCache.world);
  restoreWildMap(WORLD_DATA.frontier,'frontier',wildStateCache.frontier);
}

/* --- 2. ORTAÇAĞ KASABASI VE ÇİFTLİK ŞEHRİ (60x60) --- */

