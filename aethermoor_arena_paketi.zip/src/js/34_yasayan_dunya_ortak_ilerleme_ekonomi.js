/* ===== YAŞAYAN DÜNYA · ORTAK İLERLEME / EKONOMİ ===== */
const ADVENTURE=window.ADVENTURE={
  init(){
    P.day=Math.max(1,Math.floor(Number(P.day)||1));
    const a=P.adventure&&typeof P.adventure==='object'&&!Array.isArray(P.adventure)?P.adventure:{};
    P.adventure=a;a.version=1;a.seed=Number.isSafeInteger(a.seed)?a.seed>>>0:(Math.floor(Math.random()*4294967295)>>>0);
    a.combatLessonSeen=a.combatLessonSeen===true;
    if(a.combatTraining&&typeof a.combatTraining==='object')a.combatTraining={hits:cl(Math.floor(Number(a.combatTraining.hits)||0),0,3),dodge:a.combatTraining.dodge===true,skill:a.combatTraining.skill===true,done:a.combatTraining.done===true};
    else a.combatTraining=null;
    a.buildings=Array.isArray(a.buildings)?a.buildings.filter(b=>b&&BUILD.defs[b.kind]&&Number.isInteger(b.gx)&&Number.isInteger(b.gy)):[];
    for(const b of a.buildings){
      const d=BUILD.defs[b.kind],material=BUILD_CONFIG.materials[b.material]?b.material:d.defaultMaterial||'wood',mat=BUILD_CONFIG.materials[material]||BUILD_CONFIG.materials.wood;
      b.items=ITEMS.normalize(b.items);b.id=String(b.id||'b'+a.buildings.indexOf(b));b.material=material;
      b.level=cl(Math.floor(Number(b.level)||0),0,3);b.rotation=cl(Math.floor(Number(b.rotation)||0),0,3);
      b.hp=cl(Math.floor(Number(b.hp??mat.durability)||0),0,mat.durability);if(b.kind==='door')b.open=b.open===true;else delete b.open;
    }
    BUILD.sanitizeRestored();
    a.nextBuildId=Math.max(Number(a.nextBuildId)||1,a.buildings.length+1);
    a.roster=Array.isArray(a.roster)?a.roster.filter(r=>r&&['mountain_goat','deer','desert_fox'].includes(r.type)):[];
    a.taming=a.taming&&typeof a.taming==='object'?a.taming:{};a.captured=a.captured&&typeof a.captured==='object'?a.captured:{};
    a.mounted=false;a.energy=Number.isFinite(Number(a.energy))?cl(Number(a.energy),0,100):100;
    for(const key in a.taming){const t=a.taming[key];if(t&&typeof t==='object'){t.trust=cl(Math.floor(Number(t.trust)||0),0,3);t.lastDay=Math.max(0,Math.floor(Number(t.lastDay)||0))}else delete a.taming[key]}
    a.stats=a.stats&&typeof a.stats==='object'?a.stats:{};a.questChapters=a.questChapters&&typeof a.questChapters==='object'?a.questChapters:{};a.lootPity=cl(Math.floor(Number(a.lootPity)||0),0,7);a.chapterNotice=a.chapterNotice&&typeof a.chapterNotice==='object'?a.chapterNotice:null;a.chapterRewardPending=a.chapterRewardPending&&typeof a.chapterRewardPending==='object'?a.chapterRewardPending:null;
    a.npcLife=a.npcLife&&typeof a.npcLife==='object'&&!Array.isArray(a.npcLife)?a.npcLife:{};
    a.bestiary=a.bestiary&&typeof a.bestiary==='object'?a.bestiary:{};
    a.market=a.market&&typeof a.market==='object'?a.market:{day:P.day||1,supply:{},bought:{}};
    a.market.supply=a.market.supply||{};a.market.bought=a.market.bought||{};
    a.caves=a.caves&&typeof a.caves==='object'?a.caves:{day:P.day||1,floors:{}};a.caves.floors=a.caves.floors||{};
    a.home=a.home&&typeof a.home==='object'?a.home:{cleared:[],fruitDays:{},ores:{}};
    a.home.cleared=Array.isArray(a.home.cleared)?a.home.cleared:[];a.home.fruitDays=a.home.fruitDays||{};a.home.ores=a.home.ores||{};
    a.title=typeof a.title==='string'?a.title:'traveler';a.trackedFriend=TOWNSFOLK[a.trackedFriend]?a.trackedFriend:null;a.pinnedGoal=['story','home','social','mine','frontier','elite','bestiary'].includes(a.pinnedGoal)?a.pinnedGoal:null;GAME_BALANCE.init();CONTROLS.init();DAY_RECAP.init();
    for(const [k,flag]of [['treant','treant_killed'],['crab','crab_killed'],['golem','golem_killed']])if(P.ach[flag]&&!a.bestiary[k])a.bestiary[k]={seen:true,kills:1};
    QUEST_FLOW.migrate(a);DAILY_FOCUS.init();
    ECONOMY.newDay();this.restoreHome();BOND.syncMap(WORLD_DATA.world,'world');if(WORLD_DATA.frontier)BOND.syncMap(WORLD_DATA.frontier,'frontier');
  },
  restoreHome(){
    const md=WORLD_DATA.home,a=P.adventure;if(!md||!a)return;
    for(let i=md.objs.length-1;i>=0;i--)if(md.objs[i].homeId&&a.home.cleared.includes(md.objs[i].homeId))md.objs.splice(i,1);
    FARM.syncBeds();
    for(const t of md.fruitTrees||[]){
      const dayKey=(t.treeType||t.k)+':'+t.x+':'+t.y,legacyKey=t.k+':'+t.x+':'+t.y;
      t.fruitReady=a.home.fruitDays[dayKey]!==P.day&&a.home.fruitDays[legacyKey]!==P.day;
    }
    md.resources.forEach((r,i)=>{const old=a.home.ores[i];if(old&&old.readyDay>P.day){r.mined=true;r.readyDay=old.readyDay}});
  },
  capture(){
    if(!P.adventure)return;
    CAVE.capture();BOND.storePet();const md=WORLD_DATA.home;if(!md)return;
    for(const t of md.fruitTrees||[]){const key=(t.treeType||t.k)+':'+t.x+':'+t.y;if(!t.fruitReady&&P.adventure.home.fruitDays[key]===undefined)P.adventure.home.fruitDays[key]=P.day}
    md.resources.forEach((r,i)=>{if(r.mined)P.adventure.home.ores[i]={readyDay:r.readyDay||P.day+1}});
  },
  step(dt){
    if(P.hasCask&&P.caskItem&&!P.caskReady){P.caskTimer=Math.max(0,(Number(P.caskTimer)||0)-dt);if(P.caskTimer<=0){P.caskReady=true;if(curMap==='home')fl(19*TS,35*TS-22,'★ Zanaat Ürünü Hazır!','#ffd23f',true);sv()}}
    if(BUILD.active){const key=(P.x/TS|0)+':'+(P.y/TS|0);if(BUILD.playerKey!==key){BUILD.playerKey=key;BUILD.refresh()}}
  },
  newDay(){
    ECONOMY.newDay();DAILY_FOCUS.newDay();DAY_RECAP.startDay();WORLD_EVENTS.newDay();P.adventure.energy=100;
    for(const r of WORLD_DATA.home?.resources||[])if(r.mined&&(r.readyDay||0)<=P.day){r.mined=false;r.hp=r.maxHp}
  },
  notice(text){const el=$('journey-status');if(el)el.textContent=text;fl(P.x,P.y-28,text,'#f1d99f',true)},
  open(tab='farm'){
    const feature={build:'build',workshop:'build',bond:'social',goals:'market',expeditions:'expeditions',market:'market',titles:'titles'}[tab];if(feature)FEATURES.markSeen(feature);
    closeQuickMenu();BUILD.cancel();this.tab=FEATURES.allowedTab(tab)?tab:'farm';$('journey-modal').classList.remove('h');this.ui();
  },
  ui(){
    let tab=this.tab||'farm';if(!FEATURES.allowedTab(tab)){tab='farm';this.tab='farm'};document.querySelectorAll('[data-journey-tab]').forEach(b=>b.classList.toggle('act',b.dataset.journeyTab===tab));
    let h='';
    if(tab==='farm'){
      const plan=FARM.carePlan(),plots=WORLD_DATA.home.farmPlots,animals=HERD.list();
      const growing=plots.filter(p=>p.crop&&!p.dead&&!FARM.ripe(p)).length;
      h=`<div class="journey-lead"><small>KOLAY ÇİFTLİK DÖNGÜSÜ</small><h2>${SEASONS[FARM.seasonIdx()].icon} ${SEASONS[FARM.seasonIdx()].n} · ${FARM.dayOf()}. Gün</h2><p>${DAY_CLOCK.detail()}</p><p>Tohum seç → günlük bakımı yap → evde uyu → hasat et. Hepsi bu.</p></div>
      ${ONBOARD.active()?ONBOARD.html()+FEATURES.html():ONBOARD.html()+STORY.html()+QUEST_FLOW.html()+FEATURES.html()+`<div class="journey-box"><b>🎯 Bugün ve Uzun Vadeli Hedefler</b><p>Günlük odak, hikâye ilerlemesi ve büyük gelişim hedefleri artık ayrı bir ekranda.</p><button data-journey-tab="goals">Hedefler Merkezini Aç</button></div>`}
      <div class="journey-stats"><div><b>${plan.ripe}</b><span>Hasada hazır</span></div><div><b>${growing}</b><span>Büyüyor</span></div><div><b>${animals.filter(a=>a.ready).length}</b><span>Hazır hayvan ürünü</span></div></div>
      <div class="journey-box"><b>🌿 Bugünün bahçe durumu</b><p>${plan.tasks?`${plan.tasks} bahçe işi hazır.`:'Bahçe bakımlı; ürünlerin büyümesi için evde uyu.'}<br>Toplam tohum: ${FARM.seedCount()} · Yem: ${P.hay||0}</p><button data-journey-action="simple-garden">Kolay Bahçeyi Aç</button></div>
      <div class="journey-box"><b>🍞 Ürünleri kullan</b><p>Hasadı yemek pişirmek, görevleri tamamlamak veya altın kazanmak için satmakta kullanabilirsin.</p></div>`;
    }else if(tab==='story')h=STORY.journalHTML();
    else if(tab==='goals')h=GOALS.html();
    else if(tab==='expeditions')h=EXPEDITIONS.html();
    else if(tab==='build')h=BUILD.html();
    else if(tab==='bond')h=BOND.html();
    else if(tab==='market')h=ECONOMY.html(true);
    else if(tab==='workshop')h=BUILD.workshopHTML();
    else h=JOURNAL.html();
    $('journey-content').innerHTML=h;$('journey-status').textContent='';
  }
};
const DAILY_FOCUS=window.DAILY_FOCUS={
  defs:{
    farm:{icon:'🌿',name:'Çiftlik Günü',desc:'Bahçede bir Günlük Bakım tamamla.',need:1,gold:35,gems:1},
    explore:{icon:'🧭',name:'Keşif Günü',desc:'Dünyada 5 kaynak veya maden noktası topla.',need:5,gold:45,gems:1},
    combat:{icon:'⚔️',name:'Av Günü',desc:'Görev dışı veya görevli 5 düşman yen.',need:5,gold:55,gems:1}
  },
  init(){
    let f=P.adventure.dailyFocus;
    if(!f||typeof f!=='object'||f.day!==P.day||!Object.hasOwn(this.defs,f.type)){f={day:P.day,type:null,progress:0,done:false}}
    f.day=P.day;f.type=Object.hasOwn(this.defs,f.type)?f.type:null;f.progress=cl(Math.floor(Number(f.progress)||0),0,f.type?this.defs[f.type].need:0);f.done=f.done===true;
    P.adventure.dailyFocus=f;return f;
  },
  state(){return this.init()},
  activity(){
    let a=P.adventure.dailyActivity;if(!a||typeof a!=='object'||a.day!==P.day)a={day:P.day,farm:0,explore:0,combat:0};
    a.day=P.day;for(const k of ['farm','explore','combat'])a[k]=cl(Math.floor(Number(a[k])||0),0,999);P.adventure.dailyActivity=a;return a;
  },
  newDay(){P.adventure.dailyFocus={day:P.day,type:null,progress:0,done:false};P.adventure.dailyActivity={day:P.day,farm:0,explore:0,combat:0};if(!ONBOARD.active()&&window.STORY&&STORY.closed&&STORY.closed()&&!STORY.mastery()){const s=STORY.state();if(!s.beats.dawn){s.beats.dawn=true;setTimeout(()=>chat('MUHTAR HAMDİ','','Sabah oldu. Tarlaya bir bak, Melis’e günaydın de. Sonra bir iş seç. Üçünü birden kovalama.',1),900)}}else if(!ONBOARD.active()&&FEATURES.is('market'))setTimeout(()=>chat('REHBER','','Yeni gün. İstersen Yolcu Defteri’nden tek bir odak seç: bahçe, keşif ya da av.',1),900)},
  finish(f,d){
    if(f.done)return;f.done=true;P.gold+=d.gold;P.gems+=d.gems;P.townWorkDay=P.day;const total=P.adventure.stats.dailyFocusDone=(P.adventure.stats.dailyFocusDone||0)+1;
    let bonus='';if(total%5===0){P.gold+=100;P.gems+=3;P.adventure.stats.dailyFocusMilestones=(P.adventure.stats.dailyFocusMilestones||0)+1;bonus=' · Ustalık Sandığı +100🪙 +3💎'}
    NOTIFICATIONS.push('focus',d.icon,`${d.name} tamamlandı`,`Ödül: +${d.gold} altın · +${d.gems} elmas${bonus}.`);ban(`${d.icon} GÜNLÜK ODAK TAMAMLANDI! +${d.gold}🪙 +${d.gems}💎${bonus}`,'#86efac');playChord([523,659,784,1046],.3,'triangle',.05);chat('REHBER','',`${d.name} tamamlandı. Bugünün odak ödülü hesabına eklendi.${bonus}`,1);
  },
  select(type){
    const f=this.state(),d=this.defs[type];if(!d||f.type||f.done)return false;
    Object.assign(f,{type,progress:Math.min(d.need,this.activity()[type]||0),done:false});if(f.progress>=d.need)this.finish(f,d);
    sv();ADVENTURE.ui();ADVENTURE.notice(`${d.icon} Bugünün odağı: ${d.name}${f.progress?' · önceki ilerlemen sayıldı':''}`);return true;
  },
  event(type,amount=1){
    SESSION_COACH.event(type,amount);const d=this.defs[type];if(!d||!Number.isFinite(amount)||amount<=0)return false;
    const a=this.activity();a[type]=Math.min(999,a[type]+Math.floor(amount));
    const f=this.state();if(f.type===type&&!f.done){f.progress=Math.min(d.need,a[type]);if(f.progress>=d.need)this.finish(f,d)}
    sv();
    if(!$('journey-modal').classList.contains('h')&&ADVENTURE.tab==='farm')ADVENTURE.ui();
    return true;
  },
  milestoneHTML(){const total=P.adventure.stats.dailyFocusDone||0,n=total%5;return `<div class="focus-milestone"><span><b>🎁 Odak Ustalığı ${n}/5</b><br>Her 5 tamamlamada +100🪙 ve +3💎</span><span class="focus-dots">${'●'.repeat(n)}${'○'.repeat(5-n)}</span></div>`},
  html(){
    const f=this.state(),milestone=this.milestoneHTML();
    if(!f.type)return `<div class="daily-focus"><div class="daily-focus-head"><b>🎯 Bugünün Odağını Seç</b><small>Günde bir seçim · değiştirilmez</small></div><p style="font-size:10px;color:#b8cbd0">Bugün nasıl oynamak istediğini seç. Bu hedefler zorunlu değildir; yalnızca kısa ve anlamlı bir yön verir.</p><div class="daily-focus-options">${Object.entries(this.defs).map(([k,d])=>`<button type="button" data-daily-focus="${k}"><strong>${d.icon} ${d.name}</strong><span>${d.desc}</span><small>+${d.gold}🪙 +${d.gems}💎</small></button>`).join('')}</div>${milestone}</div>`;
    const d=this.defs[f.type],pct=Math.round(f.progress/d.need*100);
    return `<div class="daily-focus ${f.done?'daily-focus-done':''}"><div class="daily-focus-head"><b>${d.icon} ${d.name}</b><small>${f.done?'TAMAMLANDI':`${f.progress}/${d.need}`}</small></div><p>${f.done?`✓ Ödül alındı: ${d.gold}🪙 ve ${d.gems}💎`:d.desc}</p><div class="daily-focus-progress"><i style="width:${pct}%"></i></div><small style="color:#9fb6c0">${f.done?'Bugün serbestçe başka etkinliklere geçebilirsin.':'Bu odak yalnız bugünün oyun gününde geçerlidir.'}</small>${milestone}</div>`;
  }
};
const FEATURES=window.FEATURES={
  defs:{
    build:{icon:'🔨',name:'İnşa Sistemi',desc:'Depo sandığı ve yapılar',where:'Yolcu Defteri → Yapılar',next:'İlk iş depo sandığı: inşa arazisinde Depo Sandığını Kur.',ready:()=>!ONBOARD.active()||ONBOARD.current()?.id==='chest'},
    character:{icon:'🧙',name:'Karakter Gelişimi',desc:'Sınıf, ustalık ve başarımlar',where:'Sol ☰ menüsü',next:'İlk balıktan sonra açılır. Acele etme.',ready:()=>!ONBOARD.active()&&(P.q>=2||P.lvl>=3)},
    market:{icon:'📈',name:'Hedefler ve Gelişmiş Pazar',desc:'Günlük odak, uzun vadeli hedefler, fiyatlar ve yatırımlar',where:'Yolcu Defteri → Hedefler / Pazar',next:'İlk bölüm bitince kasaba defteri açılır.',ready:()=>!ONBOARD.active()&&P.q>=3},
    social:{icon:'🐾',name:'Dostlar ve Yoldaşlar',desc:'Kasabalılar ve hayvan dostları',where:'Sol ☰ menüsü',next:'Orman Muhafızı düşünce dostluklar açılır.',ready:()=>!ONBOARD.active()&&P.q>=3},
    fishing:{icon:'🎣',name:'Balıkçılık',desc:'Olta, göl ve deniz balıkları',where:'Sağ ☰ → Araçlar',next:'Balıkçı İskelesi’nde suya dönük dur ve F’ye bas.',ready:()=>!ONBOARD.active()&&(P.q>=1||(P.ach.fish_caught||0)>0)},
    expeditions:{icon:'🧭',name:'Kısa Keşif Seferleri',desc:'Üç küçük hedefli, süresiz 8–12 dakikalık rotalar',where:'Yolcu Defteri → Seferler',next:'Göl avı başlayınca kısa seferler açılır.',ready:()=>!ONBOARD.active()&&P.q>=4},
    titles:{icon:'♜',name:'Unvanlar',desc:'Kahramanlık unvanları ve koleksiyon',where:'Yolcu Defteri → Unvan',next:'İlk bölümden sonra unvan seçebilirsin.',ready:()=>!ONBOARD.active()&&P.lvl>=3&&P.q>=3},
    bestiary:{icon:'📚',name:'Canavar Kartları',desc:'Görülen düşman bilgileri',where:'Sol ☰ menüsü',next:'İlk avdan sonra kartlar açılır.',ready:()=>!ONBOARD.active()&&P.kills>=1&&P.q>=2}
  },
  init(){
    const fresh=!P.adventure.featureUnlocks||typeof P.adventure.featureUnlocks!=='object';
    const u=fresh?{}:P.adventure.featureUnlocks;P.adventure.featureUnlocks=u;
    if(fresh)for(const [id,d]of Object.entries(this.defs))if(d.ready())u[id]=true;
    P.adventure.featureFresh=P.adventure.featureFresh&&typeof P.adventure.featureFresh==='object'?P.adventure.featureFresh:{};
    P.adventure.featureQueue=Array.isArray(P.adventure.featureQueue)?P.adventure.featureQueue.filter(id=>this.defs[id]):[];
    if(!this.bound){this.bound=true;document.addEventListener('click',e=>{const b=e.target.closest?.('button');if(!b)return;const ids={bcl:'character',bms:'character',bac:'character',bpt:'social',bfr:'social',blb:'bestiary'};let id=ids[b.id];if(!id&&b.dataset.journeyTab)id={build:'build',bond:'social',goals:'market',expeditions:'expeditions',market:'market',titles:'titles'}[b.dataset.journeyTab];if(!id&&b.closest?.('.hb-slot[data-tool="rod"]'))id='fishing';if(id)this.markSeen(id)},true)}
    this.apply();return u;
  },
  is(id){return !!P.adventure?.featureUnlocks?.[id]||!!this.defs[id]?.ready()},
  markSeen(id){const fresh=P.adventure?.featureFresh;if(!fresh?.[id])return;delete fresh[id];this.apply();sv()},
  use(id){if(this.is(id)){this.markSeen(id);return true}const d=this.defs[id];fl(P.x,P.y-28,`🔒 ${d?.name||'Bu sistem'} henüz açılmadı`,'#facc15',true);return false},
  allowedTab(tab){return tab==='farm'||tab==='story'||tab==='build'&&this.is('build')||tab==='workshop'&&this.is('build')||tab==='bond'&&this.is('social')||tab==='goals'&&this.is('market')||tab==='expeditions'&&this.is('expeditions')||tab==='market'&&this.is('market')||tab==='titles'&&this.is('titles')},
  update(){
    if(!P.adventure)return;const u=P.adventure.featureUnlocks||(P.adventure.featureUnlocks={}),opened=[];
    for(const [id,d]of Object.entries(this.defs))if(!u[id]&&d.ready()){u[id]=true;P.adventure.featureFresh[id]=true;if(!P.adventure.featureQueue.includes(id))P.adventure.featureQueue.push(id);opened.push(d)}
    if(opened.length){const names=opened.map(d=>d.name).join(' · ');ban(opened.length>2?`🔓 ${opened.length} YENİ SİSTEM AÇILDI`:'🔓 YENİ SİSTEM: '+names,'#86efac');chat('REHBER','',opened.length===1?`${opened[0].name} açıldı. ${opened[0].next||opened[0].where}.`:`Sırası gelenler: ${names}. Hepsini aynı anda yapmak zorunda değilsin.`,1);playChord([523,659,784],.22,'triangle',.04);sv()}
    this.apply();this.maybeShow();
  },
  maybeShow(){
    const q=P.adventure?.featureQueue;if(!q?.length)return;const ids=q.splice(0,q.length).filter(id=>this.defs[id]);if(!ids.length)return;const names=ids.map(id=>this.defs[id].name).join(' · ');NOTIFICATIONS.push('feature','🔓',ids.length>1?`${ids.length} yeni sistem açıldı`:`${names} açıldı`,`Açılan sistemler: ${names}. Menüdeki YENİ işaretlerinden inceleyebilirsin.`);sv();
    MODAL_QUEUE.enqueue(`features:${ids.join('-')}:${P.day}`,2,'feature-unlock-modal',()=>{$('feature-unlock-content').innerHTML=ids.map(id=>{const d=this.defs[id];return `<div class="feature-unlock-card"><span>${d.icon}</span><div><b>${d.name}</b><small>${d.desc}<br><strong>Bulunduğu yer:</strong> ${d.where}${d.next?`<br><strong>İlk iş:</strong> ${d.next}`:''}</small></div></div>`}).join('');$('feature-unlock-modal').classList.remove('h');GAME_CORE.resetInput()});
  },
  apply(){
    const show=(ids,on)=>ids.forEach(id=>$(id)?.classList.toggle('h',!on));
    show(['bcl','bms','bac'],this.is('character'));show(['bpt','bfr'],this.is('social'));
    const onboarding=ONBOARD.active();show(['blb'],this.is('bestiary')&&!onboarding);if(onboarding)show(['bsh','bfg','bpr','bhs','bcf','bmk','bbd','bst','bcs','bml','bbt','bchp','btav','bth','btalent','bride','btv','bgm','blb'],false);
    const rod=document.querySelector('.hb-slot[data-tool="rod"]');if(rod)rod.classList.toggle('h',!this.is('fishing'));
    if(!this.is('fishing')&&P.activeTool==='rod')P.activeTool='sword';
    const tabs={build:'build',bond:'social',goals:'market',expeditions:'expeditions',market:'market',titles:'titles'};for(const [tab,feature]of Object.entries(tabs))document.querySelector(`[data-journey-tab="${tab}"]`)?.classList.toggle('h',!this.is(feature));
    const fresh=P.adventure?.featureFresh||{},mark=(ids,feature)=>ids.forEach(id=>$(id)?.classList.toggle('feature-new',!!fresh[feature]&&this.is(feature)));
    mark(['bcl','bms','bac'],'character');mark(['bpt','bfr'],'social');mark(['blb'],'bestiary');if(rod)rod.classList.toggle('feature-new',!!fresh.fishing&&this.is('fishing'));
    for(const [tab,feature]of Object.entries(tabs))document.querySelector(`[data-journey-tab="${tab}"]`)?.classList.toggle('feature-new',!!fresh[feature]&&this.is(feature));
  },
  html(){
    const total=Object.keys(this.defs).length,opened=Object.keys(this.defs).filter(id=>this.is(id)).length,pct=Math.round(opened/total*100),progress=`<div class="feature-unlock-progress"><i style="width:${pct}%"></i></div><small>${opened}/${total} sistem açık</small>`;
    let next=null,condition='';
    if(ONBOARD.active()){next=this.defs.build;condition=ONBOARD.current()?.id==='chest'?'İnşa sistemi şimdi açıldı; ilk sandığını kur.':'Rehberli başlangıç adımlarını tamamla.'}
    else if(!this.is('social')){next=this.defs.social;condition='Zümrüt Orman’daki ilk 6 Slime görevini tamamla.'}
    else if(!this.is('fishing')){next=this.defs.fishing;condition='İlk 6 Slime görevini tamamlayıp göl rotasını aç.'}
    else if(!this.is('expeditions')){next=this.defs.expeditions;condition='İlk orman görevini tamamla ve kısa sefer rotalarını aç.'}
    else if(!this.is('titles')){next=this.defs.titles;condition='Kahraman seviyeni 3’e yükselt.'}
    else return `<div class="feature-roadmap"><span class="feature-icon">✓</span><span style="flex:1"><b>Temel sistemlerin açık</b>Yeni içerikler dünya keşfi ve görevlerle doğal olarak açılmaya devam eder.${progress}</span><span class="feature-state">HAZIR</span></div>`;
    return `<div class="feature-roadmap"><span class="feature-icon">${next.icon}</span><span style="flex:1"><b>Sıradaki Sistem: ${next.name}</b>${next.desc}<br><small>${condition}</small>${progress}</span><span class="feature-state" style="color:#facc15">SIRADA</span></div>`;
  }
};
function closeFeatureUnlock(){$('feature-unlock-modal').classList.add('h');GAME_CORE.resetInput();MODAL_QUEUE.done()}
$('feature-unlock-close').onclick=closeFeatureUnlock;$('feature-unlock-ok').onclick=closeFeatureUnlock;
const ECONOMY=window.ECONOMY={
  stock:{wood:30,stone:30,copper_ore:10,iron_ore:8,coal:15},
  key(it){return ITEMS.key(it.k||(it.s==='fish'?'fish':''))},
  eligible(it){return !!it&&!SL[it.s]&&['mat','crop','fish','food','food_ing'].includes(it.s)&&it.k!=='skull_key'},
  factor(it){
    if(!this.eligible(it)||!P.adventure)return 1;
    const k=this.key(it),season=FARM.seasonIdx(),crop=CROPS[k];let factor=1;
    if(crop&&!crop.se.includes(season))factor+=.25;
    if(weather.type==='storm'){if(['crop','food','food_ing'].includes(it.s)||k==='wood')factor+=.12;if(it.s==='fish')factor-=.08}
    else if(weather.type==='rain'&&it.s==='fish')factor-=.05;
    const supply=Number(P.adventure.market.supply[k])||0;
    return cl((factor-supply*.004)*WORLD_EVENTS.saleMultiplier(it),.65,1.9);
  },
  trend(it){const f=this.factor(it),pct=Math.round(Math.abs(f-1)*100);return f>=1.12?{label:`▲ Yüksek +%${pct}`,cls:'high',factor:f}:f<=.88?{label:`▼ Düşük -%${pct}`,cls:'low',factor:f}:{label:'● Normal',cls:'normal',factor:f}},
  quote(it,fallback=10){const base=it.val??(ITEMS.stackable(it)?MATERIALS[ITEMS.key(it.k)].val:fallback);return Math.max(1,Math.round(base*this.factor(it)))},
  record(it,amount,buy=false){
    if(!this.eligible(it)||!P.adventure)return;const k=this.key(it);if(!k)return;
    const s=P.adventure.market.supply;s[k]=cl((Number(s[k])||0)+(buy?-amount*.6:amount),-100,100);if(!buy)WORLD_EVENTS.progress('sell',amount);
  },
  recordMany(items){for(const it of items)this.record(it,ITEMS.qty(it))},
  newDay(){
    const m=P.adventure.market,gap=Math.max(0,P.day-(Number(m.day)||P.day));
    if(gap){for(const k in m.supply)m.supply[k]=(Number(m.supply[k])||0)*Math.pow(.8,Math.min(gap,28));m.bought={}}
    m.day=P.day;
  },
  sellWhere(predicate,bonus=1){
    const sold=P.inv.filter(it=>!it.locked&&predicate(it));if(!sold.length)return 0;
    const gold=sold.reduce((sum,it)=>sum+Math.round(this.quote(it)*bonus)*ITEMS.qty(it),0);
    P.inv=P.inv.filter(it=>!predicate(it));P.gold+=gold;this.recordMany(sold);P.adventure.stats.tradeGold=(P.adventure.stats.tradeGold||0)+gold;return gold;
  },
  nextGoal(){
    const has=k=>P.adventure.buildings.some(b=>b.kind===k),home=FARM.cfg();
    if(!has('chest'))return {icon:'📦',name:'İlk Depo Sandığı',why:'Çanta sıkışıklığını azaltır ve keşif ganimetini korur.',where:'Defter → Yapılar',action:'build',gold:30,needs:{wood:10,stone:4}};
    if(home.sprinklerLv<1)return {icon:'🚰',name:'Bakır Fıskiye',why:'Her sabah tarlayı otomatik sular; günlük işi azaltır.',where:'Demirci',action:'forge',gold:150,needs:{}};
    if(!P.hasCoop)return {icon:'🐔',name:'Tavuk Kümesi',why:'Her gün yumurta üreterek düzenli yemek ve gelir sağlar.',where:'Çiftlikte kümes alanı',action:'herd',gold:120,needs:{wood:10,stone:6}};
    if(home.beds<2)return {icon:'🌱',name:'İkinci Bahçe Yatağı',why:'Ekim kapasitesini 12 parsel artırır.',where:'Kolay Bahçe',action:'garden',gold:150,needs:{wood:6,stone:4}};
    if(!has('workshop'))return {icon:'🔨',name:'Çiftlik Atölyesi',why:'Yem, gübre ve yol azığı üretimini açar.',where:'Defter → Yapılar',action:'build',gold:140,needs:{wood:18,stone:12,iron_ore:4}};
    if(houseLevel<2)return {icon:'🏡',name:'Taş Çiftlik Evi',why:'Kileri büyütür ve çiftliğin kalıcı gelişimini ilerletir.',where:'Evdeki tadilat masası',action:'house',gold:300,gems:5,needs:{wood:8,stone:8}};
    return null;
  },
  openGoal(action){
    $('market-modal').classList.add('h');$('journey-modal').classList.add('h');
    if(action==='build')ADVENTURE.open('build');
    else if(action==='garden')FARM.openUI('simple');
    else if(action==='herd'){$('herd-modal').classList.remove('h');HERD.ui()}
    else if(action==='house'){$('house-modal').classList.remove('h');houseUI()}
    else if(action==='forge'){$('forge').classList.remove('h');forgeUI()}
  },
  goalHTML(){
    const g=this.nextGoal();if(!g)return '<div class="journey-box"><b>✓ Temel yatırımlar tamam</b><p>Artık uzmanlaşmak istediğin sistemi seçebilirsin: hayvancılık, maden, inşa veya ekipman.</p></div>';
    const names={wood:'Odun',stone:'Taş',iron_ore:'Demir'},icons={wood:'🪵',stone:'🪨',iron_ore:'⛓️'};
    const parts=[`🪙 ${P.gold}/${g.gold||0}`],ratios=[Math.min(1,P.gold/Math.max(1,g.gold||1))];if(g.gems){parts.push(`💎 ${P.gems}/${g.gems}`);ratios.push(Math.min(1,P.gems/g.gems))}for(const [k,n]of Object.entries(g.needs||{})){parts.push(`${icons[k]||'📦'} ${countInv(k)}/${n} ${names[k]||k}`);ratios.push(Math.min(1,countInv(k)/n))}
    const ready=P.gold>=(g.gold||0)&&P.gems>=(g.gems||0)&&Object.entries(g.needs||{}).every(([k,n])=>countInv(k)>=n),pct=Math.round(ratios.reduce((a,b)=>a+b,0)/ratios.length*100);
    return `<div class="journey-box" style="border-color:${ready?'#86efac':'#8d97714d'}"><b>${g.icon} Sonraki Mantıklı Yatırım: ${g.name}</b><p>${g.why}<br><strong>Yer:</strong> ${g.where}<br>${parts.join(' · ')}</p><div class="daily-focus-progress"><i style="width:${pct}%"></i></div><div style="display:flex;align-items:center;justify-content:space-between;gap:8px"><span style="color:${ready?'#86efac':'#facc15'};font-size:10px">${ready?'✓ Malzemeler hazır.':`Hazırlık %${pct}`}</span><button type="button" data-goal-open="${g.action}">${ready?'Yatırıma Git':'Nerede Yapılır?'}</button></div></div>`;
  },
  buy(k,n=1){
    if(!Object.hasOwn(this.stock,k)||!Number.isInteger(n)||n<1||n>5)return false;
    const m=P.adventure.market,left=this.stock[k]-(m.bought[k]||0),item=ITEMS.make(k,n),price=Math.ceil(this.quote(item)*1.95)*n;
    if(n>left){inventoryWarning('Bugünkü tüccar stoğu yetersiz. Yeni günde yenilenir.');return false}
    if(!tryInventoryRecipe({},[item],{gold:price}))return false;
    m.bought[k]=(m.bought[k]||0)+n;this.record(item,n,true);sv();return true;
  },
  html(journal=false){
    const m=P.adventure.market;
    return `<div class="journey-lead"><small>ARZ · TALEP · MEVSİM</small><h2>🪙 Kasaba Pazarı</h2><p>Çok satılan ürün ucuzlar; mevsim dışı ürün değerlenir. Arz her yeni günde normale yaklaşır. Alış ve satış farklıdır.</p></div>
    ${this.goalHTML()}
    <div class="price-table"><div class="price-row heading"><span>Malzeme</span><span>Satış</span><span>Alış</span><span>Stok</span></div>${Object.entries(this.stock).map(([k,max])=>{
      const it=ITEMS.make(k),sell=this.quote(it),buy=Math.ceil(sell*1.95),left=max-(m.bought[k]||0),trend=this.trend(it);
      return `<div class="price-row"><span>${it.icon} ${it.n}<br><i class="trend ${trend.cls}">${trend.label}</i></span><b>${sell}🪙</b><span>${buy}🪙</span><span>${left}/${max}</span></div>${journal?'':`<div class="trade-buttons"><button data-mat-buy="${k}" data-n="1" ${left<1?'disabled':''}>1 Al</button><button data-mat-buy="${k}" data-n="5" ${left<5?'disabled':''}>5 Al</button></div>`}`;
    }).join('')}</div><p class="inventory-help">Fiyatlar tüm satış kanallarında adet/kaliteye göre hesaplanır. Gece sevkiyatında teslim anındaki pazar değeri geçerlidir.${journal?' Alışveriş için Osman’ın tezgâhına veya dünya tüccarına yaklaş.':''}</p>`;
  },
  click(e){const b=e.target.closest('[data-mat-buy]');if(!b)return false;this.buy(b.dataset.matBuy,Number(b.dataset.n));marketUI();shopUI();return true}
};
const GOALS=window.GOALS={
  ids:['story','home','social','mine','frontier','elite','bestiary'],
  card(id,icon,title,pct,desc,action,label='Aç'){const pinned=P.adventure.pinnedGoal===id;return `<div class="goal-card ${pinned?'pinned':''}"><div class="goal-card-head"><h4>${icon} ${title}</h4><strong>${pinned?'📌 ':''}%${pct}</strong></div><p>${desc}</p><div class="goal-progress"><i style="width:${pct}%"></i></div><div class="goal-card-actions"><button type="button" class="pin" data-goal-pin="${id}" title="${pinned?'Takibi bırak':'Üst hedefe sabitle'}">${pinned?'✕':'📌'}</button><button type="button" data-goals-action="${action}">${label}</button></div></div>`},
  metrics(){
    initFriendship();const q=QS[P.q],storyTotal=QUEST_FLOW.finale+1,storyDone=Math.min(P.q,storyTotal),storyPct=Math.round(storyDone/storyTotal*100),home=FARM.cfg(),has=k=>P.adventure.buildings.some(b=>b.kind===k),homeMarks=[houseLevel>=2,home.beds>=2,has('chest'),home.sprinklerLv>=1,P.hasCoop,has('workshop')],homeDone=homeMarks.filter(Boolean).length,homePct=Math.round(homeDone/homeMarks.length*100),heartSum=Object.keys(TOWNSFOLK).reduce((sum,id)=>sum+(P.friendship[id]?.hearts||1),0),socialPct=cl(Math.round((heartSum-4)/16*100),0,100),minePct=cl(Math.round((P.maxMineFloor||1)/50*100),0,100),frontierPct=Math.round(((P.frontierDiscovered?1:0)+(P.frontierMission||0)/3)/2*100),distinct=Object.values(P.adventure.bestiary||{}).filter(v=>v.kills>0).length,bestiaryPct=cl(Math.round(distinct/10*100),0,100);
    return {q,storyTotal,storyDone,storyPct,homeMarks,homeDone,homePct,heartSum,socialPct,minePct,frontierPct,distinct,bestiaryPct,plan:FARM.carePlan()};
  },
  pin(id){P.adventure.pinnedGoal=P.adventure.pinnedGoal===id?null:this.ids.includes(id)?id:null;sv();return P.adventure.pinnedGoal},
  pinnedCue(){const id=P.adventure?.pinnedGoal;if(!this.ids.includes(id))return null;const m=this.metrics(),map={story:['🐉',m.storyPct,'Ana Hikâye'],home:['🏡',m.homePct,'Çiftlik'],social:['❤️',m.socialPct,'Dostluk'],mine:['⛏️',m.minePct,'Maden'],frontier:['🌫️',m.frontierPct,'Yayla'],elite:['★',QS[P.q]?.k==='elite'?Math.round(cl((P.qn||0)/3,0,1)*100):0,'Seçkin Av'],bestiary:['📚',m.bestiaryPct,'Canavarlar']},v=map[id];return v?{id,icon:v[0],pct:v[1],name:v[2]}:null},
  recommendation(){
    const f=DAILY_FOCUS.state(),m=this.metrics();if(!f.type)return {icon:'🎯',title:'Önce bugünün oyun tarzını seç',desc:'Çiftlik, keşif veya savaş odağından biri kısa oturumuna yön verir.',action:null,label:''};
    if(!f.done){if(f.type==='farm')return{icon:'🌿',title:'Bahçedeki günlük bakımı tamamla',desc:`${m.plan.tasks} hazır bahçe işi bulunuyor.`,action:'farm',label:'Bahçeyi Aç'};if(f.type==='explore')return{icon:'🧭',title:'Tek bir bölge seç ve kaynak topla',desc:'Haritadaki güvenli veya orta zorluktaki bir bölgeden 5 kaynak getir.',action:FEATURES.is('expeditions')?'expeditions':'explore',label:FEATURES.is('expeditions')?'Seferleri Aç':'Haritayı Aç'};const prep=m.q?QUEST_FLOW.preparation(m.q):null;return prep&&prep.ready<prep.total?{icon:'🧰',title:'Avdan önce hazırlık eksiklerini tamamla',desc:`Görev hazırlığın ${prep.ready}/${prep.total}.`,action:'prep',label:'Hazırlık Planı'}:m.q?{icon:'⚔️',title:'Av odağını mevcut görevle birleştir',desc:'Beş düşman yenerek hem odak hem görev ilerlemesi kazan.',action:'quest',label:'Görevi Aç'}:{icon:'⚔️',title:'İstediğin bölgede kısa bir av yap',desc:'Haritadan seviyene uygun bir bölge seç ve beş düşman yen.',action:'explore',label:'Haritayı Aç'}}
    if(m.q){const prep=QUEST_FLOW.preparation(m.q);return prep.ready<prep.total?{icon:'🧰',title:'Hikâye görevi için hazırlan',desc:`${m.q.t} öncesi hazırlığın ${prep.ready}/${prep.total}.`,action:'prep',label:'Hazırlık Planı'}:{icon:m.q.icon,title:'Hikâyede bir adım ilerle',desc:`Sıradaki görev: ${m.q.t}`,action:'quest',label:'Görevi Gör'}}
    const goal=ECONOMY.nextGoal();return goal?{icon:goal.icon,title:goal.name+' için kaynak tamamla',desc:goal.why,action:'investment',label:'Yatırımı Gör'}:{icon:'✓',title:'Bugün ne istersen onu yap',desc:'Ana hedeflerin tamamlandı. Dünya artık serbest oyun alanın.',action:null,label:''};
  },
  recommendHTML(){const r=this.recommendation();return `<div class="goal-recommend"><small>ŞİMDİ NE YAPMALIYIM?</small><h3>${r.icon} ${r.title}</h3><p>${r.desc}</p>${r.action?`<button type="button" data-goals-action="${r.action}">${r.label}</button>`:''}</div>`},
  sessionHTML(){
    const f=DAILY_FOCUS.state();let title='Bugünkü oyun tarzını seç',desc='Kısa bir odak seçmek, bütün sistemleri aynı anda yapmak zorunda olmadığını hatırlatır.',steps=[['1','Bir odak seç'],['2','Tek hedefi tamamla'],['3','İstediğinde bırak']];
    if(f.type){const d=DAILY_FOCUS.defs[f.type];title=f.done?'Bugünün odağı tamam':'Bugünün rotası: '+d.name;desc=f.done?'Ödülünü aldın. Şimdi hiçbir baskı olmadan istediğin etkinliğe geçebilirsin.':d.desc;
      if(f.type==='farm')steps=[['1','Günlük bakımı yap'],['2','Ürünü işle veya sat'],['3','Gece evde uyu']];
      else if(f.type==='explore')steps=[['1','Haritadan bölge seç'],['2','5 kaynak topla'],['3','Depoya güvenle dön']];
      else steps=[['1','Yemek ve iksir hazırla'],['2','5 düşman yen'],['3','İyileşip ganimeti sakla']];
    }
    return `<div class="session-plan"><h3>${f.type?DAILY_FOCUS.defs[f.type].icon:'🎯'} ${title}</h3><p style="font-size:9.5px;color:#c3d1d3">${desc}</p><div class="session-steps">${steps.map(([n,t])=>`<div><b>${n}. adım</b>${t}</div>`).join('')}</div></div>`;
  },
  html(){
    const m=this.metrics(),{q,storyTotal,storyDone,storyPct,homeMarks,homeDone,homePct,heartSum,socialPct,minePct,frontierPct,distinct,bestiaryPct,plan}=m,focus=DAILY_FOCUS.html(),current=q?`${q.icon} ${q.t} · ${Math.min(P.qn,q.n)}/${q.n}`:'Ana rota tamamlandı',pinned=this.pinnedCue();
    return `<div class="journey-lead"><small>BUGÜN · YAKIN HEDEF · UZUN VADE</small><h2>🎯 Hedefler Merkezi</h2><p>Buradaki hedefler görev listesi değil, seçim aracıdır. Birini seçmen yeter; diğerleri seni bekler.</p></div><div class="goal-philosophy"><b>Rahat oynanış:</b> Günlük odak isteğe bağlıdır, uzun vadeli hedeflerin süresi yoktur ve hiçbir seriyi kaçırdığın için ceza almazsın.</div>${WORLD_EVENTS.html(true)}${pinned?`<div class="pinned-summary"><span><b>📌 Takipte: ${pinned.icon} ${pinned.name}</b><br>Üst görev göstergesinde ilerlemesi görünür.</span><strong>%${pinned.pct}</strong></div>`:''}${this.recommendHTML()}<div class="goals-section-title">Bugün <small>KISA OTURUM</small></div>${focus}${this.sessionHTML()}<div class="journey-box"><b>📜 Şu Anki Hikâye Hedefi</b><p>${current}</p><button type="button" data-goals-action="quest">Görev Ayrıntısını Aç</button></div><div class="journey-box"><b>🌿 Bugünkü Çiftlik</b><p>${plan.tasks?`${plan.tasks} bakım işi hazır.`:'Bahçe bakımlı.'} · ${plan.ripe} hasat · ${plan.fruit} meyve</p><button type="button" data-goals-action="farm">Bahçeyi Aç</button></div><div class="goals-section-title">Uzun Vadeli Hedefler <small>SÜRE SINIRI YOK</small></div><div class="goals-grid">${this.card('story','🐉','Ana Hikâye',storyPct,`${storyDone}/${storyTotal} ana görev tamamlandı.`,'quest','Görevi Gör')}${this.card('home','🏡','Çiftlik ve Yuva',homePct,`${homeDone}/${homeMarks.length} temel çiftlik yatırımı tamamlandı.`,'farm','Çiftliğe Bak')}${this.card('social','❤️','Kasabalı Dostlukları',socialPct,`${heartSum}/20 toplam kalp. Kişisel hikâyeler kalplerle açılır.`,'friends','Dostları Gör')}${this.card('mine','⛏️','Kristal Madeni',minePct,`Ulaşılan en derin kat: ${P.maxMineFloor||1}/50.`,'mine','Maden Yolunu Gör')}${this.card('frontier','🌫️','Sisli Yayla',frontierPct,`${P.frontierMission||0}/3 gözcü görevi tamamlandı.`,'frontier','Yayla Yolunu Gör')}${this.card('bestiary','📚','Canavar Koleksiyonu',bestiaryPct,`${distinct}/10 farklı düşman türü yenildi.`,'bestiary','Kartları Gör')}</div><div class="goals-section-title">Sıradaki Yatırım <small>KAYNAK HEDEFİ</small></div>${ECONOMY.goalHTML()}`;
  },
  open(action){
    $('journey-modal').classList.add('h');
    if(action==='goals')ADVENTURE.open('goals');
    else if(action==='quest')openGuide();
    else if(action==='prep')QUEST_FLOW.openPreparation();
    else if(action==='explore')openMap('world');
    else if(action==='expeditions')ADVENTURE.open('expeditions');
    else if(action==='investment'){const g=ECONOMY.nextGoal();if(g)ECONOMY.openGoal(g.action)}
    else if(action==='farm')FARM.openUI('simple');
    else if(action==='friends'){if(FEATURES.use('social')){$('friends-modal').classList.remove('h');friendsUI()}}
    else if(action==='mine'||action==='frontier')openMap('world');
    else if(action==='bestiary'){if(FEATURES.use('bestiary')){$('bestiary-modal').classList.remove('h');bestiaryUI()}}
  }
};
const EXPEDITIONS=window.EXPEDITIONS={
  defs:{
    forest:{icon:'🌲',name:'Zümrüt Orman Devriyesi',desc:'Başlangıç bölgesinde kısa savaş ve kaynak rotası.',map:'world',waypoint:'Zümrüt Orman',x:50,y:26,rec:2,gold:110,unlock:()=>true,objectives:[{id:'slime',type:'kill',target:'slime',need:3,label:'3 Slime yen'},{id:'gather',type:'gather',need:2,label:'2 doğal kaynak topla'},{id:'return',type:'return',need:1,label:'Çiftliğe güvenle dön'}]},
    lake:{icon:'🌊',name:'Sığ Göl Araştırması',desc:'Balıkçılık ve kıyı güvenliğini birleştiren rota.',map:'world',waypoint:'Balıkçı İskelesi',x:33,y:56,rec:4,gold:130,unlock:()=>P.q>=1,objectives:[{id:'fish',type:'fish',need:2,label:'2 balık tut'},{id:'lizard',type:'kill',target:'lizard',need:2,label:'2 Murloc yen'},{id:'return',type:'return',need:1,label:'Çiftliğe güvenle dön'}]},
    desert:{icon:'🏜️',name:'Kızıl Çöl Kervanı',desc:'Daha zorlu savaş ile maden toplamayı birleştirir.',map:'world',waypoint:'Kızıl Çöl',x:72,y:50,rec:7,gold:190,unlock:()=>P.q>=5||P.lvl>=7,objectives:[{id:'mine',type:'mine',need:2,label:'2 maden kaynağı kır'},{id:'scorpion',type:'kill',target:'scorpion',need:3,label:'3 Akrep yen'},{id:'return',type:'return',need:1,label:'Çiftliğe güvenle dön'}]},
    frontier:{icon:'🌫️',name:'Sisli Yayla Seferi',desc:'Yayla kaynaklarını ve yaban hayatını araştır.',map:'frontier',waypoint:'Yayla Kampı',x:43,y:42,rec:6,gold:170,unlock:()=>P.frontierDiscovered,objectives:[{id:'gather',type:'gather',need:3,label:'3 yayla kaynağı topla'},{id:'boar',type:'kill',target:'boar',need:2,label:'2 Yaban Domuzu yen'},{id:'return',type:'return',need:1,label:'Çiftliğe güvenle dön'}]}
  },
  state(){const e=P.adventure.expedition;if(!e||typeof e!=='object'||!this.defs[e.id])return null;e.progress=e.progress&&typeof e.progress==='object'?e.progress:{};e.ready=this.defs[e.id].objectives.every(o=>(e.progress[o.id]||0)>=o.need);return e},
  available(id){return !!this.defs[id]?.unlock()},
  start(id){const d=this.defs[id];if(!d||!this.available(id)||this.state()||P.adventure.lastExpeditionDay===P.day)return false;P.adventure.expedition={id,progress:{},ready:false,abandonConfirm:false};NOTIFICATIONS.push('expedition',d.icon,`${d.name} başladı`,'Hedefleri istediğin hızda tamamla; süre sınırı yok.');sv();$('journey-modal').classList.add('h');this.travel(d);return true},
  travel(d){if(!GAME_CORE.canTravel())return false;if(!WAYPOINTS.isUnlocked(d.map,d.waypoint)){const wp=WAYPOINTS.defs.find(w=>w.map===d.map&&w.name===d.waypoint)||d;WAYPOINTS.guide(d.map,{name:d.waypoint,x:wp.x,y:wp.y});if(d.map!==curMap&&!switchMap(d.map,d.map==='world'?'center':undefined))return false;ban(`🧭 İlk kez yürüyerek keşfet: ${d.waypoint}`,'#fde68a');return true}if(d.map!==curMap&&!switchMap(d.map,d.map==='world'?'center':undefined))return false;for(let r=0;r<=7;r++)for(let y=-r;y<=r;y++)for(let x=-r;x<=r;x++){if(Math.max(Math.abs(x),Math.abs(y))!==r)continue;const px=(d.x+x+.5)*TS,py=(d.y+y+.5)*TS;if(!bl(px,py,4)){P.x=px;P.y=py;FX.resetMap();svNow();ban(`${d.icon} ${d.name}`,'#a7f3d0');return true}}return false},
  event(type,target=null,amount=1){const e=this.state();if(!e||e.ready)return false;const d=this.defs[e.id],returnObj=d.objectives.find(o=>o.type==='return'),mainDone=d.objectives.filter(o=>o.type!=='return').every(o=>(e.progress[o.id]||0)>=o.need);let changed=false;for(const o of d.objectives){if(o.type!==type||(o.target&&o.target!==target)||o.type==='return'&&!mainDone)continue;e.progress[o.id]=Math.min(o.need,(e.progress[o.id]||0)+amount);changed=true}if(!changed)return false;e.ready=d.objectives.every(o=>(e.progress[o.id]||0)>=o.need);if(e.ready){ban('🧭 SEFER TAMAMLANDI · ÖDÜLÜNÜ SEÇ','#fde68a');NOTIFICATIONS.push('expedition','🧭',`${d.name} tamamlandı`,'Çiftlikte Yolcu Defteri → Seferler bölümünden ödülünü seç.')}else if(mainDone&&(e.progress[returnObj.id]||0)<1)chat('REHBER','','Sefer hedefleri tamam. Ödül için çiftliğe güvenle dön.',1);sv();return true},
  claim(choice){const e=this.state();if(!e?.ready||curMap!=='home')return false;const d=this.defs[e.id];if(choice==='gold')P.gold+=d.gold;else if(choice==='supplies'){P.gems+=2;P.pots+=2;P.seeds.wheat=(P.seeds.wheat||0)+5}else if(choice==='gear')awardInventoryItem(gen(Math.max(P.lvl,d.rec),1));else return false;P.adventure.stats.expeditions=(P.adventure.stats.expeditions||0)+1;P.adventure.lastExpeditionDay=P.day;P.adventure.expedition=null;NOTIFICATIONS.push('expedition','🎁',`${d.name} ödülü alındı`,choice==='gold'?`+${d.gold} altın`:choice==='supplies'?'+2 elmas · +2 iksir · +5 buğday tohumu':'Ekipman sandığı alındı.');ban(`🎁 ${d.name} ÖDÜLÜ ALINDI`,'#fde68a');playChord([523,659,784,1046],.35,'triangle',.055);sv();ADVENTURE.ui();return true},
  abandon(){const e=this.state();if(!e)return;if(!e.abandonConfirm){e.abandonConfirm=true;sv();ADVENTURE.ui();return}P.adventure.expedition=null;sv();ADVENTURE.ui()},
  html(){const e=this.state();if(!e){if(P.adventure.lastExpeditionDay===P.day)return '<div class="journey-lead"><small>KISA KEŞİF SEFERLERİ</small><h2>✓ Bugünkü Sefer Tamamlandı</h2><p>Yeni sefer rotaları bir sonraki oyun gününde yeniden açılır.</p></div>';return `<div class="journey-lead"><small>8–12 DAKİKALIK SERBEST ROTALAR</small><h2>🧭 Keşif Seferleri</h2><p>Üç küçük hedefi istediğin sırada tamamla ve çiftliğe dön. Süre sınırı, başarısızlık veya eşya kaybı yoktur.</p></div><div class="expedition-grid">${Object.entries(this.defs).map(([id,d])=>{const open=this.available(id);return `<div class="expedition-card ${open?'':'locked'}"><h3>${d.icon} ${d.name}</h3><p>${d.desc}<br>Önerilen seviye ${d.rec} · yaklaşık 8–12 dakika</p><div class="quest-rewards"><span>${d.gold}🪙 seçeneği</span><span>Malzeme seçeneği</span><span>Ekipman seçeneği</span></div><button type="button" data-expedition-start="${id}" ${open?'':'disabled'}>${open?'Seferi Başlat':'Henüz Kilitli'}</button></div>`}).join('')}</div>`}const d=this.defs[e.id],mainDone=d.objectives.filter(o=>o.type!=='return').every(o=>(e.progress[o.id]||0)>=o.need);return `<div class="expedition-active"><span class="guide-kicker">AKTİF SEFER</span><h2 class="guide-title">${d.icon} ${d.name}</h2><p class="guide-copy">${d.desc} Süre sınırı yok; ilerlemen kaydediliyor.</p><div class="expedition-objectives">${d.objectives.map(o=>{const n=e.progress[o.id]||0,done=n>=o.need;return `<div class="expedition-objective ${done?'done':''}"><span>${done?'✓':'○'}</span><span>${o.label}<div class="expedition-progress"><i style="width:${Math.round(n/o.need*100)}%"></i></div></span><b>${n}/${o.need}</b></div>`}).join('')}</div>${e.ready?curMap==='home'?`<div class="quest-tip">🎁 Sefer ödülünü seç:</div><div class="expedition-rewards"><button data-expedition-reward="gold">🪙 ${d.gold} Altın</button><button data-expedition-reward="supplies">📦 2💎 · 2🧪 · 5 Tohum</button><button data-expedition-reward="gear">⚔️ Ekipman Sandığı</button></div>`:`<div class="quest-tip">✓ Hedefler tamamlandı. Ödül seçmek için çiftliğe dön.</div><button data-expedition-home="1">🏡 Çiftliğe Dön</button>`:mainDone?'<div class="quest-tip">Ana hedefler tamam. Şimdi çiftliğe dön.</div>':''}${!e.ready&&curMap!==d.map?'<button type="button" data-expedition-travel="1">🧭 Sefer Bölgesine Git</button>':''}<button type="button" data-expedition-abandon="1" style="margin-top:8px;background:#3f2a2a">${e.abandonConfirm?'Tekrar Bas · Seferi Bırak':'Seferi Bırak'}</button></div>`}
};
const JOURNAL=window.JOURNAL={
  titles:[
    {id:'traveler',name:'Gezgin',desc:'Aethermoor’a ilk adım.',check:()=>true},
    {id:'builder',name:'Köy Mimarı',desc:'3 yapı kur.',check:()=>(P.adventure.stats.builds||0)>=3},
    {id:'friend',name:'Yaban Dostu',desc:'Bir vahşi hayvanın güvenini kazan.',check:()=>P.adventure.roster.length>0},
    {id:'explorer',name:'Sır Kaşifi',desc:'3 gizli oda bul.',check:()=>(P.adventure.stats.secrets||0)>=3},
    {id:'storm',name:'Fırtına Elçisi',desc:'10 yıldırım–su tepkisi oluştur.',check:()=>(P.adventure.stats.waterShocks||0)>=10},
    {id:'smith',name:'Usta Demirci',desc:'Bir ekipmanı +15 yap.',check:()=>!!P.adventure.stats.forge15},
    {id:'collector',name:'Kart Ustası',desc:'8 farklı canavarı yen.',check:()=>Object.values(P.adventure.bestiary).filter(v=>v.kills>0).length>=8},
    {id:'dragon',name:'Ejder Avcısı',desc:'Kızıl Ejder’i yen.',check:()=>!!P.ach.dragon_killed},
    {id:'guardian',name:'Yuvanın Koruyucusu',desc:'Ejder görev rotasından sonra Muhtar Hamdi ile konuş.',check:()=>STORY.closed()}
  ],
  see(e){if(!P.adventure||!e||!MT[e.k])return;const b=P.adventure.bestiary;if(!b[e.k])b[e.k]={seen:true,kills:0}},
  kill(e){this.see(e);if(e.trial||!P.adventure.bestiary[e.k])return;P.adventure.bestiary[e.k].kills++;},
  label(){const t=this.titles.find(t=>t.id===P.adventure?.title);return t&&t.check()?t.name:'Gezgin'},
  select(id){const t=this.titles.find(t=>t.id===id);if(!t||!t.check())return false;P.adventure.title=id;sv();return true},
  html(){return `<div class="journey-lead"><small>KAHRAMANIN HİKÂYESİ</small><h2>♜ ${escapeHTML(this.label())}</h2><p>Unvanlar görseldir; gizli hasar veya fiyat avantajı vermez.</p></div>${this.titles.map(t=>`<div class="journey-box title-row"><div><b>${t.check()?'✦':'🔒'} ${t.name}</b><p>${t.desc}</p></div><button data-title="${t.id}" ${!t.check()?'disabled':''}>${P.adventure.title===t.id?'Seçili':'Kuşan'}</button></div>`).join('')}<button data-journey-action="bestiary" style="width:100%">📚 Canavar Kartlarına Bak</button>`}
};
const BUILD_CONFIG={
  rules:{legacyLimit:40,partLimit:240,placementRange:6,supportRadius:2,historyLimit:20},
  materials:{
    wood:{name:'Ahşap',icon:'🪵',color:'#80512f',trim:'#c8975a',durability:70,insulation:80,fireResistance:15,recipe:{wood:1}},
    stone:{name:'Taş',icon:'🪨',color:'#657581',trim:'#b7c1c4',durability:180,insulation:45,fireResistance:100,recipe:{stone:2}},
    brick:{name:'Tuğla',icon:'🧱',color:'#934b3e',trim:'#d18468',durability:150,insulation:70,fireResistance:90,recipe:{stone:1,coal:1}},
    iron:{name:'Demir',icon:'⚙️',color:'#405866',trim:'#a6c0c8',durability:220,insulation:20,fireResistance:95,recipe:{iron_ore:2,coal:1}}
  },
  parts:{
    fence:{name:'Ahşap Çit',icon:'🪵',w:1,h:1,layer:'solid',solid:true,part:false,defaultMaterial:'wood',needs:{wood:4},gold:0,desc:'Yolu ve geçişleri kapatmadan alanını düzenle.'},
    chest:{name:'Depo Sandığı',icon:'📦',w:1,h:1,layer:'object',solid:true,pathTarget:true,part:false,defaultMaterial:'wood',needs:{wood:10,stone:4},gold:30,desc:'Her sandığın ayrı, kayıtlı 24 göz deposu vardır.'},
    workshop:{name:'Çiftlik Atölyesi',icon:'🔨',w:2,h:2,layer:'object',solid:true,pathTarget:true,part:false,defaultMaterial:'wood',needs:{wood:18,stone:12,iron_ore:4},gold:140,desc:'Yem, gübre, yol azığı ve fırtına rünü üret.'},
    floor:{name:'Zemin',icon:'▰',w:1,h:1,layer:'floor',solid:false,part:true,defaultMaterial:'wood',unitCost:1,materials:['wood','stone','brick','iron'],desc:'Yapının taban döşemesi.'},
    wall:{name:'Duvar',icon:'▥',w:1,h:1,layer:'wall',solid:true,supportsRoof:true,part:true,defaultMaterial:'wood',unitCost:2,materials:['wood','stone','brick','iron'],desc:'Geçişi kapatır ve çatıya destek olur.'},
    door:{name:'Kapı',icon:'🚪',w:1,h:1,layer:'wall',solid:true,supportsRoof:true,part:true,defaultMaterial:'wood',unitCost:3,materials:['wood','stone','brick','iron'],desc:'Kapalıyken geçişi engeller; etkileşimle açılır.'},
    window:{name:'Pencere',icon:'▣',w:1,h:1,layer:'wall',solid:true,supportsRoof:true,part:true,defaultMaterial:'wood',unitCost:3,materials:['wood','stone','brick','iron'],desc:'Duvar yuvasına yerleşir; şimdilik geçişi kapalı tutar.'},
    roof:{name:'Çatı',icon:'⌂',w:1,h:1,layer:'roof',solid:false,part:true,defaultMaterial:'wood',unitCost:2,materials:['wood','stone','brick','iron'],desc:'Duvar desteği yakınındaki kareleri örter.'}
  }
};
const BUILD=window.BUILD={
  defs:BUILD_CONFIG.parts,active:null,activeChest:null,activeWorkshop:null,lastError:'',undoStack:[],redoStack:[],
  isPart(kindOrBuilding){const kind=typeof kindOrBuilding==='string'?kindOrBuilding:kindOrBuilding?.kind;return !!this.defs[kind]?.part},
  defaultMaterial(kind){return this.defs[kind]?.defaultMaterial||'wood'},
  cost(kind,material=this.defaultMaterial(kind)){
    const d=this.defs[kind];if(!d)return{needs:{},gold:0};
    if(!d.part)return{needs:d.needs||{},gold:d.gold||0};
    const recipe=BUILD_CONFIG.materials[material]?.recipe||BUILD_CONFIG.materials[this.defaultMaterial(kind)].recipe,needs={};
    for(const [k,n]of Object.entries(recipe))needs[k]=n*d.unitCost;
    return{needs,gold:d.gold||0};
  },
  layer(kindOrBuilding){const kind=typeof kindOrBuilding==='string'?kindOrBuilding:kindOrBuilding?.kind;return this.defs[kind]?.layer||'object'},
  drawOrder(b){return({floor:0,solid:1,wall:2,object:3,roof:4})[this.layer(b)]??3},
  solid(b){const d=this.defs[b?.kind];return !!d?.solid&&!(b.kind==='door'&&b.open===true)},
  occupiesLayer(kind,gx,gy,list=P.adventure?.buildings||[],ignoreId=null){
    const layer=this.layer(kind);return list.some(b=>b.id!==ignoreId&&this.layer(b)===layer&&gx>=b.gx&&gx<b.gx+this.defs[b.kind].w&&gy>=b.gy&&gy<b.gy+this.defs[b.kind].h);
  },
  supportSafe(list=P.adventure?.buildings||[]){
    const supports=list.filter(b=>this.defs[b.kind]?.supportsRoof);
    for(const roof of list.filter(b=>b.kind==='roof')){
      const r=BUILD_CONFIG.rules.supportRadius;
      if(!supports.some(w=>Math.abs(w.gx-roof.gx)<=r&&Math.abs(w.gy-roof.gy)<=r))return false;
    }
    return true;
  },
  sanitizeRestored(){
    const a=P.adventure,source=[...(a.buildings||[])],ordered=source.map((b,i)=>({b,i})).sort((x,y)=>(x.b.kind==='roof')-(y.b.kind==='roof')||x.i-y.i),accepted=[],rejected=[];
    for(const entry of ordered){
      const b=entry.b;a.buildings=accepted;
      const error=this.validate(b.kind,b.gx,b.gy,false,b.material,null,false,b.open===true);
      if(error||!this.pathSafe([...accepted,b],false,true))rejected.push(b);else accepted.push(b);
    }
    a.buildings=accepted;P.pendingRewards=Array.isArray(P.pendingRewards)?P.pendingRewards:[];
    for(const b of rejected){
      if(Array.isArray(b.items))P.pendingRewards.push(...ITEMS.normalize(b.items));
      const refund=this.halfRefund(this.cost(b.kind,b.material||this.defaultMaterial(b.kind)));
      for(const [k,n]of Object.entries(refund)){const item=ITEMS.make(k,n);if(item)P.pendingRewards.push(item)}
    }
    if(rejected.length){console.warn('Geçersiz kayıtlı yapı güvenli yerleşim için ayrıldı:',rejected.length);pendingLoadNotices.push(`${rejected.length} geçersiz yapı güvenli yerleşim için kaldırıldı; eşya ve iade malzemeleri bekleyen ödüllere taşındı.`)}
    return rejected.length;
  },
  cloneRecord(b){return JSON.parse(JSON.stringify(b))},
  pushHistory(entry){this.undoStack.push(entry);if(this.undoStack.length>BUILD_CONFIG.rules.historyLimit)this.undoStack.shift();this.redoStack.length=0;this.updateHistoryButtons()},
  updateHistoryButtons(){const undo=$('build-undo'),redo=$('build-redo');if(undo)undo.disabled=!this.undoStack.length;if(redo)redo.disabled=!this.redoStack.length},
  pay(cost){return inventoryRecipe(cost.needs,[],{gold:cost.gold}).ok},
  grant(cost){const outputs=Object.entries(cost.needs).map(([k,n])=>ITEMS.make(k,n)).filter(Boolean);if(!ITEMS.addMany(P.inv,outputs))return false;P.gold+=cost.gold;return true},
  halfRefund(cost){const needs={};for(const [k,n]of Object.entries(cost.needs))if(n>=2)needs[k]=Math.floor(n/2);return needs},
  grantNeeds(needs){return inventoryRecipe({},Object.entries(needs).map(([k,n])=>ITEMS.make(k,n)).filter(Boolean)).ok},
  consumeNeeds(needs){return inventoryRecipe(needs).ok},
  land(x,y){return x>=24&&x<=28&&y>=38&&y<=44||x>=33&&x<=37&&y>=38&&y<=43},
  pos(b){const d=this.defs[b.kind];return {x:(b.gx+d.w/2)*TS,y:(b.gy+d.h)*TS}},
  blocks(x,y,r=4,list=P.adventure?.buildings||[]){
    for(const b of list){if(!this.solid(b))continue;const d=this.defs[b.kind];if(d&&x+r>b.gx*TS&&x-r<(b.gx+d.w)*TS&&y+r>b.gy*TS&&y-r<(b.gy+d.h)*TS)return true}
    return false;
  },
  pathSafe(list,checkPlayer=true,checkExit=true){
    const md=WORLD_DATA.home,n=md.N,blocked=new Uint8Array(n*n),seen=new Uint8Array(n*n),q=new Int16Array(n*n);
    for(let i=0;i<blocked.length;i++)if(md.tl[i]===1||md.tl[i]===4)blocked[i]=1;
    for(const o of md.objs){const rad=(o.r||4)+4;for(let y=Math.max(0,Math.floor((o.y-rad)/TS));y<=Math.min(n-1,Math.floor((o.y+rad)/TS));y++)for(let x=Math.max(0,Math.floor((o.x-rad)/TS));x<=Math.min(n-1,Math.floor((o.x+rad)/TS));x++)if(Math.hypot(x*TS+8-o.x,y*TS+8-o.y)<rad)blocked[y*n+x]=1}
    for(const b of list){if(!this.solid(b))continue;const d=this.defs[b.kind];for(let y=b.gy;y<b.gy+d.h;y++)for(let x=b.gx;x<b.gx+d.w;x++)if(x>=0&&y>=0&&x<n&&y<n)blocked[y*n+x]=1}
    let head=0,tail=0;const start=37*n+31;if(blocked[start])return false;q[tail++]=start;seen[start]=1;
    while(head<tail){const i=q[head++],x=i%n,y=(i/n)|0;for(const j of [x>0?i-1:-1,x<n-1?i+1:-1,y>0?i-n:-1,y<n-1?i+n:-1])if(j>=0&&!blocked[j]&&!seen[j]){seen[j]=1;q[tail++]=j}}
    if(checkPlayer&&!seen[cl(P.y/TS|0,0,n-1)*n+cl(P.x/TS|0,0,n-1)])return false;
    for(const b of list){const d=this.defs[b.kind];if(!d?.pathTarget)continue;const x=b.gx+Math.floor(d.w/2),y=b.gy+d.h;if(!seen[y*n+x])return false}
    if(checkExit){let exitReachable=false;for(let y=26;y<=33;y++)if(seen[y*n+(n-3)]){exitReachable=true;break}if(!exitReachable)return false}
    return true;
  },
  validate(kind,gx,gy,paths=true,material=this.defaultMaterial(kind),ignoreId=null,checkRange=true,openState=null){
    const d=this.defs[kind],md=WORLD_DATA.home;if(!d)return 'Bilinmeyen yapı.';
    if(curMap!=='home')return 'Yalnızca kasabanın inşa arazisine kurulabilir.';
    if(!Number.isInteger(gx)||!Number.isInteger(gy))return 'Bir kare seç.';
    if(d.part&&!d.materials.includes(material))return 'Bu parça için geçerli bir malzeme seç.';
    const existing=P.adventure.buildings.filter(b=>b.id!==ignoreId),current=ignoreId?P.adventure.buildings.find(b=>b.id===ignoreId):null,doorOpen=kind==='door'&&(openState??current?.open)===true,count=existing.filter(b=>this.isPart(b)===!!d.part).length;
    const limit=d.part?BUILD_CONFIG.rules.partLimit:BUILD_CONFIG.rules.legacyLimit;
    if(count>=limit)return d.part?`Parça sınırına ulaştın (${limit}).`:`Yapı sınırına ulaştın (${limit}).`;
    if(checkRange&&Math.hypot((gx+d.w/2)*TS-P.x,(gy+d.h/2)*TS-P.y)>BUILD_CONFIG.rules.placementRange*TS)return `Seçilen kareye yaklaş (en çok ${BUILD_CONFIG.rules.placementRange} kare).`;
    for(let y=gy;y<gy+d.h;y++)for(let x=gx;x<gx+d.w;x++){
      if(!this.land(x,y)||md.tl[y*md.N+x]!==0)return 'Yollar, su ve tarla korunuyor. Yalnızca işaretli güney çimenliğine kur.';
      if(this.occupiesLayer(kind,x,y,existing,ignoreId))return 'Bu katmanda zaten bir parça var.';
      const px=x*TS+8,py=y*TS+8,candidate={kind,gx,gy,material,open:doorOpen};
      if(this.solid(candidate)&&this.blocks(px,py,7,existing))return 'Bu karede başka bir yapı var.';
      if(md.objs.some(o=>Math.hypot(px-o.x,py-o.y)<(o.r||4)+8))return 'Ağaç veya başka bir nesne alanı kapatıyor.';
    }
    const candidate={id:ignoreId||'__build-preview__',kind,gx,gy,material,level:0,rotation:0,open:doorOpen};
    if(this.solid(candidate)&&this.blocks(P.x,P.y,6,[candidate]))return 'Kendi ayağının altına yapı kuramazsın.';
    const final=[...existing,candidate];
    if(paths&&!this.pathSafe(final))return 'Bu yerleşim oyuncunun veya bir yapının çıkışını kapatıyor.';
    if(!this.supportSafe(final))return 'Çatı desteği yetersiz; yakına duvar ekle.';
    return '';
  },
  start(kind,material=this.defaultMaterial(kind),moveId=null){
    const d=this.defs[kind];if(!d)return false;if(curMap!=='home'){ADVENTURE.notice('İnşa etmek için önce çiftliğe dön.');return false}
    let target=null;if(moveId){target=P.adventure.buildings.find(b=>b.id===moveId);if(!target)return false;const p=this.pos(target);if(Math.hypot(P.x-p.x,P.y-p.y)>60){ADVENTURE.notice('Taşımak için yapıya yaklaş.');return false}material=target.material||this.defaultMaterial(kind)}
    if(d.part&&!BUILD_CONFIG.materials[material])material=this.defaultMaterial(kind);
    this.cancel();const off=[[0,1],[0,-1],[-1,0],[1,0]][P.f]||[0,1];
    this.active=target?{mode:'move',id:target.id,kind:target.kind,material,gx:target.gx,gy:target.gy,rotation:target.rotation||0,open:target.open===true}:{mode:'place',kind,material,gx:(P.x/TS|0)+off[0]*3,gy:(P.y/TS|0)+off[1]*3,rotation:0,open:false};
    $('journey-modal').classList.add('h');$('build-controls').classList.remove('h');document.body.classList.add('build-mode');this.refresh();return true;
  },
  startMove(id){const b=P.adventure.buildings.find(b=>b.id===id);return b?this.start(b.kind,b.material||this.defaultMaterial(b.kind),b.id):false},
  cancel(){this.active=null;$('build-controls')?.classList.add('h');document.body.classList.remove('build-mode')},
  move(dx,dy){if(!this.active)return;this.active.gx=cl(this.active.gx+dx,2,57);this.active.gy=cl(this.active.gy+dy,2,57);this.refresh()},
  rotate(){if(!this.active)return;this.active.rotation=(this.active.rotation+1)%4;this.refresh()},
  refresh(){
    if(!this.active)return;const b=this.active,d=this.defs[b.kind],mat=BUILD_CONFIG.materials[b.material];
    this.lastError=this.validate(b.kind,b.gx,b.gy,true,b.material,b.mode==='move'?b.id:null);
    $('build-cursor').textContent=`${mat?mat.icon+' ':''}${d.icon} ${d.name} (${b.gx}, ${b.gy}) · ${b.mode==='move'?'Taşı':'Yerleştir'}`;
    const cost=this.cost(b.kind,b.material),costText=Object.entries(cost.needs).map(([k,n])=>`${n} ${MATERIALS[k]?.n||k}`).join(' · ');
    const el=$('build-hint');el.textContent=this.lastError||`${costText}${cost.gold?' · '+cost.gold+'🪙':''} · Dönüş ${b.rotation*90}° · Kurmak için ✓`;
    el.style.color=this.lastError?'#fca5a5':'#a7f3d0';this.updateHistoryButtons();
  },
  confirm(){
    if(!this.active)return false;const b=this.active,d=this.defs[b.kind],error=this.validate(b.kind,b.gx,b.gy,true,b.material,b.mode==='move'?b.id:null);
    if(error){this.lastError=error;$('build-hint').textContent=error;return false}
    const a=P.adventure;
    if(b.mode==='move'){
      const record=a.buildings.find(v=>v.id===b.id);if(!record)return false;
      const from={gx:record.gx,gy:record.gy,rotation:record.rotation||0},to={gx:b.gx,gy:b.gy,rotation:b.rotation||0};
      Object.assign(record,to);this.pushHistory({type:'move',id:record.id,from,to});
    }else{
      const cost=this.cost(b.kind,b.material);if(!this.pay(cost)){$('build-hint').textContent='Altın veya malzeme yetersiz; hiçbir şey harcanmadı.';return false}
      let id;do{id='b'+a.nextBuildId++}while(a.buildings.some(v=>v.id===id));
      const mat=BUILD_CONFIG.materials[b.material]||BUILD_CONFIG.materials[this.defaultMaterial(b.kind)];
      const record={id,kind:b.kind,gx:b.gx,gy:b.gy,material:b.material||this.defaultMaterial(b.kind),level:0,rotation:b.rotation||0,hp:mat.durability,items:[]};
      if(b.kind==='door')record.open=false;
      a.buildings.push(record);a.stats.builds=(a.stats.builds||0)+1;
      this.pushHistory({type:'place',record:this.cloneRecord(record),cost});
      if(b.kind==='chest')ONBOARD.event('chest');
    }
    const p=this.pos(b);spark(p.x,p.y-8,16,'#e9cb8a',60);playChord([523,659,784],.3,'triangle',.05);this.cancel();sv();return true;
  },
  remove(id,track=true){
    const a=P.adventure,b=a.buildings.find(v=>v.id===id);if(!b||curMap!=='home')return false;
    const p=this.pos(b);if(Math.hypot(P.x-p.x,P.y-p.y)>60){ADVENTURE.notice('Sökmek için yapıya yaklaş.');return false}
    if(b.items?.length){ADVENTURE.notice('Önce bu sandığı tamamen boşalt.');return false}
    const remaining=a.buildings.filter(v=>v!==b);if(!this.supportSafe(remaining)){ADVENTURE.notice('Önce çatıyı veya destek veren parçayı kaldır.');return false}
    const cost=this.cost(b.kind,b.material||this.defaultMaterial(b.kind)),refundNeeds=this.halfRefund(cost);
    if(!this.grantNeeds(refundNeeds)){inventoryWarning('İade malzemesi için çantanda yer aç.');return false}
    const index=a.buildings.indexOf(b);a.buildings=remaining;if(this.activeChest===id)this.activeChest=null;
    if(track)this.pushHistory({type:'remove',record:this.cloneRecord(b),index,refundNeeds});
    sv();ADVENTURE.ui();ADVENTURE.notice('Yapı söküldü; malzemenin yarısı geri verildi.');return true;
  },
  nearest(){if(curMap!=='home')return null;let found=null,dist=34;for(const b of P.adventure.buildings){const p=this.pos(b),d=Math.hypot(P.x-p.x,P.y-p.y);if(this.defs[b.kind]?.pathTarget&&d<dist){found=b;dist=d}}return found},
  nearestDoor(){if(curMap!=='home')return null;let found=null,dist=30;for(const b of P.adventure.buildings){if(b.kind!=='door')continue;const p=this.pos(b),d=Math.hypot(P.x-p.x,P.y-p.y);if(d<dist){found=b;dist=d}}return found},
  toggleDoor(id){const door=P.adventure.buildings.find(b=>b.id===id&&b.kind==='door');if(!door)return false;door.open=!door.open;if(!this.pathSafe(P.adventure.buildings)){door.open=!door.open;inventoryWarning('Bu kapıyı kapatmak çıkış yolunu engeller.');return false}fl(P.x,P.y-24,door.open?'🚪 Kapı açıldı':'🚪 Kapı kapandı','#f0d7a3');sv();return true},
  undo(){
    const action=this.undoStack[this.undoStack.length-1];if(!action)return false;const a=P.adventure;
    if(action.type==='place'){
      const b=a.buildings.find(v=>v.id===action.record.id);if(!b)return false;
      if(b.items?.length){ADVENTURE.notice('Bu sandıkta eşya var; önce boşalt.');return false}
      const remaining=a.buildings.filter(v=>v!==b);if(!this.supportSafe(remaining)||!this.pathSafe(remaining)){ADVENTURE.notice('Bu işlemi geri almak yapı desteğini veya yolu bozuyor.');return false}
      if(!this.grant(action.cost)){ADVENTURE.notice('Geri alma malzemeleri için çantanda yer aç.');return false}
      a.buildings=remaining;if(this.activeChest===b.id)this.activeChest=null;
    }else if(action.type==='remove'){
      const b=this.cloneRecord(action.record);if(a.buildings.some(v=>v.id===b.id))return false;
      const error=this.validate(b.kind,b.gx,b.gy,true,b.material,null,false,b.open===true);if(error){ADVENTURE.notice(error);return false}
      if(!this.consumeNeeds(action.refundNeeds)){ADVENTURE.notice('Söküm iadesi harcanmış; geri almak için gereken malzeme yok.');return false}
      a.buildings.splice(cl(action.index,0,a.buildings.length),0,b);
    }else if(action.type==='move'){
      const b=a.buildings.find(v=>v.id===action.id);if(!b)return false;
      const error=this.validate(b.kind,action.from.gx,action.from.gy,true,b.material,b.id,false);if(error){ADVENTURE.notice(error);return false}
      Object.assign(b,action.from);
    }
    this.undoStack.pop();this.redoStack.push(action);this.updateHistoryButtons();if(this.active)this.refresh();if(!$('journey-modal').classList.contains('h'))ADVENTURE.ui();sv();return true;
  },
  redo(){
    const action=this.redoStack[this.redoStack.length-1];if(!action)return false;const a=P.adventure;
    if(action.type==='place'){
      const b=this.cloneRecord(action.record);if(a.buildings.some(v=>v.id===b.id))return false;
      const error=this.validate(b.kind,b.gx,b.gy,true,b.material,null,false,b.open===true);if(error){ADVENTURE.notice(error);return false}
      if(!this.pay(action.cost)){ADVENTURE.notice('Yineleme için malzeme veya altın yetersiz.');return false}
      a.buildings.push(b);
    }else if(action.type==='remove'){
      const b=a.buildings.find(v=>v.id===action.record.id);if(!b||b.items?.length){ADVENTURE.notice('Yapı yok veya sandık boş değil; yineleme yapılamadı.');return false}
      const remaining=a.buildings.filter(v=>v!==b);if(!this.supportSafe(remaining)){ADVENTURE.notice('Bu işlem çatıyı desteksiz bırakır.');return false}
      if(!this.grantNeeds(action.refundNeeds)){ADVENTURE.notice('İade malzemeleri için çantanda yer aç.');return false}
      a.buildings=remaining;if(this.activeChest===b.id)this.activeChest=null;
    }else if(action.type==='move'){
      const b=a.buildings.find(v=>v.id===action.id);if(!b)return false;
      const error=this.validate(b.kind,action.to.gx,action.to.gy,true,b.material,b.id,false);if(error){ADVENTURE.notice(error);return false}
      Object.assign(b,action.to);
    }
    this.redoStack.pop();this.undoStack.push(action);if(this.undoStack.length>BUILD_CONFIG.rules.historyLimit)this.undoStack.shift();this.updateHistoryButtons();if(this.active)this.refresh();if(!$('journey-modal').classList.contains('h'))ADVENTURE.ui();sv();return true;
  },
  interact(b){if(!b||this.nearest()?.id!==b.id)return false;if(b.kind==='chest'){this.activeChest=b.id;$('storage-modal').classList.remove('h');storageUI()}else{this.activeWorkshop=b.id;ADVENTURE.open('workshop')}return true},
  craft(type){
    const b=P.adventure.buildings.find(b=>b.id===this.activeWorkshop&&b.kind==='workshop'),p=b&&this.pos(b);
    if(!p||curMap!=='home'||Math.hypot(P.x-p.x,P.y-p.y)>50){ADVENTURE.notice('Üretim için atölyene yaklaş.');return false}
    let ok=false;
    if(type==='hay'){ok=tryInventoryRecipe({wheat:1});if(ok)P.hay=(P.hay||0)+4}
    else if(type==='fert'){ok=tryInventoryRecipe({wheat:2,coal:1});if(ok)P.fert=(P.fert||0)+3}
    else if(type==='rune')ok=ELEMENTS.enchant(P.eq.weapon);
    else if(type==='ration')ok=tryInventoryRecipe({apple:1,wheat:1},[{s:'food',k:'trail_ration',n:'Yol Azığı',icon:'🥙',hp:50,mp:20,val:28,desc:'+50 Can · +20 Mana'}]);
    if(ok){sfx(750,.12,'triangle',.05);sv();ADVENTURE.ui();ADVENTURE.notice('Üretim tamamlandı.')}return ok;
  },
  html(){
    const mats=Object.entries(BUILD_CONFIG.materials),parts=Object.entries(this.defs).filter(([,d])=>d.part),legacy=Object.entries(this.defs).filter(([,d])=>!d.part);
    const partCount=P.adventure.buildings.filter(b=>this.isPart(b)).length,legacyCount=P.adventure.buildings.length-partCount;
    const chestNow=window.ONBOARD&&ONBOARD.current&&ONBOARD.current()?.id==='chest';
    return `${chestNow?`<div class="journey-box"><b>📦 Şimdi yalnız depo sandığı</b><p>10 odun, 4 taş, 30 altın. Duvar ve çatı sonra gelir. Arazideysen düğme yerleştirmeyi açar.</p><button data-build-start="chest">Depo Sandığını Yerleştir</button></div>`:''}<div class="journey-lead"><small>KALICI YERLEŞİM</small><h2>🔨 Çiftliğini Kur</h2><p>${chestNow?'Sandıktan sonra 16×16 ızgara senin.':'16×16 ızgara · güney arazisi · yeşil yerleşim, kırmızı engel. Zemin ve çatı farklı katmanlarda duvarla aynı kareyi paylaşabilir.'}</p></div>
      <div class="journey-box build-material-picker"><b>🧱 Malzeme seçimi</b><label for="build-material-select">Yeni duvar, zemin, kapı, pencere ve çatılar</label><select id="build-material-select" class="build-material-select">${mats.map(([id,m])=>`<option value="${id}">${m.icon} ${m.name} · dayanım ${m.durability} · yalıtım ${m.insulation} · yangın ${m.fireResistance}</option>`).join('')}</select><p>Çatı her hücrede yakınında bir duvar desteği ister. Kapalı kapı geçişi engeller.</p></div>
      <h3>Izgara parçaları · ${partCount}/${BUILD_CONFIG.rules.partLimit}</h3>${parts.map(([k,d])=>`<div class="journey-box"><b>${d.icon} ${d.name} · ${d.w}×${d.h}</b><p>${d.desc}<br>Maliyet seçilen malzemeye göre hesaplanır.</p><button data-build-start="${k}" data-material-pick="1">Yer Seç</button></div>`).join('')}
      <h3>İşlevsel yapılar · ${legacyCount}/${BUILD_CONFIG.rules.legacyLimit}</h3>${legacy.map(([k,d])=>`<div class="journey-box"><b>${d.icon} ${d.name} · ${d.w}×${d.h}</b><p>${d.desc}<br>${Object.entries(d.needs).map(([key,n])=>`${n} ${MATERIALS[key].n}`).join(' · ')}${d.gold?' · '+d.gold+'🪙':''}</p><button data-build-start="${k}">Yer Seç</button></div>`).join('')}
      <div class="build-tools"><button data-build-action="undo" ${!this.undoStack.length?'disabled':''}>↶ Geri al</button><button data-build-action="redo" ${!this.redoStack.length?'disabled':''}>↷ Yinele</button></div>
      <h3>Kurulu Yapılar</h3><p class="inventory-help">Sökümde her malzeme kaleminin yarısı aşağı yuvarlanır; altın iade edilmez.</p>${P.adventure.buildings.map(b=>{const d=this.defs[b.kind],mat=BUILD_CONFIG.materials[b.material||this.defaultMaterial(b.kind)];return `<div class="title-row journey-box"><div><b>${d.icon} ${d.name} (${b.gx},${b.gy})</b><p>${mat?.name||'Ahşap'} · ${b.hp??mat?.durability??0} dayanım${b.kind==='chest'?` · ${b.items.length}/24 göz`:''}</p></div><button data-build-move-id="${escapeHTML(b.id)}">Taşı</button><button data-build-remove="${escapeHTML(b.id)}">Sök</button></div>`}).join('')||'<p>Henüz yapı yok. Yolun solundaki boş çimenlikte başlayabilirsin.</p>'}`;
  },
  workshopHTML(){return `<div class="journey-lead"><small>ÇİFTLİK ATÖLYESİ</small><h2>⚒ Üretim Tezgâhı</h2><p>Tarif tamamen tamamlanabiliyorsa malzeme harcanır.</p></div><div class="workshop-recipes"><button data-workshop="hay">🌾 1 Buğday → 4 Yem</button><button data-workshop="fert">🧪 2 Buğday + 1 Kömür → 3 Gübre</button><button data-workshop="ration">🥙 1 Elma + 1 Buğday → Yol Azığı</button><button data-workshop="rune">⚡ 2 Bakır + 2 Kömür + 60🪙 → Kuşanılmış silaha fırtına rünü</button></div><p class="inventory-help">Yağmur veya fırtınada ıslanan düşmanlar rünlü silahın yıldırımını yakındaki hedeflere iletir.</p>`},
  draw(b){
    const d=this.defs[b.kind],left=b.gx*TS,top=b.gy*TS,x=(b.gx+d.w/2)*TS,y=(b.gy+d.h)*TS-2,mat=BUILD_CONFIG.materials[b.material||this.defaultMaterial(b.kind)]||BUILD_CONFIG.materials.wood;
    if(d.part){
      if(b.kind==='floor'){R(left,top,TS,TS-1,mat.color);R(left,top+TS-3,TS,2,mat.trim);R(left+2,top+2,TS-4,1,'#ffffff20')}
      else if(b.kind==='wall'){R(left+1,top+1,TS-2,TS-1,mat.color);R(left+1,top+2,TS-2,2,mat.trim);R(left+3,top+7,TS-6,1,'#ffffff30');R(left+2,top+TS-3,TS-4,2,'#0005')}
      else if(b.kind==='door'){
        const horizontal=(b.rotation||0)%2===1;R(left+1,top+1,TS-2,TS-1,'#342a25');R(left+3,top+2,TS-6,TS-3,mat.color);
        if(horizontal){R(left+2,top+2,TS-3,2,mat.trim);R(left+3,top+TS-4,TS-5,2,mat.trim);if(!b.open)R(left+10,top+6,2,2,'#f5d887')}
        else{R(left+2,top+2,2,TS-3,mat.trim);R(left+TS-4,top+2,2,TS-3,mat.trim);if(!b.open)R(left+5,top+6,2,2,'#f5d887')}
        if(b.open){if(horizontal)R(left+3,top+2,TS-6,2,mat.trim);else R(left+2,top+3,2,TS-6,mat.trim)}
      }else if(b.kind==='window'){
        R(left+1,top+1,TS-2,TS-1,mat.color);R(left+3,top+4,TS-6,TS-7,'#79b9c2');
        if((b.rotation||0)%2===1){R(left+3,top+7,TS-6,2,mat.trim);R(left+7,top+4,2,TS-7,mat.trim)}
        else{R(left+3,top+4,TS-6,2,mat.trim);R(left+7,top+4,2,TS-7,mat.trim);R(left+3,top+9,TS-6,2,mat.trim)}
      }else if(b.kind==='roof'){
        R(left,top,TS,TS-1,mat.color);R(left,top+3,TS,2,mat.trim);R(left+2,top+7,TS-4,1,'#ffffff30');R(left,top+TS-3,TS,2,'#0005')
      }
      return;
    }
    if(b.kind==='fence'){if((b.rotation||0)%2===0){R(x-7,y-10,3,11,'#755038');R(x+4,y-10,3,11,'#755038');R(x-7,y-9,14,2,'#d0ae72');R(x-7,y-4,14,2,'#9e774b')}else{R(x-7,y-7,14,3,'#755038');R(x-7,y+3,14,3,'#755038');R(x-6,y-7,2,14,'#d0ae72');R(x,y-7,2,14,'#9e774b')}}
    else if(b.kind==='chest'){R(x-7,y-10,14,10,'#86532f');R(x-7,y-12,14,4,'#b88a50');R(x-6,y-9,12,2,'#c49d65');R(x-1,y-7,3,3,'#f6d88e');R(x-7,y-2,14,2,'#4d342d')}
    else{R(x-15,y-22,30,23,'#876245');R(x-17,y-28,34,7,'#48676d');R(x-12,y-32,24,5,'#7b9a9b');R(x-3,y-13,7,14,'#263642');R(x-12,y-17,7,6,'#d3b77c');R(x+6,y-15,7,4,'#354552');R(x+8,y-20,3,7,'#8b9f9f');R(x-15,y-2,30,3,'#5c493a')}
  },
  preview(){
    if(curMap!=='home'||!this.active)return;const b=this.active,d=this.defs[b.kind],good=!this.lastError;
    g.save();g.fillStyle=good?'#6ee7b733':'#ef444433';g.strokeStyle=good?'#8ff2c6':'#ffa99a';g.lineWidth=1;
    g.fillRect(b.gx*TS,b.gy*TS,d.w*TS,d.h*TS);g.strokeRect(b.gx*TS+.5,b.gy*TS+.5,d.w*TS-1,d.h*TS-1);g.globalAlpha=.55;this.draw(b);g.restore();
  }
};
const CAVE=window.CAVE={
  rng(floor){
    let seed=((P.adventure?.seed??9137)^Math.imul(floor,2654435761)^Math.imul(P.day||1,1597334677))>>>0;
    return ()=>{seed+=0x6D2B79F5;let t=seed;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296};
  },
  decorate(md,random){
    md.day=P.day;md.traps=[];md.secret=null;
    md.resources.forEach((r,i)=>r.caveId='r'+i);md.mobs.forEach((m,i)=>m.caveId='m'+i);
    const n=md.N,used=new Set(md.resources.map(r=>(r.y/TS|0)*n+(r.x/TS|0))),free=[];
    for(let y=3;y<n-3;y++)for(let x=3;x<n-3;x++)if(md.tl[y*n+x]!==14&&Math.hypot(x-4,y-5)>5&&!used.has(y*n+x)&&!md.mobs.some(m=>Math.hypot(m.x/TS-x,m.y/TS-y)<2))free.push(y*n+x);
    const choose=()=>free.length?free.splice(Math.floor(random()*free.length),1)[0]:null;
    for(let i=0;i<(md.floor===50?1:2);i++){
      const cell=choose();if(cell===null)break;
      md.chests.push({id:'c'+i,x:(cell%n)*TS+8,y:(cell/n|0)*TS+8,opened:false,t:0,dungeon:true,gold:25+md.floor*4+Math.floor(random()*20),gems:1+Math.floor(random()*3),reward:gen(1+Math.floor(md.floor*.45),1,random)});
    }
    for(let i=0;i<Math.min(5,2+Math.floor(md.floor/12));i++){
      const cell=choose();if(cell===null)break;
      md.traps.push({id:'t'+i,x:(cell%n)*TS+8,y:(cell/n|0)*TS+8,kind:md.biome==='magma'?'flame':'spikes',wind:0,spent:false,disarmed:false});
    }
    // Gizli odanın bütün hücreleri açılana kadar duvardır; alternatif bir koridorla sızma mümkün değildir.
    if(md.floor%3===0||random()<.4){
      const pockets=[];
      for(let y=3;y<n-3;y++)for(let x=3;x<n-3;x++){
        let ok=Math.hypot(x-4,y-5)>8;
        for(let yy=y-1;yy<=y+1&&ok;yy++)for(let xx=x-1;xx<=x+1;xx++)if(md.tl[yy*n+xx]!==14)ok=false;
        if(ok)pockets.push(y*n+x);
      }
      if(pockets.length){
        const center=pockets[Math.floor(random()*pockets.length)],parent=new Int16Array(n*n).fill(-2),q=new Int16Array(n*n);let head=0,tail=0,door=-1;
        parent[center]=-1;q[tail++]=center;
        search:while(head<tail){const i=q[head++],x=i%n,y=i/n|0;for(const j of [i-1,i+1,i-n,i+n]){
          const xx=j%n,yy=j/n|0;if(xx<2||yy<2||xx>=n-2||yy>=n-2||Math.abs(xx-x)+Math.abs(yy-y)!==1)continue;
          if(md.tl[j]!==14){door=i;break search}
          if(parent[j]===-2){parent[j]=i;q[tail++]=j}
        }}
        if(door>=0){
          const cells=new Set();for(let at=door;at>=0;at=parent[at])cells.add(at);
          const cx=center%n,cy=center/n|0;for(let y=cy-1;y<=cy+1;y++)for(let x=cx-1;x<=cx+1;x++)cells.add(y*n+x);
          md.secret={cells:[...cells],door,center,revealed:false,ground:md.biome==='ice'?7:md.biome==='iridium'?11:md.biome==='magma'?4:15};
          md.resources.push({k:'ore_stone',caveId:'secret-wall',x:(door%n)*TS+8,y:(door/n|0)*TS+8,r:7,hp:4,maxHp:4,col:'#b3c3c7',gold:0,isOre:true,mined:false,isSecret:true});
          md.chests.push({id:'secret',x:cx*TS+8,y:cy*TS+8,opened:false,t:0,dungeon:true,hidden:true,gold:80+md.floor*6,gems:4,reward:gen(2+Math.floor(md.floor*.45),2,random)});
        }
      }
    }
    this.restore(md);return md;
  },
  reveal(md,quiet=false){
    if(!md?.secret||md.secret.revealed)return false;
    md.secret.revealed=true;for(const cell of md.secret.cells)md.tl[cell]=md.secret.ground;
    for(const c of md.chests)if(c.id==='secret')c.hidden=false;
    const seal=md.resources.find(r=>r.isSecret);if(seal){seal.mined=true;seal.hp=0}
    this.redrawMap(md);
    if(!quiet){P.adventure.stats.secrets=(P.adventure.stats.secrets||0)+1;ban('✦ GİZLİ ODA KEŞFEDİLDİ!','#b9f0df');FX.flash(P.x,P.y-8,60,1,.3);sv()}
    return true;
  },
  redrawMap(md){const c=md.mmc.getContext('2d');for(let y=0;y<md.N;y++)for(let x=0;x<md.N;x++){c.fillStyle=MAP_COLORS[md.tl[y*md.N+x]]||'#172131';c.fillRect(x,y,1,1)}},
  capture(){
    const md=WORLD_DATA.mine,a=P.adventure;if(!a||!md||md.day!==P.day)return;
    if(a.caves.day!==P.day){a.caves.day=P.day;a.caves.floors={}}
    a.caves.floors[md.floor]={resources:Object.fromEntries(md.resources.map(r=>[r.caveId,{mined:!!r.mined,hp:r.hp}])),mobs:Object.fromEntries(md.mobs.filter(m=>m.caveId).map(m=>[m.caveId,{dead:!!m.dead,hp:m.hp}])),chests:md.chests.filter(c=>c.opened).map(c=>c.id),traps:md.traps.filter(t=>t.spent).map(t=>({id:t.id,disarmed:!!t.disarmed})),secret:!!md.secret?.revealed,ladder:!!md.ladder?.uncovered};
  },
  restore(md){
    const a=P.adventure;if(!a||a.caves.day!==P.day)return;const old=a.caves.floors[md.floor];if(!old)return;
    if(old.secret||old.resources?.['secret-wall']?.mined)this.reveal(md,true);
    for(const r of md.resources){const saved=old.resources?.[r.caveId];if(saved){r.mined=!!saved.mined;r.hp=cl(Number(saved.hp)||0,0,r.maxHp)}}
    for(const m of md.mobs){const saved=old.mobs?.[m.caveId];if(saved){m.dead=!!saved.dead;m.hp=m.dead?0:cl(Number(saved.hp)||m.mhp,1,m.mhp)}}
    for(const c of md.chests)if(old.chests?.includes(c.id)){c.opened=true;c.t=Infinity}
    for(const t of md.traps){const saved=old.traps?.find(x=>x.id===t.id);if(saved){t.spent=true;t.disarmed=!!saved.disarmed}}
    if(md.ladder)md.ladder.uncovered=!!old.ladder;
  },
  openChest(c){
    if(!c||c.opened||c.hidden||curMap!=='mine'||Math.hypot(P.x-c.x,P.y-c.y)>22)return false;
    if(!ITEMS.add(P.inv,c.reward)){inventoryNotice(c,'Hazine korunuyor; çantada bir göz aç.',.1);return false}
    c.opened=true;c.t=Infinity;P.gold+=c.gold;P.gems+=c.gems;P.ach.chests_opened=(P.ach.chests_opened||0)+1;
    checkAch('chests');P.adventure.stats.caveChests=(P.adventure.stats.caveChests||0)+1;
    FX.flash(c.x,c.y-5,46,0,.3);fl(c.x,c.y-28,`🎁 +${c.gold}🪙 +${c.gems}💎`,'#ffe09d',true);playChord([523,659,784],.3,'triangle',.05);sv();return true;
  },
  step(dt){
    if(curMap!=='mine'||P.dead)return;const md=WORLD_DATA.mine;if(!md?.traps)return;
    for(const t of md.traps){
      if(t.spent)continue;const d=Math.hypot(P.x-t.x,P.y-t.y);
      if(!t.wind&&d<20)t.wind=.001;
      if(t.wind>0){t.wind+=dt;if(t.wind>=.75){t.spent=true;if(d<18)hurtP(Math.round(8+md.floor*.55));FX.flash(t.x,t.y,30,t.kind==='flame'?4:0,.2);FX.sparks(t.x,t.y-3,12,'#e7c48d',65,true);sfx(140,.16,'sawtooth',.04);sv()}}
    }
  },
  disarm(t){
    if(!t||t.spent||curMap!=='mine'||Math.hypot(P.x-t.x,P.y-t.y)>34||!WORLD_DATA.mine.traps.includes(t))return false;
    if(P.mp<8){inventoryWarning('Tuzağı çözmek için 8 mana gerekiyor.');return false}
    P.mp-=8;t.spent=true;t.disarmed=true;P.adventure.stats.disarms=(P.adventure.stats.disarms||0)+1;addMasteryXp('mine',6);fl(t.x,t.y-18,'✓ Tuzak çözüldü','#a7f3d0');sv();return true;
  },
  prompt(){
    if(curMap!=='mine')return null;const md=WORLD_DATA.mine;
    const trap=md?.traps?.find(t=>!t.spent&&Math.hypot(P.x-t.x,P.y-t.y)<30);
    if(trap)return {text:'⚠️ Tuzağı Etkisizleştir · 8 Mana',fn:()=>this.disarm(trap)};
    const seal=md?.resources.find(r=>r.isSecret&&!r.mined&&Math.hypot(P.x-r.x,P.y-r.y)<32);
    if(seal)return {text:'⛏️ Çatlak Duvarı Kır',fn:()=>{if(curMap==='mine'&&Math.hypot(P.x-seal.x,P.y-seal.y)<34){selectTool('pickaxe');strikeOre(seal,1)}}};
    return null;
  },
  draw(){
    if(curMap!=='mine')return;const md=WORLD_DATA.mine;g.save();
    for(const t of md?.traps||[]){if(!FX.visible(t.x,t.y,24))continue;
      const color=t.spent?'#65726b':t.wind?'#f3976e':'#c19b64';
      R(t.x-5,t.y-3,10,5,'#25303c');R(t.x-4,t.y-3,8,1,color);
      if(!t.spent)for(let i=-3;i<=3;i+=3){R(t.x+i,t.y-4,1,4,color)}
      if(t.wind&&!t.spent){g.strokeStyle='#ef986f';g.lineWidth=1;g.beginPath();g.ellipse(t.x,t.y,18,12,0,0,Math.PI*2);g.stroke();g.globalAlpha=.12;g.fillStyle='#ef704e';g.fill();g.globalAlpha=1}
    }
    g.restore();
  }
};
const BOND=window.BOND={
  species:{mountain_goat:{name:'Yayla Keçisi',icon:'🐐',food:'wheat',foodName:'Buğday',mount:true},deer:{name:'Orman Geyiği',icon:'🦌',food:'carrot',foodName:'Havuç',mount:true},desert_fox:{name:'Çöl Tilkisi',icon:'🦊',food:'fish',foodName:'Balık',mount:false}},current:null,
  syncMap(md,id){if(!md||!P.adventure)return;const names=['Bulut','Boncuk','Kehribar','Fidan','Tarçın','Rüzgâr','Kıvılcım','Yaprak'];md.critters.forEach((c,i)=>{c.bondId=id+':'+c.type+':'+i;c.bondMap=id;c.bondName=names[i%names.length];c.tamed=!!P.adventure.captured[c.bondId]})},
  nearest(){if(!['world','frontier'].includes(curMap))return null;let best=null,dist=48;for(const c of critters){const d=Math.hypot(c.x-P.x,c.y-P.y);if(!c.dead&&!c.tamed&&this.species[c.type]&&d<dist){best=c;dist=d}}return best},
  open(c){if(!c||c.dead||c.tamed||!this.species[c.type]||curMap!==c.bondMap||!critters.includes(c)||Math.hypot(P.x-c.x,P.y-c.y)>58)return false;this.current=c;$('bond-modal').classList.remove('h');this.encounterUI();return true},
  encounterUI(){
    const c=this.current;if(!c)return;const d=this.species[c.type],state=P.adventure.taming[c.bondId]||{trust:0,lastDay:0},owned=!!P.adventure.captured[c.bondId];
    $('bond-content').innerHTML=`<div class="journey-lead"><small>VAHŞİ HAYVAN DOSTLUĞU</small><h2>${d.icon} ${escapeHTML(c.bondName||d.name)}</h2><p>${d.name} · ${d.mount?'Güveni tamamlanınca açık arazide binebilirsin.':'Güveni tamamlanınca savaşta ve hasatta yardımcı yoldaş olur.'}</p></div><div class="bond-hearts">${'♥'.repeat(state.trust||0)}${'♡'.repeat(3-(state.trust||0))}</div><p>3 ayrı oyun gününde 1 ${d.foodName} ver. Aynı gün tekrar yem tüketilmez.</p><p>Çantanda ${countInv(d.food)} ${d.foodName}</p><button id="bond-feed" ${owned||state.lastDay===P.day?'disabled':''}>${owned?'✓ Dostluğa Katıldı':state.lastDay===P.day?'Bugün beslendi · yarın devam et':`1 ${d.foodName} Ver`}</button><p id="bond-status" class="inventory-status" role="status"></p>`;
  },
  feed(c=this.current){
    if(!c||!this.species[c.type]||curMap!==c.bondMap||!critters.includes(c)||c.dead||c.tamed||Math.hypot(P.x-c.x,P.y-c.y)>58)return 'Hayvana yeniden yaklaş.';
    const a=P.adventure,d=this.species[c.type],state=a.taming[c.bondId]||(a.taming[c.bondId]={trust:0,lastDay:0});
    if(state.lastDay===P.day)return 'Bugün beslendi; yarın tekrar gel.';
    if(a.roster.length>=6)return '6 hayvanlık dostluk alanın dolu.';
    if(!inventoryRecipe({[d.food]:1}).ok)return `Çantanda 1 ${d.foodName} gerekiyor.`;
    state.trust=Math.min(3,state.trust+1);state.lastDay=P.day;c.st='idle';c.t=4;
    if(state.trust===3){
      const id='bond-'+c.bondId,animal={id,type:c.type,name:c.bondName||d.name,lvl:1,xp:0,day:P.day};a.roster.push(animal);a.captured[c.bondId]=id;c.tamed=true;
      if(d.mount&&!a.mountId)a.mountId=id;
      ban(`${d.icon} ${d.name} Artık Dostun!`,'#bbebc0');
    }
    playChord([523,659,784],.25,'sine',.04);sv();return state.trust===3?'✓ Dostun Yolcu Defteri’nde seni bekliyor.':`Güven ${state.trust}/3 · başka bir gün tekrar gel.`;
  },
  lineClear(a,b){const n=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/8));for(let i=1;i<n;i++)if(tAt(a.x+(b.x-a.x)*i/n,a.y+(b.y-a.y)*i/n)===14)return false;return true},
  storePet(){const p=P.pet;if(!P.adventure||!p)return;if(p.rosterId){const r=P.adventure.roster.find(r=>r.id===p.rosterId);if(r){r.lvl=p.lvl;r.xp=p.xp}}else P.adventure.legacyPet={lvl:p.lvl,xp:p.xp}},
  equip(id){const r=P.adventure.roster.find(r=>r.id===id&&!this.species[r.type].mount);if(!r)return false;this.storePet();P.pet={...P.pet,type:'fox',rosterId:r.id,name:r.name,lvl:r.lvl||1,xp:r.xp||0,x:P.x-12,y:P.y,biteCd:0};sv();return true},
  legacy(type){this.storePet();const old=P.adventure.legacyPet||{lvl:1,xp:0};Object.assign(P.pet,{type,name:type==='dragon'?'Kızıl Ejder':'Bozkurt',lvl:old.lvl,xp:old.xp});delete P.pet.rosterId},
  ride(id=P.adventure.mountId){
    const a=P.adventure;if(a.mounted){this.dismount();return true}
    const animal=a.roster.find(r=>r.id===id&&this.species[r.type].mount);
    if(!animal){ADVENTURE.open('bond');return false}
    if(!['home','world','frontier'].includes(curMap)){inventoryWarning('Binekler yalnız açık arazide kullanılabilir.');return false}
    if(a.energy<10){inventoryWarning('Bineğin yoruldu. İnmiş halde biraz dinlen veya uyu.');return false}
    a.mountId=id;a.mounted=true;P.fs=null;sfx(550,.12,'triangle',.04);sv();return true;
  },
  dismount(){if(P.adventure)P.adventure.mounted=false},
  step(dt,moving){
    const a=P.adventure;if(!a)return;
    a.energy=cl(a.energy+(a.mounted?(moving?-2.5:1):4)*dt,0,100);
    if(a.mounted&&a.energy<=0){this.dismount();fl(P.x,P.y-30,'Bineğin yoruldu · biraz dinlensin.','#fbd48f',true)}
  },
  html(){const a=P.adventure;return `<div class="journey-lead"><small>GÜVEN · YOLCULUK · YOLDAŞLIK</small><h2>🐾 Vahşi Dostlar</h2><p>Geyik, yayla keçisi ve çöl tilkisini üç ayrı günde besle. Kalıcı olarak ${a.roster.length}/6 dost edindin.</p></div><div class="journey-box"><b>Binek enerjisi · ${Math.floor(a.energy)}/100</b><p>Binek +%45 yolculuk hızı sağlar; suyu ve duvarı aşamaz. Saldırı, dash, hasar veya kapalı alana girişte inilir. Z tuşu ile bin/in.</p></div>${a.roster.map(r=>{const d=this.species[r.type];return `<div class="journey-box title-row"><div><b>${d.icon} ${escapeHTML(r.name)}</b><p>${d.mount?'Binek':`Savaş yoldaşı · Sv.${r.lvl||1}`}</p></div><button ${d.mount?'data-mount':'data-companion'}="${escapeHTML(r.id)}">${d.mount?(a.mounted&&a.mountId===r.id?'İn':'Bin'):'Yoldaş Yap'}</button></div>`}).join('')||'<div class="journey-box"><b>İlk dostluk rotası</b><p>Yayla keçisi: 🌾 Buğday<br>Orman geyiği: 🥕 Havuç<br>Çöl tilkisi: 🐟 Balık<br>Yaklaşınca çıkan “Güven Kazan” etkileşimini kullan.</p></div>'}`},
  drawMount(x,y){
    const r=P.adventure?.roster.find(r=>r.id===P.adventure.mountId);if(!P.adventure?.mounted||!r)return;
    const deer=r.type==='deer',c=deer?'#a7764d':'#bcc4b6',hoof='#35413d',step=Math.sin(P.w*2)*1.5;
    if(P.f===0||P.f===1){R(x-6,y-8,12,13,c);R(x-6,y+2+step,3,5,hoof);R(x+3,y+2-step,3,5,hoof);const headY=P.f===1?y-15:y-1;R(x-4,headY,8,8,c);R(x-4,headY-4,2,5,'#e1cfaa');R(x+2,headY-4,2,5,'#e1cfaa');if(P.f===0){R(x-3,headY+2,1,1,hoof);R(x+2,headY+2,1,1,hoof);R(x-2,headY+6,4,1,deer?'#77563d':'#7e8c83')}}
    else{const f=P.f===2?-1:1;R(x-10,y-8,20,10,c);R(x-8,y+1+step,3,6,hoof);R(x+5,y+1-step,3,6,hoof);R(x+f*9-3,y-14,7,8,c);R(x+f*10-3,y-18,2,6,'#ead7b0');R(x+f*10+1,y-18,2,6,'#ead7b0');R(x+f*12,y-12,1,1,'#17242d')}
    R(x-5,y-9,10,5,'#684838');R(x-4,y-9,8,1,'#dbb877');
  }
};
const ELEMENTS=window.ELEMENTS={
  wet(e){return (e.wet||0)>0||['world','frontier','home'].includes(curMap)&&isWetWeather()||tAt(e.x,e.y)===1},
  splash(x,y){
    if(P.waterCan<=0)return false;const targets=mobs.filter(m=>!m.dead&&Math.hypot(m.x-x,m.y-y)<26);if(!targets.length)return false;
    P.waterCan--;for(const m of targets){m.wet=8;FX.sparks(m.x,m.y-6,7,'#7dd3fc',30);fl(m.x,m.y-25,'ISLAK · 8s','#7dd3fc')}
    sfx(700,.1,'sine',.04);sv();return true;
  },
  enchant(it){
    if(!it||it.s!=='weapon'||!forgeItems().includes(it)){inventoryWarning('Önce bir silah kuşan veya demircide seç.');return false}
    if(it.element==='lightning'){inventoryWarning('Bu silah zaten fırtına rünlü.');return false}
    if(!tryInventoryRecipe({copper_ore:2,coal:2},[],{gold:60}))return false;
    it.element='lightning';sv();return true;
  },
  chain(e,damage){
    if(!this.wet(e)||(P.shockCd||0)>0)return false;P.shockCd=.65;
    P.adventure.stats.waterShocks=(P.adventure.stats.waterShocks||0)+1;
    FX.flash(e.x,e.y-5,52,1,.24);fl(e.x,e.y-30,'⚡ ALAN ELEKTRİĞİ','#b9ebff',true);
    let count=0;for(const m of mobs){if(m===e||m.dead||m.hp<=0||Math.hypot(m.x-e.x,m.y-e.y)>55||!BOND.lineClear(e,m))continue;
      hitMob(m,Math.max(1,Math.round(damage*.6)),false,0,0,false,false,true,true);
      for(let i=0;i<7;i++){const t=i/6;FX.emit(e.x+(m.x-e.x)*t,e.y-7+(m.y-e.y)*t,0,0,.15,'#c3f1ff',1.5,0)}
      if(++count>=6)break;
    }return true;
  },
  strike(e,damage){if(!e||e.dead)return;hitMob(e,damage,false,0,0,false,false,true,true);if(!e.dead)this.chain(e,damage)},
  reflect(p){
    if(P.dead||!p||p.isHero||P.parryWindow<=0)return false;
    const speed=Math.max(150,Math.hypot(p.vx,p.vy)),len=Math.hypot(p.vx,p.vy)||1,dx=-p.vx/len,dy=-p.vy/len;
    p.vx=(dx||(!dy?1:0))*speed;p.vy=dy*speed;p.x=P.x+dx*14;p.y=P.y-10+dy*14;p.t=Math.max(.75,p.t);p.isHero=true;p.reflected=true;p.col='#a0eeff';p.kind=p.kind||'orb';p.dmg=Math.max(p.dmg||0,Math.round(S.a*.9));
    P.parryWindow=0;P.iv=Math.max(P.iv,.3);P.rage=Math.min(100,(P.rage||0)+18);
    FX.hitStop(5);FX.flash(P.x,P.y-10,35,1,.2);fl(P.x,P.y-28,'🛡 YANSITILDI!','#b9efff',true);sfx(900,.1,'sine',.05);return true;
  }
};
function isWetWeather(){return weather.type==='rain'||weather.type==='storm'}
$('bjourney').onclick=()=>ADVENTURE.open();
$('btalent').onclick=()=>{closeQuickMenu();GAME_CORE.offerTalent(true)};
$('bride').onclick=()=>{if(BOND.ride())$('pet-modal').classList.add('h')};
$('journey-close').onclick=()=>$('journey-modal').classList.add('h');
$('bond-close').onclick=()=>{$('bond-modal').classList.add('h');BOND.current=null};
$('journey-modal').onclick=e=>{
  const b=e.target.closest('button');if(!b)return;
  if(b.dataset.journeyTab){ADVENTURE.tab=b.dataset.journeyTab;ADVENTURE.ui()}
  else if(b.dataset.expeditionStart)EXPEDITIONS.start(b.dataset.expeditionStart)
  else if(b.dataset.expeditionReward)EXPEDITIONS.claim(b.dataset.expeditionReward)
  else if(b.dataset.expeditionAbandon)EXPEDITIONS.abandon()
  else if(b.dataset.expeditionTravel){const e=EXPEDITIONS.state();if(e){$('journey-modal').classList.add('h');EXPEDITIONS.travel(EXPEDITIONS.defs[e.id])}}
  else if(b.dataset.expeditionHome){$('journey-modal').classList.add('h');switchMap('home')}
  else if(b.dataset.goalPin){GOALS.pin(b.dataset.goalPin);ADVENTURE.ui()}
  else if(b.dataset.goalsAction)GOALS.open(b.dataset.goalsAction)
  else if(b.dataset.decisionOpen){$('journey-modal').classList.add('h');DECISIONS.play(b.dataset.decisionOpen)}
  else if(b.dataset.questMap){$('journey-modal').classList.add('h');const nav=navigationTarget();openMap(nav?.map)}
  else if(b.dataset.questBag)QUEST_FLOW.openPreparation()
  else if(b.dataset.dailyFocus)DAILY_FOCUS.select(b.dataset.dailyFocus)
  else if(b.dataset.goalOpen)ECONOMY.openGoal(b.dataset.goalOpen)
  else if(b.dataset.onboard==='skip')ONBOARD.skip();
  else if(b.dataset.onboard==='recover')ONBOARD.recover();
  else if(b.dataset.onboard==='chest')ONBOARD.chestAid();
  else if(b.dataset.buildStart)BUILD.start(b.dataset.buildStart,b.dataset.materialPick?$('build-material-select')?.value:undefined);
  else if(b.dataset.buildMoveId)BUILD.startMove(b.dataset.buildMoveId);
  else if(b.dataset.buildAction==='undo'){BUILD.undo();ADVENTURE.ui()}
  else if(b.dataset.buildAction==='redo'){BUILD.redo();ADVENTURE.ui()}
  else if(b.dataset.buildRemove)BUILD.remove(b.dataset.buildRemove);
  else if(b.dataset.workshop)BUILD.craft(b.dataset.workshop);
  else if(b.dataset.title){JOURNAL.select(b.dataset.title);ADVENTURE.ui()}
  else if(b.dataset.mount){if(BOND.ride(b.dataset.mount))$('journey-modal').classList.add('h')}
  else if(b.dataset.companion){BOND.equip(b.dataset.companion);ADVENTURE.ui()}
  else if(b.dataset.journeyAction==='bestiary'){$('journey-modal').classList.add('h');$('bestiary-modal').classList.remove('h');bestiaryUI()}
  else if(b.dataset.journeyAction==='simple-garden'){$('journey-modal').classList.add('h');FARM.openUI('simple')}
  else if(b.dataset.journeyAction==='fertilize'){const result=FARM.fertilizeFront();ADVENTURE.ui();ADVENTURE.notice(result)}
};
$('bond-content').onclick=e=>{if(!e.target.closest('#bond-feed'))return;const message=BOND.feed();BOND.encounterUI();$('bond-status').textContent=message};
$('build-controls').onclick=e=>{const b=e.target.closest('[data-build-move]');if(b){const [dx,dy]=b.dataset.buildMove.split(',').map(Number);BUILD.move(dx,dy);return}if(e.target.closest('#build-rotate'))BUILD.rotate();else if(e.target.closest('#build-undo'))BUILD.undo();else if(e.target.closest('#build-redo'))BUILD.redo()};
$('build-confirm').onclick=()=>BUILD.confirm();$('build-cancel').onclick=()=>BUILD.cancel();
if($('bgarden'))$('bgarden').onclick=()=>{closeQuickMenu();FARM.openUI('beds')};
if($('gardenc'))$('gardenc').onclick=()=>$('garden-modal').classList.add('h');
if($('garden-tabs'))$('garden-tabs').onclick=e=>{
  const b=e.target.closest('[data-gtab]');if(!b)return;
  FARM.uiTab=b.dataset.gtab;FARM.status('');FARM.renderUI();
};
if($('garden-content'))$('garden-content').onclick=e=>{
  const jump=e.target.closest('[data-gtab-jump]');
  if(jump){FARM.uiTab=jump.dataset.gtabJump;FARM.status('');FARM.renderUI();return}
  const seedBtn=e.target.closest('[data-g-seed]');
  if(seedBtn){P.seedSel=seedBtn.dataset.gSeed;updHotbarUI();sv();FARM.status(`✓ ${CROPS[P.seedSel]?.n||''} seçildi. Günlük bakım boş alanlara bu tohumu ekecek.`);FARM.renderUI();return}
  const buyBtn=e.target.closest('[data-sd]');
  if(buyBtn){FARM.buy(buyBtn.dataset.sd,+buyBtn.dataset.qty);return}
  const actBtn=e.target.closest('[data-g-act]');
  if(actBtn){
    const act=actBtn.dataset.gAct;
    let msg='';
    if(act==='daily-care')msg=FARM.dailyCare();
    else if(act==='harvest-all')msg=FARM.harvestAll();
    else if(act==='plant-all')msg=FARM.plantAll();
    else if(act==='water-all')msg=FARM.waterAll();
    else if(act==='fert-all')msg=FARM.fertilizeAll();
    else if(act==='orchard-harvest')msg=FARM.harvestOrchardAll();
    FARM.status(msg);FARM.renderUI();return;
  }
  const plotCard=e.target.closest('[data-g-plot]');
  if(plotCard){
    const pid=+plotCard.dataset.gPlot;
    FARM.selectedPlotId=pid;FARM.status('Seçili tarla karesinin ayrıntıları aşağıda gösteriliyor.');FARM.renderUI();return;
  }
  const pAct=e.target.closest('[data-g-plot-act]');
  if(pAct){
    const pid=+pAct.dataset.pid,act=pAct.dataset.gPlotAct;
    const p=(WORLD_DATA.home?.farmPlots||[]).find(x=>x.id===pid);let msg='İşlem yapılamadı.';
    if(p){
      if(act==='harvest'){const c=CROPS[p.crop],got=FARM.harvest(p);if(got)msg=`✓ ${got} ${c?.n||'ürün'} hasat edildi.`}
      else if(act==='plant'){const k=FARM.curSeed(),c=CROPS[k];if(FARM.plant(p)){FARM.waterPlot(p,true);msg=`✓ ${c?.n||'Tohum'} ekildi ve ilk suyu verildi.`}}
      else if(act==='water'){if(FARM.waterPlot(p))msg='✓ Toprak sulandı; ürün yeni günde büyüyebilir.';else msg='Bu alan zaten yeterince nemli.'}
      else if(act==='fert'&&(P.fert||0)>0&&!p.fert){P.fert--;p.fert=1;spark(p.x,p.y-6,10,'#b4ef98',30);sv();msg='✓ Toprak gübrelendi.'}
      else if(act==='clear'){FARM.clearPlot(p);sv();msg='✓ Solmuş ekin temizlendi; alan yeniden ekime hazır.'}
    }
    FARM.status(msg);FARM.renderUI();return;
  }
  const unlockBed=e.target.closest('[data-g-unlock-bed]');
  if(unlockBed){const msg=FARM.unlockBed(+unlockBed.dataset.gUnlockBed);FARM.status(msg);FARM.renderUI();return}
  const treePlant=e.target.closest('[data-g-tree-plant]');
  if(treePlant){const msg=FARM.plantOrchardTree(+treePlant.dataset.gTreePlant);FARM.status(msg);FARM.renderUI();return}
  const treeHarvest=e.target.closest('[data-g-tree-harvest]');
  if(treeHarvest){
    const slot=+treeHarvest.dataset.gTreeHarvest;
    const tObj=(WORLD_DATA.home?.fruitTrees||[]).find(t=>t.slot===slot);
    if(tObj&&FARM.harvestTree(tObj))FARM.status('✓ Taze meyve toplandı!');
    FARM.renderUI();return;
  }
  const upBtn=e.target.closest('[data-g-up]');
  if(upBtn){
    const kind=upBtn.dataset.gUp;
    const msg=kind==='greenhouse'?FARM.unlockGreenhouse():kind==='sprinkler'?FARM.upgradeSprinkler():FARM.upgradeSoil();
    FARM.status(msg);FARM.renderUI();return;
  }
  const extBtn=e.target.closest('[data-g-extract]');
  if(extBtn){FARM.status(FARM.extractSeeds(extBtn.dataset.gExtract));FARM.renderUI();return}
  const compBtn=e.target.closest('[data-g-compost]');
  if(compBtn){FARM.status(FARM.makeCompost());FARM.renderUI();return}
  const artBtn=e.target.closest('[data-g-artisan]');
  if(artBtn){FARM.status(FARM.buildArtisan(artBtn.dataset.gArtisan));FARM.renderUI();return}
  const beeBtn=e.target.closest('[data-g-beehive]');
  if(beeBtn){FARM.status(FARM.collectBeehive());FARM.renderUI();return}
  const caskStart=e.target.closest('[data-g-cask-start]');
  if(caskStart){
    const ok=CASK.start(caskStart.dataset.gCaskStart);
    FARM.status(ok?'✓ Mayalama işlemi başladı!':'Eksik malzeme veya fıçı dolu.');
    FARM.renderUI();return;
  }
  const caskCol=e.target.closest('[data-g-cask-collect]');
  if(caskCol){
    const ok=CASK.collect();
    FARM.status(ok?'✓ Zanaat ürünü çantana eklendi!':'Çanta dolu veya ürün hazır değil.');
    FARM.renderUI();return;
  }
  const contractBtn=e.target.closest('[data-g-contract]');
  if(contractBtn){FARM.status(FARM.deliverContract(+contractBtn.dataset.gContract));FARM.renderUI();return}
  const mileBtn=e.target.closest('[data-g-milestone]');
  if(mileBtn){FARM.status(FARM.claimMilestone());FARM.renderUI();return}
};
if($('farm-hud'))$('farm-hud').onclick=e=>{
  const b=e.target.closest('[data-fh]');if(!b)return;
  if(b.dataset.fh==='care'){
    const msg=FARM.dailyCare();
    fl(P.x,P.y-30,msg,'#86efac',true);
  }else if(b.dataset.fh==='panel')FARM.openUI('simple');
  $('farm-hud').dataset.hudKey='';
};
cv.addEventListener('pointerdown',e=>{
  if(!BUILD.active){
    if(curMap==='home'&&!GAME_CORE.busy()){
      const box=cv.getBoundingClientRect();
      const wx=(e.clientX-box.left)*LW/box.width+FX.viewX;
      const wy=(e.clientY-box.top)*LH/box.height+FX.viewY;
      // 1) Bahçe Yönetim Tabelası (18*TS, 24*TS)
      if(Math.hypot(wx-18*TS,wy-24*TS)<24){FARM.openUI('beds');return}
      // 2) Doğrudan Açık Bahçe Parseline Dokunma
      const tappedPlot=FARM.plotAt(wx,wy);
      if(tappedPlot){
        FARM.selectedPlotId=tappedPlot.id;
        FARM.smartTileAction(tappedPlot);
        if($('farm-hud'))$('farm-hud').dataset.hudKey='';
        return;
      }
      // 3) Kilitli 2. veya 3. Bahçe Yatağına Dokunma
      const h=FARM.cfg(),gx=Math.floor(wx/TS),gy=Math.floor(wy/TS);
      if(h.beds<2&&gx>=15&&gx<=18&&gy>=30&&gy<=32){FARM.openUI('upgrades');return}
      if(h.beds<3&&gx>=20&&gx<=22&&gy>=26&&gy<=32){FARM.openUI('upgrades');return}
      // 4) Kuzey Meyve Bahçesi Ağaçlarına veya Fidan Noktalarına Dokunma
      const tappedTree=(WORLD_DATA.home?.fruitTrees||[]).find(t=>Math.hypot(wx-t.x,wy-(t.y-12))<18);
      if(tappedTree){
        if(tappedTree.fruitReady)FARM.harvestTree(tappedTree);
        else FARM.openUI('orchard');
        return;
      }
      const tappedSlot=ORCHARD_SLOTS.find(s=>Math.hypot(wx-s.gx*TS,wy-s.gy*TS)<16);
      if(tappedSlot){FARM.openUI('orchard');return}
      // 5) Güney Zanaat Terası (Arı Kovanı, Fıçı, Tohum Islah & Kompost)
      if(Math.hypot(wx-16*TS,wy-35*TS)<18){
        if(P.hasBeehive&&P.honeyReady)FARM.collectBeehive();
        else FARM.openUI('orchard');
        return;
      }
      if(Math.hypot(wx-19*TS,wy-35*TS)<18){
        if(P.hasCask){$('cask-modal').classList.remove('h');caskUI()}
        else FARM.openUI('orchard');
        return;
      }
      if(Math.hypot(wx-21*TS,wy-35*TS)<18){FARM.openUI('seeds');return}
    }
    return;
  }
  const box=cv.getBoundingClientRect();BUILD.active.gx=Math.floor(((e.clientX-box.left)*LW/box.width+FX.viewX)/TS);BUILD.active.gy=Math.floor(((e.clientY-box.top)*LH/box.height+FX.viewY)/TS);BUILD.refresh();e.preventDefault();
});
