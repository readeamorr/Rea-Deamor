/* ===== GÜNCELLEME DÖNGÜSÜ ===== */
function restAtWorldOutpost(type){
  const site=WORLD_OUTPOSTS[type];
  if(curMap!=='world'||!site||Math.hypot(P.x-(site.x*TS+8),P.y-((site.y+1)*TS+8))>42)return;
  P.restDays=P.restDays||{};
  if(P.restDays[type]===P.day){fl(P.x,P.y-24,'Bugün burada zaten dinlendin.','#e2e8f0');return}
  P.restDays[type]=P.day;
  if(type==='marsh'){
    P.mp=Math.min(S.m,P.mp+55);P.hp=Math.min(S.h,P.hp+20);
    fl(P.x,P.y-28,'🍄 Sazlık çayı: +55 Mana, +20 Can','#a7f3d0',true);
  }else if(type==='frost'){
    P.hp=Math.min(S.h,P.hp+70);P.buffs.spd=Math.max(P.buffs.spd||0,35);
    fl(P.x,P.y-28,'❄️ Kar sığınağı: +70 Can, 35 sn Hız','#d5f7ff',true);
  }else if(type==='oasis'){
    P.hp=Math.min(S.h,P.hp+35);P.mp=Math.min(S.m,P.mp+30);P.waterCan=20;
    fl(P.x,P.y-28,'🌴 Vaha: +35 Can, +30 Mana, kova dolu','#c7f2d3',true);
  }
  S=st();playChord([523,659,784],.22,'triangle',.04);sv();
}

function claimLakeBait(){
  const site=LAKE_DOCK;
  if(curMap!=='world'||Math.hypot(P.x-(site.x*TS+8),P.y-((site.y+1)*TS+8))>42)return;
  if(P.lakeBaitDay===P.day){fl(P.x,P.y-24,'Bugünün yemini aldın; yarın yine gel.','#bde8d8');return}
  P.lakeBait=3;P.lakeBaitDay=P.day;
  fl(P.x,P.y-28,'🎣 3 göl yemi: Turna şansı arttı!','#8de3d8',true);
  sfx(640,.15,'triangle',.05);sv();
}

function tradeSeaFish(){
  if(curMap!=='world'||Math.hypot(P.x-(SEA_PORT.x*TS+8),P.y-((SEA_PORT.y+1)*TS+8))>46)return;
  const catchOfDay=P.inv.filter(it=>it.s==='fish'&&it.origin==='sea');
  if(!catchOfDay.length){fl(P.x,P.y-24,'İskelede deniz balığı tut, limana getir.','#a7d8e8');return}
  const gold=Math.round(catchOfDay.reduce((sum,it)=>sum+unitSaleValue(it),0)*1.25);
  P.inv=P.inv.filter(it=>it.s!=='fish'||it.origin!=='sea');
  P.gold+=gold;ECONOMY.recordMany(catchOfDay);
  fl(P.x,P.y-26,`⚓ ${catchOfDay.length} deniz balığı: +${gold}🪙`,'#ffd23f',true);
  sfx(880,.12,'sine',.05);sv();
}

function nearFrontierCamp(){
  return curMap==='frontier'&&Math.hypot(P.x-(FRONTIER.camp.x*TS+8),P.y-((FRONTIER.camp.y+1)*TS+8))<46;
}
function buildFrontierCamp(){
  if(!nearFrontierCamp()||P.hasFieldCamp)return;
  const wood=countInv('wood'),stone=countInv('stone');
  if(P.gold<90||wood<8||stone<6){
    fl(P.x,P.y-26,`🏕️ Gereken: 90🪙 · 8 Odun · 6 Taş (Şimdi ${wood}/${stone})`,'#fbbf77',true);return;
  }
  if(!tryInventoryRecipe({wood:8,stone:6},[],{gold:90}))return;
  P.hasFieldCamp=true;
  const md=WORLD_DATA.frontier;
  const idx=md.objs.findIndex(o=>o.k==='camp_marker');if(idx>=0)md.objs.splice(idx,1);
  P.fieldCampLevel=1;
  md.hs.push({x:FRONTIER.camp.x*TS+8,y:FRONTIER.camp.y*TS+8,c:'#a5674b',type:'field_camp',level:1,title:'Yayla Kampı Sv.1 🏕️'});
  md.atlas=buildFrontierAtlas(md.tl,md.objs,md.hs);
  drawFieldCampMinimap(md.mmc,1);
  ban('🏕️ Yayla Kampı Kuruldu!','#c9f3bf');playChord([523,659,784],.22,'triangle',.05);sv();
}
function restFrontierCamp(){
  if(!nearFrontierCamp()||!P.hasFieldCamp)return;
  if(P.fieldCampRestDay===P.day){fl(P.x,P.y-24,'Bugün kampta dinlendin.','#dcebc5');return}
  P.fieldCampRestDay=P.day;
  P.hp=Math.min(S.h,P.hp+50);P.mp=Math.min(S.m,P.mp+35);
  fl(P.x,P.y-24,'🏕️ +50 Can · +35 Mana','#b8f5c4',true);sv();
}
const CAMP_UPGRADES={
  2:{name:'Saha Deposu',gold:130,wood:10,stone:6,iron_ore:3,desc:'Yaylada 12 gözlü ayrı bir depo kurar; malzemeler 99’luk yığınlanır.'},
  3:{name:'Gözetleme Kulesi',gold:220,wood:14,stone:10,iron_ore:5,desc:'Depoyu 20 göze çıkarır; canlı kaynak ve sandıkları haritada işaretler.'}
};
function campStorageCapacity(){return P.fieldCampLevel>=3?20:12}
function campItemCount(k){
  return countInv(k)+(P.fieldCampLevel>=2?ITEMS.count(P.fieldCampStorage,k):0);
}
function upgradeFrontierCamp(target){
  if(!nearFrontierCamp()||!P.hasFieldCamp||target!==P.fieldCampLevel+1)return 'Önceki yapı aşaması gerekli.';
  const recipe=CAMP_UPGRADES[target];if(!recipe)return 'Kamp en yüksek seviyede.';
  const missing=[];
  if(P.gold<recipe.gold)missing.push(`${recipe.gold-P.gold} altın`);
  for(const k of ['wood','stone','iron_ore'])if(campItemCount(k)<recipe[k])missing.push(`${recipe[k]-campItemCount(k)} ${ {wood:'odun',stone:'taş',iron_ore:'demir cevheri'}[k] }`);
  if(missing.length)return `Eksik: ${missing.join(' · ')}`;
  const paid=inventoryRecipe({wood:recipe.wood,stone:recipe.stone,iron_ore:recipe.iron_ore},[],{gold:recipe.gold,camp:true});
  if(!paid.ok)return 'Malzemeler veya altın yetersiz; hiçbir şey harcanmadı.';
  P.fieldCampLevel=target;
  const md=WORLD_DATA.frontier,h=md?.hs.find(v=>v.type==='field_camp');
  if(h){h.level=target;h.title=`Yayla Kampı Sv.${target} 🏕️`}
  md.atlas=buildFrontierAtlas(md.tl,md.objs,md.hs);
  drawFieldCampMinimap(md.mmc,target);
  ban(`🏕️ ${recipe.name} Kuruldu!`,'#c9f3bf');playChord([523,659,784,1046],.3,'triangle',.055);
  sv();return null;
}
function fieldCampUI(){
  const level=P.fieldCampLevel||1,next=CAMP_UPGRADES[level+1];
  const cost=next?`<div style="text-align:left;background:#172e37;border:1px solid #52776d;border-radius:7px;padding:8px;margin-top:9px">
    <b style="color:#fcd897">Sv.${level+1} · ${next.name}</b><br>
    <span style="color:#cbd5e1;font-size:10px">${next.desc}</span><br>
    <span style="font-size:10px;color:#d5edd5">Gerekli / sende (çanta + depo): 🪙 ${next.gold}/${P.gold} · 🪵 ${next.wood}/${campItemCount('wood')} · 🪨 ${next.stone}/${campItemCount('stone')} · ⛓️ ${next.iron_ore}/${campItemCount('iron_ore')}</span><br>
    <button class="m" data-camp-upgrade="${level+1}" style="width:100%;margin:7px 0 0;padding:7px">🔨 ${next.name} İnşa Et</button>
  </div>`:'<p style="color:#a7f3d0">✔ Kampın tüm yapıları tamamlandı.</p>';
  $('field-camp-content').innerHTML=`
    <p style="color:#facc15;font-size:13px;font-weight:900">🏕️ Kamp Seviye ${level}/3</p>
    <p style="font-size:11px;color:#b7e4c7">${frontierClimateLabel()}</p>
    <p style="font-size:10px;color:#cbd5e1">Yol ve su kenarını kapatmayan bu parselde yapıların birlikte gelişir.</p>
    <button class="m" data-camp-action="rest" style="width:100%;margin:4px 0;padding:7px" ${P.fieldCampRestDay===P.day?'disabled':''}>${P.fieldCampRestDay===P.day?'💤 Bugün Dinlendin':'💤 Dinlen (+50 Can · +35 Mana)'}</button>
    ${level>=2?`<button class="m" data-camp-action="storage" style="width:100%;margin:4px 0;padding:7px">📦 Saha Deposu (${P.fieldCampStorage.length}/${campStorageCapacity()})</button>`:''}
    ${level>=3?'<button class="m" data-camp-action="scan" style="width:100%;margin:4px 0;padding:7px">🔭 Gözetleme Haritasını Aç</button>':''}
    ${cost}<p id="field-camp-error" role="status" style="min-height:14px;color:#fca5a5;font-size:10px"></p>`;
}
function openFieldCamp(){
  if(!nearFrontierCamp()||!P.hasFieldCamp)return;
  $('field-camp-modal').classList.remove('h');fieldCampUI();
}
$('field-camp-content').onclick=e=>{
  const upgrade=e.target.closest('[data-camp-upgrade]');
  if(upgrade){
    const error=upgradeFrontierCamp(+upgrade.dataset.campUpgrade);
    if(error)$('field-camp-error').textContent=error;
    else fieldCampUI();
    return;
  }
  const action=e.target.closest('[data-camp-action]')?.dataset.campAction;
  if(action==='rest'){restFrontierCamp();fieldCampUI()}
  else if(action==='storage'&&P.fieldCampLevel>=2){$('field-camp-modal').classList.add('h');$('storage-modal').classList.remove('h');storageUI()}
  else if(action==='scan'&&P.fieldCampLevel>=3){$('field-camp-modal').classList.add('h');openMap()}
};
$('fieldcampc').onclick=()=>$('field-camp-modal').classList.add('h');

const FRONTIER_MISSIONS=[
  {name:'Kervan Yolunu Onar',desc:'Harabe yolunu emniyete almak için odun ve taş getir.',needs:{wood:4,stone:3},gold:95,gems:2,rep:12},
  {name:'Fırtına Ölçer Kur',desc:'Karakolun rüzgâr ölçeri için demir ve taş getir.',needs:{iron_ore:2,stone:2},gold:160,gems:4,rep:18},
  {name:'Sürüyü Koru',desc:'Bu görev açıldıktan sonra yayladaki 3 yaban domuzunu uzaklaştır.',boars:3,gold:210,gems:6,rep:25}
];
function nearFrontierStation(){
  return curMap==='frontier'&&Math.hypot(P.x-(FRONTIER_STATION.x*TS+8),P.y-((FRONTIER_STATION.y+1)*TS+8))<50;
}
function frontierStationUI(){
  const stage=P.frontierMission||0,mission=FRONTIER_MISSIONS[stage],progress=Math.max(0,(P.frontierBoarsKilled||0)-(P.frontierBoarStart||0));
  let task='';
  if(mission){
    const needs=mission.boars?`🐗 Domuz: ${Math.min(progress,3)}/3`:
      Object.entries(mission.needs).map(([k,n])=>`${ {wood:'🪵 Odun',stone:'🪨 Taş',iron_ore:'⛓️ Demir'}[k] } ${countInv(k)}/${n}`).join(' · ');
    task=`<div style="text-align:left;background:#1e3643;border:1px solid #a8b991;border-radius:7px;padding:9px">
      <b style="color:#ffdda2">${stage+1}/3 · ${mission.name}</b><br>
      <span style="font-size:10px;color:#d4e4e2">${mission.desc}</span><br>
      <span style="font-size:11px;color:#86efac">${needs}</span><br>
      <span style="font-size:10px;color:#fcd34d">Ödül: ${mission.gold}🪙 · ${mission.gems}💎 · ${mission.rep} ⭐ İtibar</span><br>
      <button class="m" data-station-submit="1" style="width:100%;margin:6px 0 0;padding:7px">📦 Teslim Et</button>
    </div>`;
  }else{
    const done=P.frontierTradeDay===P.day;
    task=`<p style="color:#86efac">✔ Üç görev tamamlandı! Yol ve gözetleme karakolu hizmette.</p>
      <div style="text-align:left;background:#1e3643;border:1px solid #a8b991;border-radius:7px;padding:9px">
        <b style="color:#ffdda2">Günlük Kervan Erzağı</b><br>
        <span style="font-size:10px;color:#d4e4e2">3 odun + 2 taş getir; yalnız çantadaki malzemeler kabul edilir.</span><br>
        <span style="font-size:11px;color:#86efac">🪵 ${countInv('wood')}/3 · 🪨 ${countInv('stone')}/2</span><br>
        <span style="font-size:10px;color:#fcd34d">Ödül: 70🪙 · 5 ⭐ İtibar</span><br>
        ${done?'<span style="color:#a7f3d0;font-size:10px">Bugün teslim edildi; yarın yenilenir.</span>':'<button class="m" data-station-submit="1" style="width:100%;margin:6px 0 0;padding:7px">📦 Günlük Erzak Teslim Et</button>'}
      </div>`;
  }
  $('frontier-station-content').innerHTML=`
    <p style="color:#dce7e6;font-size:11px">Gözcü Lale: “Yayla yolu onarılırsa kasaba kervanı güvenle geçer.”</p>
    <p style="color:#fcd34d;font-size:11px">Kasaba İtibarı: ⭐ ${P.rep||0}</p>
    ${task}<p id="frontier-station-status" role="status" style="min-height:15px;color:#fca5a5;font-size:10px"></p>`;
}
function openFrontierStation(){
  if(!nearFrontierStation())return;
  $('frontier-station-modal').classList.remove('h');frontierStationUI();
}
function deliverFrontierMission(){
  if(!nearFrontierStation())return 'Önce karakola yaklaş.';
  const stage=P.frontierMission||0;
  if(stage>=3){
    if(P.frontierTradeDay===P.day)return 'Bugünkü erzak teslimatı yapıldı.';
    if(!inventoryRecipe({wood:3,stone:2}).ok)return 'Eksik: 3 odun ve 2 taş çantanda olmalı.';
    P.frontierTradeDay=P.day;P.gold+=70;P.rep=(P.rep||0)+5;P.townWorkDay=P.day;
    sv();return '✔ Kervan erzağı: +70🪙 · +5 itibar';
  }
  const mission=FRONTIER_MISSIONS[stage];
  if(mission.boars){
    const left=mission.boars-Math.max(0,(P.frontierBoarsKilled||0)-(P.frontierBoarStart||0));
    if(left>0)return `Önce yaylada ${left} yaban domuzunu uzaklaştır.`;
  }else{
    const missing=Object.entries(mission.needs).filter(([k,n])=>countInv(k)<n);
    if(missing.length)return `Eksik malzeme: ${missing.map(([k,n])=>`${n-countInv(k)} ${ {wood:'odun',stone:'taş',iron_ore:'demir cevheri'}[k] }`).join(' · ')}`;
    if(!inventoryRecipe(mission.needs).ok)return 'Malzemeler eksik; teslimat yapılmadı.';
  }
  P.frontierMission=stage+1;
  if(stage===1)P.frontierBoarStart=P.frontierBoarsKilled||0;
  P.gold+=mission.gold;P.gems+=mission.gems;P.rep=(P.rep||0)+mission.rep;P.townWorkDay=P.day;
  const md=WORLD_DATA.frontier;
  md.atlas=buildFrontierAtlas(md.tl,md.objs,md.hs);
  drawFrontierStationMinimap(md.mmc,P.frontierMission);
  ban(`🧭 ${mission.name} Tamamlandı!`,'#c6edc0');playChord([523,659,784],.25,'triangle',.05);
  sv();return `✔ +${mission.gold}🪙 · +${mission.gems}💎 · +${mission.rep} itibar`;
}
$('frontier-station-content').onclick=e=>{
  if(!e.target.closest('[data-station-submit]'))return;
  const result=deliverFrontierMission();frontierStationUI();
  const status=$('frontier-station-status');status.textContent=result;
  status.style.color=result.startsWith('✔')?'#86efac':'#fca5a5';
};
$('frontierstationc').onclick=()=>$('frontier-station-modal').classList.add('h');

function inspectFrontierRuin(){
  if(curMap!=='frontier'||P.frontierRuinFound||Math.hypot(P.x-(FRONTIER.ruin.x*TS+8),P.y-(FRONTIER.ruin.y*TS+8))>46)return;
  P.frontierRuinFound=true;P.gems+=4;
  ban('🗿 Kadim Harabe: +4 Elmas','#d8c3f5');spark(P.x,P.y-8,14,'#b8a4e6',55);sv();
}

function updP(dt){
  if(P.dead)return;
  P.t+=dt;P.cd-=dt;P.cs-=dt;P.ci-=dt;P.cp-=dt;P.iv-=dt;P.ct-=dt;P.cd2-=dt;
  if(P.parryWindow>0)P.parryWindow-=dt;
  P.shockCd=Math.max(0,(P.shockCd||0)-dt);P.combatTimer=Math.max(0,(P.combatTimer||0)-dt);P.areaWarnT=Math.max(0,(P.areaWarnT||0)-dt);P.lastStandCd=Math.max(0,(P.lastStandCd||0)-dt);
  for(const k in P.buffs)if(Number.isFinite(P.buffs[k])&&P.buffs[k]>0)P.buffs[k]=Math.max(0,P.buffs[k]-dt);
  if(P.phoenixCd>0)P.phoenixCd-=dt;
  
  if(P.ds>0){
    P.ds-=dt;
    mv(P,P.dx*200*dt,P.dy*200*dt,4);
    if(FX.rand(0,1)<dt*60)FX.emit(P.x,P.y-4,0,-8,.25,'#a5f3fc',2,15);
  }
  
  P.mp=Math.min(S.m,P.mp+dt*(2.2+P.lvl*.35));
  
  const v=In.vec(),m=Math.hypot(v.x,v.y);
  if(TOWN_PARK.sitTick(dt,m))return;
  if(P.fs&&m>.15)P.fs=null;
  if(!P.fs&&m>.05){
    const ground=curMap==='world'?tAt(P.x,P.y):0;
    const footing=ground===8?.82:ground===7?.93:1; // Çamur yavaşlatır; patikalar güvenli geçiştir.
    const riding=!!P.adventure?.mounted,sp=65*S.s*footing*(P.sw>0?.5:1)*(riding?1.45:1);
    mv(P,v.x*sp*dt,v.y*sp*dt,riding?6:4);
    // Duvar/nesne içinde kalındıysa 1 sn sonra en yakın boş noktaya çıkar.
    if(bl(P.x,P.y,4)){P.stkT=(P.stkT||0)+dt;if(P.stkT>1){P.stkT=0;let ok=false;for(let r=6;r<=64&&!ok;r+=6)for(let k=0;k<16&&!ok;k++){const a=k*Math.PI/8,nx=P.x+Math.cos(a)*r,ny=P.y+Math.sin(a)*r;if(!bl(nx,ny,4)){P.x=nx;P.y=ny;ok=true}}}}else P.stkT=0;
    if(P.sw<=0)P.f=dirOf(v.x,v.y);
    P.w+=dt*9;
    if(FX.rand(0,1)<dt*6)FX.emit(P.x,P.y-1,FX.rand(-8,8),-8,.3,'#c9b48a',1.5,20,2);
  }
  
  BOND.step(dt,m>.05&&!P.fs);
  if(In.atk&&!BUILD.active){
    P.chargeT = (P.chargeT||0) + dt;
    if(P.chargeT > 0.35 && P.chargeT - dt <= 0.35){
      sfx(880,.12,'sine',.06);
      spark(P.x,P.y-10,14,'#ffd23f',60);
      fl(P.x,P.y-28,'⚡ ŞARJ DOLDU!','#ffd23f',true);
    }
  }
  if(P.sw>0){
    P.sw-=dt;
    if(!P.hd&&P.sw<.18){
      P.hd=true;doHit();
    }
  }
  
  if(P.fs){
    const f=P.fs;f.t-=dt;
    if(f.st==='wait'&&f.t<=0){
      f.st='bite';f.t=QS[P.q]?.k==='fish'?1.85:1.1;
      spark(f.bx,f.by,12,'#bfe8ff',55);
      sfx(700,.15,'sine',.05);
      fl(f.bx,f.by-16,QS[P.q]?.k==='fish'?'ÇEK!':'!','#ff5d5d',true);
    }else if(f.st==='bite'&&f.t<=0){
      P.fs=null;fl(P.x,P.y-28,'Kaçtı…','#fff');
    }
  }
  
  // Köy çeşmesi doğal iyileştirme
  if(['world','home'].includes(curMap)&&Math.hypot(P.x-C*TS,P.y-C*TS)<80){
    P.hp=Math.min(S.h,P.hp+dt*12);
  }
  
  // Gizli sandıklar serbest.
  for(const ch of chests){
    if(ch.dungeon){if(!ch.opened&&!ch.hidden&&Math.hypot(P.x-ch.x,P.y-ch.y)<18)CAVE.openChest(ch);continue}
    if(!ch.opened&&Math.hypot(P.x-ch.x,P.y-ch.y)<18){
      if(P.inv.length>=BAG_CAPACITY){
        ch.warnT=(ch.warnT||0)-dt;
        if(ch.warnT<=0){fl(P.x,P.y-26,'🎒 Sandık için çantanda boş yer aç!','#fbbf77');ch.warnT=2}
        continue;
      }
      ch.opened=true;ch.t=curMap==='world'||curMap==='frontier'?Infinity:180;
      const gDrop=ri(30,100),gemDrop=ri(2,4);
      P.gold+=gDrop;P.gems+=gemDrop;
      fl(ch.x,ch.y-24,'🎁 HAZİNE! +'+gDrop+'🪙 +'+gemDrop+'💎','#ffd23f',true);
      playChord([523,659,784,1046],.3,'triangle',.05);
      spark(ch.x,ch.y,25,'#ffd23f',80);
      ITEMS.add(P.inv,gen(P.lvl+1,1));
      P.ach.chests_opened=(P.ach.chests_opened||0)+1;
      checkAch('chests');
      const mLvl=P.skills?.mine?.lvl||1;
      if(mLvl>=4&&Math.random()<.35){P.gems++;fl(ch.x,ch.y-28,'+1 💎 EKSTRA ELMAS!','#38bdf8',true)}
      addMasteryXp('mine',18);sv();
    }
    if(ch.opened&&curMap!=='world'&&curMap!=='frontier'){
      ch.t-=dt;
      if(ch.t<=0)ch.opened=false;
    }
  }
  
  // Doğal şifalı bitkiler ve meyve toplama
  for(const res of resources){
    if(!res.mined&&!res.isOre&&Math.hypot(P.x-res.x,P.y-res.y)<14){
      const gathered=res.k==='fallen_log'?ITEMS.make('wood',2):res.k==='cactus_fruit'?{s:'food',k:'cactus_fruit',n:'Kaktüs Meyvesi',icon:'🌵',hp:30,mp:15,val:24,desc:'Vahada yetişir; +30 Can, +15 Mana.'}:null;
      if(gathered&&!ITEMS.add(P.inv,gathered)){
        inventoryNotice(res,'Çanta dolu; kaynak burada kalacak.',dt);continue;
      }
      markResourceMined(res,res.k==='fallen_log'?240:res.k==='cactus_fruit'?160:80);DAILY_FOCUS.event('explore',1);EXPEDITIONS.event('gather',res.k,1);
      spark(res.x,res.y-4,10,res.col,35);
      sfx(780,.1,'sine',.04);
      if(res.k==='fallen_log'){
        fl(res.x,res.y-16,'+2 🪵 Kuru Odun','#dfac74',true);
      }else if(res.k==='cactus_fruit'){
        fl(res.x,res.y-16,'+🌵 Kaktüs Meyvesi','#f9af70',true);
      }else if(res.k==='herb_sun'){
        P.hp=Math.min(S.h,P.hp+30);
        fl(res.x,res.y-14,'+30 ❤ Güneş Çiçeği','#ffd23f');
      }else if(res.k==='herb_mana'){
        P.mp=Math.min(S.m,P.mp+35);
        fl(res.x,res.y-14,'+35 💧 Mavi Lotus','#38bdf8');
      }else if(res.k==='bog_herb'){
        P.mp=Math.min(S.m,P.mp+25);P.hp=Math.min(S.h,P.hp+10);
        fl(res.x,res.y-14,'+25 Mana · +10 Can Sazlık Şifası','#a7f3d0');
      }else if(res.k==='highland_herb'){
        const c=frontierClimate(),hp=c.season===3?8:c.rain?18:12,mp=c.season===3?12:c.rain?30:20;
        P.mp=Math.min(S.m,P.mp+mp);P.hp=Math.min(S.h,P.hp+hp);
        fl(res.x,res.y-14,`+${mp} Mana · +${hp} Can Yayla Adaçayı`,c.season===3?'#c8e8eb':'#b5e9c4');
      }else if(res.k==='snowdrop'){
        P.hp=Math.min(S.h,P.hp+35);
        fl(res.x,res.y-14,'+35 ❤ Kardelen','#e0f2fe');
      }else{
        P.hp=Math.min(S.h,P.hp+20);
        fl(res.x,res.y-14,'+20 ❤ Yaban Böğürtleni','#e11d48');
      }
      addMasteryXp('farm',8);sv();
    }
    if(res.mined&&curMap!=='mine'&&curMap!=='world'&&curMap!=='frontier'&&curMap!=='home'){
      res.respawnT-=dt;
      if(res.respawnT<=0){res.mined=false;res.hp=res.maxHp}
    }
  }
  
  // Çoklu Harita Sınır Geçitleri
  if(curMap==='world'){
    if(P.x<=3*TS&&Math.abs(P.y-50*TS)<4*TS){
      switchMap('home','east');
    }
  }else if(curMap==='home'){
    if(P.x>=(N-3)*TS&&Math.abs(P.y-30*TS)<4*TS){
      switchMap('world',worldEntrySide());
    }
    // Eve giriş görünür etkileşim düğmesiyle yapılır; tarlanın üstündeki boş kare portal değildir.
    // Arı Kovanından Bal Toplama (Güney Zanaat Terası: 16*TS, 35*TS · Çiçek Sinerjili)
    if(P.hasBeehive&&P.honeyReady&&Math.hypot(P.x-16*TS,P.y-35*TS)<26){
      const msg=FARM.collectBeehive();
      if(msg&&!msg.startsWith('✓'))inventoryNotice(P,msg,dt);
    }

    // Fıçı, diğer haritalarda da ADVENTURE.step ile ilerler.

    // Su Kuyusundan ve Nehir Kenarından Kova Doldurma
    if(Math.hypot(P.x-16*TS,P.y-24*TS)<22||Math.hypot(P.x-31*TS,P.y-30*TS)<22||DR.some(([dx,dy])=>tAt(P.x+dx*18,P.y+dy*18)===1)){
      if(!P.waterCan||P.waterCan<20){
        P.waterCan=20;
        fl(P.x,P.y-16,'💧 Kova Kuyudan Dolduruldu! (20/20)','#38bdf8',true);
        sfx(540,.14,'sine',.05);
      }
    }

    // Meyve Ağaçlarını Sallama ve Meyve Toplama (6 Tür Meyve Ağacı)
    if(objs){
      for(const o of objs){
        if((o.k==='apple_tree'||o.k==='peach_tree')&&o.fruitReady&&Math.hypot(P.x-o.x,P.y-o.y)<22){
          if(!FARM.harvestTree(o))inventoryNotice(o,'Çanta dolu; meyve ağaçta kalacak.',dt);
        }
      }
    }
    FARM.tick(dt);
  }else if(curMap==='inside'){
    // Kapı paspasından dışarı çıkma
    if(P.y>=24*TS && Math.abs(P.x-15*TS)<2*TS){
      switchMap('home');
      P.x=16*TS; P.y=25*TS; P.f=0;
    }
    // Evin içindeki yatakta uyuma
    if(Math.hypot(P.x-22*TS, P.y-8*TS)<18){
      if(!P.bedPrompt){ P.bedPrompt=true; fl(P.x, P.y-26, DAY_CLOCK.late()?'🛏️ [E / Dokun] Uyu & Sabah Yap':'🛏️ [E / Dokun] Gece yarısından sonra uyu', '#6ee7b7'); }
    }else{ P.bedPrompt=false; }
  }

  if(curMap==='world'){
    const tx=P.x/TS|0,ty=P.y/TS|0,z=zoneOf(tx,ty),b=worldBiome(tx,ty);
    const changed=z!==P.z;
    if(changed){
      P.z=z;
      const name=b==='marsh'?'🍄 Mantar Bataklığı':b==='frost'?'❄️ Akçam Karları':ZN[z];
      ban(name,'#fff');chat('SİSTEM','',name+' bölgesine girdin',1);
    }else if(b!==P.biome&&(b==='marsh'||b==='frost')){
      ban(b==='marsh'?'🍄 Mantar Bataklığı':'❄️ Akçam Karları',b==='marsh'?'#a7f3d0':'#d5f7ff');
    }
    P.biome=b;
    if(P.guideStep===3&&z===1&&b==='forest')advanceGuide(4);
  }else if(curMap==='home'&&P.guideStep===1&&Math.hypot(P.x-31*TS,P.y-30*TS)<70){
    advanceGuide(2);
  }
}

function update(dt){
  SESSION_COACH.tick(dt);BOSS_SYSTEM.tick(dt);
  DAY_CLOCK.tick(dt);
  music(dt);
  updWeather(dt);TOWN_LIFE.tick(dt);
  updBubbles(dt);
  updP(dt);CAVE.step(dt);ADVENTURE.step(dt);
  updMobs(dt);
  updCritters(dt);
  updPet(dt);
  updMerc(dt);
  updNpcs(dt);try{AUTO.update(dt)}catch(e){AUTO.reportError(e)}
  updHomeAnimals(dt);
  
  for(let i=tel.length-1;i>=0;i--){
    const t=tel[i];t.t-=dt/GAME_BALANCE.profile().windup;
    if(t.t<=.28&&!t.ping){
      t.ping=1;
      if(!P.dead&&Math.hypot(P.x-t.x,P.y-t.y)<t.r+38&&(P.areaWarnT||0)<=0){P.areaWarnT=.55;fl(P.x,P.y-34,'❗ ALANDAN ÇIK!','#fca5a5',true);sfx(900,.08,'square',.05)}
    }
    if(t.t<=0){
      if(!P.dead&&Math.hypot(P.x-t.x,P.y-t.y)<t.r)hurtP(t.dmg);
      for(let k=0;k<30;k++){
        const a=rnd(0,6.283),r=rnd(0,t.r);
        FX.emit(t.x+Math.cos(a)*r,t.y+Math.sin(a)*r*.8,0,-FX.rand(20,60),FX.rand(.3,.6),k%2?'#ffad69':'#ffd88d',2,45,1);
      }
      shk=Math.max(shk,6);FX.hitStop(5);FX.flash(t.x,t.y,t.r*1.6,4,.35);sfx(90,.3,'sawtooth',.07);
      tel.splice(i,1);
    }
  }
  
  for(let i=prj.length-1;i>=0;i--){
    const p=prj[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.t-=dt;
    if(p.isHero&&p.t>0&&bl(p.x,p.y,1)){p.t=0;spark(p.x,p.y,5,p.col||'#fff',40);sfx(260,.05,'square',.03)}
    if(p.t<=0){if(p.boom&&!p.did){p.did=1;COMBAT.boom(p)}prj.splice(i,1);continue}
    p.fxT=(p.fxT||0)+dt;
    if(p.fxT>=.025){p.fxT%=.025;FX.emit(p.x,p.y,FX.rand(-10,10),FX.rand(-10,10),.2,p.col||'#ff9f1c',1.5,0,p.kind==='arrow'?1:0)}
    if(p.isHero){
      for(const e of mobs){
        if(!e.dead&&!(p.hs&&p.hs.has(e))&&Math.hypot(e.x-p.x,e.y-p.y)<e.d.r+6){
          const cr=Math.random()<(S.c+(p.critBonus||0));
          hitMob(e,Math.round(p.dmg*(cr?1.8:1)),cr,p.vx*0.08,p.vy*0.08,p.isIce,p.isFire);
          p.main=e;
          if(p.pierce>0){p.pierce--;(p.hs=p.hs||new Set()).add(e);p.dmg=Math.round(p.dmg*.85)}else p.t=0;
          break;
        }
      }
      for(const c of critters){
        if(p.t>0&&!c.dead&&!c.tamed&&Math.hypot(c.x-p.x,c.y-p.y)<10){hitCritter(c);p.t=0;break}
      }
      // Mermiyle kütük veya taş vurma
      if(p.t>0&&curMap==='home'){
        for(let i=objs.length-1;i>=0;i--){
          const o=objs[i];
          if((o.k==='stump'||o.k==='boulder')&&Math.hypot(o.x-p.x,o.y-p.y)<o.r+6){
            strikeFarmDebris(o);p.t=0;
            break;
          }
        }
      }

  for(const res of resources){
        if(p.t>0&&!res.mined&&res.isOre&&Math.hypot(res.x-p.x,res.y-p.y)<res.r+6){
          strikeOre(res,1);p.t=0;
          break;
        }
      }
    }else{
      if(!P.dead&&Math.hypot(P.x-p.x,P.y-10-p.y)<9){
        if(ELEMENTS.reflect(p))continue;
        hurtP(p.dmg);p.t=0;
      }
    }
    if(p.t<=0){if(p.boom&&!p.did){p.did=1;COMBAT.boom(p)}prj.splice(i,1)}
  }
  
  for(let i=loot.length-1;i>=0;i--){
    const l=loot[i];l.a+=dt;l.vy+=220*dt;
    l.z=Math.min(0,l.z+l.vy*dt);if(l.z>=0)l.vy=0;
    const d=Math.hypot(P.x-l.x,P.y-l.y);
    if(l.a>.4&&d>0&&d<55&&!P.dead){
      const travel=Math.min(d,95*dt);l.x+=(P.x-l.x)/d*travel;
      l.y+=(P.y-l.y)/d*travel;
    }
    if(l.a>.4&&d<12&&!P.dead){
      if(l.t==='g'){
        P.gold+=l.v;fl(P.x,P.y-26,'+'+l.v+'🪙','#ffd23f');
        sfx(900,.06,'square',.03);
      }else if(l.t==='gem'){
        P.gems+=l.v;fl(P.x,P.y-26,'+'+l.v+'💎','#38bdf8');
        sfx(1050,.08,'sine',.04);
      }else if(l.t==='p'){
        P.pots++;fl(P.x,P.y-26,'+🧪','#6dff9c');
        sfx(750,.07,'sine',.03);
      }else if(ITEMS.add(P.inv,l.v)){
        const isLeg=l.v.r===3;
        const isEpic=l.v.r===2;
        if(isLeg){
          playChord([523,659,784,1046],.45,'triangle',.07);
          ban('★ EFSANEVİ EŞYA: '+l.v.n,'#ffd23f');
          chat('SİSTEM','','★ Efsanevi bulundu: '+l.v.n+'!',1);
          spark(P.x,P.y-10,30,'#ffd23f',90);
        }else if(isEpic){
          playChord([523,659,784],.3,'triangle',.05);
          ban('◆ Epik Eşya: '+l.v.n,'#c084fc');
          spark(P.x,P.y-10,18,'#c084fc',70);
        }else{
          fl(P.x,P.y-26,l.v.n,(RAR[l.v.r]||RAR[0])[1],true);
          sfx(600,.2,'square',.05);
        }
      }else{P.pendingRewards.push(l.v);fl(P.x,P.y-26,'🎒 Eşya korundu · çantadan teslim al.','#d8e8c5')}
      loot.splice(i,1);sv();
    }
  }
  
  chT-=dt;
  if(chT<=0){
    chT=WORLD_EVENTS.current().id==='social'?rnd(4,7):rnd(6,12);
    if(npcs&&npcs.length){
      const n=pick(npcs);
      if(n&&n.n){
        {const spoken=curMap==='home'&&window.STORY&&STORY.ambient&&STORY.ambient(n.n);const tl=!spoken&&curMap==='home'&&n.job&&!n.hidden&&Math.random()<.6?TOWN_LIFE.line(n):null;chat(n.n,n.tag||'',spoken||tl||pick(curMap==='home'&&TOWN_CHAT[n.n]?TOWN_CHAT[n.n]:CM))}
        if(curMap==='world'&&Math.random()<.12)ban(n.n+' bir efsanevi eşya buldu!','#ffd23f');
      }
    }
  }
}

/* ===== ÇİZİM VE PİKSEL SANATI ===== */
const cv=$('g');let g=cv.getContext('2d');let RS=1;window.__gfxReady=false;
const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h))};

let hf=0;

