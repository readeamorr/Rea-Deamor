/* ===== GENİŞLEME MODÜLLERİ ===== */

/* @inline:foundation-runtime:start */
/* FOUNDATION RUNTIME — lifecycle, checkpoints, input gates and existing-game onboarding. */
const GAME_CORE=window.GAME_CORE={
  loading:true,paused:true,unfocused:false,external:false,fatal:false,combat:{},sessionToRestore:null,overlay:'welcome',
  busy(){return this.loading||this.paused||this.unfocused||this.external||this.fatal||document.hidden||P.dead||!!document.querySelector('.ov:not(.h)')||$('bt').classList.contains('expanded')},
  resetInput(){if(typeof In!=='undefined'&&In.reset)In.reset()},
  init(d){
    P.life=P.life&&typeof P.life==='object'?P.life:{v:1,defeats:0,defeat:null};P.life.v=1;
    P.talentQueue=Array.isArray(P.talentQueue)?P.talentQueue:[];
    this.combat=d?.session?.combat||{};this.sessionToRestore=d?.session||null;
    for(const id of ['world','home','inside','frontier'])if(WORLD_DATA[id])this.tagMap(WORLD_DATA[id],id);
    // Eski sürümde çoklu seviye atlamasında görünmeyen seçimler kaybolabiliyordu.
    const earned=Math.floor(P.lvl/3),spent=Object.values(P.tl||{}).reduce((n,v)=>n+(Number(v)||0),0);
    let missing=Math.max(0,earned-spent-P.talentQueue.length);
    for(let level=Math.max(3,(spent+1)*3);level<=P.lvl&&missing>0;level+=3){const before=P.talentQueue.length;this.queueTalent(level);if(P.talentQueue.length>before)missing--}
    P.talentQueue.sort((a,b)=>a.level-b.level);
    migrateSeedPouches();ONBOARD.init(!!d);NOTIFICATIONS.init();WAYPOINTS.init(!!d);FEATURES.init();STORY.init();
  },
  tagMap(md,id){if(md._coreTagged)return;md._coreTagged=true;md.mobs.forEach((m,i)=>{if(!m.trial)m.saveId=id+':'+i+':'+m.k});this.restoreCombat(md,id)},
  restoreCombat(md,id){
    const data=this.combat[id];if(!data)return;const entries=Object.entries(data);
    if(entries.length&&entries.every(([,r])=>r.v===2&&MT[r.k])){
      md.mobs.length=0;
      for(const [saveId,r]of entries){const d=MT[r.k],x=cl(r.x,16,md.N*TS-16),y=cl(r.y,16,md.N*TS-16),mob={saveId,k:r.k,d,x,y,hx:r.hx,hy:r.hy,lv:r.lv,mhp:r.mhp,hp:r.dead?0:Math.max(1,r.hp),a:r.a,el:r.el,st:'idle',t:.8,kx:0,ky:0,fl:0,dead:r.dead,rt:Math.max(.1,r.rt),f:r.f||1,ph:0,tx:x,ty:y,v:0,hv:0,cast:0,act:false,r:d.r,chill:0,p2:r.p2};ENCOUNTER_VARIANTS.restore(mob,r.variant);md.mobs.push(mob);
      }
    }else for(const m of md.mobs){const r=data[m.saveId];if(!r)continue;m.dead=!!r.dead;m.hp=m.dead?0:Math.max(1,m.mhp*r.hp);m.rt=Math.max(.1,r.rt||0)}
  },
  captureCombat(){
    if(!['world','frontier'].includes(curMap))return;const data={};
    for(const m of mobs)if(m.saveId)data[m.saveId]={v:2,k:m.k,x:m.x,y:m.y,hx:m.hx,hy:m.hy,lv:m.lv,mhp:m.mhp,hp:Math.max(0,m.hp),a:m.a,el:!!m.el,dead:!!m.dead,rt:cl(m.rt||0,0,180),f:m.f||1,p2:!!m.p2,variant:m.variant||null};
    this.combat[curMap]=data;
  },
  takeLoot(l,notify=false){
    if(l.t==='g')P.gold+=l.v;else if(l.t==='gem')P.gems+=l.v;else if(l.t==='p')P.pots+=Math.max(1,l.v||1);
    else if(l.t==='i'&&l.v){if(!ITEMS.add(P.inv,l.v)){P.pendingRewards.push(l.v);if(notify)fl(P.x,P.y-29,'🎒 Eşya korunuyor · çantadan teslim al.','#e5d1a5',true)}}
  },
  settleLoot(){for(const l of loot)this.takeLoot(l);loot.length=0},
  leaveScene(){
    this.captureCombat();this.settleLoot();CAVE.capture();prj.length=0;tel.length=0;bubbles.length=0;this.resetInput();
    P.sw=0;P.chargeT=0;P.ds=0;P.parryWindow=0;P.fs=null;
  },
  snapshot(){
    this.captureCombat();const cooldowns={};for(const k of ['cd','cs','ci','cp','cd2','phoenixCd','shockCd','combatTimer'])cooldowns[k]=Math.max(0,P[k]||0);
    return {v:1,map:curMap,x:P.x,y:P.y,f:P.f,hp:P.hp,mp:P.mp,shld:P.shld||0,dead:!!P.dead,buffs:{...P.buffs},cooldowns,combat:this.combat,loot:loot.map(l=>({t:l.t,x:l.x,y:l.y,v:l.v,vy:0,z:0,a:.5}))};
  },
  placeNear(x,y){
    for(let r=0;r<8;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){
      if(Math.max(Math.abs(dx),Math.abs(dy))!==r)continue;
      const px=x+dx*TS,py=y+dy*TS;
      if(!bl(px,py,4))return {x:px,y:py};
    }
    return {x,y};
  },
  wakeSite(){
    if(curMap!=='world')return null;
    if(P.z===2)return {kind:'lake'};
    if(P.z===3)return {kind:'oasis'};
    return null;
  },
  wakePlace(kind){
    if(kind==='lake')return {kind,map:'world',x:38,y:54,title:'İskelede uyanacaksın',btn:'İskelede Uyan',who:'BALIKÇI',chat:'İskele seni tuttu. Kıyı duruyor. Sarı hedef kaldığın adımı gösterir.'};
    if(kind==='oasis')return {kind,map:'world',x:84,y:40,title:'Vahada uyanacaksın',btn:'Vahada Uyan',who:'KERVANCI LEYLA',chat:'Vaha seni tuttu. Bir nefes al, kovayı doldur. Sarı hedef kaldığın adımı gösterir.'};
    return null;
  },
  safePosition(map,x,y){
    const start={home:[14*TS,25*TS],world:[C*TS,(C+3)*TS],inside:[15*TS,18*TS],mine:[4*TS+8,5*TS+8],frontier:[(FRONTIER.gate.x+.5)*TS,(FRONTIER.gate.y-2+.5)*TS],arena:[4*TS,30*TS]}[map]||[14*TS,25*TS];
    if(Number.isFinite(x)&&Number.isFinite(y)&&!bl(x,y,4))return {x,y};
    for(let r=0;r<9;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){const px=start[0]+dx*TS,py=start[1]+dy*TS;if(!bl(px,py,4))return {x:px,y:py}}
    return {x:start[0],y:start[1]};
  },
  restoreSession(){
    const s=this.sessionToRestore;S=st();
    if(s){
      const wake=this.wakePlace(P.life.defeat?.wake?.kind);const dead=!!P.life.defeat?.pending||s.dead;const target=dead?(wake?wake.map:'home'):s.map;
      if(target!==curMap||target==='mine')switchMap(target,undefined,true);
      const pos=dead&&wake?this.placeNear(wake.x*TS+8,wake.y*TS+8):this.safePosition(target,dead?NaN:s.x,dead?NaN:s.y);P.x=pos.x;P.y=pos.y;P.f=s.f;
      P.hp=cl(s.hp,0,S.h);P.mp=cl(s.mp,0,S.m);P.shld=cl(s.shld||0,0,1000000);P.buffs={atk:0,spd:0,...s.buffs};
      for(const k of ['cd','cs','ci','cp','cd2','phoenixCd','shockCd','combatTimer'])P[k]=s.cooldowns?.[k]||0;
      loot.length=0;for(const l of s.loot||[])loot.push({...l});
      P.dead=dead;if(dead){P.hp=0;if(!P.life.defeat?.pending)P.life.defeat={id:(P.life.defeats||0)+1,loss:0,day:P.day,pending:true};this.settleLoot()}
      else if(P.hp<=0)P.hp=1;
    }else{P.dead=!!P.life.defeat?.pending;P.hp=P.dead?0:S.h;P.mp=S.m;P.shld=0}
    S=st();P.hp=Math.min(S.h,P.hp);P.mp=Math.min(S.m,P.mp);
    if(P.pet){P.pet.x=P.x-10;P.pet.y=P.y}if(P.merc){P.merc.x=P.x+10;P.merc.y=P.y}
    FX.resetMap();FARM.updCal();this.sessionToRestore=null;this.loading=false;
  },
  canTravel(){return !P.dead&&(P.combatTimer||0)<=0&&!mobs.some(m=>!m.dead&&Math.hypot(m.x-P.x,m.y-P.y)<Math.max(90,m.d.ag||0)&&(m.d.boss&&m.act||['chase','wind','rec'].includes(m.st)))&&!prj.some(p=>!p.isHero&&p.t>0&&Math.hypot(p.x-P.x,p.y-P.y)<80)},
  travel(map,side){if(!this.canTravel()){inventoryWarning('Savaş sürüyor. Haritayı kapatıp güvenli konumda birkaç saniye bekle.');return false}if(!switchMap(map,side))return false;svNow();return true},
  queueTalent(level){
    const ids=['a','h','c','s','v'];let seed=((P.adventure?.seed||79)^Math.imul(level,2654435761))>>>0;
    for(let i=ids.length-1;i>0;i--){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const j=seed%(i+1);[ids[i],ids[j]]=[ids[j],ids[i]]}
    const id='talent-'+level;if(!P.talentQueue.some(t=>t.id===id)){P.talentQueue.push({id,level,choices:ids.slice(0,3)});P.life.deferred=false}
  },
  offerTalent(force=false){
    if(P.dead||P.life.defeat?.pending||!P.talentQueue.length||!FEATURES.is('character'))return false;
    if(!force&&(!gameStarted||P.life.deferred||document.querySelector('.ov:not(.h)')))return false;
    const choice=P.talentQueue[0];this.overlay='talent';this.resetInput();
    $('cd').innerHTML='<h1 style="font-size:20px">Yetenek Seçimi</h1><p>Seviye '+choice.level+' kazanımı · '+P.talentQueue.length+' seçim bekliyor.</p>'+choice.choices.map(id=>`<button class="m" style="display:block;width:100%;padding:10px;margin:7px 0" data-t="${id}" data-talent-token="${choice.id}">${TL.find(t=>t[0]===id)?.[1]||id}</button>`).join('');
    $('cd').insertAdjacentHTML('beforeend','<button id="talent-later" style="margin-top:8px">Daha sonra seç · kazanım saklanır</button>');
    $('talent-later').onclick=()=>{P.life.deferred=true;this.overlay='';$('ov').classList.add('h');svNow()};
    $('ov').classList.remove('h');svNow();return true;
  },
  chooseTalent(id,token){
    const next=P.talentQueue[0];if(!next||next.id!==token||!next.choices.includes(id)||P.dead)return false;
    P.talentQueue.shift();P.tl[id]=(P.tl[id]||0)+1;S=st();P.hp=Math.min(S.h,P.hp+25);P.mp=Math.min(S.m,P.mp);
    $('ov').classList.add('h');this.overlay='';svNow();this.offerTalent(true);return true;
  },
  defeat(){
    if(P.life.defeat?.pending){this.showDefeat();return false}
    this.settleLoot();
    const retained=Math.floor(P.gold*(1-GAME_BALANCE.profile().death)),loss=P.gold-retained;P.gold=retained;P.dead=true;P.hp=0;
    P.life.defeats=(P.life.defeats||0)+1;P.life.defeat={id:P.life.defeats,loss,day:P.day,pending:true,wake:this.wakeSite()};
    prj.length=0;tel.length=0;this.resetInput();shk=7;svNow();this.showDefeat();return true;
  },
  showDefeat(){
    this.overlay='death';this.resetInput();const loss=P.life.defeat?.loss||0,offerHelp=(P.life.defeats||0)>=2&&GAME_BALANCE.state()!=='story',wake=this.wakePlace(P.life.defeat?.wake?.kind),where=wake?wake.title:'Çiftlikte uyanacaksın',btn=wake?wake.btn:'Çiftlikte Uyan';
    document.querySelectorAll('.ov').forEach(el=>el.classList.add('h'));
    $('cd').innerHTML=`<h1 style="color:#efb0a3">Yenildin</h1><p>${where}. Evin, görevlerin ve eşyaların duruyor.${loss?` Yolda ${loss} altın düşürdün.`:''}</p><p class="inventory-help">Sarı hedef kaldığın adımı göstermeye devam eder. Yemek ye, turuncu uyarıyı gör, sonra vur. Bu kayıp bir kez işlendi.</p>${offerHelp?'<div class="journey-box"><b>Daha rahat devam etmek ister misin?</b><p>Rahat mod hasarı azaltır ve saldırı uyarılarını uzatır. Ödüller ve başarımlar korunur.</p><button id="btn-story-assist" type="button">Rahat Moda Geç</button></div>':''}<button class="m" id="rs" style="width:100%;padding:11px">${btn}</button>`;
    $('ov').classList.remove('h');$('rs').onclick=()=>this.respawn();const assist=$('btn-story-assist');if(assist)assist.onclick=()=>{GAME_BALANCE.set('story');assist.disabled=true;assist.textContent='✓ Rahat Mod Açıldı'};
  },
  respawn(){
    if(!P.life.defeat?.pending)return false;
    const place=this.wakePlace(P.life.defeat.wake?.kind);
    this.leaveScene();P.life.defeat.pending=false;P.dead=false;
    if(place){
      if(curMap!==place.map)switchMap(place.map,undefined,true);
      const pos=this.placeNear(place.x*TS+8,place.y*TS+8);P.x=pos.x;P.y=pos.y;P.f=0;P.z=zoneOf((P.x/TS)|0,(P.y/TS)|0);P.biome=worldBiome((P.x/TS)|0,(P.y/TS)|0);
    }else{
      switchMap('home',undefined,true);const pos=this.safePosition('home',NaN,NaN);P.x=pos.x;P.y=pos.y;P.f=0;
    }
    P.shld=0;S=st();P.hp=S.h;P.mp=S.m;P.iv=2.5;P.combatTimer=0;
    if(P.pet){P.pet.x=P.x-10;P.pet.y=P.y}if(P.merc){P.merc.x=P.x+10;P.merc.y=P.y}
    this.overlay='';$('ov').classList.add('h');FX.resetMap();chat(place?place.who:'MUHTAR HAMDİ','',place?place.chat:'Kapı açık. Yaraların sarıldı; kaldığın adım sarı hedefte.',1);svNow();this.offerTalent();return true;
  },
  started(){this.overlay='';if(P.dead||P.life.defeat?.pending)this.showDefeat();else this.offerTalent()},
  closeMenu(){
    if($('bt').classList.contains('expanded')){closeQuickMenu();return true}
    const modal=[...document.querySelectorAll('.ov:not(.h)')].pop();if(!modal||modal.id==='ov')return false;
    modal.classList.add('h');if(modal.id==='bond-modal')BOND.current=null;if(modal.id==='storage-modal')BUILD.activeChest=null;this.resetInput();return true;
  },
  install(){
    document.addEventListener('click',e=>{if(this.external&&!e.target.closest?.('#save-modal,#save-warning,#crash-overlay')){e.preventDefault();e.stopImmediatePropagation();openSaveModal()}},true);
    const observer=new MutationObserver(()=>{const paused=!!document.querySelector('.ov:not(.h)')||$('bt').classList.contains('expanded');if(paused&&!this.paused)this.resetInput();this.paused=paused;saveNoticeCurrent();if(!paused&&gameStarted&&!P.life.deferred&&!P.dead)this.offerTalent()});
    for(const modal of document.querySelectorAll('.ov'))observer.observe(modal,{attributes:true,attributeFilter:['class']});observer.observe($('bt'),{attributes:true,attributeFilter:['class']});
    window.addEventListener('blur',()=>{this.unfocused=true;this.resetInput()});
    window.addEventListener('focus',()=>{this.unfocused=false;last=performance.now()});
    document.addEventListener('visibilitychange',()=>{if(document.hidden)this.resetInput()});
  }
};
const ONBOARD=window.ONBOARD={
  steps:[
    {id:'home',label:'Evini tanı',speaker:'Muhtar Hamdi',hint:'Çiftlik Evi’ne gir. Hamdi anahtarı sana bıraktı. İçerideki ocak yemek hazırlar; yatak, gece olunca yeni güne geçirir.',voice:'Bu kapı artık senin. Bir yuva, kapısı kapanan yerdir.',doneLine:'Ocak ve yatak seni tanıdı. Şimdi toprağın sırası.',why:'Ev, oyundaki güvenli merkezindir. Her keşiften sonra burada hazırlanır, iyileşir ve yeni güne başlarsın.',target:'home',place:'Çiftlik Evi'},
    {id:'farm',label:'Bahçenin günlük bakımını yap',speaker:'Çiftçi Dede',hint:'Tarlaya yaklaş ve “🌿 Günlük Bakım” düğmesine bir kez bas. Hazır ekinler toplanır, boş tarhlar ekilir, susuzlar sulanır.',voice:'Toprak beklemez. Bu buğday akşam ekmeğin olacak.',doneLine:'Toprak seni tanıdı. Bu buğday akşam ekmeği olacak.',why:'Bahçe sana yemek ve altın için düzenli ürün sağlar. Tek tek parsellerle uğraşmana gerek yoktur.',target:'farm',place:'Kolay Bahçe'},
    {id:'cook',label:'İlk köy ekmeğini hazırla',speaker:'Fırıncı Melis',hint:'Eve dön, soldaki ocağı aç ve 2 buğdayla Taze Köy Ekmeği pişir.',voice:'İki buğday, bir somun. Yola ekmeksiz çıkma.',doneLine:'İlk ekmeğin kokusu kasabaya kadar geldi. Yola böyle çıkılır.',why:'Yemekler keşifte canını yeniler ve daha uzun süre dışarıda kalmanı sağlar.',target:'home',place:'Ev Ocağı'},
    {id:'forest',label:'Zümrüt Orman’da 6 Slime yen',speaker:'Muhtar Hamdi',hint:'Doğu kapısı ya da bu düğme seni slime açıklığına bırakır. 6 slime bir arada; her biri odun ve taş düşürür. Turuncu uyarıdan sıyrıl, açık verince vur.',voice:'Slime’lar yolun nefesini kesiyor. Altısını indir, dönüşte odun ve taş getir.',doneLine:'Yolun ilk nefesi açıldı. Getirdiğin odun ve taş, sandığın olacak.',why:'Bu adım savaş, keşif ve görev ödülü döngüsünü öğretir. İlk saldırı uyarısında oyun durup kısa savaş dersini gösterecek.',target:'forest',place:'Zümrüt Orman'},
    {id:'chest',label:'İlk depo sandığını kur',speaker:'Muhtar Hamdi',hint:'İnşa arazisine git. Depo Sandığını Kur düğmesi çıkar. Gerekenler: 10 odun, 4 taş, 30 altın. Yetmezse tek seferlik destek açılır.',voice:'Kazandığın şey kaybolmasın. İnşa arazisine bir sandık kur.',doneLine:'İlk sandığın duruyor. Bundan sonra her dönüşte bu eve geleceksin.',why:'Keşiften getirdiğin kaynakları depolamak çanta sıkışıklığını azaltır ve yeni geliştirmelerin önünü açar.',target:'build',place:'İnşa Arazisi'}
  ],
  init(existing){
    const old=P.adventure.intro;
    if(old?.v>=1&&typeof old.enabled==='boolean'){
      old.events=old.events||{};
      if(!old.events.farm&&((old.events.harvest||0)>=2||(old.events.plant&&old.events.water)))old.events.farm=1;
      old.v=2;return;
    }
    P.adventure.intro={v:2,enabled:!existing,legacy:existing,skipped:false,completed:false,recoveryUsed:false,chestAid:false,events:{}};
  },
  active(){const s=P.adventure?.intro;return !!s?.enabled&&!s.completed&&!s.skipped&&!QUEST_FLOW.optional()},
  event(id,count=1){
    if(!this.active())return;const s=P.adventure.intro,step=this.steps.find(t=>t.id===id);if(!step)return;
    const ahead=this.current()&&this.current().id!==id;
    const need=step.need||1,before=(s.events[id]||0)>=need;
    const value=Math.min(need,(s.events[id]||0)+count);if(value===(s.events[id]||0))return;s.events[id]=value;
    const completedNow=!before&&value>=need;
    if(this.steps.every(t=>(s.events[t.id]||0)>=(t.need||1))){s.completed=true;P.guideStep=4;const dock=window.WAYPOINTS&&WAYPOINTS.defs.find(d=>d.name==='Balıkçı İskelesi');if(dock)WAYPOINTS.unlock(dock);P.gold+=120;P.pots+=2;P.gems+=1;ban('🏡 İLK DÜZENİN HAZIR · +120 altın, +2 iksir, +1 elmas','#c0ead0');playChord([523,659,784,1046],.4,'triangle',.05);svNow();if(window.MODAL_QUEUE)MODAL_QUEUE.enqueue('firstbase',4,'story-modal',()=>{if(window.STORY)STORY.play(this.doneBeats(),null,{skipDone:false})});else chat('MUHTAR HAMDİ','',`${(window.STORY&&STORY.hero())||'Yolcu'}, ilk düzenin hazır. Şimdi Melis’in sözü: üç balık.`,1)}
    else if(completedNow){
      const next=this.current();playChord([523,659,784],.18,'triangle',.035);
      if(step.id!=='forest'&&step.doneLine)chat(step.speaker||'MUHTAR HAMDİ','',(ahead?'Bunu önden hallettin. ':'')+step.doneLine,1);
      if(next?.id==='forest'){const road=window.WAYPOINTS&&WAYPOINTS.defs.find(d=>d.name==='Zümrüt Orman');if(road&&!WAYPOINTS.isUnlocked('world',road.name))WAYPOINTS.unlock(road)}
      if(next?.id==='chest')this.chestKit();
      if(step.id==='home'&&window.DECISIONS&&!DECISIONS.made('ilk-karar')&&window.MODAL_QUEUE)MODAL_QUEUE.enqueue('decision:ilk-karar',4,'story-modal',()=>DECISIONS.play('ilk-karar'));
      if(next)setTimeout(()=>chat('REHBER','',next.hint,1),step.id==='forest'?1200:800);
    }
    sv();
  },
  current(){return this.active()?this.steps.find(t=>(P.adventure.intro.events[t.id]||0)<(t.need||1)):null},
  label(){const t=this.current();if(!t)return '';const i=this.steps.indexOf(t);return `🧭 ${i+1}/${this.steps.length} · ${t.label}`},
  chestKit(){
    const s=P.adventure?.intro;if(!s||!this.active()||s.chestGift)return false;
    if(this.current()?.id!=='chest')return false;
    const needWood=Math.max(0,10-countInv('wood')),needStone=Math.max(0,4-countInv('stone')),needGold=Math.max(0,30-(P.gold||0));
    if(!needWood&&!needStone&&!needGold){s.chestGift=true;return false}
    const items=[];if(needWood)items.push({s:'mat',k:'wood',qty:needWood});if(needStone)items.push({s:'mat',k:'stone',qty:needStone});
    if(items.length&&!ITEMS.addMany(P.inv,items))return false;
    if(needGold&&Number.isSafeInteger(P.gold+needGold))P.gold+=needGold;
    s.chestGift=true;sv();
    ban('📦 Sandık malzemesi kasabadan · '+needWood+' odun, '+needStone+' taş'+(needGold?', '+needGold+' altın':''),'#fde68a');
    chat('MUHTAR HAMDİ','','Sandığı sen kuracaksın, malzeme kasabadan. İlk düzen böyle kurulur.',1);
    return true;
  },
  skip(){if(!this.active())return;P.adventure.intro.skipped=true;P.guideStep=4;svNow();ADVENTURE.ui()},
  recover(){
    const s=P.adventure.intro;if(!this.active()||s.recoveryUsed||s.events.cook)return false;
    if(curMap!=='home'||Math.hypot(P.x-27*TS,P.y-25*TS)>50){ADVENTURE.notice('Başlangıç yardımı için Fırıncı Melis’in tezgâhına yaklaş.');return false}
    if(countInv('wheat')>=2){ADVENTURE.notice('Ekmek için yeterli buğdayın var.');return false}
    const n=2-countInv('wheat'),items=Array.from({length:n},()=>({s:'crop',k:'wheat',n:'Buğday',icon:'🌾',star:1,val:CROPS.wheat.val,desc:'Fırıncı Melis’in tek seferlik başlangıç desteği.'}));
    if(!ITEMS.addMany(P.inv,items)){inventoryWarning('Buğday için çantanda yer aç. Paket harcanmadı.');return false}
    s.recoveryUsed=true;svNow();ADVENTURE.ui();ADVENTURE.notice('Ekmek için eksik buğday tamamlandı. Bu destek bir kez verilir.');return true;
  },
  chestAid(){
    const s=P.adventure.intro;if(!this.active()||s.chestAid||this.current()?.id!=='chest')return false;
    const wood=Math.max(0,10-countInv('wood')),stone=Math.max(0,4-countInv('stone')),gold=Math.max(0,30-(P.gold||0));
    if(!wood&&!stone&&!gold){ADVENTURE.notice('Sandık için malzemen yeterli.');return false}
    const items=[];if(wood)items.push({s:'mat',k:'wood',qty:wood});if(stone)items.push({s:'mat',k:'stone',qty:stone});
    if(items.length&&!ITEMS.addMany(P.inv,items)){inventoryWarning('Destek için çantanda yer aç. Paket harcanmadı.');return false}
    if(gold&&Number.isSafeInteger(P.gold+gold))P.gold+=gold;
    s.chestAid=true;svNow();ADVENTURE.ui();ADVENTURE.notice('Muhtar eksik odun, taş ve altını bir kez tamamladı.');
    chat('MUHTAR HAMDİ','','Orman cimri davrandıysa kasaba tamamlar. Bu destek bir kez verilir. Sandığını kur.',1);return true;
  },
  doneBeats(){
    return [
      {who:'Fırıncı Melis',icon:'🥖',kicker:'İLK DÜZEN · TAMAM',line:'Sofranda ekmek, kilerinde yer var. Bu kasaba seni artık yolcu değil, komşu sayıyor.'},
      {who:'Çiftçi Dede',icon:'🌾',kicker:'BAHÇE',line:'Toprak da tanıdı seni. Sabah bakımını yaptığın sürece sana ürün verir; unutma, toprak beklemez.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'SIRADAKİ İŞ',line:'İlk düşünü kurduk. Şimdi göl: Rıza iskelede, ağ kuru. Melis’in ocağı üç balık bekliyor.'}
    ];
  },
  html(){
    const s=P.adventure.intro;if(!s)return '';
    if(!this.active())return s.completed?'<div class="journey-box"><b>✓ İlk düzenini kurdun</b><p>Çiftliğin maceranı besliyor; maceran da yuvanı geliştiriyor.</p></div>':'';
    const t=this.current();
    return `<div id="onboarding-card" class="journey-box"><b>${this.label()}</b><p>${t.voice?`“${t.voice}” `:''}${t.hint}</p><ol class="intro-steps">${this.steps.map(step=>`<li class="${(s.events[step.id]||0)>=(step.need||1)?'done':''}">${(s.events[step.id]||0)>=(step.need||1)?'✓':'○'} ${step.label}</li>`).join('')}</ol><p class="inventory-help">${window.STORY?STORY.soFar():''} Sarı hedef, sıradaki adımı ve nedenini açıklar.</p>${!s.recoveryUsed&&!s.events.cook?'<button data-onboard="recover">Buğdayı kaybettim · Melis’ten yardım</button>':''}${t.id==='chest'&&!s.chestAid?'<button data-onboard="chest">Odun veya taş yetmedi · Muhtarın desteği</button>':''}<button data-onboard="skip">Rehberi atla</button></div>`;
  }
};
function guideChapterCard(){
  const box=$('guide-chapter');if(!box)return;
  const c=window.chapterAt?chapterAt(P.q):null;
  if(!c){box.innerHTML='';return}
  const nexts=c.quests.map(i=>({i,q:QS[i]})).filter(x=>x.i>=P.q).slice(0,3);
  const pct=Math.round(c.done/c.size*100),intro=window.ONBOARD&&ONBOARD.active&&ONBOARD.active()?ONBOARD.current():null;
  box.innerHTML=`<div class="gch"><div class="gch-top"><span>📖 BÖLÜM ${c.no}/${c.total}</span><b>${c.name}</b></div>
    <div class="gch-why"><b>Neden buradayım?</b> Gölgeköy’de bir hayat kuruyorsun. Bu bölüm, kasabanın yeniden nefes alması için üç iş istiyor; sonunda seçtiğin bir sandık ve yeni bir yol açılıyor.</div>
    ${intro?`<div class="gch-intro">🏡 <b>Önce ilk günün:</b> ${intro.label} <small>(${ONBOARD.steps.indexOf(intro)+1}/${ONBOARD.steps.length})</small></div>`:''}
    <div class="gch-bar"><i style="width:${pct}%"></i><small>${c.done}/${c.size} adım</small></div>
    <ol class="gch-next">${nexts.map((x,k)=>`<li class="${k===0?'now':''}">${k===0?'▶':'·'} ${x.q.icon} ${x.q.t}${k===0?` <em>${Math.min(P.qn||0,x.q.n)}/${x.q.n}</em>`:''}</li>`).join('')}</ol>
    <button type="button" data-brief-open="1" class="gch-brief">📜 Bölüm sözleşmesini oku</button></div>`;
}
function guideUI(){
  const box=$('guide-content');if(!box)return;
  if(window.ONBOARD&&ONBOARD.chestKit)ONBOARD.chestKit();
  guideChapterCard();
  const step=ONBOARD.current();
  if(step){
    const s=P.adventure.intro,done=ONBOARD.steps.filter(t=>(s.events[t.id]||0)>=(t.need||1)).length;
    const index=ONBOARD.steps.indexOf(step)+1,pct=Math.round(done/ONBOARD.steps.length*100);
    const actionLabel=step.id==='forest'?'🌲 Ormana Git':step.id==='chest'?'📦 Sandığı Kurmaya Başla':step.id==='cook'&&curMap==='inside'?'🍳 Ocağı Aç':step.target==='farm'&&curMap==='home'?'🌿 Kolay Bahçeyi Aç':step.target==='build'?'🔨 Yapılar Bölümünü Aç':'🗺️ Haritada Göster';
    box.innerHTML=`<span class="guide-kicker">İLK YOLCULUK · ADIM ${index}/${ONBOARD.steps.length}</span><h2 class="guide-title">${step.label}</h2><p class="guide-copy">${STORY.soFar()}</p><p class="guide-copy">${step.hint}</p>${step.voice?`<div class="guide-why"><b>${step.speaker||'Muhtar Hamdi'}</b><br>“${step.voice}”</div>`:''}<div class="guide-progress"><i style="width:${pct}%"></i></div><p style="font-size:9px;color:#8fa6af;text-align:right">${done}/${ONBOARD.steps.length} temel adım tamamlandı</p><div class="guide-meta"><div><b>📍 Gideceğin Yer</b>${step.place||'Hedef bölge'}</div><div><b>🎯 Amaç</b>${index===ONBOARD.steps.length?'Temel döngüyü tamamla':'Bir sonraki sistemi öğren'}</div></div><div class="guide-why"><b>Neden yapıyorum?</b><br>${step.why}</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="${step.target}">${actionLabel}</button><button id="guide-journal">📔 Yolcu Defteri</button></div><button id="guide-skip" class="guide-skip">Rehberli başlangıcı atla</button>${step.id==='chest'&&!s.chestAid?'<button id="guide-aid" type="button" style="width:100%;margin-top:8px">🪵 Odun veya taş yetmedi · tek seferlik destek</button>':''}`;
  }else{
    const q=QS[P.q],free=!q;
    if(STORY.needsRest()){
      box.innerHTML=`<span class="guide-kicker">AKŞAM</span><h2 class="guide-title">Önce sabahı aç</h2><p class="guide-copy">Balıklar bu akşamın sofrası. Orman Muhafızı sabah korusunda bekler; gece yorgun girilmez.</p><div class="guide-why"><b>Fırıncı Melis</b><br>“Eve dön, yat. Kökler sabahı da orada olur.”</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="rest">🛏️ Eve Dön</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(STORY.needsOasis()){
      box.innerHTML=`<span class="guide-kicker">ÇÖL</span><h2 class="guide-title">Önce bir nefes</h2><p class="guide-copy">Akrepler yolda kaldı. Kum Golemi yolun güneyindeki çukurda. Vahada dur, kovayı doldur, sonra in.</p><div class="guide-why"><b>Kervancı Leyla</b><br>“Çöl bir anda bitmez. Nefessiz taşın karşısına çıkma.”</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="oasis">🏜️ Çöl Ağzına Git</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(STORY.cueHome()){
      box.innerHTML=`<span class="guide-kicker">GÖLGEKÖY’E DÖNÜŞ</span><h2 class="guide-title">Kapıda bir nefes</h2><p class="guide-copy">${STORY.soFar()}</p><div class="guide-why"><b>Muhtar Hamdi</b><br>“${STORY.fill('Dön, {name}. Rapor yok. Bu gece kasaba payı da, elit av da yok.')}”</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="hamdi">🏛️ Hamdi’nin Kapısına Git</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(STORY.resting&&STORY.resting()){
      box.innerHTML=`<span class="guide-kicker">BU GECE</span><h2 class="guide-title">Kasabadasın</h2><p class="guide-copy">Hamdi bu gece hiçbir iş istemiyor. Tarla, dostlar ve bir ustalık sabah da burada olur.</p><div class="guide-why"><b>Muhtar Hamdi</b><br>“${STORY.fill('Kapın açık, {name}. Bu gece sırtı kimse izlemesin.')}”</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="night">🛏️ Eve Git</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(STORY.morningDue&&STORY.morningDue()){
      box.innerHTML=`<span class="guide-kicker">SABAH</span><h2 class="guide-title">Tarla, bir dost, bir iş</h2><p class="guide-copy">Hamdi üç iş birden istemiyor. Tarlaya bak, Melis’e uğra, sonra birini seç.</p><div class="guide-why"><b>Muhtar Hamdi</b><br>“Üçünü birden kovalama. Bir iş, bir gün.”</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="garden">🌿 Bahçeye Git</button><button data-target="melis">🥐 Melis’e Uğra</button><button data-target="pick-mine">⛏️ Maden</button><button data-target="pick-frontier">🌫️ Yayla</button><button data-target="pick-elite">★ Seçkin Av</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(STORY.mastery&&STORY.mastery()==='mine'){
      box.innerHTML=`<span class="guide-kicker">USTALIK</span><h2 class="guide-title">Kristal madeni</h2><p class="guide-copy">Bugünün uzun işi bu. Tarla ve Melis duruyor; üçünü birden kovalama.</p><div class="guide-actions"><button id="guide-primary" class="primary" data-target="mine">⛏️ Madene Git</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(STORY.mastery&&STORY.mastery()==='frontier'){
      box.innerHTML=`<span class="guide-kicker">USTALIK</span><h2 class="guide-title">Sisli yayla</h2><p class="guide-copy">Geçitten bir kez gir, kampı gör. Tarla akşam da burada.</p><div class="guide-actions"><button id="guide-primary" class="primary" data-target="yayla">🌫️ Yaylaya Git</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(STORY.mastery&&STORY.mastery()==='elite'){
      box.innerHTML=`<span class="guide-kicker">USTALIK</span><h2 class="guide-title">Seçkin sırt</h2><p class="guide-copy">Üç seçkin kül sırtının batısında. Yoldan çekilmezler. Birine yanaş.</p><div class="guide-actions"><button id="guide-primary" class="primary" data-target="elite">★ Sırta Git</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(free){
      box.innerHTML=`<span class="guide-kicker">SERBEST MACERA</span><h2 class="guide-title">Kendi hedefini seç</h2><p class="guide-copy">Ana rota tamamlandı. Çiftlik, dostluklar, maden, inşa, arena veya keşif hedeflerinden istediğini seçebilirsin.</p><div class="guide-why"><b>Sıkılmadan oynamak için:</b><br>Aynı gün her sistemi yapmak zorunda değilsin. Bir ana hedef seç, tamamla ve sonra başka bir etkinliğe geç.</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="map">🗺️ Haritayı Aç</button><button id="guide-journal">📔 Hedefleri Gör</button></div>`;
    }else if(q.k==='forge'){
      box.innerHTML=`<span class="guide-kicker">EJDER YOLU</span><h2 class="guide-title">Bir kez +1</h2><p class="guide-copy">Boran kılıcı dövecek. 40 altın, elmas yok, sonuç kesin. Fıskiye ve kovan sonra.</p><div class="guide-why"><b>Demirci Boran</b><br>“Kör çelikle küllü yola çıkılmaz. Getir, bir kez vurayım.”</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="forge">🔨 Demirciye Git</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(q.k==='skeleton'){
      box.innerHTML=`<span class="guide-kicker">EJDER YOLU</span><h2 class="guide-title">Geçitte beş iskelet</h2><p class="guide-copy">Kül Geçidi yolu tutuyor. Ejder daha güneydeki arenada. Onu buraya çekme.</p><div class="guide-why"><b>Demirci Boran</b><br>“Birini çek, bitir. Arenaya inmeden işi kapat.”</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="pass">💀 Geçide Git</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else if(q.k==='dragon'){
      box.innerHTML=`<span class="guide-kicker">EJDER YOLU</span><h2 class="guide-title">Tek arena</h2><p class="guide-copy">Geçidi geç, güneydeki arenaya yalnız gir. İskeletleri oraya sürme.</p><div class="guide-why"><b>Muhtar Hamdi</b><br>“İşaretli alandan çık. Sersemleyince vur.”</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="pass">🐉 Geçitten Gir</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }else{
      const pct=Math.round(cl(P.qn/q.n,0,1)*100),place=navigationTarget()?.name||ZN[q.z]||'Gölgeköy',repeat=q.k==='any'&&P.bounties>0,rewardG=repeat?80:q.g,rewardM=repeat?2:q.m,rewardXp=repeat?150:q.xp,prep=QUEST_FLOW.preparation(q);
      box.innerHTML=`<span class="guide-kicker">${q.ch} · ${q.giver}</span><h2 class="guide-title">${q.icon} ${q.t}</h2><p class="guide-copy">${STORY.soFar()}</p><p class="guide-copy">${q.story}<br><br><b>İpucu:</b> ${q.tip}</p><div class="guide-progress"><i style="width:${pct}%"></i></div><p style="font-size:9px;color:#8fa6af;text-align:right">İlerleme: ${Math.min(P.qn,q.n)}/${q.n}</p><div class="guide-meta"><div><b>📍 Bölge</b>${place}</div><div><b>🎁 Ödül</b>${rewardG}🪙 · ${rewardM}💎 · ${rewardXp} XP</div><div><b>🧰 Hazırlık</b>${prep.ready}/${prep.total} hazır · önerilen Sv.${q.rec}</div></div><div class="guide-why"><b>Neden yapıyorum?</b><br>${q.why}</div><div class="guide-actions"><button id="guide-primary" class="primary" data-target="map">🗺️ Haritada Göster</button><button id="guide-journal">📔 Yolcu Defteri</button></div>`;
    }
  }
  const primary=$('guide-primary');if(primary)primary.onclick=()=>{
    const target=primary.dataset.target;$('guide-modal').classList.add('h');
    const stepNow=ONBOARD.current();
    if(target==='rest'){
      if(curMap==='inside'){P.x=22*TS;P.y=10*TS;P.f=1;ban('Yatak sağ üstte.','#93c5fd')}
      else if(switchMap('home')){P.x=14*TS;P.y=25*TS;P.f=0;chat('REHBER','','İçeri gir, yatağa uzan. Gece yarısından sonra sabah açılır.',1)}
    }else if(target==='oasis'){
      if(curMap!=='world'){if(switchMap('world','desert'))chat('KERVANCI LEYLA','','Çöl ağzındasın. Doğuya yürü. Akrepler yolun kenarında, vaha daha ileride.',1)}
      else ban('Sarı hedef vahayı gösterir. Yol doğuya gider.','#fde68a');
    }else if(target==='forge'){
      if(curMap!=='home'){if(switchMap('home')){P.x=48*TS;P.y=40*TS;P.f=0;chat('DEMİRCİ BORAN','','Ocağın başındayım. Kılıcını getir; bir kez, 40 altına.',1)}}
      else{P.x=48*TS;P.y=40*TS;P.f=0;ban('Demirci hemen yanında.','#f6d7a3')}
    }else if(target==='pass'){
      if(curMap!=='world')switchMap('world','pass');
      else ban('Sarı hedef geçidi gösterir. Güneye in.','#fca5a5');
    }else if(target==='hamdi'){
      if(curMap!=='home')switchMap('home','hamdi');
      else{P.x=20*TS;P.y=13*TS;P.f=2;ban('🏛️ Belediye önü','#fde68a')}
    }else if(target==='night'){
      if(curMap!=='home')switchMap('home');
      P.x=14*TS;P.y=25*TS;P.f=0;ban('🏡 Kapın açık','#e9d39d');
    }else if(target==='garden'){
      if(curMap!=='home'){if(!switchMap('home'))return}
      P.x=17*TS;P.y=27*TS;P.f=0;FARM.openUI('simple');
    }else if(target==='melis'){
      if(curMap!=='home'){if(!switchMap('home'))return}
      P.x=25*TS;P.y=23*TS;P.f=3;P.adventure.trackedFriend='melis';
      ban('🥐 Melis','#fca5a5');chat('MELİS','','Günaydın. Sana somun duruyor. Uzun konuşmayız.',1);
    }else if(target==='pick-mine'||target==='pick-frontier'||target==='pick-elite'){
      const id=target.slice(5);P.adventure.pinnedGoal=id;sv();
      chat(id==='elite'?'ARENA USTASI':'MUHTAR HAMDİ','',id==='mine'?'Maden kasabanın batısında. Bugün bir kat yeter.':id==='frontier'?'Yayla geçidi doğu yolunda. Bir kez gir, kampı gör, dön.':'Üçü kül sırtının batısında. Yoldan çekilmezler. Birine yanaş.',1);
    }else if(target==='mine'){
      if(curMap!=='home'){if(!switchMap('home'))return}
      P.x=6*TS;P.y=9*TS;P.f=1;ban('⛏️ Kristal Madeni','#fde68a');
    }else if(target==='yayla'){
      if(curMap!=='world'){if(!switchMap('world'))return}
      P.x=55*TS;P.y=32*TS;P.f=1;ban('🌫️ Yayla Geçidi','#c4b5fd');
    }else if(target==='elite'){
      if(curMap!=='world'){if(!switchMap('world'))return}
      P.x=28*TS;P.y=76*TS;P.f=0;ban('★ Seçkin sırt','#fca5a5');
    }
    else if(target==='farm'&&curMap==='home')FARM.openUI('simple');
    else if(stepNow?.id==='cook'&&curMap==='inside'){ $('cook-modal').classList.remove('h'); cookUI(); }
    else if(stepNow?.id==='forest'){
      const road=WAYPOINTS.defs.find(d=>d.name==='Zümrüt Orman');
      if(road&&!WAYPOINTS.isUnlocked('world',road.name))WAYPOINTS.unlock(road);
      if(curMap!=='world')switchMap('world','forest');
      else{P.x=50*TS;P.y=26*TS;P.f=1;P.z=1;P.biome='forest';ban('🌲 Slime açıklığı','#86efac')}
    }
    else if(stepNow?.id==='chest'){
      if(curMap!=='home'){if(switchMap('home')){P.x=29*TS;P.y=36*TS;P.f=0;chat('REHBER','','İnşa arazisindesin. Depo Sandığını Kur.',1)}}
      else if(Math.hypot(P.x-27*TS,P.y-37*TS)<90)BUILD.start('chest');
      else chat('REHBER','','İnşa arazisi evin güneyinde. Sarı ok orayı gösteriyor; varınca Depo Sandığını Kur çıkar.',1);
    }
    else if(target==='build')ADVENTURE.open('build');
    else{const nav=navigationTarget();openMap(nav?.map)}
  };
  box.querySelectorAll('[data-target]').forEach(btn=>{if(btn!==primary)btn.onclick=()=>{primary.dataset.target=btn.dataset.target;primary.click()}});
  const journal=$('guide-journal');if(journal)journal.onclick=()=>{$('guide-modal').classList.add('h');ADVENTURE.open('farm')};
  const skip=$('guide-skip');if(skip)skip.onclick=()=>{ONBOARD.skip();$('guide-modal').classList.add('h')};
  const aid=$('guide-aid');if(aid)aid.onclick=()=>{ONBOARD.chestAid();guideUI()};
}
function openGuide(){guideUI();$('guide-modal').classList.remove('h')}
$('qs').onclick=openGuide;
$('guide-close').onclick=()=>$('guide-modal').classList.add('h');

const STORY=window.STORY={
  page:0,draftName:'',scene:null,bound:false,
  init(){
    const s=P.adventure.story||{};
    const beats=s.beats&&typeof s.beats==='object'?{...s.beats}:{};
    P.adventure.story={v:2,closed:s.closed===true,closedDay:Number(s.closedDay)||0,name:typeof s.name==='string'?s.name.slice(0,18):'',prologue:s.prologue===true,beats};
    this.install();
  },
  state(){if(!P.adventure.story)this.init();return P.adventure.story},
  hero(){const n=this.state().name;return n&&n.length>=2?n:''},
  fill(s){return String(s||'').split('{name}').join(this.hero()||'Yolcu')},
  fresh(){return !!(window.ONBOARD&&ONBOARD.active&&ONBOARD.active()&&!this.state().prologue)},
  ready(){return QUEST_FLOW.optional()&&QUEST_FLOW.verifiedDragon()},
  closed(){return this.ready()&&this.state().closed},
  needsRest(){return this.state().beats.rest===true&&P.q===2&&!(window.ONBOARD&&ONBOARD.active&&ONBOARD.active())},
  needsOasis(){return this.state().beats.oasis===true&&P.q===6&&!(window.ONBOARD&&ONBOARD.active&&ONBOARD.active())},
  cueHome(){return this.ready()&&!this.closed()},
  resting(){return this.closed()&&Number(this.state().closedDay)===Number(P.day)},
  mastery(){const id=P.adventure?.pinnedGoal;return ['mine','frontier','elite'].includes(id)?id:null},
  morningDue(){return this.closed()&&!this.resting()&&!this.mastery()},
  wantsTalk(){return !!(window.ONBOARD&&ONBOARD.active&&ONBOARD.active())||this.cueHome()},
  openingDue(){return !!(window.ONBOARD&&ONBOARD.active&&ONBOARD.active()&&!this.state().beats.arrive)},
  pathLine(){return {warrior:'Kılıcın kapıda dursun. İlk darbeyi sen vuracaksın.',mage:'Külün içindeki eski sözleri sen okursun.',ranger:'Orman yolunu bizden önce sen görürsün.'}[P.cls]||'Yolun senin.'},
  soFar(){
    const name=this.hero();
    if(window.ONBOARD&&ONBOARD.active&&ONBOARD.active())return (name?name+', ':'')+'Muhtar Hamdi sana boş bir ev ve bir söz verdi: önce yuvanı kur, sonra yolları aç, en son ejderin gölgesiyle yüzleş.';
    const q=P.q|0;
    if(q<=2)return 'Gölgeköy seni yeni tanıyor. Orman yolu ve kadim muhafız, yuvanın ilk sınavı.';
    if(q<=4)return 'Orman seni kabul etti. Şimdi gölün kıyısı, kasabanın kileri için tutulmalı.';
    if(q<=6)return 'Kıyı açıldı. Kızıl Çöl’deki kervan yolu kasabanın nefes borusu; taş dev hâlâ dostu düşmandan ayıramıyor.';
    if(q<=9)return 'Yollar geri alındı. Kalan iş çelik, geçit ve Kızıl Ejder. Kurduğun hayat, bu yüzleşmenin nedeni.';
    if(this.cueHome())return (name?name+', ':'')+'güney sırtı sustu. Hamdi rapor istemiyor. Hikâye, belediye kapısında bir nefesle kapanır.';
    if(this.closed()&&this.mastery()==='mine')return 'Ana hikâye kapandı. Bugünün uzun işi kristal madeni. Tarla ve dostlar duruyor.';
    if(this.closed()&&this.mastery()==='frontier')return 'Ana hikâye kapandı. Bugünün uzun işi sisli yayla. Tarla ve dostlar duruyor.';
    if(this.closed()&&this.mastery()==='elite')return 'Ana hikâye kapandı. Bugünün uzun işi seçkin sırt. Üçünü birden çekme.';
    if(this.closed())return (name?name+', ':'')+'gece bitti. Tarlaya bak, Melis’e uğra, bir iş seç.';
    return 'Bir hayat kur, kurduğun hayatı koru.';
  },
  chapterKey(){
    if(this.cueHome())return 'DÖNÜŞ';
    if(this.closed())return 'SON';
    return QS[P.q]?.ch||'';
  },
  npcLine(id){
    const ch=this.chapterKey();
    const book={
      melis:{
        'YUVADAN İLK ADIM':'Ekmek kokusu kasabayı ayakta tutuyor. Balık getirirsen akşam sofrası tamamlanır.',
        'KIYILARIN ÇAĞRISI':'Göl huzursuz. Balıkçılar dönene kadar fırın yarım ekmek pişiriyor.',
        'KIZIL ÇÖL':'Kervan gecikince un da gecikiyor. Leyla’nın yolu açılırsa kahve de gelir.',
        'EJDER YOLU':'Yola çıkacaksan sıcak bir somun al. Kül, aç karna daha ağırdır.',
        'DÖNÜŞ':'Fırın sıcak. Sana somun ayırdım. Hamdi kapıda; ben o konuşmayı bölmem.',
        'SON':'Yarın kutlama ekmeği senin undan olur. Bu gece sadece ye.'
      },
      osman:{
        'YUVADAN İLK ADIM':'Toprak acele etmez. Önce evi tanı, sonra tohumun sırasını sor.',
        'KIYILARIN ÇAĞRISI':'Gölün balığı sofraya, toprağın ürünü pazara gider. İkisi de kasabadır.',
        'KIZIL ÇÖL':'Kervan susarsa eski tohumlar da susar. Yolu açık tut.',
        'EJDER YOLU':'Çöle ya da geçide çıkmadan önce azığını iki kez say.',
        'DÖNÜŞ':'Tarlayı suladım, sormadım. Bu gece tohum konuşmayız.',
        'SON':'Bereket kesesi duruyor. Sabah bakarsın.'
      },
      dede:{
        'YUVADAN İLK ADIM':'Her bitkinin mevsimi, her insanın da bir büyüme zamanı vardır. Bahçenden başla.',
        'KIYILARIN ÇAĞRISI':'Köklerdeki kül dinmeden muhafız da dinmezdi. Göl şimdi aynı şarkıyı söylüyor.',
        'KIZIL ÇÖL':'Çöl toprağı sabırsızdır. Kasabanın toprağı değil. İkisini karıştırma.',
        'EJDER YOLU':'Kadim bahçeler ejderi hatırlar. Sen de hatırla: savaşmak için değil, korumak için gittin.',
        'DÖNÜŞ':'Sırt sustu. Ben de sustum. Yarın kökleri sayarız.',
        'SON':'Bu gece öğrencilik de, koruyuculuk da konuşulmaz.'
      },
      boran:{
        'YUVADAN İLK ADIM':'Kılıç sabır ister. Önce ocağını yak, sonra benimkine gel.',
        'KIYILARIN ÇAĞRISI':'Islak çelik pas tutar. Gölden dönünce kılıcını kurula.',
        'KIZIL ÇÖL':'Taş dev kördür. Kör çelikle onun karşısına çıkma.',
        'EJDER YOLU':'Bir eşyayı +1 yapmak niyetini metale yazmaktır. Yazmadan geçide çıkma.',
        'DÖNÜŞ':'Kılıç işini gördü. Bu gece örs de sussun.',
        'SON':'Atölye sabah açık. Bu gece kilitliyim.'
      }
    };
    return book[id]?.[ch]||'';
  },
  hamdiLine(){
    const ch=this.chapterKey();
    const lines={
      'YUVADAN İLK ADIM':'Önce evi, sonra yol. Ejder bekleyebilir.',
      'KIYILARIN ÇAĞRISI':'Göl kasabanın kileridir. Kıyıyı boş bırakma.',
      'KIZIL ÇÖL':'Kervan yolu susarsa fırın da susar.',
      'EJDER YOLU':'Çeliğin hazırsa geçide çık. Değilse Boran’a uğra.',
      'DÖNÜŞ':'Kapıdayım. Rapor yok. Bir nefes yeter.',
      'SON':'Anahtar sende. Bu gece başka sözüm yok.'
    };
    return lines[ch]||'Acele etme. Bir hayat kur, sonra onu koru.';
  },
  ambient(name){
    if(Math.random()>.42)return null;
    if(name==='Muhtar Hamdi')return this.hamdiLine();
    const id={Melis:'melis','Amca Osman':'osman','Çiftçi Dede':'dede'}[name];
    return id?this.npcLine(id)||null:null;
  },
  sky(){return '<div class="story-sky" aria-hidden="true"><i class="moon"></i><i class="ridge"></i><i class="town"><b style="left:22%"></b><b style="left:48%"></b><b style="left:71%"></b></i></div>'},
  pages(){
    return [
      {kicker:'AETHERMOOR',title:'Kızıl gölge',body:'Güney sırtının ardında gökyüzü bir yara gibi duruyor. Aethermoor’un kadim ejderi uyanmadı. Hiç uyumamıştı. Yalnızca bekliyordu. Kül, rüzgârla köylere iniyor.'},
      {kicker:'GÖLGEKÖY',title:'Kurulmuş bir hayat',body:'Fırının dumanı, tarlanın kokusu, demircinin örsü. Burada insanlar küçük bir hayat kurmuş. Şimdi o hayatı koruyacak birine ihtiyaçları var. Ejder henüz uzakta. Gölgesi değil.'},
      {kicker:'ANAHTAR',title:'Boş duran ev',body:'Eski çiftlik evinin anahtarı Muhtar Hamdi’de. Toprağı işle, sofrayı kur, yolları güvenli kıl. Yüzleşme vakti geldiğinde hazır olacaksın. Acele etme. Bir hayat kur. Sonra onu koru.'}
    ];
  },
  renderTitle(){
    const box=$('cd');if(!box)return;
    if(!this.fresh()){
      const q=QS[P.q],rec=GOALS.recommendation(),pinned=GOALS.pinnedCue(),mode=GAME_BALANCE.profile();
      const summary=`<div class="resume-card"><b>${q?q.icon+' '+q.t:'Serbest macera'}</b><span>${this.soFar()}</span>${rec?`<span>${rec.icon} Öneri: ${rec.title}</span>`:''}${pinned?`<span>📌 Takipte: ${pinned.icon} ${pinned.name} · %${pinned.pct}</span>`:''}<span>⚔️ Mod: ${mode.name}</span></div>`;
      box.innerHTML=`<div class="prologue-page">${this.sky()}<span class="story-kicker">KALDIĞIN YER</span><h1>AETHERMOOR</h1><p class="visual-intro"><b>${escapeHTML(this.hero()||'Yolcu')}, bir hayat kur. Sonra onu koru.</b><br><span style="font-size:10px;color:#bed4da">Sarı hedef kaldığın adımı gösterir. Hikâye, görev listesinin üstünde durur.</span></p>${summary}${WORLD_EVENTS.html()}<button class="m" id="go" type="button" style="width:100%;min-height:44px;font-size:15px;margin:6px 0">${P.lvl>1||P.q>0||this.state().prologue?'KALDIĞIN YERDEN DEVAM':'MACERAYA BAŞLA'}</button><p style="font-size:11px;margin:4px 0">🏡 Hazırlan · 🌿 Üret · 🧭 Keşfet · 🎁 Güçlen</p><p style="font-size:10px;color:#a5f3fc;margin:2px 0">🎮 Joystick · ☰ menüler · sarı hedef: sıradaki adım</p></div>`;
      $('go').onclick=startGame;return;
    }
    const pages=this.pages();
    if(this.page<pages.length){
      const pg=pages[this.page];
      box.innerHTML=`<div class="prologue-page">${this.page===0?this.sky():''}<span class="story-kicker">${pg.kicker} · ${this.page+1}/4</span><h1>${pg.title}</h1><p class="story-line">${pg.body}</p><div class="story-dots">${pages.concat([{}]).map((_,i)=>`<i class="${i===this.page?'on':''}"></i>`).join('')}</div><button class="m" id="story-turn" type="button" style="width:100%;min-height:44px;font-size:14px;margin:6px 0">Devam</button><p style="font-size:9px;color:#94a3b8;text-align:center">Enter ile devam · karanlık alana basmak hikâyeyi atlamaz</p></div>`;
      $('story-turn').onclick=()=>{this.page++;this.renderTitle()};
      return;
    }
    const pace=GAME_BALANCE.state();
    const paths=Object.values(CLASSES).map(c=>`<button type="button" class="path-card${c.id===P.cls?' on':''}" data-path="${c.id}"><span style="font-size:22px">${c.icon}</span><span><b>${c.name}</b><small>${c.id==='warrior'?'Kapının ilk kalkanı. Yakın dövüş, yüksek can.':c.id==='mage'?'Küldeki eski büyü. Uzaktan, kırılgan, güçlü.':'Orman yolunun gözü. Hızlı ve delici.'}</small></span></button>`).join('');
    const paces=Object.entries(GAME_BALANCE.profiles).map(([id,pr])=>`<button type="button" class="${id===pace?'on':''}" data-pace="${id}">${pr.name}</button>`).join('');
    box.innerHTML=`<div class="prologue-page"><span class="story-kicker">SEN · 4/4</span><h1>Adın ve yolun</h1><p class="guide-copy" style="font-size:11px">Kasaba seni adınla çağıracak. Yolun, ilk dövüşün nasıl hissedileceğini belirler; sonra da değiştirebilirsin.</p><input id="origin-name" class="origin-name" maxlength="16" autocomplete="nickname" placeholder="Adın" value="${escapeHTML(this.draftName||this.hero())}" aria-label="Kahramanın adı"><div class="path-grid">${paths}</div><div class="pace-row" role="group" aria-label="Macera temposu">${paces}</div><p class="difficulty-desc">${escapeHTML(GAME_BALANCE.profile().desc)}</p><button class="m" id="go" type="button" style="width:100%;min-height:44px;font-size:15px;margin:6px 0">GÖLGEKÖY’E AYAK BAS</button><p style="font-size:9.5px;color:#94a3b8">İlk beş adım sırayla gösterilir. Sarı hedef, ne yapacağını ve nedenini her zaman açıklar.</p></div>`;
    $('origin-name').addEventListener('input',e=>{this.draftName=e.target.value});
    box.querySelectorAll('[data-path]').forEach(b=>b.onclick=()=>{P.cls=b.dataset.path;updateClassButtons();this.rememberDraft();this.renderTitle()});
    box.querySelectorAll('[data-pace]').forEach(b=>b.onclick=()=>{P.adventure.difficulty=b.dataset.pace;this.rememberDraft();this.renderTitle()});
    $('go').onclick=startGame;
  },
  rememberDraft(){const input=$('origin-name');if(input)this.draftName=input.value},
  commit(){
    const input=$('origin-name');
    if(input){
      const raw=input.value.replace(/[<>]/g,'').trim().slice(0,16);
      this.state().name=raw.length>=2?raw:(this.draftName||'').replace(/[<>]/g,'').trim().slice(0,16);
      if(this.state().name.length<2)this.state().name='Yolcu';
    }else if(this.fresh()&&!this.hero())this.state().name='Yolcu';
    if(this.fresh())this.state().prologue=true;
  },
  openingBeats(){
    return [
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'ANAHTAR',line:'{name}. Anahtar sende. Bu ev, bu tarla, bu kapı artık senin. '+this.pathLine()},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'YUVA',line:'Önce yuvanı tanı. Ocağı yak, bahçeyi ayıkla, bir somun ekmek pişir. Karnı tok insan ormana daha doğru bakar.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'YOL',line:'Zümrüt Orman yolu slime kaynıyor. Altısını temizle. Dönüşte kuru dallardan odun, kayalardan taş getir. İlk sandığını birlikte kurarız.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'GÖLGE',line:'Ejder henüz uzakta. Ama gölgesi her sabah biraz daha yakın. Acele etme. Sarı hedef, sıradaki adımı unutturmaz.',cta:'Eve doğru yürü'}
    ];
  },
  finaleBeats(){
    return [
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'BELEDİYE ÖNÜ',line:'Döndün. Güney sırtında duman yok. Bunu sormama gerek kalmadı.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'SAYILMAYANLAR',line:'Anahtarı verdiğim gün bu kapı boştu. Melis’in ekmeği yetti, Boran çeliği bir kez dövdü, geçitte durdun. Bunu madalya diye okumam.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'BU GECE',line:'Arena ustası sabah kapını çalar. Bu gece çalmasın. Kasaba payı da, elit av da sabahın işi.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'SENİN YOLUN',line:window.DECISIONS?DECISIONS.finaleLine():'Bir hayat kurdun ve onu korudun.'},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'ANAHTAR',line:'Anahtarı geri istemiyorum, {name}. Bu gece evinde uyu. Sabah tarla da, dostlar da, seçtiğin bir iş de burada olur.',cta:'Bu gece kalıyorum'}
    ];
  },
  begin(){
    if(!this.openingDue()||this.scene)return;
    setTimeout(()=>{if(this.openingDue()&&!this.scene)this.play(this.openingBeats(),()=>this.grantWelcome())},420);
  },
  briefHTML(){
    const c=(window.CHAPTERS&&CHAPTERS[0])||{name:'Yuvadan İlk Adım'};
    return `<span class="brief-kicker">ANA HİKÂYE · ${c.name.toUpperCase()}</span>
      <h2 class="brief-title">Yuvadan İlk Adım</h2>
      <p class="brief-copy">Gölgeköy seni içine aldı. Muhtar Hamdi boş bir evin anahtarını verdi ama karşılığında bir şey istiyor: <b>kasaba yeniden nefes alsın.</b></p>
      <div class="brief-goals">
        <div><span>🏡</span><div><b>İlk gününü kur</b><small>Eve gir, tarlaya bak, ocağı yak. Sen ayakta olmazsan kimseye faydan dokunmaz.</small></div></div>
        <div><span>⚔️</span><div><b>Yolu aç</b><small>Orman yolunu kesen 6 slime’ı temizle. Kasaba pazara çıkamıyor.</small></div></div>
        <div><span>🎣</span><div><b>Sofrayı kur</b><small>Melis’in ocağı için 3 balık tut. Aç kasaba, korunmuş kasaba değildir.</small></div></div>
        <div><span>🌳</span><div><b>Sınırı koru</b><small>Köklerine kül işlemiş Orman Muhafızı’nı durdur. Bölüm burada kapanır.</small></div></div>
      </div>
      <div class="brief-reward"><b>BÖLÜM SONUNDA</b><span>Üç sandıktan birini seçersin · Kıyıların Çağrısı açılır</span></div>
      <div class="brief-hook">🕯️ <b>Bir not:</b> Kül güneyden geliyor ama rüzgâr kuzeyden esiyor. Bunu sonra konuşacağız.</div>`;
  },
  showChapterBrief(){
    if(!P.adventure||P.adventure.brief1)return false;
    P.adventure.brief1=true;
    $('chapter-brief-content').innerHTML=this.briefHTML();
    $('chapter-brief-modal').classList.remove('h');
    if(window.GAME_CORE)GAME_CORE.resetInput();
    playChord([392,523,659],.25,'triangle',.04);
    sv();
    return true;
  },
  grantWelcome(){
    const s=this.state();if(s.beats.arrive)return;
    s.beats.arrive=true;s.beats.purse=true;
    if(Number.isSafeInteger(P.gold+20))P.gold+=20;
    ban('🪙 Kasaba kesesi · +20 altın','#fde68a');
    chat('MUHTAR HAMDİ','','İlk günün kesesi hazır. Evin kapısı hemen yanında; içeri gir.',1);
    playChord([392,523,659],.22,'triangle',.04);svNow();
    if(window.MODAL_QUEUE&&(P.q|0)===0)MODAL_QUEUE.enqueue('brief1',5,'chapter-brief-modal',()=>this.showChapterBrief());
  },
  welcomeLine(){
    const name=this.hero();
    if(this.closed())return (name?name+', ':'')+'yuvana döndün. Gölgeköy seni bekliyordu.';
    if(this.cueHome())return (name?name+', ':'')+'duman kesildi. Hamdi kapıda. Rapor yok.';
    if(window.ONBOARD&&ONBOARD.active&&ONBOARD.active())return (name?name+', ':'')+'ilk düzenin yarım kaldı. Sarı hedef kaldığın yerden devam eder.';
    const q=QS[P.q];
    if(q)return (name?name+', ':'')+'kaldığın yer: '+q.t+'. '+q.story;
    return 'Gölgeköy’e döndün. Bir hayat kur, kurduğun hayatı koru.';
  },
  talk(){
    if(this.cueHome())return this.finale();
    const step=window.ONBOARD&&ONBOARD.current&&ONBOARD.current();
    const q=QS[P.q];
    const beats=step?[
      {who:step.speaker||'Muhtar Hamdi',icon:'🏛️',kicker:'İLK DÜZEN',line:step.voice||step.hint},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'TEMPO',line:'Acele etme. Sarı hedef sıradaki adımı gösterir. Kasaba payın ilk gün ücretsiz; düzenini kurunca bu binadan alırsın.',cta:'Anladım'}
    ]:q?[
      {who:q.giver,icon:q.icon,kicker:q.ch,line:q.story},
      {who:'Muhtar Hamdi',icon:'🏛️',kicker:'YOL',line:q.tip,cta:'Anladım'}
    ]:[{who:'Muhtar Hamdi',icon:'🏛️',line:this.soFar(),cta:'Anladım'}];
    const alt=window.ONBOARD&&ONBOARD.active&&ONBOARD.active()?{label:'Kasaba geliri',fn:()=>{$('townhall-modal').classList.remove('h');townhallUI()}}:null;
    this.play(beats,null,{skipDone:false,alt});
  },
  finale(){
    if(this.scene||!this.ready()||this.closed())return false;
    if(curMap!=='home'||Math.hypot(P.x-18*TS,P.y-14*TS)>70){
      P.adventure.navWaypoint={map:'home',x:18,y:14,name:'Muhtar Hamdi'};
      fl(P.x,P.y-28,'Muhtar belediye önünde bekliyor.','#fde68a',true);
      $('townhall-modal')?.classList.add('h');$('journey-modal')?.classList.add('h');
      return false;
    }
    $('townhall-modal')?.classList.add('h');$('journey-modal')?.classList.add('h');
    this.play(this.finaleBeats(),()=>this.close(),{skipDone:false});
    return true;
  },
  close(){
    if(!this.ready()||this.closed()||curMap!=='home'||Math.hypot(P.x-18*TS,P.y-14*TS)>70)return false;
    const s=this.state();s.closed=true;s.closedDay=P.day;s.beats.finale=true;svNow();
    ban('🏡 Bu gece kapın açık.','#e9d39d');playChord([392,523,659,784],.35,'triangle',.05);
    chat('MUHTAR HAMDİ','',this.fill('{name}. Anahtar sende. Sabah konuşuruz.'),1);
    return true;
  },
  play(beats,done,opts={}){
    if(!beats||!beats.length){if(done)done();return}
    this.scene={beats,i:0,done,alt:opts.alt||null,skipDone:opts.skipDone!==false,decisionId:opts.decisionId||null};
    this.renderScene();
    $('story-modal').classList.remove('h');
    if(window.GAME_CORE)GAME_CORE.resetInput();
  },
  renderScene(){
    const sc=this.scene;if(!sc)return;
    const b=sc.beats[sc.i],last=sc.i===sc.beats.length-1;
    $('story-kicker').textContent=b.kicker||'GÖLGEKÖY';
    $('story-speaker').innerHTML=`<span>${b.icon||'🏛️'}</span><div>${escapeHTML(b.who||'Muhtar Hamdi')}</div>`;
    $('story-line').textContent=this.fill(b.line);
    $('story-dots').innerHTML=sc.beats.map((_,i)=>`<i class="${i===sc.i?'on':''}"></i>`).join('');
    const alt=$('story-alt'),actions=$('story-actions'),choicesBox=$('story-choices'),hasChoices=!!(b.choices&&b.choices.length);
    if(hasChoices){
      choicesBox.innerHTML=b.choices.map(o=>`<button type="button" class="choice" data-choice="${o.id}"><b>${o.icon||'•'} ${o.label}</b>${o.hint?`<small>${o.hint}</small>`:''}${o.reward?`<em>🎁 ${o.reward}</em>`:''}</button>`).join('');
      choicesBox.classList.remove('h');actions.classList.add('h');$('story-skip').classList.add('h');
      choicesBox.querySelectorAll('[data-choice]').forEach(btn=>btn.onclick=()=>this.pick(btn.dataset.choice));
      return;
    }
    choicesBox.classList.add('h');choicesBox.innerHTML='';actions.classList.remove('h');$('story-skip').classList.remove('h');
    $('story-next').textContent=last?(b.cta||'Devam et'):'Devam';
    if(sc.alt){alt.classList.remove('h');alt.textContent=sc.alt.label;actions.classList.remove('single')}
    else{alt.classList.add('h');actions.classList.add('single')}
  },
  advance(){
    const sc=this.scene;if(!sc)return;
    const cur=sc.beats[sc.i];
    if(cur&&cur.choices&&cur.choices.length)return; // karar bekliyor: ilerletme yok
    if(sc.i<sc.beats.length-1){sc.i++;this.renderScene();sfx(620,.08,'sine',.03);return}
    this.finish(false);
  },
  pick(id){
    const sc=this.scene;if(!sc||!sc.decisionId)return false;
    const def=window.DECISIONS&&DECISIONS.defs.find(d=>d.id===sc.decisionId);if(!def)return false;
    const opt=def.options.find(o=>o.id===id);if(!opt||DECISIONS.made(def.id))return false;
    DECISIONS.apply(def,opt);
    sc.beats.splice(sc.i+1,0,{who:def.who,icon:def.icon,kicker:'SONUÇ · '+def.kicker.replace(/^KARAR · /,''),line:opt.line,cta:'Devam'});
    sc.decisionId=null;
    sc.i++;this.renderScene();sfx(720,.12,'triangle',.05);
    return true;
  },
  finish(fromSkip){
    const sc=this.scene;if(!sc)return;
    if(sc.decisionId&&window.DECISIONS&&!DECISIONS.made(sc.decisionId))return; // karar verilmeden sahne kapanmaz
    $('story-skip').classList.remove('h');$('story-choices').classList.add('h');$('story-actions').classList.remove('h');
    const done=!fromSkip||sc.skipDone?sc.done:null;
    this.scene=null;
    $('story-modal').classList.add('h');
    if(window.GAME_CORE)GAME_CORE.resetInput();
    if(done)done();
  },
  install(){
    if(this.bound)return;this.bound=true;
    $('story-next').onclick=()=>this.advance();
    $('story-skip').onclick=()=>this.finish(true);
    $('story-alt').onclick=()=>{const alt=this.scene&&this.scene.alt;this.finish(true);if(alt)alt.fn()};
    document.addEventListener('click',e=>{if(e.target.closest?.('#story-close'))this.finale()});
    const replay=$('story-replay');
    if(replay)replay.onclick=()=>{$('help').classList.add('h');this.play(this.openingBeats(),null,{skipDone:false})};
  },
  journalHTML(){
    const order=[];for(const q of QS)if(!order.includes(q.ch))order.push(q.ch);
    const main=order.filter(c=>c!=='USTALIK HEDEFLERİ'&&c!=='GÜNLÜK SERBEST HEDEF');
    const rows=main.map(ch=>{
      const items=QS.map((q,i)=>({q,i})).filter(x=>x.q.ch===ch);
      const total=items.length,done=items.filter(x=>x.i<P.q).length,cur=items.some(x=>x.i===P.q);
      const state=done===total?'done':cur?'current':'locked';
      const icon=state==='done'?'✓':state==='current'?'➜':'🔒';
      return `<div class="story-track-row ${state}"><span>${icon}</span><strong>${ch}</strong><span>${done}/${total}</span></div>`;
    }).join('');
    const q=QS[P.q],defs=window.DECISIONS?DECISIONS.defs:[],st=window.DECISIONS?DECISIONS.state():{};
    const decided=defs.map(d=>{
      const v=st[d.id];
      if(!v)return '';
      if(v.opt==='legacy')return `<div class="decision-card"><h4>⏳ ${d.kicker.replace(/^KARAR · /,'')}</h4><p>Bu karar senin yolculuğunda sorulmadan geçti. Hikâye seni beklemedi.</p></div>`;
      return `<div class="decision-card"><h4>${escapeHTML(v.icon||d.icon)} ${escapeHTML(v.label||'Karar')}</h4><p>${escapeHTML(v.line||'')}</p><small>Gün ${v.day} · kalıcı karar</small></div>`;
    }).filter(Boolean).join('');
    const pending=window.DECISIONS?DECISIONS.due():null;
    const pendingCard=pending?`<div class="decision-card pending"><h4>⚖️ Şu an bir karar bekliyor</h4><p>${escapeHTML(pending.kicker.replace(/^KARAR · /,''))} bölümünde bir seçim seni bekliyor. Karar verilene kadar hikâye ilerlemez.</p><button type="button" data-decision-open="${pending.id}">Kararı Aç</button></div>`:'';
    const next=q?`<div class="story-next-box"><b>📍 Sıradaki adım: ${q.icon} ${q.t}</b><p>${q.why}</p><button type="button" data-goals-action="quest">Görevi Aç</button><button type="button" data-quest-map="1">🗺️ Haritada Göster</button></div>`:`<div class="story-next-box"><b>🌱 Ana rota tamam</b><p>Kendi hedefini seçebilirsin. Hikâye bitti; hayat devam ediyor.</p></div>`;
    return `<div class="journey-lead"><small>HİKÂYE DEFTERİ</small><h2>📖 Hikâyen</h2><p>${this.soFar()}</p></div>${next}<div class="goals-section-title">Bölümler <small>ANA ROTA</small></div><div class="story-track">${rows}</div>${pendingCard}${decided?`<div class="goals-section-title">Kararların <small>KALICI</small></div>${decided}`:''}<div class="journey-box"><b>🧭 Bu defter ne işe yarar?</b><p>Bölümleri, verdiğin kararları ve sıradaki adımı tek yerde tutar. Kararlar sonradan değiştirilemez; bu yüzden seçerken iki kez düşün.</p></div>`;
  },
  html(){
    if(!this.ready())return '';
    const name=escapeHTML(this.hero()||'Yolcu');
    if(this.closed())return `<div id="story-epilogue" class="journey-lead"><small>ANA HİKÂYE TAMAMLANDI</small><h2>🏡 Yuvanın Koruyucusu</h2><p>Muhtar Hamdi: “${name}, Gölgeköy senin de yuvan. Ejderle yüzleştin; şimdi burada nasıl bir hayat sürdüreceğine sen karar vereceksin.”</p><p>Çiftlik, dostluklar, derin maden ve Kupa isteğe bağlı olarak devam eder. Tekrar karşılaşmalar bu kapanışı geri almaz.</p>${window.DECISIONS?DECISIONS.epilogueHTML():''}</div>`;
    return `<div id="story-return" class="journey-lead"><small>GÖLGEKÖY’E DÖNÜŞ</small><h2>🏡 Hikâyeni burada tamamla</h2><p>${name}, Muhtar Hamdi ejder yolculuğundan dönüşünü bekliyor. Bu kapanış ek para veya eşya üretmez; kazanımların zaten kayıtlı.</p><button id="story-close" type="button">Muhtarla Konuş · Ana Rotayı Tamamla</button></div>`;
  }
};
const DECISIONS=window.DECISIONS={
  queued:new Set(),migrated:false,
  defs:[
    {id:'ilk-karar',manual:true,at:9999,icon:'⚖️',who:'Muhtar Hamdi',kicker:'KARAR · İLK GECE',
     prompt:'Kül, damlarda ince bir tabaka bıraktı. Hamdi kapının önünde duruyor: “Yarın kimse aç kalmasın. Ama sen de kendini unutma. Bu gece neye öncelik vereceksin?”',
     options:[
      {id:'firin',icon:'🥖',label:'Fırına koş',hint:'Melis’in unu bitti; sabah ekmek çıkmalı.',reward:'+2 can iksiri · +20 altın',grant:{pots:2,gold:20},line:'Melis hamuru yoğururken gülümsedi: “Bu somun senin adına olacak.”'},
      {id:'kapi',icon:'🏡',label:'Kendi kapını sağlamlaştır',hint:'İlk gece, ilk çatı.',reward:'+60 altın · +1 can iksiri',grant:{gold:60,pots:1},line:'Kapanı sıkıca kapattın. Bu gece rüzgâr içeri girmeyecek.'},
      {id:'kul',icon:'🔍',label:'Külü araştır',hint:'Bu kül normal değil.',reward:'+1 elmas · +25 XP',grant:{gems:1,xp:25},line:'Külü parmaklarının arasına aldın: sıcak değil, ama yanık kokuyor. Bu, bir ocaktan çıkmadı.'}
     ]},
    {id:'ilk-sinav',at:3,win:2,icon:'🏛️',who:'Muhtar Hamdi',kicker:'KARAR · YUVADAN İLK ADIM',
     prompt:'Orman yolu açıldı, göl sustu. Gölgeköy seni artık yolcu değil komşu sayıyor. Hamdi anahtarı avucunda çeviriyor: “Burada ne olacaksın?”',
     options:[
      {id:'bekci',icon:'🛡️',label:'Yolun bekçisi',hint:'Sınırda dur; kimse zarar görmeden dönsün.',reward:'+150 altın · +2 can iksiri',grant:{gold:150,pots:2},line:'Boran örsü bıraktı: “Kapıda duran adam, kapıyı yapan adamdan kıymetlidir.”'},
      {id:'toprak',icon:'🌿',label:'Toprağın sesi',hint:'Bir hayat kurmak da korumaktır.',reward:'+6 buğday tohumu · +2 gübre · +120 altın',grant:{gold:120,fert:2,seeds:{wheat:6}},line:'Çiftçi Dede başını salladı: “Eken adam, kaçan adam değildir.”'},
      {id:'sessiz',icon:'🕯️',label:'Adı kalmasın',hint:'İşi bitir, ödülü kasabaya bırak.',reward:'+2 elmas · seviyene uygun eşya',grant:{gems:2,item:1},line:'Kimse görmedi. Melis yine de bir somun bıraktı: “Bunu senin için ayırdım.”'}
     ]},
    {id:'kiyi-yol',at:5,win:2,icon:'🎣',who:'Balıkçı Rıza',kicker:'KARAR · KIYILARIN ÇAĞRISI',
     prompt:'Kral Yengeç geri çekildi. Göl yeniden ekmek veriyor ama bu yük kimin sırtına binecek? Rıza iskeleyi, Leyla kervan yolunu, Melis kileri işaret ediyor.',
     options:[
      {id:'balikci',icon:'🎣',label:'İskeleyi onar',hint:'Kıyı halkı önce doysun.',reward:'+160 altın · +2 can iksiri',grant:{gold:160,pots:2},line:'Rıza ağını serdi: “Bu iskele artık iki kişilik. Biri senin.”'},
      {id:'kervan',icon:'🐫',label:'Kervan yolunu aç',hint:'Ticaret gelirse kasaba büyür.',reward:'+200 altın · +2 elmas',grant:{gold:200,gems:2},line:'Leyla defterini kapattı: “Yol açan, yol bekleyenden çok kazanır.”'},
      {id:'kiler',icon:'🏚️',label:'Kileri doldur',hint:'Kimse kışı aç geçirmesin.',reward:'+8 buğday tohumu · +3 gübre · +100 altın',grant:{gold:100,fert:3,seeds:{wheat:8}},line:'Melis un çuvalını taşıdı: “Bu kış fırın erken yanar.”'}
     ]},
    {id:'ejder-sinavi',at:9,win:1,icon:'🔨',who:'Demirci Boran',kicker:'KARAR · EJDER YOLU',
     prompt:'Geçit sustu. Arenaya çıkmadan önce Boran örsün üstüne üç şey koydu: bir kılıç, bir kitap, bir de kasabanın defteri. “Hangisini yanına alacaksın?”',
     options:[
      {id:'celik',icon:'⚔️',label:'Çeliği al',hint:'Gücünü artır; tek başına dayan.',reward:'+1 epik eşya · +2 can iksiri',grant:{item:1,rarity:2,pots:2},line:'Boran metalin sesini dinledi: “Niyetin çeliğe yazıldı. Ejder bunu hisseder.”'},
      {id:'bilgi',icon:'📖',label:'Kitabı al',hint:'Ejderin dilini öğren; zayıf yanını bul.',reward:'+3 elmas · +3 can iksiri · +200 altın',grant:{gold:200,gems:3,pots:3},line:'Rahibe Elara başını eğdi: “Bilmek, vurmanın ucuz yoludur.”'},
      {id:'soz',icon:'📜',label:'Kasabanın defterini al',hint:'Ardında bıraktığın hayatı hatırla.',reward:'+300 altın · +6 tohum · +4 gübre',grant:{gold:300,fert:4,seeds:{wheat:6}},line:'Hamdi defteri kapattı: “Bu sayfada senin adın var. Silmeyeceğim.”'}
     ]}
  ],
  state(){if(!P.adventure)return {};if(!P.adventure.decisions||typeof P.adventure.decisions!=='object')P.adventure.decisions={};return P.adventure.decisions},
  made(id){const v=this.state()[id];return !!(v&&v.opt)},
  migrate(){
    if(this.migrated)return;this.migrated=true;
    const st=this.state();let changed=false;
    for(const d of this.defs){
      if(d.manual||st[d.id])continue;
      if((P.q|0)>=d.at+(d.win||2)){st[d.id]={opt:'legacy',day:P.day|0,label:'Sorulmadı',icon:'⏳',line:'Bu karar senin yolculuğunda sorulmadan geçti.'};changed=true}
    }
    if(changed&&typeof sv==='function')sv();
  },
  due(){
    const st=this.state();
    const onboarding=window.ONBOARD&&ONBOARD.active&&ONBOARD.active();
    if(!onboarding){const man=this.defs.find(d=>d.manual&&!st[d.id]);if(man)return man}
    return this.defs.find(d=>!d.manual&&!st[d.id]&&(P.q|0)>=d.at&&(P.q|0)<d.at+(d.win||2))||null;
  },
  check(){this.migrate();const d=this.due();if(!d)return false;if(this.queued.has(d.id))return false;this.queued.add(d.id);MODAL_QUEUE.enqueue('decision:'+d.id,2,'story-modal',()=>this.play(d.id));return true},
  tick(){if(!gameStarted||!P.adventure)return;if(window.ONBOARD&&ONBOARD.active&&ONBOARD.active())return;this.check()},
  play(id){
    const d=this.defs.find(x=>x.id===id);if(!d||this.made(id))return false;
    if(this.sceneOpen())return false;
    STORY.play([
      {who:d.who,icon:d.icon,kicker:d.kicker,line:d.prompt},
      {who:'Sen',icon:'🎭',kicker:'KARAR · KALICI',line:'Bu seçim kalıcıdır. Kasabanın sana bakışını, sonraki replikleri ve dönüş hikâyeni değiştirir. Geri alınamaz.',choices:d.options}
    ],null,{skipDone:false,decisionId:id});
    return true;
  },
  sceneOpen(){const el=$('story-modal');return !!el&&!el.classList.contains('h')},
  apply(def,opt){
    const st=this.state(),g=opt.grant||{};
    st[def.id]={opt:opt.id,day:P.day|0,label:opt.label,icon:opt.icon,line:opt.line};
    if(g.gold)P.gold+=g.gold;
    if(g.gems)P.gems+=g.gems;
    if(g.pots)P.pots+=g.pots;
    if(g.fert)P.fert=(P.fert||0)+g.fert;
    if(g.seeds)for(const[k,n]of Object.entries(g.seeds))P.seeds[k]=(P.seeds[k]||0)+n;
    if(g.item){try{awardInventoryItem(gen(Math.max(P.lvl||1,3),g.rarity||1))}catch(e){P.gold+=120}}
    if(g.xp&&typeof addXp==='function')addXp(g.xp);
    NOTIFICATIONS.push('story',def.icon||'⚖️','Karar: '+opt.label,opt.line);
    ban('⚖️ KARAR VERİLDİ · '+opt.label,'#fde68a');
    playChord([392,523,659],.28,'triangle',.05);
    this.queued.delete(def.id);
    sv();
    return opt;
  },
  tone(){
    const st=this.state(),score={kalkan:0,kok:0,sessiz:0};
    const map={bekci:'kalkan',celik:'kalkan',toprak:'kok',balikci:'kok',kiler:'kok',sessiz:'sessiz',kervan:'sessiz',bilgi:'sessiz',soz:'sessiz'};
    for(const v of Object.values(st)){const t=v&&map[v.opt];if(t)score[t]++}
    return Object.entries(score).sort((a,b)=>b[1]-a[1])[0][0];
  },
  count(){return Object.values(this.state()).filter(v=>v&&v.opt&&v.opt!=='legacy').length},
  epilogueHTML(){
    const n=this.count();
    if(!n)return '<p style="font-size:9.5px;color:#9fb6c0">Bu yolculukta büyük bir karar vermedin. Yine de her sabah bir seçim: kalmak ya da gitmek.</p>';
    const lines={
      kalkan:'Seni kapıda duran biri olarak hatırlayacaklar. Gölgeköy artık bir sınır değil, bir söz.',
      kok:'Seni eken biri olarak hatırlayacaklar. Kasaba buğdayını senin bahçenden aldı.',
      sessiz:'Adını az kişi bilir. Ama küller dağıldığında ilk açan fırın senin sayende yandı.'
    };
    return `<p style="font-size:9.5px;color:#9fb6c0"><b style="color:#f3e2b6">Kararların:</b> ${n}/3 · ${lines[this.tone()]}</p>`;
  },
  finaleLine(){
    const n=this.count(),t=this.tone();
    if(!n)return 'Yolu yürüdün. Gerisini kasaba anlatacak.';
    const lines={
      kalkan:'Verdiğin kararlar örsün üstünde hâlâ duruyor. Bekçi olmayı seçtin; bu kapı bunu unutmaz.',
      kok:'Verdiğin kararlar tarlada hâlâ duruyor. Kurmayı seçtin; bu sofra bunu unutmaz.',
      sessiz:'Verdiğin kararlar küllün altında hâlâ duruyor. Adını saklamayı seçtin; bu kasaba bunu unutmaz.'
    };
    return lines[t]||'Yolu yürüdün.';
  }
};
function migrateSeedPouches(){
  let refunded=0,moved=0;const bags=[P.inv,P.storage,P.fieldCampStorage,P.shippingBin,P.pendingRewards,...P.adventure.buildings.map(b=>b.items)];
  for(const bag of bags)for(let i=bag.length-1;i>=0;i--){const it=bag[i];if(it.s!=='seed')continue;const n=Math.max(1,Math.floor(Number(it.qty)||1)),crop=it.cropK==='sun'?'sunflower':it.cropK;
    if(CROPS[crop]&&(P.seeds[crop]||0)+n<=1e9){P.seeds[crop]=(P.seeds[crop]||0)+n;moved+=n;bag.splice(i,1)}
    else if(['lotus','peach'].includes(crop)){const cost=(crop==='lotus'?15:30)*n;if(Number.isSafeInteger(P.gold+cost)){P.gold+=cost;refunded+=cost;bag.splice(i,1)}}
  }
  if(refunded)pendingLoadNotices.push(`🌱 Eski sürümde ekilemeyen nilüfer/şeftali fidanları için ${refunded} altın iade edildi.`);
  if(moved)pendingLoadNotices.push(`🌱 ${moved} eski tohum tohum kesesine taşındı.`);
}
function addPetXp(amount){
  const p=P.pet;if(!p||!Number.isFinite(amount)||amount<=0)return;
  const before=p.lvl;p.xp=(p.xp||0)+amount;
  while(p.lvl<10000&&p.xp>=p.lvl*25){p.xp-=p.lvl*25;p.lvl++}
  if(p.lvl>=10000)p.xp=0;
  if(p.lvl>before){fl(p.x,p.y-22,`★ YOLDAŞ SEVİYE ${p.lvl}!`,'#ffd23f',true);playChord([523,659,784],.2,'triangle',.04)}
}
function friendHearts(id){return P.friendship?.[id]?.hearts||0}
function friendPrice(id,base){return Math.max(1,Math.ceil(base*(friendHearts(id)>=2?.8:1)))}
function grantShield(amount,cap){const before=P.shld||0;P.shld=Math.max(before,Math.min(cap,before+Math.max(0,amount)));return P.shld-before}
function tileAhead(){const off=[[0,1],[0,-1],[-1,0],[1,0]][P.f]||[0,1];return {gx:Math.floor(P.x/TS)+off[0],gy:Math.floor(P.y/TS)+off[1],ox:off[0],oy:off[1]}}
function skillPerksText(){
  // Ekranda sunulanlar ile fiilen çalışan kurallar aynı olmalı; uygulanmamış oranlar vaat edilmez.
  MASTERY_INFO.farm.thresholds=[1,1,1,1];MASTERY_INFO.mine.thresholds=[2,4,1,1];MASTERY_INFO.cook.thresholds=[2,4,1,10];MASTERY_INFO.fish.thresholds=[1,1,7,1];
  TOWNSFOLK.melis.perks=['2 Kalp: Kafe alışverişlerinde %20 indirim.','5 Kalp: Kafenin süreli destekleri 6 dakika sürer.'];
  TOWNSFOLK.osman.perks=['2 Kalp: Tohumlarda %20 indirim.','5 Kalp: Ekimde %15 tohum harcamama şansı.'];
  TOWNSFOLK.dede.perks=['2 Kalp: Çiftçilik XP’si +%25.','5 Kalp: Sulama etkisi iki büyüme günü sürer.'];
  TOWNSFOLK.boran.perks=['2 Kalp: Ekipman geliştirmede altın maliyeti %20 azalır.','5 Kalp: Geliştirme başarısına +15 puan.'];
  MASTERY_INFO.farm.perks=['Her seviye: ek hasat olasılığı +3 puan.','Her seviye: altın kalite olasılığı +2,5 puan.','Her seviye: gümüş kalite olasılığı +3 puan.','Gübre, ek hasat ve kalite olasılığını artırır.'];
  MASTERY_INFO.mine.perks=['Lv.2: Kazma ve yakın dövüş maden darbesi 2 olur.','Lv.4: Normal keşif sandığında %35 ek elmas şansı.','Derin katlar daha değerli cevherler barındırır.','Kazma, merdivenli kayayı ve gizli duvarı açar.'];
  MASTERY_INFO.cook.perks=['Lv.2: Yemek desteği en az 6 dakika sürer.','Lv.4: %25 şansla çift porsiyon; tamamı sığmalı.','Tarifteki daha uzun destek süresi korunur.','Lv.10: Destek süresi en az 10 dakikadır.'];
  MASTERY_INFO.fish.perks=['Yağmur/fırtınada Şimşek Balığına rastlanabilir.','Göl yemi göldeki nadir balık şansını artırır.','Lv.7: %20 şansla +60 altın / +2 elmas hazinesi.','Deniz balıkları limanda anlık değerin %25 üstüne satılır.'];
}
/* @inline:foundation-runtime:end */
/* @inline:foundation-codec:start */
/* FOUNDATION CODEC — source fragment embedded in index.html; no runtime dependency. */
const SAVE_CODEC=window.SAVE_CODEC=(()=>{
  const MAX_BYTES=4*1024*1024,MAX_ROWS=4096;
  const forbidden=new Set(['__proto__','prototype','constructor']);
  const defaults=JSON.parse(JSON.stringify(P));
  const maps=new Set(['home','inside','world','frontier','mine']);
  const itemTypes=new Set([...Object.keys(SL),'mat','crop','food','food_ing','fish','seed','artisan','quest','spell']);
  const numFields={lvl:[1,10000],xp:[0,1e8],gold:[0,Number.MAX_SAFE_INTEGER],gems:[0,Number.MAX_SAFE_INTEGER],pots:[0,1e9],q:[0,QS.length],qn:[0,1000000],kills:[0,1e12],day:[1,1e9],guideStep:[0,4],rep:[0,1e12],rage:[0,100],waterCan:[0,20],houseLevel:[1,3],musicTrack:[0,MUSIC_TRACKS.length-1],mineFloor:[1,50],maxMineFloor:[1,50],mineElevator:[1,50],fieldCampLevel:[0,3],frontierMission:[0,3],coopLv:[0,3],barnLv:[0,3],arenaPts:[0,1e9],arenaWinsToday:[0,1e9],arenaStreak:[0,1e9],hay:[0,1e9],fert:[0,1e9],bounties:[0,1e9],caskTimer:[0,3600]};
  const isRecord=v=>!!v&&typeof v==='object'&&!Array.isArray(v);
  function clone(v,depth=0){
    if(depth>14)throw new Error('Kayıt iç içe veri sınırını aşıyor.');
    if(typeof v==='string')return v.replace(/[<>]/g,'');
    if(v===null||typeof v!=='object')return v;
    if(Array.isArray(v)){if(v.length>MAX_ROWS)throw new Error('Bir kayıt listesi güvenli boyutu aşıyor. Ham veri korunmalı.');return v.map(x=>clone(x,depth+1))}
    const out={};for(const k of Object.keys(v)){if(forbidden.has(k))continue;out[k]=clone(v[k],depth+1)}return out;
  }
  function normalize(input){
    if(!isRecord(input)||!Number.isFinite(input.lvl)||input.lvl<1)throw new Error('Geçerli bir oyuncu kaydı bulunamadı.');
    if(input.lvl>10000)throw new Error('Seviye güvenli motor sınırını aşıyor. Ham kayıt korunur.');
    if(Number(input.saveVersion)>SAVE_VERSION){const e=new Error('Bu kayıt daha yeni bir oyun sürümüne ait. Eski sürüm üzerine yazmayacak.');e.code='FUTURE_SAVE';throw e}
    const source=clone(input),out={},issues=new Set(),unknown=[];
    const issue=p=>issues.add(p);
    const number=(v,f,min=0,max=Number.MAX_SAFE_INTEGER,integer=true,p='sayı')=>{if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max){issue(p);return f}const n=integer?Math.floor(v):v;if(n!==v)issue(p);return n};
    const text=(v,f='',n=240,p='metin')=>{if(typeof v!=='string'){if(v!==undefined)issue(p);return f}return v.replace(/[<>\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').slice(0,n)};
    const key=(v,f='')=>typeof v==='string'&&/^[a-zA-Z0-9_:\-]{1,96}$/.test(v)?v:f;
    const record=(v,p)=>{if(isRecord(v))return v;if(v!==undefined&&v!==null)issue(p);return {}};
    const list=(v,p)=>{if(Array.isArray(v))return v;if(v!==undefined&&v!==null)issue(p);return []};
    const numbers=(v,p,min=0,max=1e12)=>{const result={};for(const [k,n]of Object.entries(record(v,p))){if(!key(k)){issue(p+'.anahtar');continue}result[k]=number(p==='ach'&&typeof n==='boolean'?Number(n):n,0,min,max,p==='ach',p+'.'+k)}return result};
    for(const [k,v]of Object.entries(source)){if(SAVE_KEYS.has(k)&&!forbidden.has(k))out[k]=v;else unknown.push(k)}
    // Bozuk sürüm etiketi (örn. "x") NaN üretip tüm < sürüm geçişlerini atlatmasın.
    out.saveVersion=out.saveVersion===undefined?0:number(out.saveVersion,0,0,SAVE_VERSION,true,'saveVersion');
    for(const [k,bounds]of Object.entries(numFields))if(out[k]!==undefined)out[k]=number(out[k],defaults[k]??(k==='day'||k==='houseLevel'||k.includes('Floor')||k==='mineElevator'?1:0),...bounds,!['caskTimer','xp'].includes(k),k);
    for(const k of ['lastBountyDay','townWorkDay','arenaRewardDay','fieldCampRestDay','frontierTradeDay','frontierBoarsKilled','frontierBoarStart','lakeBaitDay','caskReadyDay','eggsAvailable','coopLove'])if(out[k]!==undefined)out[k]=number(out[k],0,0,1e12,true,k);
    for(const [k,v]of Object.entries(defaults))if(typeof v==='boolean'&&out[k]!==undefined&&typeof out[k]!=='boolean'){issue(k);out[k]=v}
    for(const k of ['hasBarn','autoFeed'])if(out[k]!==undefined&&typeof out[k]!=='boolean'){issue(k);out[k]=false}
    if(!CLASSES[out.cls]){if(out.cls!==undefined)issue('cls');out.cls=defaults.cls}
    if(!['sword','hoe','can','pickaxe','rod','food','seed'].includes(out.activeTool)){if(out.activeTool!==undefined)issue('activeTool');out.activeTool='sword'}
    if(out.mineEntrance!==undefined)out.mineEntrance=out.mineEntrance==='world'?'world':'home';
    for(const k of ['volMusic','volSfx'])if(out[k]!==undefined)out[k]=number(out[k],k==='volMusic'?.8:.9,0,1,false,k);
    if(out.shakeSetting!==undefined&&!['normal','reduced','off'].includes(out.shakeSetting)){issue('shakeSetting');out.shakeSetting='normal'}
    if(out.auto!==undefined){
      const a=record(out.auto,'auto'),golem=number(a.golem??0,0,0,3,true,'auto.golem'),maxEnergy=AUTO.CAP[golem]||0;
      const flag=(v,p)=>{if(v===undefined||v===false||v===0)return false;if(v===true||v===1)return true;issue(p);return false};
      out.auto={golem,sorter:flag(a.sorter,'auto.sorter'),supply:flag(a.supply,'auto.supply'),post:flag(a.post,'auto.post'),energy:number(a.energy??0,0,0,maxEnergy,true,'auto.energy'),day:number(a.day??0,0,0,1e9,true,'auto.day'),h:number(a.h??0,0,0,1e12,true,'auto.h'),p:number(a.p??0,0,0,1e12,true,'auto.p'),w:number(a.w??0,0,0,1e12,true,'auto.w'),gold:number(a.gold??0,0,0,1e12,true,'auto.gold'),orders:number(a.orders??0,0,0,1e12,true,'auto.orders')};
    }
    function item(value,p){
      if(!isRecord(value)||!itemTypes.has(value.s)){issue(p);return null}
      const i={...value,s:value.s};
      i.k=key(value.k)||undefined;i.n=text(value.n,SL[i.s]?'Eski Ekipman':MATERIALS[ITEMS.key(i.k)]?.n||'Eşya',120,p+'.ad');
      if(value.icon!==undefined)i.icon=text(value.icon,'📦',16,p+'.ikon');
      if(value.desc!==undefined)i.desc=text(value.desc,'',1000,p+'.açıklama');
      for(const k of ['atk','def','hp','mp','val'])if(i[k]!==undefined)i[k]=number(i[k],0,0,1e12,false,p+'.'+k);
      for(const k of ['spd','crit'])if(i[k]!==undefined)i[k]=number(i[k],0,0,k==='crit'?1:20,false,p+'.'+k);
      if(i.r!==undefined)i.r=number(i.r,0,0,3,true,p+'.nadirlik');
      if(i.up!==undefined)i.up=number(i.up,0,0,15,true,p+'.geliştirme');
      if(i.star!==undefined)i.star=number(i.star,1,1,3,true,p+'.kalite');
      if(i.qty!==undefined){if(Number.isSafeInteger(i.qty)&&i.qty>10000)throw new Error('Malzeme miktarı güvenli yükleme sınırını aşıyor; ham kayıt korundu.');i.qty=number(i.qty,1,0,10000,true,p+'.miktar')}
      if(i.forgePity!==undefined)i.forgePity=number(i.forgePity,0,0,100,true,p+'.güvence');
      if(i.s==='food'&&i.k==='honey'&&i.duration===undefined)i.duration=360;
      if(i.duration!==undefined)i.duration=number(i.duration,180,1,3600,false,p+'.süre');
      if(i.buff&&!['atk','def','spd','crit'].includes(i.buff)){delete i.buff;issue(p+'.destek')}
      if(i.passive){const canonical=PASSIVES.find(x=>x.id===i.passive.id);if(canonical)i.passive={...canonical};else{delete i.passive;issue(p+'.pasif')}}
      if(i.element&&i.element!=='lightning'){delete i.element;issue(p+'.element')}
      if(i.origin)i.origin=['sea','lake','freshwater'].includes(i.origin)?i.origin:'freshwater';
      if(i.cropK)i.cropK=key(i.cropK);if(i.id!==undefined)i.id=key(String(i.id));if(i.locked!==true)delete i.locked;
      return i;
    }
    const items=(v,p)=>{const result=list(v,p).map((x,i)=>item(x,p+'['+i+']')).filter(Boolean);let slots=0;for(const it of result){slots+=ITEMS.stackable(it)?Math.ceil(ITEMS.qty(it)/ITEMS.MAX_STACK):1;if(slots>MAX_ROWS)throw new Error('Yığın açılımı güvenli liste sınırını aşıyor; ham kayıt korunur.')}return result};
    for(const k of ['inv','storage','fieldCampStorage','shippingBin','pendingRewards'])if(out[k]!==undefined)out[k]=items(out[k],k);
    if(out.inv===undefined)out.inv=[];
    const eq={};for(const [slot,value]of Object.entries(record(out.eq,'eq'))){if(!SL[slot]){issue('eq.'+slot);continue}const it=item(value,'eq.'+slot);if(it&&it.s===slot)eq[slot]=it;else issue('eq.'+slot)}out.eq=eq;
    out.ach=numbers(out.ach,'ach',0,1e12);out.tl={};for(const [k,v]of Object.entries(record(source.tl,'tl')))if(['a','h','c','s','v'].includes(k))out.tl[k]=number(v,0,0,100000,true,'tl.'+k);
    if(out.seeds!==undefined){const seeds={};for(const [k,v]of Object.entries(record(out.seeds,'seeds')))if(CROPS[k])seeds[k]=number(v,0,0,1e9,true,'seeds.'+k);out.seeds=seeds}
    if(out.seedSel!==undefined&&!CROPS[out.seedSel])out.seedSel=null;
    out.restDays=numbers(out.restDays,'restDays');
    if(out.skills!==undefined){const skills={};for(const k of ['farm','mine','cook','fish']){const s=record(out.skills?.[k],'skills.'+k);skills[k]={lvl:number(s.lvl??1,1,1,10,true,'skills.'+k),xp:number(s.xp??0,0,0,1e8,false,'skills.'+k+'.xp')}}out.skills=skills}
    if(out.friendship!==undefined){const friends={};for(const k of Object.keys(TOWNSFOLK)){const f=record(out.friendship?.[k],'friendship.'+k);friends[k]={hearts:number(f.hearts??1,1,0,5,true,'friendship.'+k),pts:number(f.pts??0,0,0,100000,true,'friendship.'+k+'.pts'),talkedToday:f.talkedToday===true,giftedToday:f.giftedToday===true,personalDone:f.personalDone===true,sceneSeen:number(f.sceneSeen??0,0,0,5,true,'friendship.'+k+'.sceneSeen'),newScene:number(f.newScene??0,0,0,5,true,'friendship.'+k+'.newScene'),lastHeartDay:number(f.lastHeartDay??0,0,0,1e9,true,'friendship.'+k+'.lastHeartDay'),lastReaction:text(f.lastReaction,'',240,'friendship.'+k+'.lastReaction')}}out.friendship=friends}
    if(out.herd!==undefined)out.herd=list(out.herd,'herd').filter(a=>{if(!isRecord(a)||!HTYPES[a.type]){issue('herd.tür');return false}return true}).map((a,i)=>{
      const pen=HPENS[HTYPES[a.type].pen];return {...a,id:typeof a.id==='number'?a.id:i+1,name:text(a.name,HTYPES[a.type].n,40,'herd.ad'),age:number(a.age??0,0,0,1e9,true,'herd.yaş'),love:number(a.love??100,100,0,1000,true,'herd.sevgi'),pc:number(a.pc??0,0,0,100,true,'herd.pc'),fed:a.fed===true,petted:a.petted===true,ready:a.ready===true,x:number(a.x,pen.x0,pen.x0-32,pen.x1+32,false,'herd.x'),y:number(a.y,pen.y0,pen.y0-32,pen.y1+32,false,'herd.y'),f:a.f===-1?-1:1,t:1,tx:undefined,ty:undefined};
    });
    if(out.pet!==undefined){const p=record(out.pet,'pet');out.pet={...defaults.pet,...p,type:['wolf','dragon','fox'].includes(p.type)?p.type:'wolf',name:text(p.name,'Bozkurt',50,'pet.ad'),lvl:number(p.lvl??1,1,1,10000,true,'pet.lvl'),xp:number(p.xp??0,0,0,1e9,false,'pet.xp'),x:number(p.x??0,0,0,2000,false,'pet.x'),y:number(p.y??0,0,0,2000,false,'pet.y'),biteCd:number(Math.max(0,p.biteCd||0),0,0,60,false,'pet.cd')};if(p.rosterId)out.pet.rosterId=key(p.rosterId)}
    if(out.merc!==undefined&&out.merc!==null){const m=record(out.merc,'merc');if(!MERCS.some(v=>v.type===m.type)){out.merc=null;issue('merc.tür')}else{out.merc={...m,icon:MERCS.find(v=>v.type===m.type).icon,hp:number(m.hp??100,100,0,1e6,false,'merc.hp'),mhp:number(m.mhp??100,100,1,1e6,false,'merc.mhp'),x:number(m.x??0,0,0,2000,false,'merc.x'),y:number(m.y??0,0,0,2000,false,'merc.y'),cd:number(Math.max(0,m.cd||0),0,0,60,false,'merc.cd'),healCd:number(Math.max(0,m.healCd||0),0,0,60,false,'merc.healCd'),t:0,f:m.f===-1?-1:1,name:text(m.name,'Yoldaş',60,'merc.ad')}}}
    if(out.orders!==undefined)out.orders=list(out.orders,'orders').filter(isRecord).map((o,i)=>({...o,id:key(o.id,'order-'+i),reqK:key(o.reqK),reqN:number(o.reqN,1,1,10000,true,'orders.adet'),g:number(o.g??0,0,0,1e8,true,'orders.altın'),m:number(o.m??0,0,0,10000,true,'orders.elmas'),rep:number(o.rep??0,0,0,10000,true,'orders.itibar'),from:text(o.from,'Kasabalı',80),reqName:text(o.reqName,'Teslimat',120),desc:text(o.desc,'',400),icon:text(o.icon,'📋',12),done:o.done===true})).filter(o=>o.reqK);
    if(out.farmPlots!==undefined){const seen=new Set();out.farmPlots=list(out.farmPlots,'farmPlots').filter(p=>{
      const valid=isRecord(p)&&Number.isFinite(p.x)&&Number.isFinite(p.y)&&p.x%16===8&&p.y%16===8&&p.x/16>=15&&p.x/16<23&&p.y/16>=25&&p.y/16<34&&!seen.has(p.x+':'+p.y);
      if(!valid){issue('farmPlots.konum');return false}seen.add(p.x+':'+p.y);return true;
    }).map((p,i)=>({...p,id:i,crop:CROPS[p.crop]?p.crop:null,age:number(p.age??(CROPS[p.crop]?.d||0)*(p.stage||0)/3,0,0,1000,false,'farmPlots.yaş'),stage:number(p.stage??0,0,0,3,true,'farmPlots.aşama'),fert:p.fert?1:0,moisture:number(p.moisture??(p.watered?1:0),0,0,2,true,'farmPlots.nem'),watered:p.watered===true,dead:p.dead===true,dry:number(p.dry??0,0,0,100,true,'farmPlots.kuru'),t:0}))}
    if(out.caskItem&&!CASK_RECIPES[out.caskItem]){issue('caskItem');out.caskItem=null;out.caskReady=false}
    if(out.arenaReward!==undefined&&out.arenaReward!==null){const r=record(out.arenaReward,'arenaReward');out.arenaReward={g:number(r.g,0,0,1e8,true,'arenaReward.g'),gm:number(r.gm,0,0,100000,true,'arenaReward.gm'),rep:number(r.rep,0,0,100000,true,'arenaReward.rep'),pts:number(r.pts??0,0,0,10000,true,'arenaReward.pts')}}
    if(out.adventure!==undefined){
      const a=record(out.adventure,'adventure');out.adventure=a;
      a.stats=record(a.stats,'adventure.stats');for(const k in a.stats)if(typeof a.stats[k]!=='boolean')a.stats[k]=number(a.stats[k],0,0,1e12,false,'adventure.stats.'+k);
      a.questChapters=record(a.questChapters,'adventure.questChapters');const chapterFlags={};for(const k of ['2','6','9'])if(a.questChapters[k]===true)chapterFlags[k]=true;a.questChapters=chapterFlags;
      if(a.chapterNotice!==undefined&&a.chapterNotice!==null){const n=record(a.chapterNotice,'adventure.chapterNotice'),index=[2,6,9].includes(Number(n.index))?Number(n.index):null;a.chapterNotice=index===null?null:{index,name:text(n.name,'Tamamlanan Bölüm',80)}}if(a.chapterRewardPending!==undefined&&a.chapterRewardPending!==null){const n=record(a.chapterRewardPending,'adventure.chapterRewardPending'),index=[2,6,9].includes(Number(n.index))?Number(n.index):null;a.chapterRewardPending=index===null?null:{index,name:text(n.name,'Tamamlanan Bölüm',80)}}
      a.seed=number(a.seed??9137,9137,0,4294967295,true,'adventure.seed');a.lootPity=number(a.lootPity??0,0,0,7,true,'adventure.lootPity');a.energy=number(a.energy??100,100,0,100,false,'adventure.energy');a.trackedFriend=TOWNSFOLK[key(a.trackedFriend)]?key(a.trackedFriend):null;if(a.waypoints!==undefined){const waypointRaw=record(a.waypoints,'adventure.waypoints'),waypointClean={};for(const d of WAYPOINTS.defs){const wk=WAYPOINTS.key(d.map,d.name);if(waypointRaw[wk]===true)waypointClean[wk]=true}if(waypointRaw['world:Gölgeköy']===true)waypointClean['world:Gölgeköy']=true;a.waypoints=waypointClean}if(a.navWaypoint!==undefined&&a.navWaypoint!==null){const n=record(a.navWaypoint,'adventure.navWaypoint'),map=['world','frontier','home'].includes(n.map)?n.map:null;a.navWaypoint=map?{map,name:text(n.name,'Hedef',80),x:number(n.x,50,0,1000,false,'nav.x'),y:number(n.y,50,0,1000,false,'nav.y')}:null}a.pinnedGoal=['story','home','social','mine','frontier','elite','bestiary'].includes(key(a.pinnedGoal))?key(a.pinnedGoal):null;a.difficulty=['story','standard','veteran'].includes(a.difficulty)?a.difficulty:'standard';const controls=record(a.controls,'adventure.controls');a.controls={handedness:['right','left'].includes(controls.handedness)?controls.handedness:'right',size:['compact','normal','large'].includes(controls.size)?controls.size:'normal',view:['normal','wide','ultra'].includes(controls.view)?controls.view:'wide',haptics:controls.haptics!==false,labels:controls.labels===true,contrast:controls.contrast===true};
      a.bestiary=record(a.bestiary,'adventure.bestiary');for(const k in a.bestiary){if(!MT[k]){delete a.bestiary[k];continue}const b=record(a.bestiary[k],'bestiary.'+k);a.bestiary[k]={...b,seen:!!b.seen,kills:number(b.kills??0,0,0,1e12,true,'bestiary.'+k)}}
      a.market=record(a.market,'adventure.market');a.market.day=number(a.market.day??out.day??1,1,1,1e9,true,'market.day');a.market.supply=numbers(a.market.supply,'market.supply',-100,100);a.market.bought=numbers(a.market.bought,'market.bought',0,10000);
      if(a.dailyFocus!==undefined){const f=record(a.dailyFocus,'adventure.dailyFocus'),type=['farm','explore','combat'].includes(f.type)?f.type:null;a.dailyFocus={day:number(f.day??out.day??1,1,1,1e9,true,'dailyFocus.day'),type,progress:number(f.progress??0,0,0,5,true,'dailyFocus.progress'),done:f.done===true}}
      if(a.dailyActivity!==undefined){const d=record(a.dailyActivity,'adventure.dailyActivity');a.dailyActivity={day:number(d.day??out.day??1,1,1,1e9,true,'dailyActivity.day'),farm:number(d.farm??0,0,0,999,true,'dailyActivity.farm'),explore:number(d.explore??0,0,0,999,true,'dailyActivity.explore'),combat:number(d.combat??0,0,0,999,true,'dailyActivity.combat')}}
      if(a.dayStats!==undefined){const d=record(a.dayStats,'adventure.dayStats');a.dayStats={day:number(d.day??out.day??1,1,1,1e9,true,'dayStats.day'),startGold:number(d.startGold??out.gold??0,0,0,Number.MAX_SAFE_INTEGER,true,'dayStats.gold'),startLevel:number(d.startLevel??out.lvl??1,1,1,10000,true,'dayStats.level'),farm:number(d.farm??0,0,0,9999,true,'dayStats.farm'),explore:number(d.explore??0,0,0,9999,true,'dayStats.explore'),combat:number(d.combat??0,0,0,9999,true,'dayStats.combat'),fish:number(d.fish??0,0,0,9999,true,'dayStats.fish'),social:number(d.social??0,0,0,9999,true,'dayStats.social')}}
      if(a.worldEventProgress!==undefined){const w=record(a.worldEventProgress,'adventure.worldEventProgress'),ids=['market','harvest','fishing','hunt','mining','social'];a.worldEventProgress={day:number(w.day??out.day??1,1,1,1e9,true,'worldEvent.day'),id:ids.includes(w.id)?w.id:'market',progress:number(w.progress??0,0,0,1000,true,'worldEvent.progress'),done:w.done===true}}
      a.lastExpeditionDay=number(a.lastExpeditionDay??0,0,0,1e9,true,'expedition.lastDay');if(a.expedition!==undefined&&a.expedition!==null){const e=record(a.expedition,'adventure.expedition'),id=['forest','lake','desert','frontier'].includes(e.id)?e.id:null,p=record(e.progress,'expedition.progress'),progress={};for(const k of ['slime','gather','return','fish','lizard','mine','scorpion','boar'])progress[k]=number(p[k]??0,0,0,99,true,'expedition.progress.'+k);a.expedition=id?{id,progress,ready:e.ready===true,abandonConfirm:false}:null}
      if(a.lastDaySummary!==undefined&&a.lastDaySummary!==null){const d=record(a.lastDaySummary,'adventure.lastDaySummary');a.lastDaySummary={day:number(d.day??1,1,1,1e9,true,'daySummary.day'),farm:number(d.farm??0,0,0,9999,true,'daySummary.farm'),explore:number(d.explore??0,0,0,9999,true,'daySummary.explore'),combat:number(d.combat??0,0,0,9999,true,'daySummary.combat'),fish:number(d.fish??0,0,0,9999,true,'daySummary.fish'),social:number(d.social??0,0,0,9999,true,'daySummary.social'),netGold:number(d.netGold??0,0,-Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER,true,'daySummary.netGold'),levels:number(d.levels??0,0,0,10000,true,'daySummary.levels'),focus:['farm','explore','combat'].includes(d.focus)?d.focus:null,focusDone:d.focusDone===true,event:['market','harvest','fishing','hunt','mining','social'].includes(d.event)?d.event:null}}a.dayRecapPending=a.dayRecapPending===true;
      if(a.decisions!==undefined){const dv=record(a.decisions,'adventure.decisions'),clean={};for(const id of ['ilk-karar','ilk-sinav','kiyi-yol','ejder-sinavi']){const v=dv[id];if(!isRecord(v))continue;clean[id]={opt:text(v.opt,'',24,'decision.opt'),day:number(v.day??0,0,0,1e9,true,'decision.day'),label:text(v.label,'',60,'decision.label'),icon:text(v.icon,'⚖️',8,'decision.icon'),line:text(v.line,'',300,'decision.line')}}a.decisions=clean}
      a.notificationMode=a.notificationMode==='quiet'?'quiet':'normal';a.notifications=list(a.notifications,'adventure.notifications').filter(isRecord).slice(-40).map((n,i)=>({id:number(n.id??i,i,0,Number.MAX_SAFE_INTEGER,true,'notification.id'),day:number(n.day??out.day??1,1,1,1e9,true,'notification.day'),type:text(n.type,'info',30,'notification.type'),icon:text(n.icon,'🔔',16,'notification.icon'),title:text(n.title,'Bildirim',100,'notification.title'),text:text(n.text,'',500,'notification.text'),read:n.read===true}));
      if(a.featureUnlocks!==undefined){const ids=['build','character','market','social','fishing','expeditions','titles','bestiary'],u=record(a.featureUnlocks,'adventure.featureUnlocks'),clean={};for(const k of ids)if(u[k]===true)clean[k]=true;a.featureUnlocks=clean;const fresh=record(a.featureFresh,'adventure.featureFresh'),freshClean={};for(const k of ids)if(fresh[k]===true&&clean[k])freshClean[k]=true;a.featureFresh=freshClean;a.featureQueue=list(a.featureQueue,'adventure.featureQueue').filter(k=>ids.includes(k)&&clean[k]).slice(0,ids.length)}
      a.taming=record(a.taming,'taming');for(const k in a.taming){const t=record(a.taming[k],'taming.'+k);a.taming[k]={trust:number(t.trust??0,0,0,3,true,'taming.trust'),lastDay:number(t.lastDay??0,0,0,1e9,true,'taming.day')}}
      a.captured=record(a.captured,'captured');for(const k in a.captured)if(!key(a.captured[k]))delete a.captured[k];
      a.roster=list(a.roster,'roster').filter(r=>isRecord(r)&&BOND.species[r.type]).map((r,i)=>({...r,id:key(r.id,'bond-'+i),name:text(r.name,BOND.species[r.type].name,50),lvl:number(r.lvl??1,1,1,10000,true,'roster.lvl'),xp:number(r.xp??0,0,0,1e9,false,'roster.xp')}));
      const owned=new Set(a.roster.map(r=>r.id));for(const k in a.captured)if(!owned.has(a.captured[k])){delete a.captured[k];issue('captured.eşleşme')}
      a.buildings=list(a.buildings,'buildings');const ids=new Set();a.buildings=a.buildings.filter(b=>{
        if(!isRecord(b)||!BUILD.defs[b.kind]||!Number.isInteger(b.gx)||!Number.isInteger(b.gy)||b.gx<0||b.gy<0||!BUILD.land(b.gx,b.gy)||!BUILD.land(b.gx+BUILD.defs[b.kind].w-1,b.gy+BUILD.defs[b.kind].h-1)){issue('buildings.yapı');if(b?.items)out.pendingRewards=[...(out.pendingRewards||[]),...items(b.items,'buildings.kurtarılan')];return false}return true;
      }).map((b,i)=>{
        let id=key(b.id,'b-'+i);while(ids.has(id))id+='x';ids.add(id);
        const d=BUILD.defs[b.kind],candidate=Object.hasOwn(BUILD_CONFIG.materials,b.material)?b.material:d.defaultMaterial||'wood';
        const material=d.part&&!d.materials.includes(candidate)?d.defaultMaterial:candidate,mat=BUILD_CONFIG.materials[material]||BUILD_CONFIG.materials.wood;
        const clean={id,kind:b.kind,gx:b.gx,gy:b.gy,material,level:number(b.level??0,0,0,3,true,'buildings.level'),rotation:number(b.rotation??0,0,0,3,true,'buildings.rotation'),hp:number(b.hp??mat.durability,mat.durability,0,mat.durability,true,'buildings.hp'),items:items(b.items,'buildings.depo')};
        if(b.kind==='door')clean.open=b.open===true;return clean;
      });
      a.nextBuildId=number(a.nextBuildId??1,1,1,1e9,true,'buildings.sıra');
      if(a.legacyPet!==undefined){const p=record(a.legacyPet,'legacyPet');a.legacyPet={lvl:number(p.lvl??1,1,1,10000,true,'legacyPet.lvl'),xp:number(p.xp??0,0,0,1e9,false,'legacyPet.xp')}}
      a.home=record(a.home,'adventure.home');
      const hRaw=a.home;
      a.home.cleared=list(hRaw.cleared,'home.cleared').filter(v=>key(v));
      a.home.fruitDays=numbers(hRaw.fruitDays,'home.fruitDays');
      a.home.ores=record(hRaw.ores,'home.ores');for(const k in a.home.ores){const r=record(a.home.ores[k],'home.ore');a.home.ores[k]={readyDay:number(r.readyDay??0,0,0,1e9,true,'home.ore.day')}}
      a.home.beds=number(hRaw.beds??1,1,1,3,true,'home.beds');
      a.home.soilLv=number(hRaw.soilLv??0,0,0,3,true,'home.soilLv');
      a.home.sprinklerLv=number(hRaw.sprinklerLv??(out.hasSprinkler?1:0),0,0,3,true,'home.sprinklerLv');
      a.home.greenhouse=hRaw.greenhouse===true;
      a.home.orchard=Array.isArray(hRaw.orchard)?[...new Set([0,1,2,3,...hRaw.orchard.filter(n=>Number.isInteger(n)&&n>=0&&n<8)])]:[0,1,2,3];
      a.home.totalHarvests=number(hRaw.totalHarvests??0,0,0,1e9,true,'home.totalHarvests');
      a.home.milestoneClaimed=number(hRaw.milestoneClaimed??0,0,0,1e9,true,'home.milestoneClaimed');
      a.home.contractsDay=number(hRaw.contractsDay??0,0,0,1e9,true,'home.contractsDay');
      a.home.contractsDone=Array.isArray(hRaw.contractsDone)?hRaw.contractsDone.filter(n=>Number.isInteger(n)&&n>=0&&n<3):[];
      if(hRaw.lastFarmReport&&typeof hRaw.lastFarmReport==='object'){const r=hRaw.lastFarmReport;a.home.lastFarmReport={day:number(r.day??out.day??1,1,1,1e9,true,'farmReport.day'),grew:number(r.grew??0,0,0,1000,true,'farmReport.grew'),ripe:number(r.ripe??0,0,0,1000,true,'farmReport.ripe'),died:number(r.died??0,0,0,1000,true,'farmReport.died'),autoWater:r.autoWater===true,weather:text(r.weather,'clear',20,'farmReport.weather')}}
      a.caves=record(a.caves,'caves');a.caves.day=number(a.caves.day??out.day??1,1,1,1e9,true,'caves.day');a.caves.floors=record(a.caves.floors,'caves.floors');
      for(const k in a.caves.floors){if(!/^([1-9]|[1-4][0-9]|50)$/.test(k)){delete a.caves.floors[k];continue}const f=record(a.caves.floors[k],'caves.floor');f.resources=record(f.resources,'caves.resources');f.mobs=record(f.mobs,'caves.mobs');
        for(const id in f.resources){const r=record(f.resources[id],'caves.resource');f.resources[id]={mined:!!r.mined,hp:number(r.hp??0,0,0,1e9,false,'caves.resource.hp')}}
        for(const id in f.mobs){const m=record(f.mobs[id],'caves.mob');f.mobs[id]={dead:!!m.dead,hp:number(m.hp??1,1,0,1e12,false,'caves.mob.hp')}}
        f.chests=list(f.chests,'caves.chests').filter(v=>key(v));f.traps=list(f.traps,'caves.traps').filter(isRecord).map(t=>({id:key(t.id),disarmed:!!t.disarmed}));f.secret=!!f.secret;f.ladder=!!f.ladder;a.caves.floors[k]=f;
      }
      a.npcLife=record(a.npcLife,'adventure.npcLife');const npcLife={};
      for(const [name,j]of Object.entries(TOWN_LIFE.JOBS)){
        const id=j.id||name,n=record(a.npcLife[id],'npcLife.'+id),base=NPC_NEEDS_CONFIG.initial;
        const memory=list(n.memory,'npcLife.memory').filter(isRecord).slice(0,NPC_NEEDS_CONFIG.memoryLimit).map((m,i)=>({kind:['talk','gift','meal','rest','shelter'].includes(m.kind)?m.kind:'talk',day:number(m.day??out.day??1,1,1,1e9,true,'npcLife.memory.day')}));
        npcLife[id]={hunger:number(n.hunger??base.hunger,base.hunger,0,100,false,'npcLife.hunger'),fatigue:number(n.fatigue??base.fatigue,base.fatigue,0,100,false,'npcLife.fatigue'),safety:number(n.safety??base.safety,base.safety,0,100,false,'npcLife.safety'),mood:number(n.mood??base.mood,base.mood,0,100,false,'npcLife.mood'),mealHours:number(n.mealHours??0,0,0,NPC_NEEDS_CONFIG.actions.mealHours,false,'npcLife.mealHours'),restHours:number(n.restHours??0,0,0,NPC_NEEDS_CONFIG.actions.restHours,false,'npcLife.restHours'),lastMealDay:number(n.lastMealDay??0,0,0,1e9,true,'npcLife.lastMealDay'),memory};
      }
      a.npcLife=npcLife;
      a.title=key(a.title,'traveler');
      if(a.dragonVictory){const v=record(a.dragonVictory,'dragonVictory');a.dragonVictory={v:1,verified:v.verified===true&&['dragon','quest-history'].includes(v.source),source:['dragon','quest-history','legacy-credit','none'].includes(v.source)?v.source:'none',day:v.day===null?null:number(v.day??0,0,0,1e9,true,'dragonVictory.day')}}
      if(a.intro){const i=record(a.intro,'intro');a.intro={v:1,enabled:i.enabled===true,legacy:i.legacy===true,skipped:i.skipped===true,recoveryUsed:i.recoveryUsed===true,chestAid:i.chestAid===true,completed:i.completed===true,events:record(i.events,'intro.events')};for(const k in a.intro.events)a.intro.events[k]=number(a.intro.events[k],0,0,1e6,true,'intro.events.'+k)}
      if(a.story!==undefined){const s=record(a.story,'story'),raw=record(s.beats,'story.beats'),beats={};for(const k of ['arrive','purse','home','farm','cook','forest','chest','rest','grove','oasis','pass','arena','finale','dawn','ch2','ch3','ch4'])if(raw[k]===true)beats[k]=true;let name=text(s.name,'',18,'story.name').trim();if(name.length<2)name='';a.story={v:2,closed:s.closed===true,closedDay:number(s.closedDay??0,0,0,1e9,true,'story.day'),name,prologue:s.prologue===true,beats}}
    }
    if(out.life!==undefined){const l=record(out.life,'life'),d=record(l.defeat,'life.defeat');out.life={v:1,deferred:l.deferred===true,defeats:number(l.defeats??0,0,0,1e9,true,'life.defeats'),defeat:l.defeat?{id:number(d.id??1,1,1,1e9,true,'life.id'),loss:number(d.loss??0,0,0,Number.MAX_SAFE_INTEGER,true,'life.loss'),day:number(d.day??1,1,1,1e9,true,'life.day'),pending:d.pending===true,wake:d.wake&&(d.wake.kind==='lake'||d.wake.kind==='oasis')?{kind:d.wake.kind}:null}:null}}
    if(out.talentQueue!==undefined)out.talentQueue=list(out.talentQueue,'talentQueue').filter(isRecord).map((t,i)=>({id:key(t.id,'talent-'+i),level:number(t.level??3,3,1,1000000,true,'talent.level'),choices:list(t.choices,'talent.choices').filter(k=>['a','h','c','s','v'].includes(k)).slice(0,3)})).filter(t=>t.choices.length>0);
    if(out.session!==undefined){
      const s=record(out.session,'session');if(s.map==='arena'){s.map='home';s.x=14*16;s.y=25*16}if(!maps.has(s.map)){issue('session.map');s.map='home'}
      out.session={v:1,map:s.map,x:number(s.x,224,0,2000,false,'session.x'),y:number(s.y,400,0,2000,false,'session.y'),f:number(s.f??0,0,0,3,true,'session.f'),hp:number(s.hp,100,0,1e12,false,'session.hp'),mp:number(s.mp,50,0,1e12,false,'session.mp'),shld:number(s.shld??0,0,0,1e12,false,'session.shld'),dead:s.dead===true||s.hp===0,buffs:numbers(s.buffs,'session.buffs',0,86400),cooldowns:numbers(s.cooldowns,'session.cooldowns',0,60),combat:record(s.combat,'session.combat'),loot:[]};
      out.session.loot=list(s.loot,'session.loot').filter(isRecord).map(l=>({t:['g','gem','p','i'].includes(l.t)?l.t:'i',x:number(l.x,224,0,2000,false,'loot.x'),y:number(l.y,400,0,2000,false,'loot.y'),v:l.t==='i'?item(l.v,'loot.item'):number(l.v,1,0,1e12,false,'loot.value'),vy:0,z:0,a:.5})).filter(l=>l.v!==null);
      for(const id in out.session.combat){if(!['world','frontier'].includes(id)){delete out.session.combat[id];continue}const rows=record(out.session.combat[id],'combat.'+id);for(const k in rows){const r=record(rows[k],'combat.mob');if(r.v===2&&MT[r.k]){const d=MT[r.k];rows[k]={v:2,k:r.k,x:number(r.x,800,0,2000,false,'combat.x'),y:number(r.y,800,0,2000,false,'combat.y'),hx:number(r.hx??r.x,800,0,2000,false,'combat.hx'),hy:number(r.hy??r.y,800,0,2000,false,'combat.hy'),lv:number(r.lv??d.lv,d.lv,1,1000000,true,'combat.lv'),mhp:number(r.mhp??d.hp,d.hp,1,1e12,false,'combat.mhp'),hp:number(r.hp??d.hp,d.hp,0,1e12,false,'combat.hp'),a:number(r.a??d.a,d.a,0,1e9,false,'combat.a'),el:r.el===true,dead:r.dead===true,rt:number(r.rt??0,0,0,180,false,'combat.rt'),f:r.f===-1?-1:1,p2:r.p2===true,variant:['swift','armored','volatile','treasure'].includes(r.variant)?r.variant:null}}else rows[k]={dead:r.dead===true,hp:number(r.hp??1,1,0,1,false,'combat.hp'),rt:number(r.rt??0,0,0,180,false,'combat.rt')}}out.session.combat[id]=rows}
    }
    return {clean:out,badType:[...issues],unknown};
  }
  function parse(raw){if(typeof raw!=='string'||new TextEncoder().encode(raw).length>MAX_BYTES)throw new Error('Kayıt boyutu güvenli sınırı aşıyor.');const parsed=JSON.parse(raw);return normalize(parsed)}
  function assertRuntime(){
    for(const k of ['gold','gems','pots','lvl','day'])if(!Number.isSafeInteger(P[k]))throw new Error('Tam sayı sınırı aşıldı: '+k);
    for(const k of ['lvl','xp','gold','gems','pots','hp','mp','shld','day'])if(!Number.isFinite(P[k])||P[k]<0)throw new Error('Geçersiz oyun sayısı: '+k);
    if(P.lvl<1||P.day<1||!Array.isArray(P.inv)||!Array.isArray(P.storage)||!Array.isArray(P.pendingRewards))throw new Error('Oyuncu durumu güvenli biçimde kaydedilemiyor.');
  }
  return {normalize,parse,assertRuntime,MAX_BYTES};
})();
/* @inline:foundation-codec:end */

