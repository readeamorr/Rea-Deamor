'use strict';
(()=>{
const $=i=>document.getElementById(i);
const rnd=(a,b)=>a+Math.random()*(b-a),ri=(a,b)=>Math.floor(rnd(a,b+.999)),pick=a=>a[ri(0,a.length-1)],cl=(v,a,b)=>Math.max(a,Math.min(b,v));
const H=(x,y)=>{let h=Math.imul(x,374761393)^Math.imul(y,668265263);h=Math.imul(h^(h>>>13),1274126177);return((h^(h>>>16))>>>0)/4294967295};
const vn=(x,y)=>{const ix=Math.floor(x),iy=Math.floor(y),fx=x-ix,fy=y-iy,u=fx*fx*(3-2*fx),v=fy*fy*(3-2*fy);return(H(ix,iy)*(1-u)+H(ix+1,iy)*u)*(1-v)+(H(ix,iy+1)*(1-u)+H(ix+1,iy+1)*u)*v};

/* ===== SES SENTEZLEYİCİ ===== */
let AC=null,mute=false,sfxWarned=false;
let volMusic = 0.8, volSfx = 0.9, shakeSetting = 'normal';

const sfx=(f,d,t,v)=>{
  if(!AC||mute)return;
  try{
    const o=AC.createOscillator(),g=AC.createGain();
    o.type=t||'square';o.frequency.value=f;
    const finalV = (v||.03) * volSfx;
    g.gain.setValueAtTime(finalV,AC.currentTime);
    g.gain.exponentialRampToValueAtTime(.0001,AC.currentTime+d);
    o.connect(g);g.connect(AC.destination);
    o.start();o.stop(AC.currentTime+d);
  }catch(e){if(!sfxWarned){sfxWarned=true;console.warn('Ses efekti çalınamadı.',e)}}
};

function playChord(notes,duration,type,vol){
  if(!AC||mute)return;
  notes.forEach((freq,idx)=>{
    setTimeout(()=>sfx(freq,duration,type||'triangle',vol||.02),idx*65);
  });
}

